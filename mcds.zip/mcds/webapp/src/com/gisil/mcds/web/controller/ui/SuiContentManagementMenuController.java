package com.gisil.mcds.web.controller.ui;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gisil.mcds.web.controller.AbstractJspController;
public class SuiContentManagementMenuController extends AbstractJspController {
	
	public static final String PAGE_PATH = "suiContentManagementMenu.jsp";
	
	public SuiContentManagementMenuController(HttpServletRequest aRequest, HttpServletResponse aResponse)
	{
		super(aRequest,aResponse);		
		
	}

}
