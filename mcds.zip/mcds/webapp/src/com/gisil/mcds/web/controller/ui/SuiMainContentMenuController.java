package com.gisil.mcds.web.controller.ui;
 import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gisil.mcds.web.controller.AbstractJspController;;
public class SuiMainContentMenuController extends AbstractJspController {

	public static final String _pagePath = "icds/jsp/ui/suiMainContentMenu.jsp";
	
	public SuiMainContentMenuController(HttpServletRequest aRequest,HttpServletResponse aResponse)
	{
		super(aRequest,aResponse);
	}
	
}
