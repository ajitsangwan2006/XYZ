
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1=new String("ajit");
		String str2="ajit";
		if(str1.equals(str2))
			System.out.println(true);
		if(str1==str2)
			System.out.println(true);

	}

}
