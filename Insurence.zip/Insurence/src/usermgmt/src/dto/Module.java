package usermgmt.src.dto;

import java.math.BigDecimal;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class Module extends ModelImpl implements java.io.Serializable {

    private Integer moduleId;

    private String moduleDescription;

    private Integer moduleStatus = new Integer(0);

    private BigDecimal type1TransactionFee;

    private BigDecimal type2TransactionFee;

    private BigDecimal subscriptionFee;

    private BigDecimal signOnFee;

    private BigDecimal additionalUserFee;

    private BigDecimal support24X7Fee;

    private BigDecimal trainingFee;

    private BigDecimal cappedAmount;

    private String deploymentUrl;
    
    private Integer adminPrivilege;
    
    private Integer enduserPrivilege;

    public Module() {
    }

    public BigDecimal getAdditionalUserFee() {
        return additionalUserFee;
    }

    public void setAdditionalUserFee(BigDecimal additionalUserFee) {
        this.additionalUserFee = additionalUserFee;
    }

    public BigDecimal getSupport24X7Fee() {
        return support24X7Fee;
    }

    public void setSupport24X7Fee(BigDecimal maintenanceFee) {
        this.support24X7Fee = maintenanceFee;
    }

    public String getModuleDescription() {
        return moduleDescription;
    }

    public void setModuleDescription(String moduleDescription) {
        this.moduleDescription = moduleDescription;
    }

    public Integer getModuleId() {
        return moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public Integer getModuleStatus() {
        return moduleStatus;
    }

    public void setModuleStatus(Integer moduleStatus) {
        this.moduleStatus = moduleStatus;
    }

    public BigDecimal getSignOnFee() {
        return signOnFee;
    }

    public void setSignOnFee(BigDecimal signOnFee) {
        this.signOnFee = signOnFee;
    }

    public BigDecimal getSubscriptionFee() {
        return subscriptionFee;
    }

    public void setSubscriptionFee(BigDecimal subscriptionFee) {
        this.subscriptionFee = subscriptionFee;
    }

    public BigDecimal getTrainingFee() {
        return trainingFee;
    }

    public void setTrainingFee(BigDecimal trainingFee) {
        this.trainingFee = trainingFee;
    }

    public BigDecimal getType1TransactionFee() {
        return type1TransactionFee;
    }

    public void setType1TransactionFee(BigDecimal type1TransactionFee) {
        this.type1TransactionFee = type1TransactionFee;
    }

    public BigDecimal getType2TransactionFee() {
        return type2TransactionFee;
    }

    public void setType2TransactionFee(BigDecimal type2TransactionFee) {
        this.type2TransactionFee = type2TransactionFee;
    }

    public BigDecimal getCappedAmount() {
        return cappedAmount;
    }

    public void setCappedAmount(BigDecimal cappedAmount) {
        this.cappedAmount = cappedAmount;
    }

    public String getDeploymentUrl() {
        return deploymentUrl;
    }

    public void setDeploymentUrl(String deploymentUrl) {
        this.deploymentUrl = deploymentUrl;
    }

	public Integer getAdminPrivilege() {
		return adminPrivilege;
	}
	
	public void setAdminPrivilege(Integer adminPrivilege) {
		this.adminPrivilege = adminPrivilege;
	}
	
	public Integer getEnduserPrivilege() {
		return enduserPrivilege;
	}
	
	public void setEnduserPrivilege(Integer enduserPrivilege) {
		this.enduserPrivilege = enduserPrivilege;
	}
	
    public ValidationErrors validate() {
        return null;
    }
}
