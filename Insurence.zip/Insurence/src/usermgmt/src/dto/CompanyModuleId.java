package usermgmt.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class CompanyModuleId extends ModelImpl implements java.io.Serializable {

    private Integer moduleId;

    private String companyId;

    public CompanyModuleId() {
    }

    public CompanyModuleId(Integer moduleId, String companyId) {
        this.moduleId = moduleId;
        this.companyId = companyId;
    }

    public Integer getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public String getCompanyId() {
        return this.companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public boolean equals(Object other) {
        if ((this == other))
            return true;
        if ((other == null))
            return false;
        if (!(other instanceof CompanyModuleId))
            return false;
        CompanyModuleId castOther = (CompanyModuleId) other;

        return (this.getModuleId() == castOther.getModuleId()) && ((this.getCompanyId() == castOther.getCompanyId()) || (this.getCompanyId() != null && castOther.getCompanyId() != null && this.getCompanyId().equals(castOther.getCompanyId())));
    }

    public int hashCode() {
        int result = 17;
        result = 37 * result + (getModuleId() == null ? 0 : this.getModuleId().hashCode());
        result = 37 * result + (getCompanyId() == null ? 0 : this.getCompanyId().hashCode());
        return result;
    }

    public ValidationErrors validate() {
        return null;
    }

}
