package usermgmt.src.dto;

import java.util.*;
import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class Company extends ModelImpl implements java.io.Serializable {

    private String companyId;

    private String companyName;

    private Integer securityRole;

    private String title;

    private String firstName;

    private String lastName;

    private String otherName;

    private String address1;

    private String address2;

    private String city;

    private String state;

    private String postalCode;

    private String country;

    private String emailId;

    private String phone;

    private String fax;

    private Date setupDate;

    private Date expiry;

    private Date applicableDate;

    private Integer status;

    private String paymentMethod;

    private String billingFreuquency;

    private String billingMode;

    private String supportType;

    private String paymentReminder;

    private Date lastUpdateDate;

    private String lastUpdatedBy;

    private String registeredBy;

    private String bankAccountName;

    private String bankAccountNo;

    private String bsbNo;

    private String documentName;

    private byte[] documentContent;

    private String feeOverrideComments;

    private String changeRequestUserId;

    private String changeApproveUserId;

    private CompanyModule[] companyModule;

    private Set companyModules = new HashSet(0);

    private String fromName;

    private String abnNo;

    public Company() {
    }

    public String getCompanyId() {
        return this.companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public CompanyModule[] getCompanyModule() {
        return companyModule;
    }

    public void setCompanyModule(CompanyModule[] companyModule) {
        this.companyModule = companyModule;
    }

    public String getCompanyName() {
        return this.companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress1() {
        return this.address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return this.address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostalCode() {
        return this.postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEmailId() {
        return this.emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return this.fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Date getSetupDate() {
        return this.setupDate;
    }

    public void setSetupDate(Date setupDate) {
        this.setupDate = setupDate;
    }

    public Date getExpiry() {
        return this.expiry;
    }

    public void setExpiry(Date expiry) {
        this.expiry = expiry;
    }

    public String getOtherName() {
        return otherName;
    }

    public void setOtherName(String otherName) {
        this.otherName = otherName;
    }

    public Integer getStatus() {
        return this.status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Set getCompanyModules() {
        return this.companyModules;
    }

    public void setCompanyModules(Set companyModules) {
        this.companyModules = companyModules;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getBillingFreuquency() {
        return this.billingFreuquency;
    }

    public void setBillingFreuquency(String billingFreuquency) {
        this.billingFreuquency = billingFreuquency;
    }

    public String getBillingMode() {
        return this.billingMode;
    }

    public void setBillingMode(String billingMode) {
        this.billingMode = billingMode;
    }

    public String getPaymentReminder() {
        return this.paymentReminder;
    }

    public void setPaymentReminder(String paymentReminder) {
        this.paymentReminder = paymentReminder;
    }

    public Date getLastUpdateDate() {
        return this.lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getLastUpdatedBy() {
        return this.lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getRegisteredBy() {
        return this.registeredBy;
    }

    public void setRegisteredBy(String registeredBy) {
        this.registeredBy = registeredBy;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public String getBsbNo() {
        return bsbNo;
    }

    public void setBsbNo(String bsbNo) {
        this.bsbNo = bsbNo;
    }

    public String getChangeApproveUserId() {
        return changeApproveUserId;
    }

    public void setChangeApproveUserId(String changeApproveUserId) {
        this.changeApproveUserId = changeApproveUserId;
    }

    public String getChangeRequestUserId() {
        return changeRequestUserId;
    }

    public void setChangeRequestUserId(String changeRequestUserId) {
        this.changeRequestUserId = changeRequestUserId;
    }

    public byte[] getDocumentContent() {
        return documentContent;
    }

    public void setDocumentContent(byte[] documentContent) {
        this.documentContent = documentContent;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getFeeOverrideComments() {
        return feeOverrideComments;
    }

    public void setFeeOverrideComments(String feeOverrideComments) {
        this.feeOverrideComments = feeOverrideComments;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public void setBankAccountName(String bankAccountName) {
        this.bankAccountName = bankAccountName;
    }

    public String getSupportType() {
        return supportType;
    }

    public void setSupportType(String supportType) {
        this.supportType = supportType;
    }

    public String getAbnNo() {
        return abnNo;
    }

    public void setAbnNo(String abnNo) {
        this.abnNo = abnNo;
    }

    public Date getApplicableDate() {
        return applicableDate;
    }

    public void setApplicableDate(Date applicableDate) {
        this.applicableDate = applicableDate;
    }

    public Integer getSecurityRole() {
        return securityRole;
    }

    public void setSecurityRole(Integer securityRole) {
        this.securityRole = securityRole;
    }

    public void registerJavaScriptValidation() {
    }

    public ValidationErrors validate() {
        return null;
    }
}
