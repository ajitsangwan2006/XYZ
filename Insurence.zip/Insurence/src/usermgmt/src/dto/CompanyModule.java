package usermgmt.src.dto;

import java.math.BigDecimal;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class CompanyModule extends ModelImpl implements java.io.Serializable {

    private CompanyModuleId id;

    private int status;

    private BigDecimal subscriptionFee;

    private BigDecimal type1TransactionFee;

    private BigDecimal type2TransactionFee;

    private BigDecimal signOnFee;

    private BigDecimal additionalUserFee;

    private BigDecimal support24X7Fee;

    private BigDecimal trainingFee;

    private BigDecimal cappedAmount;

    private Module module;

    public CompanyModule() {
        this.id = new CompanyModuleId();
    }

    public CompanyModule(CompanyModuleId id, int status) {
        this.id = id;
        this.status = status;
    }

    public CompanyModuleId getId() {
        return this.id;
    }

    public void setId(CompanyModuleId id) {
        this.id = id;
    }

    public int getStatus() {
        return this.status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public BigDecimal getAdditionalUserFee() {
        return additionalUserFee;
    }

    public void setAdditionalUserFee(BigDecimal additionalUserFee) {
        this.additionalUserFee = additionalUserFee;
    }

    public BigDecimal getCappedAmount() {
        return cappedAmount;
    }

    public void setCappedAmount(BigDecimal cappedAmount) {
        this.cappedAmount = cappedAmount;
    }

    public BigDecimal getSignOnFee() {
        return signOnFee;
    }

    public void setSignOnFee(BigDecimal signOnFee) {
        this.signOnFee = signOnFee;
    }

    public BigDecimal getSubscriptionFee() {
        return subscriptionFee;
    }

    public void setSubscriptionFee(BigDecimal subscriptionFee) {
        this.subscriptionFee = subscriptionFee;
    }

    public BigDecimal getSupport24X7Fee() {
        return support24X7Fee;
    }

    public void setSupport24X7Fee(BigDecimal support24X7Fee) {
        this.support24X7Fee = support24X7Fee;
    }

    public BigDecimal getTrainingFee() {
        return trainingFee;
    }

    public void setTrainingFee(BigDecimal trainingFee) {
        this.trainingFee = trainingFee;
    }

    public BigDecimal getType1TransactionFee() {
        return type1TransactionFee;
    }

    public void setType1TransactionFee(BigDecimal type1TransactionFee) {
        this.type1TransactionFee = type1TransactionFee;
    }

    public BigDecimal getType2TransactionFee() {
        return type2TransactionFee;
    }

    public void setType2TransactionFee(BigDecimal type2TransactionFee) {
        this.type2TransactionFee = type2TransactionFee;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }

    public ValidationErrors validate() {
        return null;
    }
}
