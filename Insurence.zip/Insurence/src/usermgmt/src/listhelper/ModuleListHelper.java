package usermgmt.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ModuleListHelper extends ListHelperImpl {

	private Integer moduleId;
	
	private Integer adminPrivilege;
	
	private Integer enduserPrivilege;
	

	public Integer getAdminPrivilege() {
		return adminPrivilege;
	}
	public void setAdminPrivilege(Integer adminPrivilege) {
		this.adminPrivilege = adminPrivilege;
	}
	public Integer getEnduserPrivilege() {
		return enduserPrivilege;
	}
	public void setEnduserPrivilege(Integer enduserPrivilege) {
		this.enduserPrivilege = enduserPrivilege;
	}
	public Integer getModuleId() {
		return moduleId;
	}
	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}
}
