package usermgmt.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;


public class PersonListHelper extends ListHelperImpl {

    private String siteId;

    private String userId;

    private Long uniqueUserRef;

    private String firstName;

    private String emailId;

    private String country;

    private Integer status;

    private Character userType;
    
    private String regionCode;
    
    private String securityRole;
    
    private String communicationEmailId;
    
    private String alertEmailId;
    
    private String digitalSignatureFlag;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    } 

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getUniqueUserRef() {
        return uniqueUserRef;
    }

    public void setUniqueUserRef(Long uniqueUserRef) {
        this.uniqueUserRef = uniqueUserRef;
    }
    
	public String getRegionCode() {
		return regionCode;
	}
	
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	
	public Integer getStatus() {
		return status;
	}
	
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	public Character getUserType() {
		return userType;
	}
	
	public void setUserType(Character userType) {
		this.userType = userType;
	}
	
    public String getAlertEmailId() {
        return alertEmailId;
    }
    
    public void setAlertEmailId(String alertEmailId) {
        this.alertEmailId = alertEmailId;
    }
    
    public String getCommunicationEmailId() {
        return communicationEmailId;
    }
    
    public void setCommunicationEmailId(String communicationEmailId) {
        this.communicationEmailId = communicationEmailId;
    }
}
