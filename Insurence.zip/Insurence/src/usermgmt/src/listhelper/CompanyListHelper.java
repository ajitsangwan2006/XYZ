package usermgmt.src.listhelper;

import java.util.Date;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class CompanyListHelper extends ListHelperImpl {

    private String companyId;

    private String companyName;

    private String country;

    private Date expiry;
    
    private Date expiryTo;

    private String status;
    
    private String dateBoundry;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Date getExpiry() {
        return expiry;
    }

    public void setExpiry(Date expiry) {
        this.expiry = expiry;
    }

    public String getCountry() {
        return country;
    }
    
    public void setCountry(String country) {
        this.country = country;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Date getExpiryTo() {
        return expiryTo;
    }
    
    public void setExpiryTo(Date expiryTo) {
        this.expiryTo = expiryTo;
    }
    
    public String getDateBoundry() {
        return dateBoundry;
    }
    
    public void setDateBoundry(String dateBoundry) {
        this.dateBoundry = dateBoundry;
    }
}