package usermgmt.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class CompanyModuleListHelper extends ListHelperImpl {

	private int status;
	
	private int moduleId;

	private String companyId;
    

	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public int getModuleId() {
		return moduleId;
	}
	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
