package usermgmt.src.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import usermgmt.src.dao.interfaces.ModuleDAO;
import usermgmt.src.dto.Module;
import usermgmt.src.listhelper.ModuleListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public class ModuleDAOImpl extends DAOImpl implements ModuleDAO {

    public PageDAO getList(ModuleListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            session = getSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session);
            int totalRecords = getTotalRecords(criteriaForCounter);
            log("getUserList-totalRecords: " + totalRecords);
            Criteria criteriaForList = buildCriteria(listHelper, session);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);            
        } finally {
            closeSession(session);
        }
    }

    public Module getModule(Integer moduleId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        Module module = null;
        try {
            session = getHibernateSession();
            module = (Module) session.get(Module.class, moduleId);
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return module;
    }

    public Module getByDescription(String moduleDescription) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(Module.class);
            criteria.add(Restrictions.like("moduleDescription", moduleDescription));
            List list = criteria.list();
            if (list.size() > 0) {
                return (Module) list.get(0);
            }
            return null;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }
    private Criteria buildCriteria(ModuleListHelper listHelper, Session session) {
        Criteria criteria = session.createCriteria(Module.class);
        if (listHelper != null) {
        	if (listHelper.getAdminPrivilege() != null) {
                criteria.add(Restrictions.eq("adminPrivilege", listHelper.getAdminPrivilege()));
            }        	
        	if(listHelper.getEnduserPrivilege() != null){
        		criteria.add(Restrictions.eq("enduserPrivilege", listHelper.getEnduserPrivilege()));
        	}
        }
        return criteria;
    }
}
