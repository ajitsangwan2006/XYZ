package usermgmt.src.dao.impl;

import java.util.List;
import org.hibernate.Query;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import usermgmt.src.dao.interfaces.PersonDAO;
import usermgmt.src.dto.Person;
import usermgmt.src.listhelper.PersonListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;

public class PersonDAOImpl extends DAOImpl implements PersonDAO {

    public PageDAO getPersonList(PersonListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);
            log("getUserList-totalRecords: " + totalRecords);

            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public Person getPerson(String siteId, String userId) throws DAOException, InvalidDAOArgumentException {
        if (GenericValidator.isBlankOrNull(siteId)) {
            throw new InvalidDAOArgumentException("SiteId can not be NULL.");
        }
        if (GenericValidator.isBlankOrNull(userId)) {
            throw new InvalidDAOArgumentException("Id can not be NULL.");
        }
        PersonListHelper criteria = new PersonListHelper();
        criteria.setSiteId(siteId);
        criteria.setUserId(userId);
        System.err.println("-----user id in get person method---"+criteria.getUserId());
        List list = getPersonList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (Person) list.get(0);
        } else {
            return null;
        }
    }

    public Person getPerson(String userId) throws DAOException, InvalidDAOArgumentException {
    	if (GenericValidator.isBlankOrNull(userId)) {
            throw new InvalidDAOArgumentException("Id can not be NULL.");
        }
        PersonListHelper criteria = new PersonListHelper();
        criteria.setUserId(userId);
        List list = getPersonList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (Person) list.get(0);
        } else {
            return null;
        }
    }

    public Person getPerson(Long uniqueUserRef) throws DAOException, InvalidDAOArgumentException {
        if (uniqueUserRef == null) {
            throw new InvalidDAOArgumentException("Unique User Ref can not be NULL.");
        }
        PersonListHelper criteria = new PersonListHelper();
        criteria.setUniqueUserRef(uniqueUserRef);
        List list = getPersonList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (Person) list.get(0);
        } else {
            return null;
        }
    }

    public Person createPerson(Person person) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        Session session = null;
        if (person == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        Person isUsersExist = getPerson(person.getSiteId(), person.getUserId());
        if (isUsersExist != null) {
        	 ValidationError error = new ValidationError();
      	     error.setPropertyName("userId");
             error.setErrorCode("OZA-80003-19");
             error.setErrorMessage("User with Id ["+person.getUserId().toUpperCase()+"] already exist in the system, please enter another Id.");
             ValidationErrors errors = new ValidationErrors();
             errors.addValidationError("userId", error);
             throw new DuplicateRecordException(errors);
        }
        try {
            session = getSession();
            session.save(person);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return person;
    }
    
    public boolean isProjectAssigned(String siteId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        Session session = null;
        boolean projectAssigned = false;
        try {
            session = getHibernateSession();
            Query sqlQuery = null;
            sqlQuery = session.getNamedQuery("sql.projectAssociation");
            sqlQuery.setString("SelCompanyId", siteId);
            Integer x = (Integer) (sqlQuery.uniqueResult());

            if (x == null) {
                projectAssigned = false;
            } else {
                if (x.intValue() >= 1) {
                    projectAssigned = true;
                } else {
                    projectAssigned = false;
                }
            }
            session.flush();
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return projectAssigned;
    }

    public boolean isCompanyDisabled(String siteId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        Session session = null;
        boolean isCompanyDisabled = false;
        try {
            session = getHibernateSession();
            Query sqlQuery = null;
            sqlQuery = session.getNamedQuery("sql.companyStatus");
            sqlQuery.setString("SelCompanyId", siteId);
            Integer x = (Integer) (sqlQuery.uniqueResult());

            if (x == null) {
                isCompanyDisabled = true;
            } else {
                if (x.intValue() == 1) {
                    isCompanyDisabled = false;
                } else {
                    isCompanyDisabled = true;
                }
            }
            session.flush();
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return isCompanyDisabled;
    }

    public void updatePerson(Person criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        System.err.println("user Id-------------------in dao impl--------"+criteria.getUserId());
        System.err.println("scroll amt in dao impl-------"+criteria.getScrollAmount());
        int resultint = 0;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        if (criteria.getUserId() == null) {
            throw new InvalidDAOArgumentException("UserId can not be NULL.");
        }
        if (criteria.getSiteId() == null) {
            throw new InvalidDAOArgumentException("SiteId can not be NULL.");
        }

        try {
            session = getHibernateSession();
            session.clear();
            session.update(criteria);
            session.flush();
        } catch (HibernateException hex) {
            Person isPersonExist = getPerson(criteria.getSiteId(), criteria.getUserId());
            if (isPersonExist == null) {
                throw new RecordNotFoundException("No User found for this Criteria.");
            }
        } finally {
            closeSession(session);
        }
    }

    private Criteria buildCriteria(PersonListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(Person.class);

        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getSiteId())) {
                criteria.add(Restrictions.like("siteId", listHelper.getSiteId()));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getUserId())) {
                criteria.add(Restrictions.like("userId", prepareWildcardSearchString(listHelper.getUserId())));
            }
            if (listHelper.getUniqueUserRef() != null) {
                criteria.add(Restrictions.eq("uniqueUserRef", listHelper.getUniqueUserRef()));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(PersonListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("userId");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("userId")) {
                criteria.addOrder(Order.asc("userId"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {      
        return columnName;
    }

}
