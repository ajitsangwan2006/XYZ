package usermgmt.src.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import usermgmt.src.dao.interfaces.CompanyDAO;
import usermgmt.src.dto.Company;
import usermgmt.src.dto.CompanyModule;
import usermgmt.src.listhelper.CompanyListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import docprep.src.services.SystemUtil;


public class CompanyDAOImpl extends DAOImpl implements CompanyDAO {

    public PageDAO getCompany(CompanyListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {

        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();
            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());
        } catch (HibernateException e) {
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return page;

    }

    public PageDAO getCompany(CompanyListHelper criteria) throws DAOException {
        return getCompany(criteria, -1, -1);
    }

    public Company getCompany(String companyId) throws DAOException, InvalidDAOArgumentException {

        if (companyId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        CompanyListHelper criteria = new CompanyListHelper();
        criteria.setCompanyId(companyId);
        List list = getCompany(criteria).getCurrentPageData();
        if (list.size() > 0) {
            Company company = (Company) list.get(0);
            Set companyModules = company.getCompanyModules();
            CompanyModule[] companyModuleArray = (CompanyModule[]) companyModules.toArray(new CompanyModule[companyModules.size()]);
            company.setCompanyModule(companyModuleArray);
            return company;
        } else {
            return null;
        }

    }
    
    public void createCompany(Company dto) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {

        Session session = null;
        String companyId = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        Company isCompanyExist = getCompany(dto.getCompanyId());
        if (isCompanyExist != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("companyId");
            error.setErrorCode("OZA-80003-12");
            error.setErrorMessage("Duplicate Entry exists for this Company Id.");
            ValidationErrors errors = new ValidationErrors();
            errors.addValidationError("companyId", error);
            throw new DuplicateRecordException(errors);
        }

        try {
            session = getHibernateSession();
            System.err.println("I m called upto here 1");
            session.clear();
            System.err.println("I m called upto here 2");
            session.save(dto);
            System.err.println("I m called upto here 3");
            CompanyModule[] companyModuleArray = (CompanyModule[]) dto.getCompanyModule();
            System.err.println("I m called upto here 4");
            updateCompanyModuleFromCompanyModuleArray(session, companyModuleArray);
            System.err.println("I m called upto here 7");
            session.flush();
            System.err.println("I m called upto here 8");
        } catch (HibernateException hex) {
        	hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            session.clear();
            session.flush();
            closeSession(session);
        }
    }
    
    private void updateCompanyModuleFromCompanyModuleArray(Session session, CompanyModule[] companyModuleArray) {
        for (int i = 0; i < companyModuleArray.length; i++) {
        	System.err.println("I m called upto here 5 "+i);
            session.saveOrUpdate(companyModuleArray[i]);
            System.err.println("I m called upto here 6 "+i);
            session.flush();
        }
    }
    
    private Criteria buildCriteria(CompanyListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(Company.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getCompanyId())) {
                criteria.add(Restrictions.like("companyId", prepareWildcardSearchString(listHelper.getCompanyId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCompanyName())) {
                criteria.add(Restrictions.like("companyName", prepareWildcardSearchString(listHelper.getCompanyName())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCountry())) {
                criteria.add(Restrictions.like("country", prepareWildcardSearchString(listHelper.getCountry())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getStatus())) {
                criteria.add(Restrictions.like("status", new Integer(listHelper.getStatus())));
            }
            if (listHelper.getExpiry() != null) {
                Date dateFrom = listHelper.getExpiry();
                Date dateTo = listHelper.getExpiryTo();

                if (dateTo == null) {
                    if (listHelper.getDateBoundry() == null || listHelper.getDateBoundry().equals("On")) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(dateFrom);
                        calendar.set(Calendar.HOUR, 23);
                        calendar.set(Calendar.MINUTE, 59);
                        calendar.set(Calendar.SECOND, 59);
                        dateTo = calendar.getTime();
                    } else if (listHelper.getDateBoundry().equals("Before")) {
                        dateTo = dateFrom;
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.YEAR, 1950);
                        dateFrom = calendar.getTime();
                    } else if (listHelper.getDateBoundry().equals("After")) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.YEAR, 2090);
                        dateTo = calendar.getTime();
                    }
                } else {
                    dateTo = SystemUtil.adjustDateBy(dateTo, 1);
                }
                criteria.add(Restrictions.between("expiry", dateFrom, dateTo));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(CompanyListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("companyId");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("companyId")) {
                criteria.addOrder(Order.asc("companyId"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

}