package usermgmt.src.dao.impl;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import usermgmt.src.dao.interfaces.CompanyModuleDAO;
import usermgmt.src.dto.CompanyModule;
import usermgmt.src.dto.CompanyModuleId;
import usermgmt.src.listhelper.CompanyModuleListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public class CompanyModuleDAOImpl extends DAOImpl implements CompanyModuleDAO {

	public PageDAO getCompanyModuleList(CompanyModuleListHelper listHelper, int startRowNo, int scrollValue) throws DAOException{
        Session session = null;        
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);       
           int totalRecords = getTotalRecords(criteriaForCounter);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace(System.err);
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }    
		
    public CompanyModule get(String siteId, Integer moduleId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            session = getHibernateSession();
            session.clear();
            return (CompanyModule) session.get(CompanyModule.class, new CompanyModuleId(moduleId, siteId));
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            session.clear();
            session.flush();
            closeSession(session);
        }
    }

    private Criteria buildCriteria(CompanyModuleListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(CompanyModule.class);
      if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);            
            if (!GenericValidator.isBlankOrNull(listHelper.getCompanyId())) {
                criteria.add(Restrictions.like("id.companyId", listHelper.getCompanyId()));
            }
         }
        return criteria;
    }

    private void buildCriteriaOrder(CompanyModuleListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("id.companyId");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("id.companyId")) {
                criteria.addOrder(Order.asc("id.companyId"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        if (columnName.equals("moduleId")) {
            return "id.moduleId";
        }
        if (columnName.equals("companyId")) {
            return "id.companyId";
        }
        if (columnName.equals("status")) {
            return "status";
        }
        else
        {
        	return columnName;
        }
     
    }
            
}

