package usermgmt.src.dao.interfaces;

import usermgmt.src.dto.CompanyModule;
import usermgmt.src.listhelper.CompanyModuleListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public interface CompanyModuleDAO extends DAO {    
   
	public PageDAO getCompanyModuleList(CompanyModuleListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;
			
	public CompanyModule get(String siteId, Integer moduleId) throws DAOException, InvalidDAOArgumentException;
}