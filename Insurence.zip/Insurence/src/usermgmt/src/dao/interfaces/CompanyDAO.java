package usermgmt.src.dao.interfaces;

import usermgmt.src.dto.Company;
import usermgmt.src.listhelper.CompanyListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;




public interface CompanyDAO extends DAO {
	
	public PageDAO getCompany(CompanyListHelper criteria, int startRowNo, int scrollValue) throws DAOException;
	
	public PageDAO getCompany(CompanyListHelper criteria) throws DAOException;
	
	public Company getCompany(String companyId) throws DAOException, InvalidDAOArgumentException;
	
    public void createCompany(Company dto) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException ;
}