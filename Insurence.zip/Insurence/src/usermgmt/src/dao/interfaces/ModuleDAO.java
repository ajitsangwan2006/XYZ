package usermgmt.src.dao.interfaces;

import usermgmt.src.dto.Module;
import usermgmt.src.listhelper.ModuleListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public interface ModuleDAO extends DAO {

	public PageDAO getList(ModuleListHelper listHelper, int startRowNo, int scrollValue) throws DAOException;

    public Module getModule(Integer moduleId) throws DAOException, InvalidDAOArgumentException;

    public Module getByDescription(String moduleDescription) throws DAOException, InvalidDAOArgumentException;
}
