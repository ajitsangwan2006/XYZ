package usermgmt.src.dao.interfaces;

import usermgmt.src.dto.Person;
import usermgmt.src.listhelper.PersonListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public interface PersonDAO extends DAO {    
   
	public PageDAO getPersonList(PersonListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;	
	
	public Person getPerson(String userId)throws DAOException, InvalidDAOArgumentException;
	
	public Person getPerson(String siteId, String userId)throws DAOException, InvalidDAOArgumentException;
	
	public Person getPerson(Long uniqueUserRef)throws DAOException, InvalidDAOArgumentException;			

	public void updatePerson(Person criteria)	throws DAOException, InvalidDAOArgumentException,RecordNotFoundException;

    public boolean isProjectAssigned(String siteId) throws DAOException, InvalidDAOArgumentException;
    
    public boolean isCompanyDisabled(String siteId) throws DAOException, InvalidDAOArgumentException;
    
	public Person createPerson(Person criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
}