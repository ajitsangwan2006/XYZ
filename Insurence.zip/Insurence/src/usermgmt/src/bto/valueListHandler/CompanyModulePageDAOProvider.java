package usermgmt.src.bto.valueListHandler;

import usermgmt.src.listhelper.CompanyModuleListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.daotier.listpages.PageDAO;
import docprep.src.bto.base.BTOBase;


public class CompanyModulePageDAOProvider extends BTOBase implements PageDAOProvider {
    public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue) {
        PageDAO pageDAO = null;
        pageDAO = getCompanyModuleDAO().getCompanyModuleList((CompanyModuleListHelper) criteria, startRowNo, pageScrollValue);
        return pageDAO;
    }
}
