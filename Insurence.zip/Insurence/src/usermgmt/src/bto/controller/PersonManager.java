package usermgmt.src.bto.controller;

import usermgmt.src.dto.Person;
import usermgmt.src.listhelper.PersonListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;

public interface PersonManager {

    public PageHandler getPersonList(PersonListHelper criteria);

    public Person getPerson() throws InvalidArgumentException;

    public Person getPerson(String userId) throws InvalidArgumentException;
    
    public Person getPerson(String userId, String siteId) throws InvalidArgumentException;

    public void updatePerson(Person user) throws InvalidArgumentException;
        
    public Person createPerson(Person person) throws InvalidArgumentException, DuplicateRecordException;

}