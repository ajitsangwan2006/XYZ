package usermgmt.src.bto.controller;

import usermgmt.src.dto.Company;
import usermgmt.src.listhelper.CompanyListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;

public interface CompanyManager {
    
    public PageHandler getCompanyList(CompanyListHelper criteria);

    public Company getCompany(String companyId) throws InvalidArgumentException;

    public void createCompany(Company company) throws InvalidArgumentException, DuplicateRecordException;
}

