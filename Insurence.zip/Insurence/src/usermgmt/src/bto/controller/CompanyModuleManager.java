package usermgmt.src.bto.controller;

import usermgmt.src.dto.CompanyModule;
import usermgmt.src.listhelper.CompanyModuleListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public interface CompanyModuleManager {

	public PageHandler getCompanyModuleList(CompanyModuleListHelper listHelper);

	public CompanyModule get(String siteId, Integer moduleId) throws InvalidArgumentException;
}