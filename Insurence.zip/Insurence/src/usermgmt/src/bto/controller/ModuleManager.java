package usermgmt.src.bto.controller;

import java.util.List;

import usermgmt.src.dto.Module;
import usermgmt.src.listhelper.ModuleListHelper;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public interface ModuleManager  {
    
    public List getList(ModuleListHelper listHelper) ;  
    
    public Module getModule(Integer moduleId) throws  InvalidDAOArgumentException;

    public Module getByDescription(String moduleDescription) throws InvalidDAOArgumentException;
}
