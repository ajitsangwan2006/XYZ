package usermgmt.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.bto.controller.CompanyModuleManager;
import usermgmt.src.bto.valueListHandler.CompanyModulePageDAOProvider;
import usermgmt.src.dto.CompanyModule;
import usermgmt.src.listhelper.CompanyModuleListHelper;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;


public class CompanyModuleManagerImpl extends BTOBase implements CompanyModuleManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private String siteId;
    
    private String userId;    
    
    private int pageScrollValue;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.siteId = siteId;
        this.userId = userId;
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getCompanyModuleList(CompanyModuleListHelper criteria) {
        if (criteria == null) {
            criteria = new CompanyModuleListHelper();
        }
        criteria.setCompanyId(this.siteId);
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CompanyModulePageDAOProvider companyModulePageDAOProvider  = (CompanyModulePageDAOProvider) springFactory.getBean("companyModulePageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, companyModulePageDAOProvider, pageScrollValue);
    }

	public CompanyModule get(String siteId, Integer moduleId) throws InvalidArgumentException {
	    return getCompanyModuleDAO().get(siteId, moduleId);
	}     
}