package usermgmt.src.bto.controllerImpl;


import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.bto.controller.CompanyManager;
import usermgmt.src.bto.valueListHandler.CompanyPageDAOProvider;
import usermgmt.src.dto.Company;
import usermgmt.src.listhelper.CompanyListHelper;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.validation.ValidationErrors;


public class CompanyManagerImpl extends BTOBase implements CompanyManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipaddress;

    

    public void initialize(String userId, String siteId, String ipaddress, int pageScrollValue, dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipaddress = ipaddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        
    }

    public Company getCompany(String companyId) throws InvalidArgumentException {
        if (companyId == null || companyId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Company");
            invalidArgumentException.setErrorOzCode("system.errors.Company");
            throw invalidArgumentException;
        }
        Company company = null;
        company = getCompanyDAO().getCompany(companyId);

        return company;
    }

    public PageHandler getCompanyList(CompanyListHelper listHelper) {
        if (listHelper == null) {
            listHelper = new CompanyListHelper();
        }

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CompanyPageDAOProvider companyPageDAOProvider = (CompanyPageDAOProvider) springFactory.getBean("companyPageDAOProvider");
        return getPageHandler(pageHandlerHolder, listHelper, companyPageDAOProvider, pageScrollValue);
    }
  
    public void createCompany(Company company) throws InvalidArgumentException, DuplicateRecordException {
        if (company == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Company");
            invalidArgumentException.setErrorOzCode("system.errors.Company");
            throw invalidArgumentException;
        }  
        ValidationErrors validationErrors = company.validate();
        if (validationErrors != null) {            
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        getCompanyDAO().createCompany(company);
    }
}
