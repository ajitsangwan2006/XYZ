package usermgmt.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.bto.controller.PersonManager;
import usermgmt.src.bto.valueListHandler.PersonPageDAOProvider;
import usermgmt.src.dto.Person;
import usermgmt.src.listhelper.PersonListHelper;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.validation.ValidationErrors;

public class PersonManagerImpl extends BTOBase implements PersonManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getPersonList(PersonListHelper listHelper) {
        if (listHelper == null) {
            listHelper = new PersonListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();

        PersonPageDAOProvider personPageDAOProvider = (PersonPageDAOProvider) springFactory.getBean("personPageDAOProvider");
        return getPageHandler(pageHandlerHolder, listHelper, personPageDAOProvider, pageScrollValue);
    }

    public Person getPerson() throws InvalidArgumentException {       
        Person user = null;
        user = getPersonDAO().getPerson(this.userId);
        return user;
    }
    
    public Person getPerson(String userID, String siteId) throws InvalidArgumentException {
        if (siteId == null || siteId.trim().length() <= 0) {
            throw new InvalidArgumentException("Site Id connot be null.");
        }
        if (userID == null || userID.trim().length() <= 0) {
            throw new InvalidArgumentException("User Id connot be null.");
        }
        Person user = null;
        user = getPersonDAO().getPerson(siteId, userId);
        return user;
    }
    public Person getPerson(String userID) throws InvalidArgumentException {
        if (userID == null || userID.trim().length() <= 0) {
            throw new InvalidArgumentException("User Id connot be null.");
        }
        Person user = null;
        user = getPersonDAO().getPerson(userID);
        return user;
    }
    public void updatePerson(Person user) throws InvalidArgumentException {
    	if (user == null) {
            throw new InvalidArgumentException("User connot be null.");
        }
        user.setUserId(this.userId);
        user.setSiteId(this.siteId);
        ValidationErrors validationErrors = user.validate();
        if (validationErrors != null) {
            throw new InvalidArgumentException(validationErrors);
        }
        System.err.println("ScrollAmount in Manager==========:"+user.getScrollAmount());
        getPersonDAO().updatePerson(user);
    }

	public Person createPerson(Person person) throws InvalidArgumentException , DuplicateRecordException{
		if(person == null){
			throw new InvalidArgumentException("Persn cannot be null.");
		}
		getPersonDAO().createPerson(person);
		return person;
	}

}
