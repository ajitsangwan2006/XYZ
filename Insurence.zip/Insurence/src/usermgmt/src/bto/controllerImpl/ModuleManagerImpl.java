package usermgmt.src.bto.controllerImpl;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.bto.controller.ModuleManager;
import usermgmt.src.dto.Module;
import usermgmt.src.listhelper.ModuleListHelper;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.controllerImpl.ActivityLogManagerImpl;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public class ModuleManagerImpl extends BTOBase implements ModuleManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipaddress;

    private ActivityLogManager activitymanager;

    public void initialize(String siteId, String userId, String ipaddress, int pageScrollValue, dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipaddress = ipaddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ActivityLogManagerImpl activityManagerImpl = (ActivityLogManagerImpl) springFactory.getBean("activityLogManager");
        activityManagerImpl.initialize(pageScrollValue, pageHandlerHolder, userId, siteId, this.ipaddress);
        this.activitymanager = activityManagerImpl;
    }

    public List getList(ModuleListHelper listHelper) {
        if(listHelper == null){
            listHelper = new ModuleListHelper();
        }
        List list = getModuleDAO().getList(listHelper, -1, -1).getCurrentPageData();
        return list;
    }
    
    public Module getModule(Integer moduleId) throws InvalidDAOArgumentException {
        Module module = null;
        module = getModuleDAO().getModule(moduleId);
        return module;
    }
    
    public Module getByDescription(String moduleDescription) throws InvalidDAOArgumentException {
        return getModuleDAO().getByDescription(moduleDescription);
    }
}
