package dev.zing.framework.webtier.ui.table;

public class DojoTable {
    public static final String COMPONENT_TYPE = "FilterTable";

    private String _id;

    private String _width;

    private String _styleClass = null;

    private String _headClass;

    private String _tbodyClass;

    private String _rowClass;
    
    private String _sortURI;
    
    private String _sortBy;
    
    private String _sortOrder;
    
    private String _defaultSortOrder;

    private Boolean _multiple;

    private Boolean _alternateRows;

    private Integer _maxSortable;

    private Integer _cellpadding;

    private Integer _cellspacing;

    private Integer _border;

    public DojoTable() {
        _id = "listingDojoTable";
        _width = "100%";
        _styleClass = "dojoTable";
        _headClass = "dojoThead";
        _tbodyClass = "dojoTbody";
        _rowClass = "dojoTr";
        _multiple = new Boolean(false);
        _alternateRows = new Boolean(true);
        _maxSortable = new Integer(1);
        _cellpadding = new Integer(0);
        _cellspacing = new Integer(0);
        _border = new Integer(0);
        _sortOrder = "asc";
        _defaultSortOrder = "asc";
    }

    public String getStyleClass() {
        return _styleClass;

    }

    public void setStyleClass(String styleClass) {
        _styleClass = styleClass;
    }

    public String getHeadClass() {
        return _headClass;
    }

    public void setHeadClass(String headClass) {
        _headClass = headClass;
    }

    public String getTbodyClass() {
        return _tbodyClass;
    }

    public void setTbodyClass(String tbodyClass) {
        _tbodyClass = tbodyClass;
    }

    public Boolean getMultiple() {
        return _multiple;
    }

    public void setMultiple(Boolean multiple) {
        _multiple = multiple;
    }

    public Boolean getAlternateRows() {
        return _alternateRows;
    }

    public void setAlternateRows(Boolean alternateRows) {
        _alternateRows = alternateRows;
    }

    public Integer getMaxSortable() {
        return _maxSortable;
    }

    public void setMaxSortable(Integer maxSortable) {
        _maxSortable = maxSortable;
    }

    public Integer getCellpadding() {
        return _cellpadding;
    }

    public void setCellpadding(Integer cellpadding) {
        _cellpadding = cellpadding;
    }

    public Integer getCellspacing() {
        return _cellspacing;
    }

    public void setCellspacing(Integer cellspacing) {
        _cellspacing = cellspacing;
    }

    public Integer getBorder() {
        return _border;
    }

    public void setBorder(Integer border) {
        _border = border;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        this._id = id;
    }

    public String getWidth() {
        return _width;
    }

    public void setWidth(String width) {
        this._width = width;
    }

    public String getRowClass() {
        return _rowClass;
    }

    public void setRowClass(String rowClass) {
        this._rowClass = rowClass;
    }

    public String getSortURI() {
        return _sortURI;
    }

    public void setSortURI(String sortURI) {
        this._sortURI = sortURI;
    }

    public String getSortBy() {
        if (_sortBy == null) {
            return _sortBy;
        }
        String[] valueTokens = _sortBy.split("\\.");
        if (valueTokens.length == 1) {
            return _sortBy;
        } else {
            return valueTokens[1];
        }
    }

    public void setSortBy(String sortBy) {
        this._sortBy = sortBy;
    }

    public String getSortOrder() {
        if (_sortOrder == null) {
            return "asc";
        }
        return _sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this._sortOrder = sortOrder;
    }
    
    public String getDefaultSortOrder() {
        return _defaultSortOrder;
    }

    public void setDefaultSortOrder(String defaultSortOrder) {
        this._defaultSortOrder = defaultSortOrder;
    }
}
