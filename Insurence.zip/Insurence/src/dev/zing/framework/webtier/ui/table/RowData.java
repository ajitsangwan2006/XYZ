
package dev.zing.framework.webtier.ui.table;

import java.util.HashMap;
import java.util.Map;

public class RowData {
        
    Map _columns = new HashMap();
    
    public void addColumn(String id, Object value) {
        _columns.put(id, value);
    }
        
    public Map get() {
        return _columns;
    }
}
