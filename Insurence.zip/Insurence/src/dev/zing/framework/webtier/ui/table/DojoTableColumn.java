package dev.zing.framework.webtier.ui.table;

public class DojoTableColumn {

    private String _id;

    private String _field;

    private String _dataType;
   
    private String _width;   

    private String _format;

    private String _align;

    private String _valign;

    private String _text;

    private Boolean _escape;
    
    private boolean _disableSort = false;
    
    private boolean _hiddenColumn = false;

    public DojoTableColumn() {
        
    }

    public String getField() {
        return _field;
    }

    public String getDataType() {
        return _dataType;
    }

    public void setDataType(String dataType) {
        _dataType = dataType;
    }

    public String getFormat() {
        return _format;
    }

    public void setFormat(String format) {
        _format = format;
    }

    public String getAlign() {
        return _align;
    }

    public void setAlign(String align) {
        _align = align;
    }

    public String getValign() {
        return _valign;
    }

    public void setValign(String valign) {
        _valign = valign;
    }

    public String getText() {
        return _text;
    }

    public void setText(String text) {
        _text = text;
    }

    public Boolean getEscape() {
        return _escape;
    }

    public void setEscape(Boolean escape) {
        _escape = escape;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        this._id = id;
        this._field = id;
    }

    public String getWidth() {
        return _width;
    }

    public void setWidth(String width) {
        this._width = width;
    }
   
    public boolean getDisableSort() {
        return _disableSort;
    }
   
    public void setDisableSort(boolean disableSort) {
        this._disableSort = disableSort;
    }
    
    public boolean isHiddenColumn() {
        return _hiddenColumn;
    }

    public void setHiddenColumn(boolean hiddenColumn) {
        this._hiddenColumn = hiddenColumn;
    }
}
