
package dev.zing.framework.webtier.ui.table;

public class ResponseWriter {
    private String responseText = "";
    
    public void write(String textchunk) {
        responseText += textchunk;
    }
    
    public void writeAttribute(String attributeName, String attributeValue) {
        if (attributeValue != null) {
            write(" " + attributeName + "=\"" + attributeValue + "\" ");
        }
    }
    
    public String getResponseText() {
        return responseText;
    }
}
