
package dev.zing.framework.webtier.ui.table;

import java.util.List;
import java.util.Vector;

public class InnerListData {
    
    private List _dataRows = new Vector();
    
    public void add(String[] rowData) {
        _dataRows.add(rowData);
    }
        
    public List get() {
        return _dataRows;
    }
}
