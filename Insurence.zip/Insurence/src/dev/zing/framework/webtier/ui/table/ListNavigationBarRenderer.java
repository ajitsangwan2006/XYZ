package dev.zing.framework.webtier.ui.table;

import dev.zing.framework.businesstier.listpages.Page;

public class ListNavigationBarRenderer {

    private ResponseWriter writer = null;

    private int _startingNumber;

    private int _endingNumber;

    private int _totalSize;

    private boolean _isPreviousPageAvailable;

    private boolean _isNextPageAvailable;

    private String _contextPath;

    private String _uri;

    private String _sortBy;

    private String _sortOrder;

    public ListNavigationBarRenderer(Page page, String contextPath, String uri, String sortBy, String sortOrder) {
        writer = new ResponseWriter();
        _startingNumber = page.getStartingNumber();
        _endingNumber = page.getEndingNumber();
        _totalSize = page.getTotalSize();
        _isPreviousPageAvailable = page.isPreviousPageAvailable();
        _isNextPageAvailable = page.isNextPageAvailable();
        _contextPath = contextPath;
        _uri = uri;
        _sortBy = sortBy;
        _sortOrder = sortOrder;
    }

    public void encodeBegin() {
        writer.write("<TD align=\"left\" nowrap><span style=\" margin-left: 4px; \" > Listing " + _startingNumber + "-" + _endingNumber + " of " + _totalSize + "</span></TD>");

        writer.write("<TD align=\"right\" class=\"newstitle\" nowrap>");
        if (_isPreviousPageAvailable) {
            writer.write("<A href=\"#\" onclick=\"listPageNavigation('FIRST'); return;\" >");
            writer.write("<img class=\"hand\" style=\" margin-right: 4px; \" src=\"" + _contextPath + "/image/backstoreimage/First.gif\" alt=\"Go to First Page\" border=0 name=\"First\">");
            writer.write("</A>");
            writer.write("<A href=\"#\" onclick=\"listPageNavigation('PREVIOUS'); return;\" >");
            writer.write("<img class=\"hand\" style=\" margin-right: 4px; \" src=\"" + _contextPath + "/image/backstoreimage/Prev.gif\" alt=\"Go to Previous Page\" border=0 name=\"Prev\">");
            writer.write("</A>");
        }
        if (_isNextPageAvailable) {
            writer.write("<A href=\"#\" onclick=\"listPageNavigation('NEXT'); return;\" >");
            writer.write("<img class=\"hand\" style=\" margin-right: 4px; \" src=\"" + _contextPath + "/image/backstoreimage/Next.gif\" alt=\"Go to Next Page\" border=0 name=\"Next\">");
            writer.write("</A>");
            writer.write("<A href=\"#\" onclick=\"listPageNavigation('LAST'); return;\" >");
            writer.write("<img class=\"hand\" style=\" margin-right: 4px; \" src=\"" + _contextPath + "/image/backstoreimage/Last.gif\" alt=\"Go to Last Page\" border=0 name=\"Last\">");
            writer.write("</A>");
        }
        writer.write("</TD>");

    }

    public void encodeEnd() {

    }

    public String getRenderedContent() {
        encodeBegin();
        return writer.getResponseText();
    }
}
