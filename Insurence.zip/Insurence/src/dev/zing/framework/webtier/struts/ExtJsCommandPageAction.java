package dev.zing.framework.webtier.struts;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.lowagie.text.DocumentException;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.util.DateValueProcessor;
import dev.zing.framework.webtier.adapter.SignedInUser;

public abstract class ExtJsCommandPageAction extends ExtJsWebTierAction {

    public ExtJsCommandPageAction() {
        super();
    }

    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException {
        ActionForward forward = new ActionForward(); // return value
        log("inside ExtJsCommandPageAction action");

        java.util.Enumeration paramnames = request.getParameterNames();
        while (paramnames.hasMoreElements()) {
            String key = (String) paramnames.nextElement();
            Object value = request.getParameter(key);
            log("ExtJsCommandPageAction -   " + key + " = " + value);
        }

        SignedInUser signedInUser = (SignedInUser) request.getSession().getAttribute("SignedInUser");
        if (signedInUser == null) {
            forward = mapping.findForward("SessionExpired");
            return (forward);
        }
        log("SignedInUser: [" + signedInUser + "]");

        String actionMode = request.getParameter("actionMode");
        log("actionMode: " + actionMode);

        try {
            executeAction(getEnvironment(signedInUser), actionMode, mapping, form, request, response);
            return null;
        } catch (AccessDeniedException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            if (e != null && e.getValidationErrors() != null) {
                Iterator iterator = e.getValidationErrors().getValidationErrorsIterator();
                while (iterator.hasNext()) {
                    String key = (String) iterator.next();
                    ValidationError error = (ValidationError) e.getValidationErrors().getValidationErrors().get(key);
                    log(error.getPropertyName());
                    log(error.getErrorMessage());
                }
            }
            e.printStackTrace();

            log("InvalidArgumentException exception occurred");
            JSONObject json = getErrorJSON(e);
            log("json String: " + json);
            jsonResponse(json, request, response);
        } catch (DuplicateRecordException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        return null;
    }

    abstract protected Environment getEnvironment(SignedInUser signedInUser) throws AccessDeniedException;

    abstract protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, InvalidArgumentException, IllegalAccessException, DuplicateRecordException, AccessDeniedException, DocumentException;
    
    protected Model serviceCommand(Environment enviornment, String actionMode, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        log("Inside method serviceCommand..");
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("NEW")) {
                return doNew(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("EDIT")) {
                return doEdit(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("CLONE")) {
                return doClone(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("VIEW")) {
                return doView(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("DELETE")) {
                return doDelete(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("CHANGESTATUS")) {
                return doStatusChange(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("CHANGEPASSWORD")) {
                return doPasswordChange(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("IMPORT")) {
                return doImport(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("PRINTPREVIEW")) {
                return doPrintPreview(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("DOWNLOAD")) {
                return doDownload(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("EMAIL")) {
                return doEmail(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("ASSOLIST")) {
                return doAssoList(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("MOVEUP")) {
                return doMoveUp(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("MOVEDOWN")) {
                return doMoveDown(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("LINK")) {
                return doLink(enviornment, mapping, request, response);
            } else if (actionMode.equalsIgnoreCase("UNLINK")) {
                return doUnLink(enviornment, mapping, request, response);
            }
        }
        return null;
    }

    protected Model doNew(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doEdit(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doView(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doClone(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doDelete(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doStatusChange(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doPasswordChange(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doImport(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doPrintPreview(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doDownload(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doEmail(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doAssoList(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doMoveUp(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doMoveDown(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doLink(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    protected Model doUnLink(Environment enviornment, ActionMapping mapping, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException {
        return null;
    }

    public JSONObject getGridData(Object[] object) {        
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(object.length));        
        JSONArray jsonItems = new JSONArray();
        if (object != null) {
            for (int i = 0; i < object.length; i++) {   
                JSONObject jsonRow = getJSONObject(object[i]);                                
                jsonItems.add(jsonRow);
            }
        }
        json.put("results", jsonItems);
        return json;
    }
    
    public JSONObject getModelData(Model model) {
        JSONObject json = null;
        if (model.toJSONObject() != null) {
            json = getJSON(model.toJSONObject());
        } else {
            json = getJSON(model);
        }
        return json;
    }
    
    protected JSONObject getJSONObject(Object object) {
        JsonConfig jsonConfig = new JsonConfig();
        //jsonConfig.registerJsonBeanProcessor(java.util.Date.class, new DateBeanProcessor());
        jsonConfig.registerJsonValueProcessor(java.util.Date.class, new DateValueProcessor());
        //jsonConfig.setExcludes(new String[]{"imageSmall", "imageMedium", "imageLarge"});
        JSONObject jsonobj = JSONObject.fromObject(object, jsonConfig);        
        return jsonobj;
    }
    
    protected JSONObject getJSON(Object object) {
        JsonConfig jsonConfig = new JsonConfig();
        //jsonConfig.registerJsonBeanProcessor(java.util.Date.class, new DateBeanProcessor());
        jsonConfig.registerJsonValueProcessor(java.util.Date.class, new DateValueProcessor());
        jsonConfig.setExcludes(new String[]{"imageSmall", "imageMedium", "imageLarge"});
        JSONObject jsonobj = JSONObject.fromObject(object, jsonConfig);
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(true));
        json.put("data", jsonobj);
        return json;
    }

    protected JSONObject getJSON(JSONObject jsonobj) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(true));
        json.put("data", jsonobj);
        return json;
    }

    protected JSONObject getErrorJSON(InvalidArgumentException e) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        json.put("level", new Integer(1));
        if (e.getMessage() != null) {
            json.put("errorMsg", e.getMessage());
        }
        return json;
    }
    
    protected String getComboValueFormat(String value, String text) {
        if (GenericValidator.isBlankOrNull(value) || GenericValidator.isBlankOrNull(text)) {
            return "";
        }
        return "{value:'" + value + "', text:'" + text + "'}";
    }
}
