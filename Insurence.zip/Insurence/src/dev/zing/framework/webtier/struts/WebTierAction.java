package dev.zing.framework.webtier.struts;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public abstract class WebTierAction extends Action {

    public WebTierAction() {
        super();
    }

    protected ServletContext getServletContext() {
        return servlet.getServletContext();
    }

    protected void log(String logMessage) {
        System.out.println(logMessage);
    }

    public String getFormattedDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        return sdf.format(date);
    }

    public String getSessionPKID() {
        String rand = new Double(Math.random()).toString();
        String temp = new Long(System.currentTimeMillis()).toString() + rand.substring(2, 4);
        String retVal = String.valueOf(temp.hashCode());
        return retVal;
    }

    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.getSession().setAttribute("SessionPKID", getSessionPKID());
        return executePageAction(mapping, form, request, response);
    }

    abstract public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
}
