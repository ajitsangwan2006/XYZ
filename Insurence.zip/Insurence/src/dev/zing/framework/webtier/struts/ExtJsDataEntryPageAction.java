package dev.zing.framework.webtier.struts;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.services.validation.ValidationRegisterer;
import dev.zing.framework.util.BeanUtilsExtJs;
import dev.zing.framework.util.HTTPRequestUtils;
import dev.zing.framework.util.ValidationUtils;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFieldImpl;
import dev.zing.framework.webtier.adapter.FormFileImpl;
import dev.zing.framework.webtier.adapter.SignedInUser;

public abstract class ExtJsDataEntryPageAction extends ExtJsWebTierAction {

    public ExtJsDataEntryPageAction() {
        super();
    }

    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException {
        ActionForward forward = new ActionForward(); // return value
        HttpSession session = request.getSession();
        log("inside DataEntryPageAction action");
        SignedInUser signedInUser = (SignedInUser) session.getAttribute("SignedInUser");
        if (signedInUser == null) {
            forward = mapping.findForward("SessionExpired");
            return (forward);
        }
        log("SignedInUser: [" + signedInUser + "]");

		java.util.Enumeration paramnames = request.getParameterNames();
		while (paramnames.hasMoreElements()) {
		    String key = (String)paramnames.nextElement();
		    Object value = request.getParameter(key);
		    log("Export Document Form Field InfoAction -   " + key + " = " + value);
		}
		
        HTTPRequestUtils httpRequestUtils = HTTPRequestUtils.getInstance();
        BeanUtilsExtJs beanUtils = BeanUtilsExtJs.getInstance();
        FormFieldImpl formFields = null;
        FormFileImpl formFiles = null;
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        log("Request isMultipart: " + isMultipart);
        if (!isMultipart) {
            formFields = httpRequestUtils.getMapFromHTTPApplicationRequest(request);
            log("formFields.getParameter(\"docTypeCode\"): " + formFields.getParameter("docTypeCode"));
        } else {
            try {
                Map map = httpRequestUtils.getMapFromHTTPMultipartRequest(request);
                formFields = (FormFieldImpl) map.get("FormField");
                formFiles = (FormFileImpl) map.get("FormFile");
            } catch (FileUploadException e) {
                e.printStackTrace();
            }
        }

        String selectedMenu = formFields.getParameter("SelMenu");
        if (selectedMenu != null) {
            request.getSession().setAttribute("CurrentSelection", selectedMenu);
        }
        request.setAttribute("FormDiscardAction", formFields.getParameter("FormDiscardAction"));
        request.setAttribute("ENCTYPE", formFields.getParameter("ENCTYPE"));
        request.setAttribute("contentPaneTitle", formFields.getParameter("contentPaneTitle"));
        request.setAttribute("actionMode", formFields.getParameter("ActionMode"));

        String actionMode = formFields.getParameter("actionMode");
        log("actionMode: [" + actionMode + "]");
        if (!GenericValidator.isBlankOrNull(actionMode)) {
            prepareForFailureAndReload(request, formFields);
            Model model = getPageModel(formFields);
            ValidationErrors errors = new ValidationErrors();
            try {
                if (model != null) {
                    beanUtils.populate(formFields.getFieldsMap(), model, errors);
                    log("BeanUtils.getInstance():- " + errors.getValidationErrors().size());
                    /*
                    if (actionMode.equalsIgnoreCase("NEW") || actionMode.equalsIgnoreCase("EDIT") || actionMode.equalsIgnoreCase("CLONE")) {
                        errors.add(model.validate());
                        log("model.validate():- " + errors.getValidationErrors().size());                                                    
                    }
                    */
                    Iterator iterator = errors.getValidationErrorsIterator();
                    while (iterator.hasNext()) {
                        String key = (String)iterator.next();
                        ValidationError error = (ValidationError)errors.getValidationErrors().get(key);
                        log(error.getPropertyName());
                        log(error.getErrorMessage());
                    } 
                }
                if (actionMode.equalsIgnoreCase("CHANGEPASSWORD")) {

                }

                if (errors.getValidationErrors().size() > 0) {
                    return reloadDataEntryPage(actionMode, mapping, formFields, request, model, errors);
                }
                JSONObject responseJSON = null;
                if (actionMode.equalsIgnoreCase("NEW") || actionMode.equalsIgnoreCase("CLONE")) {
                    responseJSON = performAddAction(getEnvironment(signedInUser), model, request, response, formFields, formFiles);
                } else if (actionMode.equalsIgnoreCase("EDIT")) {
                    responseJSON = performModifyAction(getEnvironment(signedInUser), model, request, response, formFields, formFiles);
                } else {
                    responseJSON = performAction(actionMode, getEnvironment(signedInUser), model, request, response, formFields, formFiles, mapping);                    
                }
                if (responseJSON != null) {
                    jsonResponse(responseJSON, request, response);
                }                  
                /*
                if (!GenericValidator.isBlankOrNull(statusMessage)) {
                    request.setAttribute("statusMessage", statusMessage);
                }*/
            } catch (InvalidArgumentException e) {
                e.printStackTrace();
                log("InvalidArgumentException exception occurred");
                JSONObject json = getErrorJSON(e);
                log("json String: "+json);
                jsonResponse(json, request, response);                
                //errors.add(e.getValidationErrors());
                //return reloadDataEntryPage(actionMode, mapping, formFields, request, model, errors);
            } catch (DuplicateRecordException e) {
                e.printStackTrace();
                log("DuplicateRecordException exception occurred");
                errors.add(e.getValidationErrors());
                return reloadDataEntryPage(actionMode, mapping, formFields, request, model, errors);
            } catch (RecordNotFoundException e) {
                log("RecordNotFoundException exception occurred");
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                log("IllegalAccessException exception occurred");
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                log("InvocationTargetException exception occurred");
                e.printStackTrace();
            } catch (AccessDeniedException e) {
                log("AccessDeniedException exception occurred");
                e.printStackTrace();
            } catch (InvalidPasswordException e) {
                e.printStackTrace();
            }
        }

        //forward = getSuccessActionForward(mapping);
        //log("forward: [" + forward + "]");

        //return (forward);
        return null;
    }

    private ActionForward reloadDataEntryPage(String actionMode, ActionMapping mapping, FormField formFields, HttpServletRequest request, Model model, ValidationErrors errors) {
        request.setAttribute("beanInstance", model);
        
        String[] javaScript = ValidationRegisterer.getInstance().getJavaScriptValidationCode(model);
        request.setAttribute("hbnateJSValidation", HbnateValidator.getInstance().getJavaScriptValidationCode(model));
        request.setAttribute("declarativeJSValidation", javaScript[0]);   
        request.setAttribute("programmaticJSValidation", javaScript[1]);
        
        request.setAttribute("validationErrors", errors.getValidationErrors());
        log("reloadDataEntryPage:- " + errors.getValidationErrors().size());
        /*
        if (actionMode.equalsIgnoreCase("NEW") || actionMode.equalsIgnoreCase("EDIT") || actionMode.equalsIgnoreCase("CLONE")) {
            return getFailureActionForward(mapping, formFields);
        } else {
            if (getFailureActionForward(actionMode, mapping) != null) {
                return getFailureActionForward(actionMode, mapping);
            } else {
                return getFailureActionForward(mapping, formFields);
            }
        }
        */
        return null;
    }

    protected ServletContext getServletContext() {
        return servlet.getServletContext();
    }

    abstract protected Model getPageModel(FormField formFields);

    //abstract protected ActionForward getFailureActionForward(ActionMapping mapping, FormField formFields);

    //abstract protected ActionForward getSuccessActionForward(ActionMapping mapping);

    abstract protected Environment getEnvironment(SignedInUser signedInUser) throws AccessDeniedException;

    abstract protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest httpservletrequest, HttpServletResponse response, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException;

    abstract protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest httpservletrequest, HttpServletResponse response, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException;

    protected ActionForward getFailureActionForward(String actionMode, ActionMapping mapping) {
        return null;
    }

    protected void prepareForFailureAndReload(HttpServletRequest request, FormField formFields) {
        return;
    }
    
    protected JSONObject performAction(String actionMode, Environment enviornment, Model model, HttpServletRequest httpservletrequest, HttpServletResponse response, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
        log("Inside method performAction of DataEntryPageAction with actionMode: " + actionMode);
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("CHANGEPASSWORD")) {
                validatePassword(formFields);
                return doPasswordChange(enviornment, model, httpservletrequest, formFields, formFiles, mapping);
            } else if (actionMode.equalsIgnoreCase("IMPORT")) {
                return doImport(enviornment, model, httpservletrequest, formFields, formFiles, mapping);
            } else if (actionMode.equalsIgnoreCase("EMAIL")) {
                return doEmail(enviornment, model, httpservletrequest, formFields, formFiles, mapping);
            } else if (actionMode.equalsIgnoreCase("CHANGEPREFERENCES")) {
                return doChangePreferences(enviornment, model, httpservletrequest, formFields, formFiles, mapping);
            }
        }
        return null;
    }

    protected JSONObject doPasswordChange(Environment enviornment, Model model, HttpServletRequest httpservletrequest, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
        return null;
    }

    protected JSONObject doChangePreferences(Environment enviornment, Model model, HttpServletRequest httpservletrequest, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
        return null;
    }

    protected JSONObject doEmail(Environment enviornment, Model model, HttpServletRequest httpservletrequest, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
        return null;
    }

    protected JSONObject doImport(Environment enviornment, Model model, HttpServletRequest httpservletrequest, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
        return null;
    }
    
    protected void validatePassword(FormField formFields) throws InvalidArgumentException {
        String password = formFields.getParameter("password");
        String confirmPassword = formFields.getParameter("confirmPassword");
        log("password: "+password);
        log("confirmPassword: "+confirmPassword);
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils.getInstance().validatePassword("password", password, confirmPassword, errors);
        log("UserDataEntryPageAction-doPasswordChange-ValidationErrors size:- "+errors.getValidationErrors().size());
        if (errors.getValidationErrors().size() > 0) {
            log("UserDataEntryPageAction-doPasswordChange- throwing exception InvalidArgumentException.");
            throw new InvalidArgumentException(errors);
        }
        log("UserDataEntryPageAction-doPasswordChange- escaped exception InvalidArgumentException.");
    }

    protected JSONObject getErrorJSON(InvalidArgumentException e) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        json.put("level", new Integer(1));
        JSONObject fieldErrors = new JSONObject();
        
        ValidationErrors errors = e.getValidationErrors();
        Iterator iterator = errors.getValidationErrorsIterator();        
        while (iterator.hasNext()) {
            String key = (String)iterator.next();
            ValidationError error = (ValidationError)errors.getValidationErrors().get(key);
            fieldErrors.put(error.getPropertyName(), error.getErrorMessage());
        } 
        json.put("fieldErrors", fieldErrors);
        return json;
    }
}
