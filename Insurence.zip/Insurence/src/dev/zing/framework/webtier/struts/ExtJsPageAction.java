package dev.zing.framework.webtier.struts;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.util.DateValueProcessor;
import dev.zing.framework.webtier.adapter.SignedInUser;

public abstract class ExtJsPageAction extends ExtJsWebTierAction {

    public ExtJsPageAction() {
        super();
    }

    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException {
        ActionForward forward = new ActionForward(); // return value
        log("inside ExtJsCommandPageAction action");

        java.util.Enumeration paramnames = request.getParameterNames();
        while (paramnames.hasMoreElements()) {
            String key = (String) paramnames.nextElement();
            Object value = request.getParameter(key);
            log("ExtJsCommandPageAction -   " + key + " = " + value);
        }
        
        HttpSession session = request.getSession();
        if (session == null) {
            sendFailureResponse(request, response);
            return null;
        }

        SignedInUser signedInUser = (SignedInUser) request.getSession().getAttribute("SignedInUser");
        if (signedInUser == null) {
            sendFailureResponse(request, response);
            return null;           
        }
        log("SignedInUser: [" + signedInUser + "]");
        

        String actionMode = request.getParameter("ActionMode");
        log("actionMode: " + actionMode);

        try {
            forward = executeAction(mapping, form, request, response, signedInUser);
            return forward;
        } catch (AccessDeniedException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            e.printStackTrace();
        }
        return forward;
    }

    abstract public ActionForward executeAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, SignedInUser signedInUser) throws AccessDeniedException, InvalidArgumentException;

    public JSONObject getGridData(Map[] map) {        
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(map.length));        
        JSONArray jsonItems = new JSONArray();
        if (map != null) {
            for (int i = 0; i < map.length; i++) {               
                Iterator keysIterator = map[i].keySet().iterator();
                JSONObject jsonRow = new JSONObject();
                while (keysIterator.hasNext()) {
                    String key = (String)keysIterator.next();
                    Object value = map[i].get(key);
                    jsonRow.put(key, value);
                }                
                jsonItems.add(jsonRow);
            }
        }
        json.put("results", jsonItems);
        return json;
    }

    public JSONObject getGridData(Object[] object) {        
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(object.length));        
        JSONArray jsonItems = new JSONArray();
        if (object != null) {
            for (int i = 0; i < object.length; i++) {   
                JSONObject jsonRow = getJSONObject(object[i]);                                
                jsonItems.add(jsonRow);
            }
        }
        json.put("results", jsonItems);
        return json;
    }

    public JSONObject getGridData(List list) {        
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(list.size()));        
        JSONArray jsonItems = new JSONArray();
        if (list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {   
                JSONObject jsonRow = getJSONObject(list.get(i));                                
                jsonItems.add(jsonRow);
            }
        }
        json.put("results", jsonItems);
        return json;
    }
    
    protected JSONObject getJSONObject(Object object) {
        JsonConfig jsonConfig = new JsonConfig();
        //jsonConfig.registerJsonBeanProcessor(java.util.Date.class, new DateBeanProcessor());
        jsonConfig.registerJsonValueProcessor(java.util.Date.class, new DateValueProcessor());
        //jsonConfig.setExcludes(new String[]{"imageSmall", "imageMedium", "imageLarge"});
        JSONObject jsonobj = JSONObject.fromObject(object, jsonConfig);        
        return jsonobj;
    }
    
    protected JSONObject getJSON(Object object) {
        JsonConfig jsonConfig = new JsonConfig();
        //jsonConfig.registerJsonBeanProcessor(java.util.Date.class, new DateBeanProcessor());
        jsonConfig.registerJsonValueProcessor(java.util.Date.class, new DateValueProcessor());
        jsonConfig.setExcludes(new String[]{"imageSmall", "imageMedium", "imageLarge"});
        JSONObject jsonobj = JSONObject.fromObject(object, jsonConfig);
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(true));
        json.put("data", jsonobj);
        return json;
    }

    protected JSONObject getJSON(JSONObject jsonobj) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(true));
        json.put("data", jsonobj);
        return json;
    }

    protected String getComboValueFormat(String value, String text) {
        if (GenericValidator.isBlankOrNull(value) || GenericValidator.isBlankOrNull(text)) {
            return "";
        }
        return "{value:'" + value + "', text:'" + text + "'}";
    }        
}
