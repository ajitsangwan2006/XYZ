package dev.zing.framework.webtier.struts;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public abstract class ExtJsWebTierAction extends Action {

    public ExtJsWebTierAction() {
        super();
    }

    protected ServletContext getServletContext() {
        return servlet.getServletContext();
    }

    protected void log(String logMessage) {
        System.err.println(logMessage);
    }

    public String getFormattedDateTime(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm");
        return sdf.format(date);
    }

    public String getFormattedDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }
    
    protected void jsonResponse(JSONObject jsonData, HttpServletRequest request, HttpServletResponse response) {
        // check whether it is script Tag...
        // which is called by JSON
        boolean scriptTag = false;
        String cb = request.getParameter("callback");
        if (cb != null) {
            scriptTag = true;
            response.setContentType("text/javascript");
        } else {
            response.setContentType("application/x-json");
        }

        try {
            PrintWriter out = response.getWriter();
            if (scriptTag) {
                out.write(cb + "(");
            }
            response.getWriter().print(jsonData);
            if (scriptTag) {
                out.write(");");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void jsonResponse(JSONArray jsonData, HttpServletRequest request, HttpServletResponse response) throws IOException {
        // check whether it is script Tag...
        // which is called by JSON
        boolean scriptTag = false;
        String cb = request.getParameter("callback");
        if (cb != null) {
            scriptTag = true;
            response.setContentType("text/javascript");
        } else {
            response.setContentType("application/x-json");
        }

        PrintWriter out = response.getWriter();
        if (scriptTag) {
            out.write(cb + "(");
        }
        response.getWriter().print(jsonData);
        if (scriptTag) {
            out.write(");");
        }
    }
    
    protected JSONObject getSuccessJSON() {
        return getSuccessJSON(new Integer(200), null);
    }

    protected JSONObject getSuccessJSON(Integer level, String msg) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(true));
        json.put("level", level);
        if (msg != null) {
            json.put("msg", msg);
        }
        return json;
    }

    protected JSONObject getFailureJSON(int level, Map errorMap) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        json.put("level", new Integer(level));
        return json;
    }

    protected JSONObject getFailureJSON() {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        return json;
    }
    
    protected JSONObject getFailureJSON(HttpServletResponse response, int httpStatus, String errorMsgs) {
        response.setStatus(httpStatus);
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        json.put("errorMsg", errorMsgs);
        json.put("level", new Integer(httpStatus));
        return json;
    }
    
    protected JSONObject getFailureJSON(int level, String errorMsgs) {
        JSONObject json = new JSONObject();
        json.put("success", new Boolean(false));
        json.put("errors", new Boolean(true));
        json.put("errorMsg", errorMsgs);
        json.put("level", new Integer(level));
        return json;
    }
    
    protected void sendSuccessResponse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONObject json = getSuccessJSON();
        jsonResponse(json, request, response);
    }

    protected void sendFailureResponse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONObject json = getFailureJSON();
        jsonResponse(json, request, response);
    }
    
    /*
     * public String getSessionPKID() { String rand = new
     * Double(Math.random()).toString(); String temp = new
     * Long(System.currentTimeMillis()).toString() + rand.substring(2, 4);
     * String retVal = String.valueOf(temp.hashCode());
     * System.err.println("SessionPKID-----Action---1------------"+retVal);
     * return retVal; }
     */

    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        //request.getSession().setAttribute("SessionPKID", getSessionPKID());
        return executePageAction(mapping, form, request, response);
    }

    abstract public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
}
