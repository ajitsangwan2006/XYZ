package dev.zing.framework.webtier.struts;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.businesstier.listpages.Page;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.exception.application.bto.BTOException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.handler.ProgrammingExceptionHandler;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.BeanUtils;
import dev.zing.framework.webtier.adapter.SignedInUser;
import dev.zing.framework.webtier.ui.table.InnerListData;
import dev.zing.framework.webtier.ui.table.RowData;


public abstract class ExtJsListingPageAction extends ExtJsWebTierAction {

    public ExtJsListingPageAction() {
        super();
    }

    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException {
        String requestType = request.getParameter("requestType");
        if (requestType == null || requestType.equals("Data") || requestType.equals("ComboList")) {
            return executePageActionForData(mapping, form, request, response);
        } else if (requestType.equals("View")) {
            //return executePageActionForView(mapping, form, request, response);
        }
        return null;
    }
    
    public ActionForward executePageActionForData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException {
        ActionForward forward = new ActionForward(); // return value
        log("inside ListingPageAction action");
        log("request.getRequestURI(): " + request.getRequestURI());
        log("request.getRequestURL(): " + request.getRequestURL());
        request.setAttribute("ListRequestURI", request.getRequestURI());
        
        
		java.util.Enumeration paramnames = request.getParameterNames();
		while (paramnames.hasMoreElements()) {
		    String key = (String)paramnames.nextElement();
		    Object value = request.getParameter(key);
		    log("ExtJsListingPageAction -   " + key + " = " + value);
		}
        
        SignedInUser signedInUser = (SignedInUser) request.getSession().getAttribute("SignedInUser");
        log("SignedInUser: [" + signedInUser + "]");
        if (signedInUser == null) {           
            response.setStatus(401);
        	JSONObject json = getFailureJSON(401, "");
            jsonResponse(json, request, response);
            return null;
        }
        
        //exportdocs.src.bto.main.SignedInUser loggedInUser = (exportdocs.src.bto.main.SignedInUser) signedInUser;
                
        String startRowNo_str = request.getParameter("start");
        String scrollValue_str = request.getParameter("limit");
        
        int startRowNo = 0;
        int scrollValue = 0;
        if (startRowNo_str != null) {
            startRowNo = Integer.parseInt(startRowNo_str);
            scrollValue = Integer.parseInt(scrollValue_str);
        }            
                
        ListHelper listHelper = null;
        //PageHandler pageHandler = null;
        //Page page = null;
        try {
            if (getListHelper() != null) {
                listHelper = (ListHelper) getListHelper().newInstance();
            }
            if (listHelper != null) {
                ((ListHelperImpl)listHelper).setOrderByParam(request.getParameter("sort"));
                ((ListHelperImpl)listHelper).setOrderByFlow(request.getParameter("dir"));
            }
            log("Sort By: [" + ((ListHelperImpl)listHelper).getOrderByParam() + "]");
            log("Sort Direction: [" + ((ListHelperImpl)listHelper).getOrderByFlow() + "]");
            
            if (listHelper != null) {
                log("ExtJsListingPageAction - populating ListHelper from Request...");
                ValidationErrors errors = new ValidationErrors();
                BeanUtils beanUtils = BeanUtils.getInstance();
                beanUtils.populate(request, listHelper, errors);
                postProcessListHelper(listHelper, request, errors);
                if (errors.getValidationErrors().size() > 0) {
                    // below method is to be implemented
                    //return reloadListPage(mapping, request, model, errors);
                }
            }
            //request.getSession().setAttribute("listHelperBean", listHelper);
            
            
            if (this.getRenderingWidgetName().equals("Grid")) {
                PageHandler pageHandler = getPageHandler(listHelper, signedInUser, request);
                log("pageHandler: [" + pageHandler + "]");
                Page page = pageHandler.getPageForStartRowNo(startRowNo);
                log("page: [" + page + "]");
                JSONObject json = getGridData(page);
                log("json String:" + json.toString());
                jsonResponse(json, request, response);
            } else if (this.getRenderingWidgetName().equals("Tree")) {
                List[] list = this.getPageHandlers(listHelper, signedInUser, request);
                JSONArray json = new JSONArray();
                for (int i=0; i < list.length; i++) {
                    log("pageHandler: [" + list[i] + "]");
                    json = getColumnTreeData(json, list[i], request, i);                    
                }
                log("json String:" + json.toString());
                jsonResponse(json, request, response);
            }                                   
        } catch (BTOException bx) {
            new ProgrammingExceptionHandler().handleException(bx, null);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (AccessDeniedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvalidArgumentException e) {
            e.printStackTrace();
        }                
        return null;
    }
      
    public ServletContext getServletContext() {
        return servlet.getServletContext();
    }

    protected String getRenderingWidgetName() {
        return "Grid";
    }
        
    public JSONObject getGridData(Page page) {
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(page.getTotalSize()));
        InnerListData _innerData = new InnerListData();
        java.util.List list = (java.util.List) page.getList();
        JSONArray jsonItems = new JSONArray();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Model model = (Model) list.get(i);
                Map rowData = getListRowData(model).get();
                Iterator keysIterator = rowData.keySet().iterator();
                JSONObject jsonRow = new JSONObject();
                while (keysIterator.hasNext()) {
                    String key = (String)keysIterator.next();
                    Object value = rowData.get(key);
                    jsonRow.put(key, value);
                }                
                jsonItems.add(jsonRow);
            }
        }
        json.put("results", jsonItems);
        return json;
    }

    public JSONArray getColumnTreeData(JSONArray jsonItems, List list, HttpServletRequest request, int elementNo ) {
        //JSONObject json = new JSONObject();
        //json.put("totalCount", new Integer(page.getTotalSize()));
        InnerListData _innerData = new InnerListData();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Model model = (Model) list.get(i);
                Map rowData = getListRowData(model, getParentTreeNode(request), elementNo).get();
                Iterator keysIterator = rowData.keySet().iterator();
                JSONObject jsonRow = new JSONObject();
                while (keysIterator.hasNext()) {
                    String key = (String)keysIterator.next();
                    Object value = rowData.get(key);
                    jsonRow.put(key, value);
                }                
                jsonItems.add(jsonRow);
            }
        }
        //json.put("results", jsonItems);
        return jsonItems;
    }
    
    protected List[] getPageHandlers(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException {
        return null;
    }

    protected RowData getListRowData(Model model, String parentTreeNode, int elementNo) {
        return null;
    }

    protected String getParentTreeNode(HttpServletRequest request) {
        return null;
    }
    
    abstract protected Class getListHelper();
    
    abstract protected void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException;
        
    abstract protected PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException;
    
    
    

    //abstract protected ActionForward getActionForward(ActionMapping mapping);
    
    //abstract protected ActionForward getLookupActionForward(ActionMapping mapping);
    
    //abstract protected String getCommandActionName();

    //abstract protected DojoTableColumn[] getGridHeader();

    abstract protected RowData getListRowData(Model model);
    
    //abstract protected DojoTable getListTableLayout();

}
