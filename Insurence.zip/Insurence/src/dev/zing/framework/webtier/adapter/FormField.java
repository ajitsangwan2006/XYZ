package dev.zing.framework.webtier.adapter;

public interface FormField {
    public abstract String getParameter(String name);
    public abstract String[] getParameterValues(String name);
}