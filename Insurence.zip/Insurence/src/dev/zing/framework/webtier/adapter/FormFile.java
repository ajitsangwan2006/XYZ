
package dev.zing.framework.webtier.adapter;

import org.apache.commons.fileupload.FileItem;

public interface FormFile {
    public abstract FileItem getFileItem(String name);
}