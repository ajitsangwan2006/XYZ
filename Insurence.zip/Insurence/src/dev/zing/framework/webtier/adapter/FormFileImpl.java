package dev.zing.framework.webtier.adapter;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.fileupload.FileItem;

public class FormFileImpl implements FormFile {
    private Map filesMap = new HashMap();
    
    public FormFileImpl(Map filesMap) {
        super();
        this.filesMap = filesMap;
    }

    public void setFieldsMap(Map filesMap) {
        this.filesMap = filesMap;
    }

    public Map getFileItems() {       
        return this.filesMap;
    }
    
    public FileItem getFileItem(String name) {
        if (filesMap == null || filesMap.isEmpty() || !filesMap.containsKey(name)) {
            return null;
        }
        return (FileItem)filesMap.get(name);
    }

}
