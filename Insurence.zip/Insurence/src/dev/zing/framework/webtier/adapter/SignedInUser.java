package dev.zing.framework.webtier.adapter;

public interface SignedInUser {

    public String getUserId();

    public String getWelcomeMessage();
    
    public String getSiteId();

    public void logout();

    public boolean isActive();
}
