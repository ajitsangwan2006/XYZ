package dev.zing.framework.webtier.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class FormFieldImpl implements FormField {
    private Map fieldsMap = new HashMap();
    private Map multiValueFieldsMap = new HashMap();
    

    public FormFieldImpl() {
        super();
    }
    
/*    public FormFieldImpl(Map fieldsMap) {
        super();
        this.fieldsMap = fieldsMap;
    }
*/

    public void setFormField(String name, String value) {
        this.fieldsMap.put(name, value);
        if (!this.multiValueFieldsMap.containsKey(name)) {
            List list = new Vector();
            list.add(value);
            this.multiValueFieldsMap.put(name, list);
        } else {
            List list = (List)this.multiValueFieldsMap.get(name);
            list.add(value);
            this.multiValueFieldsMap.put(name, list);
        }
    }
    
    public void setFieldsMap(Map fieldsMap) {
        this.fieldsMap = fieldsMap;
    }

    public Map getFieldsMap() {
        return fieldsMap;
    }

    public void setMultiValueFieldsMap(Map fieldsMap) {
        this.fieldsMap = fieldsMap;
    }

    public Map getMultiValueFieldsMap() {
        return fieldsMap;
    }
    
    public String getParameter(String name) {
        if (fieldsMap == null || fieldsMap.isEmpty() || !fieldsMap.containsKey(name)) {
            return null;
        }
        return (String)fieldsMap.get(name);
    }
    
    public String[] getParameterValues(String name) {
        if (multiValueFieldsMap == null || multiValueFieldsMap.isEmpty() || !multiValueFieldsMap.containsKey(name)) {
            return null;
        }
        List list = (List)this.multiValueFieldsMap.get(name);
        String[] elements = new String[list.size()];
        elements = (String[]) list.toArray(elements);
        return elements;
    }
}
