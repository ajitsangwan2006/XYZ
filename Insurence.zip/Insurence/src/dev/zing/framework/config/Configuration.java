package dev.zing.framework.config;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import dev.zing.framework.services.exception.handler.ConfigurationExceptionHandler;
import dev.zing.framework.services.logging.LoggerAdapter;
import dev.zing.framework.util.LoggerUtils;


public class Configuration {
    
    private static LoggerAdapter logger = LoggerUtils.getLogger();
    
    private static String propFilename = "db.properties";
    
    private static String dbConnectionString = null;
    
    private static String driverClasses = null;
    
    private static String UserName = "";
    
    private static String Password = "";
    
    private static int Daily_JobSchedule_Hour = 22;
    
    private static int Daily_JobSchedule_Min = 0;
    
    private static String SMTP_Host = "mail.ozdocs.net.au";
    
    private static String Sender_Email = "tlfManager@digerati.com.au";
    
    private static String Email_Image_URL = "http://localhost:9080";
    
    private static String AssistSrv_EndPoint = "localhost";
    
    private static String usrMgmSrv_EndPoint = "localhost";
    
    private static String sentinelSrv_Mode = "WEB-SERVICE";
    
    private static String SentinelSrv_EndPoint = "localhost";
    
    private static String hostNameForException = "";
    
    private static String fromEmailIDForException = "";
    
    private static String toEmailIDForException = "";
    
    private static String subjectForException = "";
    
    static {
        init();
    }
    
    private static void init() {
        InputStream is = null;
        Properties props = new Properties();
        
        try {
            String workingFolder = System.getProperty("user.dir");
            is = new java.io.FileInputStream(workingFolder + File.separator + propFilename);
        } catch (FileNotFoundException e) {
            logger.info("Property File [" + propFilename + "] not found in Current Folder, now going to check on Class Path.");
            is = Configuration.class.getClass().getResourceAsStream("/" + propFilename);
        }
        if (is == null) {
            logger.info("Property File [" + propFilename + "] not found on paths [Current Folder & Class Path].");
        }
        logger.info("Property File [" + propFilename + "] loaded successfully.");
        
        try {
            props.load(is);
        } catch (IOException e1) {
            logger.fatal("Problem while creating Property object from Property File [" + propFilename + "] InputStream ." + e1);
        }
        
        if (props.getProperty("URL") != null) {
            dbConnectionString = props.getProperty("URL").trim();
        }
        logger.debug("dbConnectionString [" + dbConnectionString + "]");
        
        if (props.getProperty("Drivers") != null) {
            driverClasses = props.getProperty("Drivers").trim();
        }
        logger.debug("driverClasses [" + driverClasses + "]");
        
        if (props.getProperty("UserName") != null) {
            UserName = props.getProperty("UserName").trim();
        }
        logger.debug("UserName [" + UserName + "]");
        
        if (props.getProperty("Password") != null) {
            Password = props.getProperty("Password").trim();
        }
        logger.debug("Password [" + Password + "]");
        
        if (props.getProperty("Daily_JobSchedule_Hour") != null) {
            try {
                Daily_JobSchedule_Hour = Integer.parseInt(props.getProperty("Daily_JobSchedule_Hour").trim());
            } catch (NumberFormatException nfe) {
            }
        }
        logger.debug("Daily_JobSchedule_Hour [" + Daily_JobSchedule_Hour + "]");
        
        if (props.getProperty("Daily_JobSchedule_Min") != null) {
            try {
                Daily_JobSchedule_Min = Integer.parseInt(props.getProperty("Daily_JobSchedule_Min").trim());
            } catch (NumberFormatException nfe) {
            }
        }
        logger.debug("Daily_JobSchedule_Min [" + Daily_JobSchedule_Min + "]");
        
        if (props.getProperty("SMTP_Host") != null) {
            SMTP_Host = props.getProperty("SMTP_Host").trim();
        }
        logger.debug("SMTP_Host [" + SMTP_Host + "]");
        
        if (props.getProperty("Sender_Email") != null) {
            Sender_Email = props.getProperty("Sender_Email").trim();
        }
        logger.debug("Sender_Email [" + Sender_Email + "]");
        
        if (props.getProperty("Email_Image_URL") != null) {
            Email_Image_URL = props.getProperty("Email_Image_URL").trim();
        }
        logger.debug("Email_Image_URL [" + Email_Image_URL + "]");
        
        if (props.getProperty("AssistSrv_EndPoint") != null) {
            AssistSrv_EndPoint = props.getProperty("AssistSrv_EndPoint").trim();
        }
        logger.debug("Email_Image_URL [" + Email_Image_URL + "]");
        
        if (props.getProperty("UsrMgmSrv_EndPoint") != null) {
            usrMgmSrv_EndPoint = props.getProperty("UsrMgmSrv_EndPoint").trim();
        }
        logger.debug("usrMgmSrv_EndPoint [" + usrMgmSrv_EndPoint + "]");

        if (props.getProperty("SentinelSrv_Mode") != null) {
            sentinelSrv_Mode = props.getProperty("SentinelSrv_Mode").trim();
        }
        logger.debug("SentinelSrv_Mode [" + sentinelSrv_Mode + "]");
        
        if (props.getProperty("SentinelSrv_EndPoint") != null) {
            SentinelSrv_EndPoint = props.getProperty("SentinelSrv_EndPoint").trim();
        }
        logger.debug("SentinelSrv_EndPoint [" + SentinelSrv_EndPoint + "]");
        
        if (props.getProperty("ExceptionReportHost") != null) {
            hostNameForException = props.getProperty("ExceptionReportHost").trim();
        }
        logger.debug("hostNameForException [" + hostNameForException + "]");
        
        if (props.getProperty("FromEmail") != null) {
            fromEmailIDForException = props.getProperty("FromEmail").trim();
        }
        logger.debug("fromEmailIDForException [" + fromEmailIDForException + "]");
        
        if (props.getProperty("ToEmail") != null) {
            toEmailIDForException = props.getProperty("ToEmail").trim();
        }
        logger.debug("toEmailIDForException [" + toEmailIDForException + "]");
        
        if (props.getProperty("Subject") != null) {
            subjectForException = props.getProperty("Subject").trim();
        }
        logger.debug("subjectForException [" + subjectForException + "]");
        
        performValidation();
    }
    
    public static void performValidation() {
        if (getDbConnectionString() == null || getDbConnectionString().length() < 1) {
            new ConfigurationExceptionHandler().handleException(null, "DB Connection URL not supplied in Properties File [" + propFilename + "].");
        }
        if (getDriverClasses() == null || getDriverClasses().length() < 1) {
            new ConfigurationExceptionHandler().handleException(null, "DB Connection Driver Class Name not supplied in Properties File [" + propFilename + "].");
        }
        if (getUserName() == null || getUserName().length() < 1) {
            new ConfigurationExceptionHandler().handleException(null, "DB Connection Username not supplied in Properties File [" + propFilename + "].");
        }
        if (getPassword() == null || getPassword().length() < 1) {
            new ConfigurationExceptionHandler().handleException(null, "DB Connection Password not supplied in Properties File [" + propFilename + "].");
        }
    }
    
    /**
     * @return Returns the dbConnectionString.
     */
    public static String getDbConnectionString() {
        return dbConnectionString;
    }
    
    /**
     * @param dbConnectionString
     *            The dbConnectionString to set.
     */
    public static void setDbConnectionString(String dbConnectionString) {
        Configuration.dbConnectionString = dbConnectionString;
    }
    
    /**
     * @return Returns the driverClasses.
     */
    public static String getDriverClasses() {
        return driverClasses;
    }
    
    /**
     * @param driverClasses
     *            The driverClasses to set.
     */
    public static void setDriverClasses(String driverClasses) {
        Configuration.driverClasses = driverClasses;
    }
    
    /**
     * @return Returns the password.
     */
    public static String getPassword() {
        return Password;
    }
    
    /**
     * @param password
     *            The password to set.
     */
    public static void setPassword(String password) {
        Password = password;
    }
    
    /**
     * @return Returns the userName.
     */
    public static String getUserName() {
        return UserName;
    }
    
    /**
     * @param userName
     *            The userName to set.
     */
    public static void setUserName(String userName) {
        UserName = userName;
    }
    
    /**
     * @return Returns the sentinelSrv_EndPoint.
     */
    public static String getSentinelSrv_EndPoint() {
        return SentinelSrv_EndPoint.trim();
    }
    
    /**
     * @param sentinelSrv_EndPoint
     *            The sentinelSrv_EndPoint to set.
     */
    public static void setSentinelSrv_EndPoint(String sentinelSrv_EndPoint) {
        SentinelSrv_EndPoint = sentinelSrv_EndPoint;
    }
    
    /**
     * @return Returns the usrMgmSrv_EndPoint.
     */
    public static String getUsrMgmSrv_EndPoint() {
        return usrMgmSrv_EndPoint.trim();
    }
    
    /**
     * @param usrMgmSrv_EndPoint
     *            The usrMgmSrv_EndPoint to set.
     */
    public static void setUsrMgmSrv_EndPoint(String usrMgmSrv_EndPoint) {
        Configuration.usrMgmSrv_EndPoint = usrMgmSrv_EndPoint;
    }
    
    /**
     * @return Returns the assistSrv_EndPoint.
     */
    public static String getAssistSrv_EndPoint() {
        return AssistSrv_EndPoint.trim();
    }
    
    /**
     * @return Returns the sender_Email.
     */
    public static String getSender_Email() {
        return Sender_Email;
    }
    
    /**
     * @param sender_Email
     *            The sender_Email to set.
     */
    public static void setSender_Email(String sender_Email) {
        Sender_Email = sender_Email;
    }
    
    /**
     * @return Returns the sMTP_Host.
     */
    public static String getSMTP_Host() {
        return SMTP_Host;
    }
    
    /**
     * @param host
     *            The sMTP_Host to set.
     */
    public static void setSMTP_Host(String host) {
        SMTP_Host = host;
    }
    
    /**
     * @return Returns the email_Image_URL.
     */
    public static String getEmail_Image_URL() {
        return Email_Image_URL;
    }
    
    /**
     * @return Returns the daily_JobSchedule_Hour.
     */
    public static int getDaily_JobSchedule_Hour() {
        return Daily_JobSchedule_Hour;
    }
    
    /**
     * @return Returns the Daily_JobSchedule_Min.
     */
    public static int getDaily_JobSchedule_Min() {
        return Daily_JobSchedule_Min;
    }
    
    /**
     * @return Returns the fromEmailIDForException.
     */
    public static String getFromEmailIDForException() {
        return fromEmailIDForException;
    }
    
    /**
     * @return Returns the hostNameForException.
     */
    public static String getHostNameForException() {
        return hostNameForException;
    }
    
    /**
     * @return Returns the subjectForException.
     */
    public static String getSubjectForException() {
        return subjectForException;
    }
    
    /**
     * @return Returns the toEmailIDForException.
     */
    public static String getToEmailIDForException() {
        return toEmailIDForException;
    }
    /**
     * @return Returns the sentinelSrv_Mode.
     */
    public static String getSentinelSrv_Mode() {
        return sentinelSrv_Mode;
    }
}