package dev.zing.framework.services.validation;

public class ValidationError {
	
	private String propertyName;
	private String[] propertyValues;
	private String propertyValue;
	private String errorCode;
	private String errorMessage;

	/**
	 * @return Returns the errorCode.
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode The errorCode to set.
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return Returns the errorMessage.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage The errorMessage to set.
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
    /**
     * @return Returns the propertyName.
     */
    public String getPropertyName() {
        return propertyName;
    }
    /**
     * @param propertyName The propertyName to set.
     */
    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }
    /**
     * @return Returns the propertyValue.
     */
    public String getPropertyValue() {
        return propertyValue;
    }
    /**
     * @param propertyValue The propertyValue to set.
     */
    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }
    /**
     * @return Returns the propertyValues.
     */
    public String[] getPropertyValues() {
        return propertyValues;
    }
    /**
     * @param propertyValues The propertyValues to set.
     */
    public void setPropertyValues(String[] propertyValues) {
        this.propertyValues = propertyValues;
    }
    

	public String getEncodedErrorMessage() {
		return encodeValue(errorMessage);
	}

    private String encodeValue(String text1) {
        String tmp = text1;
        String tmpencoded = "";
        String tmpchar = "";
        int asciitmp = 0;
        for (int i = 0; i < tmp.length(); i++) {
            asciitmp = tmp.charAt(i);
            tmpchar = "" + asciitmp;
            while (tmpchar.length() < 3) {
                tmpchar = "0" + tmpchar;
            }
            tmpencoded = tmpencoded + tmpchar;
        }
        return tmpencoded;
    }
}
