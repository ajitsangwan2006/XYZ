package dev.zing.framework.services.validation;

import java.util.Hashtable;
import java.util.Iterator;

public class ValidationErrors {
	
	private Hashtable validationErrors = new Hashtable();

	/**
	 * @return Returns the validationError.
	 */
	public Hashtable getValidationErrors() {
		return validationErrors;
	}
	
	public Iterator getValidationErrorsIterator() {
		return validationErrors.keySet().iterator();
	}
	
	/**
	 * @param validationError The validationError to set.
	 */
	public void addValidationError(String propertyName, ValidationError validationError) {
		this.validationErrors.put(propertyName, validationError);
	}
	
	public void add(ValidationErrors errors) {
	    if (errors != null && errors.getValidationErrors() != null) {
	        this.validationErrors.putAll(errors.getValidationErrors());
	    }
	}
	
	public void removeValidationError(String propertyName) {
	    validationErrors.remove(propertyName);
	}
}
