package dev.zing.framework.services.validation;

public class ValidationProperty {

    private String name = null;
    private String validationType = null;
    private Integer lowerIntegerBound = null;
    private Integer upperIntegerBound = null;
    private Float lowerFloatBound = null;
    private Float upperFloatBound = null;
   
    public ValidationProperty(String name, String validationType) {
        super();
        this.name = name;
        this.validationType = validationType;
    }
    
    public ValidationProperty(String name, String validationType, Integer lowerIntegerBound, Integer upperIntegerBound) {
        super();
        this.name = name;
        this.validationType = validationType;
        this.lowerIntegerBound = lowerIntegerBound;
        this.upperIntegerBound = upperIntegerBound;
    }
    
    public ValidationProperty(String name, String validationType, Float lowerFloatBound, Float upperFloatBound) {
        super();
        this.name = name;
        this.validationType = validationType;
        this.lowerFloatBound = lowerFloatBound;
        this.upperFloatBound = upperFloatBound;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getValidationType() {
        return validationType;
    }
    
    public void setValidationType(String type) {
        this.validationType = type;
    }

    public Integer getLowerIntegerBound() {
        return lowerIntegerBound;
    }

    public void setLowerIntegerBound(Integer lowerBound) {
        this.lowerIntegerBound = lowerBound;
    }

    public Integer getUpperIntegerBound() {
        return upperIntegerBound;
    }

    public void setUpperIntegerBound(Integer upperBound) {
        this.upperIntegerBound = upperBound;
    }

    public Float getLowerFloatBound() {
        return lowerFloatBound;
    }

    public void setLowerFloatBound(Float lowerFloatBound) {
        this.lowerFloatBound = lowerFloatBound;
    }

    public Float getUpperFloatBound() {
        return upperFloatBound;
    }

    public void setUpperFloatBound(Float upperFloatBound) {
        this.upperFloatBound = upperFloatBound;
    }
}
