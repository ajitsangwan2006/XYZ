package dev.zing.framework.services.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ValidationUnit {

    private String name = null;
    private List validationProperty = new ArrayList();
    private Map validationPropertyMap = new HashMap();
    
    public List getValidationProperty() {
        return validationProperty;
    }

    public void addValidationProperty(ValidationProperty validationProperty) {
        if (!this.validationPropertyMap.containsKey(validationProperty.getName())) {
            this.validationProperty.add(validationProperty);
            this.validationPropertyMap.put(validationProperty.getName(), validationProperty);
        } else {
            ValidationProperty vProperty = (ValidationProperty)this.validationPropertyMap.get(validationProperty.getName());
            vProperty.setValidationType(vProperty.getValidationType() + ", " + validationProperty.getValidationType());
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
