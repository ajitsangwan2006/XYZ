package dev.zing.framework.services.validation;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.beanutils.PropertyUtilsBean;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.util.ValidationUtils;

public class ValidationRegisterer {

    private static ValidationRegisterer validationRegisterer = new ValidationRegisterer();
    private static PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
    private static Map validationUnitMap = new HashMap();
    private Map javaScriptUnit = new HashMap();
    
    private ValidationRegisterer() {
        super();
    }
    
    public static ValidationRegisterer getInstance() {
        return validationRegisterer;
    }
    
    public void registerProperty(String className, String propertyName, String validationType) {
        ValidationProperty validationProperty = new ValidationProperty(propertyName, validationType);
        ValidationUnit validationUnit = null;
        if (!validationUnitMap.containsKey(className)) {
            validationUnit = new ValidationUnit();
            validationUnit.setName(className);
            validationUnitMap.put(className, validationUnit);
        } else {
            validationUnit = (ValidationUnit) validationUnitMap.get(className);
        }
        validationUnit.addValidationProperty(validationProperty);
    }
    
    public void registerProperty(String className, String propertyName, String validationType, int lowerBound, int upperBound) {
        ValidationProperty validationProperty = new ValidationProperty(propertyName, validationType, new Integer(lowerBound), new Integer(upperBound));
        ValidationUnit validationUnit = null;
        if (!validationUnitMap.containsKey(className)) {
            validationUnit = new ValidationUnit();
            validationUnit.setName(className);
            validationUnitMap.put(className, validationUnit);
        } else {
            validationUnit = (ValidationUnit) validationUnitMap.get(className);
        }
        validationUnit.addValidationProperty(validationProperty);
    }
    
    public void registerProperty(String className, String propertyName, String validationType, float lowerBound, float upperBound) {
        ValidationProperty validationProperty = new ValidationProperty(propertyName, validationType, new Float(lowerBound), new Float(upperBound));
        ValidationUnit validationUnit = null;
        if (!validationUnitMap.containsKey(className)) {
            validationUnit = new ValidationUnit();
            validationUnit.setName(className);
            validationUnitMap.put(className, validationUnit);
        } else {
            validationUnit = (ValidationUnit) validationUnitMap.get(className);
        }
        validationUnit.addValidationProperty(validationProperty);
    }
    
    public ValidationUnit getValidationUnit(String className) {
        ValidationUnit validationUnit = null;
        if (validationUnitMap.containsKey(className)) {
            validationUnit = (ValidationUnit) validationUnitMap.get(className);
        }
        return validationUnit;
    }

    public String[] getJavaScriptValidationCode(Model model) {
        model.registerJavaScriptValidation();
        if (javaScriptUnit.containsKey(model.getClass().getName())) {
            return (String[]) javaScriptUnit.get(model.getClass().getName());
        } else {
            String[] javaScript = createNewJavaScriptValidationCode(getValidationUnit(model.getClass().getName()));
            javaScriptUnit.put(model.getClass().getName(), javaScript);
            return javaScript;
        }
    }

    private String[] createNewJavaScriptValidationCode(ValidationUnit validationUnit) {
        String[] javaScript = new String[2];
        javaScript[0] = "";
        javaScript[1] = "";
        if (validationUnit == null) {
            return javaScript;
        }
        System.out.println(validationUnit.getName());

        Iterator propertyIterator = validationUnit.getValidationProperty().listIterator();
        if (propertyIterator == null) {
            return javaScript;
        }
        ValidationProperty property = null;
                
        while (propertyIterator.hasNext()) {
            property = (ValidationProperty) propertyIterator.next();
            log("createNewJavaScriptValidationCode - Property Name: "+property.getName());
            log("createNewJavaScriptValidationCode - Property Type: "+property.getValidationType());

            String propertyName = getPropertyName(property.getName());
            String validationType = property.getValidationType();
            
            String[] validationTypeTokens = validationType.split(",");
            for (int k=0; k < validationTypeTokens.length; k++) {
                validationType = validationTypeTokens[k].trim();
                log("createNewJavaScriptValidationCode - preparinging javascript for type: "+validationType);
                if (validationType.equals("notNull") || validationType.equals("dateNotNull") || validationType.equals("email") || validationType.equals("alphaNumeric") || validationType.equals("numeric") || validationType.equals("integer") || validationType.equals("alpha")) {
                    if (validationType.equals("dateNotNull")) {
                        javaScript[0] += "validateDateNotNull('" + propertyName + "'); ";
                    }
                    javaScript[0] += "if (document.form." + propertyName + ") {";
                    if (validationType.equals("notNull")) {
                        javaScript[0] += "validateNotNull('" + propertyName + "'); ";
                    }
                    if (validationType.equals("email")) {
                        javaScript[0] += "validateEmail('" + propertyName + "'); ";
                    }
                    if (validationType.equals("alphaNumeric")) {
                        javaScript[0] += "validateAlphaNumeric('" + propertyName + "'); ";
                    }
                    if (validationType.equals("numeric")) {
                        javaScript[0] += "validateNumeric('" + propertyName + "'); ";
                    }
                    if (validationType.equals("integer")) {
                        javaScript[0] += "validateInteger('" + propertyName + "'); ";
                    }
                    if (validationType.equals("alpha")) {
                        javaScript[0] += "validateAlpha('" + propertyName + "'); ";
                    }
                    javaScript[0] += "}";
                }
                
                if (validationType.equals("inIntegerRange") || validationType.equals("inFloatRange")) {
                    javaScript[1] += "if (document.form." + propertyName + ") {";
                    if (validationType.equals("inIntegerRange") || validationType.equals("inFloatRange")) {
                        log(propertyName + " - " + property.getLowerIntegerBound() + " - " + property.getUpperIntegerBound());
                        javaScript[1] += "if (!inNumericRange('" + propertyName + "', " + property.getLowerIntegerBound().intValue() + ", " + property.getUpperIntegerBound().intValue() + ")) { ";
                        javaScript[1] += "return false;";
                        javaScript[1] += "}";
                    }
                    javaScript[1] += "}";
                }
            }
        }
        return javaScript;
    }
    
    public ValidationErrors validate(Model model) {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        ValidationUnit validationUnit = null;
        if (validationUnitMap.containsKey(model.getClass().getName())) {
            validationUnit = (ValidationUnit) validationUnitMap.get(model.getClass().getName());
            List validationPropertyList = validationUnit.getValidationProperty();
            for (int x=0; x < validationPropertyList.size(); x++) {
                ValidationProperty validationProperty = (ValidationProperty)validationPropertyList.get(x);
                String propertyName = getPropertyName(validationProperty.getName());
                Class propertyClassType = getPropertyType(model, propertyName);
                if (validationProperty.getValidationType().equals("notNull") || validationProperty.getValidationType().equals("dateNotNull")) {
                    if (propertyClassType.getName().equals("java.lang.String")) {
                        validationUtil.required(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                    } else {
                        validationUtil.requiredObjectValue(propertyName, getPropertyValue(model, validationProperty.getName()), errors);
                    }
                }
                if (validationProperty.getValidationType().equals("email")) {
                    validationUtil.isEmail(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                }
                if (validationProperty.getValidationType().equals("alphaNumeric")) {
                    validationUtil.isAlphaNumeric(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                }
                if (validationProperty.getValidationType().equals("numeric")) {
                    validationUtil.isNumeric(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                }
                if (validationProperty.getValidationType().equals("integer")) {
                    validationUtil.isInteger(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                }
                if (validationProperty.getValidationType().equals("alpha")) {
                    validationUtil.isAlpha(propertyName, getStringPropertyValue(model, validationProperty.getName()), errors);
                }
                if (validationProperty.getValidationType().equals("inIntegerRange")) {
                    validationUtil.isIntegerInRange(propertyName, getIntegerPropertyValue(model, validationProperty.getName()), validationProperty.getLowerIntegerBound().intValue(), validationProperty.getUpperIntegerBound().intValue(), errors);
                }
                if (validationProperty.getValidationType().equals("inFloatRange")) {
                    validationUtil.isFloatInRange(propertyName, getFloatPropertyValue(model, validationProperty.getName()), validationProperty.getLowerFloatBound().floatValue(), validationProperty.getUpperFloatBound().floatValue(), errors);
                }
            }
        }
        return errors;
    }    

    private String getPropertyName(String propertyName) {
        log("getPropertyName -1 "+ propertyName);
        log("getPropertyName -2 "+ propertyName.split("."));
        String[] propertyTokens = propertyName.split("\\.");
        log("getPropertyName -3 "+ propertyTokens.length);
        if (propertyTokens.length == 1) {
            return propertyTokens[0];
        } else if (propertyTokens.length == 2) {
            return propertyTokens[1];
        }
        return null;
    }
    private String getStringPropertyValue(Model model, String propertyName) {
        Object propValue = getPropertyValue(model, propertyName);
        if (propValue == null) {
            return null;
        }
        return (String) propValue;
    }       
    private Integer getIntegerPropertyValue(Model model, String propertyName) {
        Object propValue = getPropertyValue(model, propertyName);
        if (propValue == null) {
            return null;
        }
        return (Integer) propValue;
    }       
    private Float getFloatPropertyValue(Model model, String propertyName) {
        Object propValue = getPropertyValue(model, propertyName);
        if (propValue == null) {
            return null;
        }
        return (Float) propValue;
    }      
    private Date getDatePropertyValue(Model model, String propertyName) {
        Object propValue = getPropertyValue(model, propertyName);
        if (propValue == null) {
            return null;
        }
        return (Date) propValue;
    }
    private Object getPropertyValue(Model model, String propertyName) {
        if (model == null || propertyName == null) {
            return null;
        }
        
        String[] propertyTokens = propertyName.split("\\.");
        
        Object propValue = null;
        try {
            if (propertyTokens.length == 1) {
                propValue = getPropertyUtils().getProperty(model, propertyName);
            } else if (propertyTokens.length == 2) {
                Object propIdentifier = getPropertyUtils().getProperty(model, "id");
                propValue = getPropertyUtils().getProperty(propIdentifier, propertyTokens[1]);
            }
            return propValue;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }
    private Class getPropertyType(Model model, String propertyName) {
        if (model == null || propertyName == null) {
            return null;
        }
        
        String[] propertyTokens = propertyName.split("\\.");
        
        Class propValue = null;
        try {
            if (propertyTokens.length == 1) {
                propValue = getPropertyUtils().getPropertyType(model, propertyName);
            } else if (propertyTokens.length == 2) {
                Object propIdentifier = getPropertyUtils().getProperty(model, "id");
                propValue = getPropertyUtils().getPropertyType(propIdentifier, propertyTokens[1]);
            }
            return propValue;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void log(String msg) {
        System.out.println(msg);
    }
    
    private PropertyUtilsBean getPropertyUtils() {
        return propertyUtilsBean;
    }
}
