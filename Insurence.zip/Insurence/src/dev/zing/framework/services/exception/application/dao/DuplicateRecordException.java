package dev.zing.framework.services.exception.application.dao;

import dev.zing.framework.services.exception.application.ApplicationException;
import dev.zing.framework.services.validation.ValidationErrors;

public class DuplicateRecordException extends ApplicationException  {

    private ValidationErrors validationErrors;
        
    public DuplicateRecordException(String msg) {
        super(msg);        
    }  
    
    public DuplicateRecordException(ValidationErrors validationErrors) {
        this.validationErrors = validationErrors;
    }
    
    public ValidationErrors getValidationErrors() {
        return validationErrors;
    }    
}
