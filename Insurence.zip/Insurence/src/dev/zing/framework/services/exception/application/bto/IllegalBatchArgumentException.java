package dev.zing.framework.services.exception.application.bto;

public class IllegalBatchArgumentException extends BatchException {

    public IllegalBatchArgumentException(Exception ex) {
        super(ex);
    }

    public IllegalBatchArgumentException(String message) {
        super(message);
    }

    public IllegalBatchArgumentException(String message, Throwable cause) {
        super(message, cause);
    }

    public IllegalBatchArgumentException(Throwable cause) {
        super(cause);
    }
}
