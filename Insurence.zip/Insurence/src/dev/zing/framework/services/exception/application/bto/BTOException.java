
package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;


public class BTOException extends ApplicationException   {
    
	public BTOException(Exception ex) {
		super(ex);
	}
	
	public BTOException(String message) {
		super(message);
	}
	
	public BTOException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public BTOException(Throwable cause) {
		super(cause);
	}
}
