package dev.zing.framework.services.exception.handler;


import dev.zing.framework.services.exception.system.base.SystemException;
import dev.zing.framework.util.LoggerUtils;

public class ConfigurationExceptionHandler extends SystemExceptionHandler {
    
    public void handleException(Throwable th, String message) throws SystemException {
        LoggerUtils.getLogger().fatal("Configuration Exception: " + th);
        throw new SystemException(th);
    }
    public void handleException(String message) throws SystemException {
        LoggerUtils.getLogger().fatal("Configuration Exception: " + message);
        throw new SystemException(message);
    }
}
