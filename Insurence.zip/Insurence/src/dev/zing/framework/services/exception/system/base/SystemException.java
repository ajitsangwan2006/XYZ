package dev.zing.framework.services.exception.system.base;

public class SystemException extends RuntimeException {
    
    private StackTraceElement[] stackTrace = null;

    private String exceptionTrace = null;

    private String exceptionMessage = null;

    private String errorOzCode = null;

    public SystemException(Exception ex) {
        super();
        stackTrace = ex.getStackTrace();
        exceptionTrace = ex.toString();
        exceptionMessage = ex.getMessage();
    }

    public SystemException(String message) {
        super(message);
    }

    public SystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public SystemException(Throwable cause) {
        super(cause);
    }

    public String getErrorOzCode() {
        return errorOzCode;
    }

    public void setErrorOzCode(String errorOzCode) {
        this.errorOzCode = errorOzCode;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public String getExceptionTrace() {
        return exceptionTrace;
    }

    public void setExceptionTrace(String exceptionTrace) {
        this.exceptionTrace = exceptionTrace;
    }

    public StackTraceElement[] getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace(StackTraceElement[] stackTrace) {
        this.stackTrace = stackTrace;
    }
}
