package dev.zing.framework.services.exception.application.dao;

import dev.zing.framework.services.exception.system.base.SystemException;

public class InvalidDAOArgumentException extends SystemException  {

    public InvalidDAOArgumentException(Exception ex) {
        super(ex);
    }

    public InvalidDAOArgumentException(String message) {
        super(message);
    }

    public InvalidDAOArgumentException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidDAOArgumentException(Throwable cause) {
        super(cause);
    }
}
