
package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;


public class AccessDeniedException extends ApplicationException   {
    
	public AccessDeniedException(Exception ex) {
		super(ex);
	}
	
	public AccessDeniedException(String message) {
		super(message);
	}
	
	public AccessDeniedException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public AccessDeniedException(Throwable cause) {
		super(cause);
	}
}
