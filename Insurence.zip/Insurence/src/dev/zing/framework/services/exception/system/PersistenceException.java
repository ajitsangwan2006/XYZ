
package dev.zing.framework.services.exception.system;

import dev.zing.framework.services.exception.system.base.SystemException;

public class PersistenceException extends SystemException {
    
	public PersistenceException(Exception ex) {
		super(ex);
	}
	
	public PersistenceException(String message) {
		super(message);
	}
	
	public PersistenceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public PersistenceException(Throwable cause) {
		super(cause);
	}
}
