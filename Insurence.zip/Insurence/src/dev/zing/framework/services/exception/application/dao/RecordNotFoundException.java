package dev.zing.framework.services.exception.application.dao;

import dev.zing.framework.services.exception.system.base.SystemException;
import dev.zing.framework.services.validation.ValidationErrors;


public class RecordNotFoundException extends SystemException  {

    private ValidationErrors validationErrors;
        
    public RecordNotFoundException(String msg) {
        super(msg);        
    }  
    
    public RecordNotFoundException(ValidationErrors validationErrors) {
        super("");
        this.validationErrors = validationErrors;
    }
    
    public ValidationErrors getValidationErrors() {
        return validationErrors;
    }    
    
    public RecordNotFoundException(Exception ex) {
        super(ex);
    }

    public RecordNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public RecordNotFoundException(Throwable cause) {
        super(cause);
    }
}
