package dev.zing.framework.services.exception.handler;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import dev.zing.framework.config.Configuration;
import dev.zing.framework.services.exception.system.base.SystemException;
import dev.zing.framework.util.LoggerUtils;



public class SystemExceptionHandler {

    public SystemExceptionHandler() {
        super();
    }
    
    public void handleException(Throwable th, String message) throws SystemException {
        LoggerUtils.getLogger().fatal(message, th);                
        String errorCode = new Long(System.currentTimeMillis()).toString();
        String message1 = "The application could not establish connection with the service.";
        reportToTechnicalSupportStaff(message1, errorCode);
        throw new SystemException (th);
    }

    public void reportToTechnicalSupportStaff(String messg, String errorCode) {

        String host = Configuration.getHostNameForException();
        String from = Configuration.getFromEmailIDForException();
        String supportMailID = Configuration.getToEmailIDForException();
        String Subject = Configuration.getSubjectForException();

        LoggerUtils.getDaoLogger().fatal(messg);

        String message = "Dear Sir,\n\n";
        message += "A technical problem occured from TLF Management System with Error Code: " + errorCode + ".\n\n";
        message += messg + "\n\n";
        message += "The problem reported on: " + new java.util.Date() + ". \n\n";
        message += "With best regards. \n";
        message += "Automated Error Reporting Service.\n";
       
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", host);
            Session session = Session.getInstance(props);
            MimeMessage msg = new MimeMessage(session);
            
            msg.setFrom(new InternetAddress(from));

            InternetAddress toAddress = new InternetAddress(supportMailID);
            msg.addRecipient(Message.RecipientType.TO, toAddress);
            msg.setSentDate(new Date());
            msg.setSubject(Subject);

            Multipart mp = new MimeMultipart();
            MimeBodyPart mbp1 = new MimeBodyPart();

            mbp1.setContent(message, "text/plain");
            mp.addBodyPart(mbp1);
            msg.setContent(mp);
            msg.saveChanges();

            Transport.send(msg);
            
        } catch (SendFailedException e) {
            LoggerUtils.getJdbcWrapperLogger().fatal("Exception while sending the message :" + e.getMessage());
        } catch (MessagingException e) {
            LoggerUtils.getJdbcWrapperLogger().fatal("Exception while sending the message :" + e.getMessage());
        }

    }

}
