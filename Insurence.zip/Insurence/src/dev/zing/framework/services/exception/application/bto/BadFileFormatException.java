
package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;




public class BadFileFormatException extends ApplicationException  {
    
	public BadFileFormatException(Exception ex) {
		super(ex);
	}
	
	public BadFileFormatException(String message) {
		super(message);
	}
	
	public BadFileFormatException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public BadFileFormatException(Throwable cause) {
		super(cause);
	}
}
