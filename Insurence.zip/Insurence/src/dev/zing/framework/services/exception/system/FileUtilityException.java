
package dev.zing.framework.services.exception.system;

import dev.zing.framework.services.exception.system.base.SystemException;

public class FileUtilityException extends SystemException {
    
	public FileUtilityException(Exception ex) {
		super(ex);
	}
	
	public FileUtilityException(String message) {
		super(message);
	}
	
	public FileUtilityException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public FileUtilityException(Throwable cause) {
		super(cause);
	}
}
