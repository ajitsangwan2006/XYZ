package dev.zing.framework.services.exception.application.dao;

import dev.zing.framework.services.exception.system.base.SystemException;

public class DAOException extends SystemException  {

    public DAOException(Exception ex) {
        super(ex);
    }

    public DAOException(String message) {
        super(message);
    }

    public DAOException(String message, Throwable cause) {
        super(message, cause);
    }

    public DAOException(Throwable cause) {
        super(cause);
    }
}
