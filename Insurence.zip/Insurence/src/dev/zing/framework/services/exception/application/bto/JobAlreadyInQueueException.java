
package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;


public class JobAlreadyInQueueException extends ApplicationException {
    
	public JobAlreadyInQueueException(Exception ex) {
		super(ex);
	}
	
	public JobAlreadyInQueueException(String message) {
		super(message);
	}
	
	public JobAlreadyInQueueException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public JobAlreadyInQueueException(Throwable cause) {
		super(cause);
	}
}
