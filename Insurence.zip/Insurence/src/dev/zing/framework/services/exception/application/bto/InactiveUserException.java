package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;



public class InactiveUserException extends ApplicationException  {

    public InactiveUserException(Exception ex) {
        super(ex);
    }

    public InactiveUserException(String message) {
        super(message);
    }

    public InactiveUserException(String message, Throwable cause) {
        super(message, cause);
    }

    public InactiveUserException(Throwable cause) {
        super(cause);
    }
}
