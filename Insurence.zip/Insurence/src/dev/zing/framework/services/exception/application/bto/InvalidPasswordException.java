package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;
import dev.zing.framework.services.validation.ValidationErrors;


public class InvalidPasswordException extends ApplicationException {

    private ValidationErrors validationErrors;
        
    public InvalidPasswordException(String msg) {
        super(msg);        
    }  
    
    public InvalidPasswordException(ValidationErrors validationErrors) {        
        this.validationErrors = validationErrors;
    }
    
    public ValidationErrors getValidationErrors() {
        return validationErrors;
    }
}
