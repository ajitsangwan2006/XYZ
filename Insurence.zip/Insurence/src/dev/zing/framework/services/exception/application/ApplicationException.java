package dev.zing.framework.services.exception.application;

import java.io.Serializable;
import java.util.Vector;

public class ApplicationException extends Exception implements Serializable {

	private static final long serialVersionUID = 1L;

	private StackTraceElement[] stackTrace = null;

    private String exceptionTrace = null;

    private String exceptionMessage = null;

    private Vector errorOzCodes = new Vector(0);

    public ApplicationException() {
        
    }
    public ApplicationException(Exception ex) {
        super(ex);
        stackTrace = ex.getStackTrace();
        exceptionTrace = ex.toString();
        exceptionMessage = ex.getMessage();
    }

    public ApplicationException(String message) {
        super(message);
        exceptionMessage = message;
    }

    public ApplicationException(String message, Throwable cause) {
        super(message, cause);
        stackTrace = cause.getStackTrace();
        exceptionTrace = cause.toString();
        exceptionMessage = cause.getMessage();
    }

    public ApplicationException(Throwable cause) {
        super(cause);
        stackTrace = cause.getStackTrace();
        exceptionTrace = cause.toString();
        exceptionMessage = cause.getMessage();
    }

    public String[] getErrorOzCode() {
        String[] elements = new String[errorOzCodes.size()];
        elements = (String[]) errorOzCodes.toArray(elements);
        return elements;
    }

    public void setErrorOzCode(String errorOzCode) {
        this.errorOzCodes.add(errorOzCode);
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public String getExceptionTrace() {
        return exceptionTrace;
    }

    public void setExceptionTrace(String exceptionTrace) {
        this.exceptionTrace = exceptionTrace;
    }

    public StackTraceElement[] getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace(StackTraceElement[] stackTrace) {
        this.stackTrace = stackTrace;
    }
}
