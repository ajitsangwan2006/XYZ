
package dev.zing.framework.services.exception.system;

import dev.zing.framework.services.exception.system.base.SystemException;

public class ConfigurationException extends SystemException {
    
	public ConfigurationException(Exception ex) {
		super(ex);
	}
	
	public ConfigurationException(String message) {
		super(message);
	}
	
	public ConfigurationException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public ConfigurationException(Throwable cause) {
		super(cause);
	}
}
