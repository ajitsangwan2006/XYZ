
package dev.zing.framework.services.exception.application.bto;

public class InvalidTLFItemException extends Exception {
	
	public InvalidTLFItemException(Exception ex) {
		super(ex);
	}
	
	public InvalidTLFItemException(String message) {
		super(message);
	}
	
	public InvalidTLFItemException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public InvalidTLFItemException(Throwable cause) {
		super(cause);
	}
}
