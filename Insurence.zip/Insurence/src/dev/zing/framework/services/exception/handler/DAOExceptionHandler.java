package dev.zing.framework.services.exception.handler;


import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.system.PersistenceException;
import dev.zing.framework.util.LoggerUtils;

public class DAOExceptionHandler extends SystemExceptionHandler {

    public void handleAndReThrowException(DAOException ex) throws PersistenceException {
        String message = "DAOException raised: \n\n";
        LoggerUtils.getLogger().fatal(message, ex);
        message = message + ex.getExceptionTrace() + "\n\n";
               
        StackTraceElement[] sct = ex.getStackTrace();
        LoggerUtils.getLogger().fatal("StackTraceElement element length is: "+sct);
        for (int i=0; i<sct.length; i++) {
            message = message + sct[i].toString() + "\n\n";
        }
        
       String errorCode =  new Long(System.currentTimeMillis()).toString();
        ex.setErrorOzCode(errorCode);
             
        LoggerUtils.getLogger().fatal("Sending the email to Support Team");
        
        reportToTechnicalSupportStaff(message, errorCode);

        PersistenceException pe = new PersistenceException(ex);
        
        throw pe;
    }

    

}
