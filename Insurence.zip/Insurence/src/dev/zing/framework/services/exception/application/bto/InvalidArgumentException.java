package dev.zing.framework.services.exception.application.bto;

import dev.zing.framework.services.exception.application.ApplicationException;
import dev.zing.framework.services.validation.ValidationErrors;


public class InvalidArgumentException extends ApplicationException {

    private ValidationErrors validationErrors;
        
    public InvalidArgumentException(String msg) {
        super(msg);        
    }  
    
    public InvalidArgumentException(ValidationErrors validationErrors) {        
        this.validationErrors = validationErrors;
    }
    
    public ValidationErrors getValidationErrors() {
        return validationErrors;
    }
}
