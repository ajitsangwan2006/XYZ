
package dev.zing.framework.services.exception.system;

import dev.zing.framework.services.exception.system.base.SystemException;

public class CommunicationException extends SystemException {
    
	public CommunicationException(Exception ex) {
		super(ex);
	}
	
	public CommunicationException(String message) {
		super(message);
	}
	
	public CommunicationException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public CommunicationException(Throwable cause) {
		super(cause);
	}
}
