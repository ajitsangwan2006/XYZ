package dev.zing.framework.services.exception.handler;

import dev.zing.framework.services.exception.system.base.SystemException;
import dev.zing.framework.util.LoggerUtils;

public class ProgrammingExceptionHandler extends SystemExceptionHandler {

    public void handleException(Throwable th, String message) throws SystemException {

        LoggerUtils.getLogger().fatal(message, th);
        
        String errorCode = new Long(System.currentTimeMillis()).toString();

        String message1 = "The application could not establish connection with the database server. The details are as follows:\n\n";
        message1 += th.getMessage();

        reportToTechnicalSupportStaff(message, errorCode);

        SystemException pe = new SystemException(th);

        throw pe;
    }

}
