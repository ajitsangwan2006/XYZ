
package dev.zing.framework.services.logging;

import org.apache.log4j.Logger;

public class LoggerAdapterImpl implements LoggerAdapter {
	
    private Logger logger = null;
    	
	public LoggerAdapterImpl(String loggerName) {
		super();
		logger = Logger.getLogger(loggerName);
	}
	
    public void fatal(String msg) {
    	logger.fatal(msg);
    	return;
    }

    public void fatal(String msg, Throwable th) {
    	logger.fatal(msg, th);
    	return;
    }
    
    public void error(String msg) {
    	logger.error(msg);
    	return;
    }

    public void error(String msg, Throwable th) {
    	logger.error(msg, th);
    	return;
    }
    
    public void warning(String msg) {
    	logger.warn(msg);
    	return;
    }

    public void warning(String msg, Throwable th) {
    	logger.warn(msg, th);
    	return;
    }
    
    public void info(String msg) {
    	logger.info(msg);
    	return;
    }

    public void info(String msg, Throwable th) {
    	logger.info(msg, th);
    	return;
    }
    
    public void debug(String msg) {
    	logger.debug(msg);
    	return;
    }

    public void debug(String msg, Throwable th) {
    	logger.debug(msg, th);
    	return;
    }
}
