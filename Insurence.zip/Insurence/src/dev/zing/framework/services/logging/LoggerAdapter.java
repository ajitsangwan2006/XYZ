
package dev.zing.framework.services.logging;

public interface LoggerAdapter {
	
	public static final int FATAL_LOG_LEVEL = 1;
	public static final int ERROR_LOG_LEVEL = 1;
	public static final int WARNING_LOG_LEVEL = 2;
	public static final int INFO_LOG_LEVEL = 3;
	public static final int DEBUG_LOG_LEVEL = 4;

    void fatal(String msg);
    
    void fatal(String msg, Throwable th);
    
    void error(String msg);
    
    void error(String msg, Throwable th);
    
    void warning(String msg);
    
    void warning(String msg, Throwable th);
    
    void info(String msg);
    
    void info(String msg, Throwable th);
    
    void debug(String msg);
 
    void debug(String msg, Throwable th);
}
