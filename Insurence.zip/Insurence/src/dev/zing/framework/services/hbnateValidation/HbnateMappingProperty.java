package dev.zing.framework.services.hbnateValidation;

public class HbnateMappingProperty {

    private String name = null;
    private String type = null;
    private int length = 0;
    private boolean isNullable = true;

    /**
     * @return Returns the isNullable.
     */
    public boolean isNullable() {
        return isNullable;
    }
    /**
     * @param isNullable The isNullable to set.
     */
    public void setNullable(boolean isNullable) {
        this.isNullable = isNullable;
    }
    /**
     * @return Returns the length.
     */
    public int getLength() {
        return length;
    }
    /**
     * @param length The length to set.
     */
    public void setLength(int length) {
        this.length = length;
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }
    /**
     * @param type The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }
}
