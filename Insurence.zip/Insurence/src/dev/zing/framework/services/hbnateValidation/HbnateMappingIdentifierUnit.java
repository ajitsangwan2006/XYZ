package dev.zing.framework.services.hbnateValidation;

public class HbnateMappingIdentifierUnit extends HbnateMappingUnit {

    private boolean isComposite = false;

    /**
     * @return Returns the isComponent.
     */
    public boolean isComposite() {
        return isComposite;
    }

    /**
     * @param isComponent The isComponent to set.
     */
    public void setComposite(boolean isComponent) {
        this.isComposite = isComponent;
    }
}
