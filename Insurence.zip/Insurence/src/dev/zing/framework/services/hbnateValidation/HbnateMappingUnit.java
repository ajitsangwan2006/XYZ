package dev.zing.framework.services.hbnateValidation;

import java.util.ArrayList;
import java.util.List;

public class HbnateMappingUnit {

    private String name = null;
    private List hbnateMappingProperty = new ArrayList();
    
    /**
     * @return Returns the hbnateMappingProperty.
     */
    public List getHbnateMappingProperty() {
        return hbnateMappingProperty;
    }
    /**
     * @param hbnateMappingProperty The hbnateMappingProperty to set.
     */
    public void addHbnateMappingProperty(HbnateMappingProperty hbnateMappingProperty) {
        this.hbnateMappingProperty.add(hbnateMappingProperty);
    }
    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
}
