package dev.zing.framework.services.hbnateValidation;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;

import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;

public class HbnateValidator {

    private static HbnateValidator hbnateValidator = new HbnateValidator();

    private static PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
    
    private Configuration cfg = new Configuration();

    private String[] mappingFiles = null;

    private Map mappingUnit = new HashMap();
    
    private Map mappingIdentifierUnit = new HashMap();

    private Map javaScriptUnit = new HashMap();

    private HbnateValidator() {
        super();
    }

    public static HbnateValidator getInstance() {
        return hbnateValidator;
    }
    
    public String getJavaScriptValidationCode(Object instance) {
        if (javaScriptUnit.containsKey(instance.getClass().getName())) {
            return (String) javaScriptUnit.get(instance.getClass().getName());
        } else {
            log("getJavaScriptValidationCode-1: creating javascript for property...");
            String javaScript = createNewJavaScriptValidationCode(getHbnateMappingUnit(instance));
            if (javaScript == null) {
                javaScript = "";
            }
            log("getJavaScriptValidationCode-2: creating javascript for Identifier...");
            String javaScript2 = createNewJavaScriptValidationCode(getHbnateMappingIdentifierUnit(instance));
            if (javaScript != null) {
                javaScript += javaScript2;
            }
            log("getJavaScriptValidationCode-3: JavaScript is prepared...");
            javaScriptUnit.put(instance.getClass().getName(), javaScript);
            return javaScript;
        }
    }

    public ValidationErrors validate(Model model, boolean validateIdentifier, String ignoreProperties) {
        ValidationErrors errors = validate(model, validateIdentifier);
        
        String[] properties = ignoreProperties.split(",");
        for (int x=0; x<properties.length; x++) {
            String[] propertyTokens = properties[x].split("\\.");
            if (propertyTokens.length == 1) {
                errors.removeValidationError(properties[x].trim());
            } else {
                errors.removeValidationError(propertyTokens[1].trim());
            }
        }
        return errors;
    }
    
    public ValidationErrors validate(Model model, boolean validateIdentifier) {
        ValidationErrors errors = new ValidationErrors();
        if (validateIdentifier) {
            errors.add(validateIdentifier(model));
        }
        errors.add(validateProperty(model));
        return errors;
    }
    
    private ValidationErrors validateIdentifier(Model model) {
        ValidationErrors errors = new ValidationErrors();
        HbnateMappingIdentifierUnit hbnateMappingIdentifierUnit = getHbnateMappingIdentifierUnit(model);
        if (hbnateMappingIdentifierUnit == null) {
            return errors;
        }
        if(hbnateMappingIdentifierUnit.isComposite()) {
            Iterator propertyIterator = hbnateMappingIdentifierUnit.getHbnateMappingProperty().listIterator();
            Object idBeanInstance = null;
            try {
                idBeanInstance = getPropertyUtils().getProperty(model, "id");
            } catch (IllegalAccessException e1) {
                return errors;
            } catch (InvocationTargetException e1) {
                return errors;
            } catch (NoSuchMethodException e1) {
                return errors;
            }
            if (idBeanInstance == null) {
                return errors;
            }
            errors = validateModelProperty((Model)idBeanInstance, propertyIterator, errors);
            return errors;
        } else {
            Iterator propertyIterator = hbnateMappingIdentifierUnit.getHbnateMappingProperty().listIterator();
            errors = validateModelProperty(model, propertyIterator, errors);
            return errors;
        }
    }
    
    private ValidationErrors validateProperty(Model model) {
        ValidationErrors errors = new ValidationErrors();
        HbnateMappingUnit hbnateMappingUnit = getHbnateMappingUnit(model);
        if (hbnateMappingUnit == null) {
            return errors;
        }
        log(hbnateMappingUnit.getName());

        Iterator propertyIterator = hbnateMappingUnit.getHbnateMappingProperty().listIterator();
        errors = validateModelProperty(model, propertyIterator, errors);
        return errors;
    }

    private ValidationErrors validateModelProperty(Model model, Iterator propertyIterator, ValidationErrors errors) {
        if (propertyIterator == null) {
            return errors;
        }

        HbnateMappingProperty property = null;
        ValidationError error = null;

        while (propertyIterator.hasNext()) {
            property = (HbnateMappingProperty) propertyIterator.next();
            log(property.getName());
            log(property.getType());

            Object propValue;
            try {
                propValue = getPropertyUtils().getProperty(model, property.getName());
                if (property.getType().equals("string")) {
                    if (!property.isNullable()) {
                        if (GenericValidator.isBlankOrNull((String) propValue)) {
                            error = new ValidationError();
                            error.setPropertyName(property.getName());
                            error.setErrorCode("OZA-70001-1");
                            error.setErrorMessage("This field is required.");
                            errors.addValidationError(property.getName(), error);
                            continue;
                        }
                    }
                    if (propValue != null) {
                        if (!GenericValidator.maxLength((String) propValue, property.getLength())) {
                            error = new ValidationError();
                            error.setPropertyName(property.getName());
                            error.setErrorCode("OZA-70001-2");
                            error.setErrorMessage("Allowed maximum length for this field is " + property.getLength() + ".");
                            errors.addValidationError(property.getName(), error);
                            continue;
                        }
                    }
                } else {
                    if (!property.isNullable()) {
                        if (propValue == null) {
                            error = new ValidationError();
                            error.setPropertyName(property.getName());
                            error.setErrorCode("OZA-70001-1");
                            error.setErrorMessage("This field is required.");
                            errors.addValidationError(property.getName(), error);
                            continue;
                        }
                    }
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        return errors;
    }
    
    public void setMappingFiles(String[] mappings) {
        this.mappingFiles = mappings;
        loadMappingFiles();
    }

    private void loadMappingFiles() {
        if (mappingFiles != null) {
            for (int x = 0; x < mappingFiles.length; x++) {
                cfg.addURL(HbnateValidator.class.getResource(mappingFiles[x].trim()));
            }
        }
    }

    private PersistentClass getClassMapping(Object instance) {
        PersistentClass persistentClass = this.cfg.getClassMapping(instance.getClass().getName());
        return persistentClass;
    }

    private HbnateMappingIdentifierUnit getHbnateMappingIdentifierUnit(Object instance) {
        if (mappingIdentifierUnit.containsKey(instance.getClass().getName())) {
            if (mappingIdentifierUnit.containsKey(instance.getClass().getName())) {
                return (HbnateMappingIdentifierUnit) mappingIdentifierUnit.get(instance.getClass().getName());
            } else {
                return null;
            }
        } else {
            HbnateMappingIdentifierUnit hbnateMappingIdentifierUnit = createNewHbnateMappingIdentifierUnit(instance);
            if (hbnateMappingIdentifierUnit != null) {
                mappingIdentifierUnit.put(instance.getClass().getName(), hbnateMappingIdentifierUnit);
            }
            return hbnateMappingIdentifierUnit;
        }
    }

    private HbnateMappingIdentifierUnit createNewHbnateMappingIdentifierUnit(Object instance) {
        PersistentClass persistentClass = getClassMapping(instance);
        if (persistentClass == null) {
            return null;
        }
        
        Property identifierProperty = persistentClass.getIdentifierProperty();
       
        log("identifier: "+identifierProperty.getName());
        log("identifier: "+identifierProperty.getType().getName());
        log("identifier.isComposite: "+identifierProperty.isComposite());
        log("identifier.getPersistentClass: "+identifierProperty.getPersistentClass());
        log("identifier.getColumnIterator: "+identifierProperty.getColumnIterator());
        
        
        HbnateMappingIdentifierUnit hbnateMappingIdentifierUnit = new HbnateMappingIdentifierUnit();
        hbnateMappingIdentifierUnit.setName(instance.getClass().getName());
        hbnateMappingIdentifierUnit.setComposite(identifierProperty.isComposite());
        if (identifierProperty.isComposite()) {
            Column column = null;
            HbnateMappingProperty hbnateMappingProperty = null;
            Iterator columnIterator = identifierProperty.getColumnIterator();
            while (columnIterator.hasNext()) {
                column = (Column) columnIterator.next();                
                hbnateMappingProperty = new HbnateMappingProperty();
                hbnateMappingProperty.setName(column.getName());
                hbnateMappingProperty.setType(getIdentifierPropertyType(instance, column.getName()));
                hbnateMappingProperty.setLength(column.getLength());
                hbnateMappingProperty.setNullable(false);
                hbnateMappingIdentifierUnit.addHbnateMappingProperty(hbnateMappingProperty);
            }
            return hbnateMappingIdentifierUnit;
        } else {
            HbnateMappingProperty hbnateMappingProperty = new HbnateMappingProperty();
            log("identifier.getName: "+identifierProperty.getName());
            log("identifier.getType().getName(): "+identifierProperty.getType().getName());
            hbnateMappingProperty.setName(identifierProperty.getName());
            hbnateMappingProperty.setType(identifierProperty.getType().getName());

            Column column = null;
            Iterator columnIterator = identifierProperty.getColumnIterator();
            while (columnIterator.hasNext()) {
                column = (Column) columnIterator.next();                
                hbnateMappingProperty.setLength(column.getLength());
                hbnateMappingProperty.setNullable(false);
            }
            hbnateMappingIdentifierUnit.addHbnateMappingProperty(hbnateMappingProperty);
            return hbnateMappingIdentifierUnit;
        }
    }
    private String getIdentifierPropertyType(Object instance, String propertyName) {
        if (instance == null || propertyName == null) {
            return null;
	    }
        Object idBeanInstance = null;
        try {
            idBeanInstance = getPropertyUtils().getProperty(instance, "id");
        } catch (IllegalAccessException e1) {
            return null;
        } catch (InvocationTargetException e1) {
            return null;
        } catch (NoSuchMethodException e1) {
            return null;
        }
        if (idBeanInstance == null) {
            return null;
        }
        
	    Class cls = idBeanInstance.getClass();

        Field field = null;
        try {
            field = cls.getDeclaredField(propertyName);
        } catch (SecurityException e) {
            return null;
        } catch (NoSuchFieldException e) {
            return null;
        }
        if (field == null) {
            return null;
        }
        Class type = field.getType();
        if (type.isInstance(new java.lang.String())) {
            return "string";
        }
        return field.getType().getName();
    }
    
    private HbnateMappingUnit getHbnateMappingUnit(Object instance) {
        if (mappingUnit.containsKey(instance.getClass().getName())) {
            return (HbnateMappingUnit) mappingUnit.get(instance.getClass().getName());
        } else {
            HbnateMappingUnit hbnateMappingUnit = createNewHbnateMappingUnit(instance);
            if (hbnateMappingUnit != null) {
                mappingUnit.put(instance.getClass().getName(), hbnateMappingUnit);
            }
            return hbnateMappingUnit;
        }
    }
    private HbnateMappingUnit createNewHbnateMappingUnit(Object instance) {
        PersistentClass persistentClass = getClassMapping(instance);
        if (persistentClass == null) {
            return null;
        }
        log("createNewHbnateMappingUnit-1: "+persistentClass.getEntityName());
        log("createNewHbnateMappingUnit-2: "+persistentClass.getClassName());
        
        Iterator propertyIterator = persistentClass.getPropertyIterator();
        if (propertyIterator == null) {
            return null;
        }

        HbnateMappingUnit hbnateMappingUnit = createNewHbnateMappingUnit(instance.getClass().getName(), propertyIterator);
        return hbnateMappingUnit;
    }
    private HbnateMappingUnit createNewHbnateMappingUnit(String mappingUnitName, Iterator propertyIterator) {
        HbnateMappingUnit hbnateMappingUnit = new HbnateMappingUnit();
        hbnateMappingUnit.setName(mappingUnitName);

        Property property = null;
        Iterator columnIterator = null;
        Column column = null;
        HbnateMappingProperty hbnateMappingProperty = null;
        while (propertyIterator.hasNext()) {
            property = (Property) propertyIterator.next();
            log("createNewHbnateMappingUnit-3: "+property.getName());
            log("createNewHbnateMappingUnit-4: "+property.getType().getName());
            hbnateMappingProperty = new HbnateMappingProperty();
            hbnateMappingProperty.setName(property.getName());
            hbnateMappingProperty.setType(property.getType().getName());

            columnIterator = property.getColumnIterator();
            while (columnIterator.hasNext()) {
                column = (Column) columnIterator.next();
                log("createNewHbnateMappingUnit-5: "+column.getName());
                log("createNewHbnateMappingUnit-6: "+column.getLength());
                log("createNewHbnateMappingUnit-7: "+column.isNullable());
                hbnateMappingProperty.setLength(column.getLength());
                hbnateMappingProperty.setNullable(column.isNullable());
            }
            hbnateMappingUnit.addHbnateMappingProperty(hbnateMappingProperty);

        }
        return hbnateMappingUnit;        
    }
    
    private String createNewJavaScriptValidationCode(HbnateMappingUnit hbnateMappingUnit) {
        if (hbnateMappingUnit == null) {
            return null;
        }
        log(hbnateMappingUnit.getName());
        String javaScript = "";

        Iterator propertyIterator = hbnateMappingUnit.getHbnateMappingProperty().listIterator();
        if (propertyIterator == null) {
            return javaScript;
        }
        HbnateMappingProperty property = null;

        while (propertyIterator.hasNext()) {
            property = (HbnateMappingProperty) propertyIterator.next();
            log(property.getName());
            log(property.getType());

            if (property.getType().equals("java.util.Date") || property.getType().equals("timestamp")) {
                if (!property.isNullable()) {
                    javaScript += "validateDateNotNull('" + property.getName() + "'); ";
                }
            } else {
                javaScript += "if (document.form." + property.getName() + ") {";
                if (property.getType().equals("string")) {
                    javaScript += "document.form." + property.getName() + ".maxlength = " + property.getLength() + "; ";
                }
                if (property.getType().equals("int") || property.getType().equals("integer") || property.getType().equals("java.lang.Integer") || property.getType().equals("big_integer")) {
                    javaScript += "validateInteger('" + property.getName() + "'); ";
                }
                if (property.getType().equals("float") || property.getType().equals("java.lang.Float") || property.getType().equals("big_decimal")) {
                    javaScript += "validateNumeric('" + property.getName() + "'); ";
                }
                if (!property.isNullable()) {
                    javaScript += "validateNotNull('" + property.getName() + "'); ";
                }
                javaScript += "}";
            }
        }
        return javaScript;
    }

    private PropertyUtilsBean getPropertyUtils() {
        return propertyUtilsBean;
    }

    private void log(String msg) {
        //System.out.println(msg);
    }    
}
