
package dev.zing.framework.daotier.listpages;

import java.io.Serializable;
import java.util.List;

public interface PageDAO extends Serializable {
	
	public List getCurrentPageData();
	
	public int getTotalSize();
	
	public int getCurrentLength();
	
	public int getCurrentOffset();

}
