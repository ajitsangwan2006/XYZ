
package dev.zing.framework.daotier.listpages;

import java.util.List;
import java.util.Vector;

public class PageDAOImpl implements PageDAO {
    
	private static final long serialVersionUID = 1L;
	
	private int totalSize;
	private List currentPageData;
	private int currentOffset;
	private int currentLength;
	

	public PageDAOImpl() {
		currentPageData = new Vector();
		totalSize = 0;
	}
	
	public PageDAOImpl(int totalSize, List currentPageData, int currentOffset, int currentLength) {
		this.totalSize = totalSize;
		this.currentPageData = currentPageData;
		this.currentOffset = currentOffset;
		this.currentLength = currentLength;
	}

	/**
	 * @return Returns the list.
	 */
	public List getCurrentPageData() {
		return currentPageData;
	}
	/**
	 * @param list The list to set.
	 */
	public void setCurrentPageData(List list) {
		this.currentPageData = list;
	}
	/**
	 * @return Returns the totalRecord.
	 */
	public int getTotalSize() {
		return totalSize;
	}
	/**
	 * @param totalRecord The totalRecord to set.
	 */
	public void setTotalSize(int totalRecords) {
		this.totalSize = totalRecords;
	}
    /**
     * @return Returns the currentLength.
     */
    public int getCurrentLength() {
        return currentLength;
    }
    /**
     * @param currentLength The currentLength to set.
     */
    public void setCurrentLength(int currentLength) {
        this.currentLength = currentLength;
    }
    /**
     * @return Returns the currentOffset.
     */
    public int getCurrentOffset() {
        return currentOffset;
    }
    /**
     * @param currentOffset The currentOffset to set.
     */
    public void setCurrentOffset(int currentOffset) {
        this.currentOffset = currentOffset;
    }
}
