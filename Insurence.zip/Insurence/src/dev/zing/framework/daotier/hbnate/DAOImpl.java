package dev.zing.framework.daotier.hbnate;

import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class DAOImpl extends HibernateDaoSupport {

	protected Session getHibernateSession() {
		//return HibernateUtil.getSession();
		return getSession();
	}

	public void flush() {
		getHibernateSession().flush();
	}

	public void clear() {
		getHibernateSession().clear();
	}

	protected void closeSession() {
		//HibernateUtil.closeSession();
	}

	protected void closeSession(Session session) {
		//HibernateUtil.closeSession();
	}
}
