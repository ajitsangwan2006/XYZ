package dev.zing.framework.daotier.spring.hbnate;

import java.io.Serializable;


public interface DAO extends Serializable {
	
}
