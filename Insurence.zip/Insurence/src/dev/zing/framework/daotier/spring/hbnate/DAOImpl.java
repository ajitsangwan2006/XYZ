package dev.zing.framework.daotier.spring.hbnate;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.util.ListDateHelper;

public class DAOImpl extends HibernateDaoSupport {

    protected void log(String logMessage) {
        System.out.println(logMessage);
    }
    
	protected Session getHibernateSession() {
		return getSession();
	}

	public void flush() {
		getHibernateSession().flush();
	}

	public void clear() {
		getHibernateSession().clear();
	}

	protected void closeSession() {
		/*
		 * Reserved for cleanup tasks
		 */
	}

	protected void closeSession(Session session) {
		/*
		 * Reserved for cleanup tasks
		 */
	}

	protected void throwException(HibernateException hex) throws DAOException {
		hex.printStackTrace();
		throw new DAOException(hex);
	}
	
    protected int getTotalRecords(Criteria criteria) {
        criteria.setProjection(Projections.rowCount());
        int totalRecords = ((Integer) criteria.uniqueResult()).intValue();
        return totalRecords;
    }

    protected void loadBTOCriteria(ListHelper listHelper, Criteria criteria) {
        ListHelperImpl listHelperImpl = (ListHelperImpl) listHelper;
        if (listHelperImpl.getCriteriaRestrictionType() != null && listHelperImpl.getCriteriaRestrictionType().equals("Expression")) {
            Vector restrictions = listHelperImpl.getCriteriaRestrictions();
            for (int i = 0; i < restrictions.size(); i++) {
                Object expression = restrictions.elementAt(i);
                if (expression instanceof LogicalExpression) {
                    criteria.add((LogicalExpression) restrictions.elementAt(i));
                } else if (expression instanceof SimpleExpression) {
                    criteria.add((SimpleExpression) restrictions.elementAt(i));
                }
            }
        }
    }
    
    protected PageDAOImpl buildPageDAO(int startRowNo, int scrollValue, int totalRecords, Criteria criteriaForList) {
        PageDAOImpl page = new PageDAOImpl();
        page.setTotalSize(totalRecords);           
        if (startRowNo > -1) {
            criteriaForList.setFirstResult(startRowNo);
        }
        if (scrollValue > -1) {
            criteriaForList.setMaxResults(scrollValue);
        }
        List list = criteriaForList.list();        
        page.setCurrentPageData(list);
        page.setCurrentOffset(startRowNo);
        page.setCurrentLength(list.size());
        return page;
    }

    protected String prepareWildcardSearchString(String searchString) {
        if (searchString == null) {
            return null;
        }
        String preparedString = searchString;
        if (searchString.indexOf("*") > -1) {
            preparedString = searchString.replaceAll("\\*", "\\%");
        }
        if (searchString.indexOf("?") > -1) {
            preparedString = searchString.replaceAll("\\?", "\\_");
        }
        return preparedString;
    }
    
    protected ListDateHelper[] getListDateHelper(String listDateString) throws ParseException {
        /**
         * 09/05/2008-$$$-gt,09/07/2008-$$$-lt
         */    
        String[] params = listDateString.split(",");
        if (params == null || params.length == 0) {
            return null;            
        }
        Vector vector = new Vector();
        for (int i=0; i < params.length; i++) {
            String[] values = params[i].split("-\\$\\$\\$-");            
            vector.add(new ListDateHelper(values[1], (new SimpleDateFormat("MM/dd/yyyy")).parse(values[0], new ParsePosition(0))));
        }        
        return (ListDateHelper[])vector.toArray(new ListDateHelper[vector.size()]);
    }
    
    protected void addDateCriteria(Criteria criteria, String propertyName, String searchValues) throws ParseException {
        ListDateHelper[] listDateHelpers = getListDateHelper(searchValues);
        for (int i = 0; i < listDateHelpers.length; i++) {
            if (listDateHelpers[i].getComparisonType().equals("lt")) {
                criteria.add(Restrictions.lt(propertyName, listDateHelpers[i].getComparisonDate()));
            } else if (listDateHelpers[i].getComparisonType().equals("gt")) {
                criteria.add(Restrictions.gt(propertyName, listDateHelpers[i].getComparisonDate()));
            } else if (listDateHelpers[i].getComparisonType().equals("eq")) {
                Date dateFrom = listDateHelpers[i].getComparisonDate();
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(dateFrom);
                calendar.set(Calendar.HOUR, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.SECOND, 59);
                Date dateTo = calendar.getTime();
                criteria.add(Restrictions.between(propertyName, dateFrom, dateTo));
            }
        }
    }   
    
    protected void addDateCriteria(Criteria criteria, String propertyName, Date fromDate, Date toDate) throws ParseException {
        Date dateRangeFrom = fromDate;
        Date dateRangeTo = toDate;
        Calendar calendar = Calendar.getInstance();
        if(dateRangeFrom == null){
         calendar.set(1970,0,1);
         dateRangeFrom = calendar.getTime();
        }
        if(dateRangeTo == null){        
        	dateRangeTo = new Date();
        }
        /**
         * Increased day by 1 to include upper limit date.
         */
        dateRangeTo =  DateUtils.addDays(dateRangeTo, 1);
        criteria.add(Restrictions.between(propertyName, dateRangeFrom, dateRangeTo));       
     } 
    
    protected void addListCriteria(Criteria criteria, String propertyName, String searchValues) {
        String[] values_str = searchValues.split(",");
        Integer[] values = new Integer[values_str.length];
        for (int i = 0; i < values_str.length; i++) {
            values[i] = new Integer(values_str[i].trim());
        }
        criteria.add(Restrictions.in(propertyName, values));        
    }

    protected void addStringListCriteria(Criteria criteria, String propertyName, String searchValues) {
        String[] values_str = searchValues.split(",");
        for (int i = 0; i < values_str.length; i++) {
            values_str[i] = values_str[i].trim();
        }
        criteria.add(Restrictions.in(propertyName, values_str));        
    }

    protected void addStringLikeListCriteria(Criteria criteria, String propertyName, String searchValues) {
        String[] values_str = searchValues.split(",");
        for (int i = 0; i < values_str.length; i++) {
            values_str[i] = "%" + values_str[i].trim() + "%";
        }
        criteria.add(Restrictions.in(propertyName, values_str));        
    }
}
