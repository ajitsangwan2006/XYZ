
package dev.zing.framework.util;

import java.io.File;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemUtils {

    public static String getCurrentDateTimeFormat1() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return sdf.format(new Date());
    }

    public static String getCurrentDateTimeFormat1(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return sdf.format(date);
    }
    
    public static Date getCurrentDateTimeFormat() {
    	Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
			date = sdf.parse(sdf.format(date));
		} catch (ParseException e) {
	    }
		return date;
    }
    
    public static String getCurrentDateTimeFormat3() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }
    public static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }
    
    public static String getCurrentDateTimeFormat3(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }
    
    public static String getCurrentDateTimeFormat4(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.format(date);
    }

    public static Date getDateFromStringFormat5(String stringDate) throws ParseException {
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.parse(stringDate);
    }
    
    public static String getCurrentDateTimeFormat2() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE d MMM yyyy hh:mm aaa");
        return sdf.format(new Date());
    }
    
    public static String getCurrentDateTimeFormat2(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE d MMM yyyy hh:mm aaa");
        return sdf.format(date);
    }
    
    public static Date getDateFromStringFormat1(String stringDate) throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        return sdf.parse(stringDate);
    }
    
    public static Date getDateFromStringFormat4(String stringDate) throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.parse(stringDate,new ParsePosition(0));
    }
    
    public static Date getDateFromStringFormat3(String stringDate) throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.parse(stringDate);
    }
    public static Date getDateFromStringFormat2(String stringDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.parse(stringDate);
    }
    
    public static java.util.Date adjustDateBy(java.util.Date d, int numberOfDays) {
       	java.util.GregorianCalendar cal = new java.util.GregorianCalendar();
       	cal.setTime(d);
       	cal.add(java.util.GregorianCalendar.DATE, numberOfDays);
       	return cal.getTime();
    }
    
    public static String getWorkingFolder() {
        return System.getProperty("user.dir");
    }
    
    public static String getTempFolder() {
        return System.getProperty("user.dir" + File.separator + "Temp");
    }
}
