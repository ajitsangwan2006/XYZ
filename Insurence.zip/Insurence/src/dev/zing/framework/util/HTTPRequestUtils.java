
package dev.zing.framework.util;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import dev.zing.framework.webtier.adapter.FormFieldImpl;
import dev.zing.framework.webtier.adapter.FormFileImpl;

public class HTTPRequestUtils {
    
    private static HTTPRequestUtils instance = new HTTPRequestUtils();
    private boolean traceEnabled = false;
    
    private HTTPRequestUtils() {
        super();
    }
    
    public static HTTPRequestUtils getInstance(){
        return instance;
    }
    
    public boolean isTraceEnabled() {
        return traceEnabled;
    }
    
    public void setTraceEnabled(boolean traceEnabled) {
        this.traceEnabled = traceEnabled;
    }
    public void log(String str) {
        System.out.println(str);
    }
    
    public HashMap getMapFromHTTPRequest(HttpServletRequest request) {
        HashMap map = new HashMap();
        Enumeration names = request.getParameterNames();
        while (names.hasMoreElements()) {
          String name = (String) names.nextElement();
          map.put(name, request.getParameter(name));
        }
        return map;
    }

    public FormFieldImpl getMapFromHTTPApplicationRequest(HttpServletRequest request) {
        FormFieldImpl formField = new FormFieldImpl();
        Enumeration names = request.getParameterNames();
        while (names.hasMoreElements()) {
          String name = (String) names.nextElement();
          String[] values = request.getParameterValues(name);          
          for (int i=0; i < values.length; i++) {
              log("getMapFromHTTPApplicationRequest:- "+ name + " - " + values[i]);
              formField.setFormField(name, values[i]);
          }
        }
        return formField;
    }
        
    public HashMap getMapFromHTTPMultipartRequest(HttpServletRequest request) throws FileUploadException {
        log("MultipartRequest-Form Field Name - Start");
        FormFieldImpl formField = new FormFieldImpl();
        HashMap map = new HashMap();
        HashMap formFilesMap = new HashMap();
        // Create a factory for disk-based file items
        FileItemFactory factory = new DiskFileItemFactory();

        // Create a new file upload handler
        ServletFileUpload upload = new ServletFileUpload(factory);

        // Parse the request
        List /* FileItem */ items = upload.parseRequest(request);
        // Process the uploaded items
        Iterator iter = items.iterator();
        while (iter.hasNext()) {
            FileItem item = (FileItem) iter.next();
            log("MultipartRequest-Form Field Name:- "+ item.getFieldName());
            if (item.isFormField()) {
                log("MultipartRequest-Form Field Value:- "+ item.getString());
                formField.setFormField(item.getFieldName(), item.getString());
            } else {
                log("File Field Name:- "+ item.getFieldName());
                formFilesMap.put(item.getFieldName(), item);
            }
        }
        System.out.println("size: "+formFilesMap.size());
        FormFileImpl formFile = new FormFileImpl(formFilesMap);
        map.put("FormField", formField);
        map.put("FormFile", formFile);
        return map;
    }    
}
