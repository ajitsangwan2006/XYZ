package dev.zing.framework.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.validator.GenericValidator;


public class FormFieldPopulateUtils {

    private static FormFieldPopulateUtils instance = new FormFieldPopulateUtils();

    private static PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();

    private FormFieldPopulateUtils() {
        super();

    }

    public static FormFieldPopulateUtils getInstance() {
        return instance;
    }

    private void log(String logMessage) {
        System.out.println(logMessage);
    }

    private String encodeValue(String text1) {
        String tmp = text1;
        String tmpencoded = "";
        String tmpchar = "";
        int asciitmp = 0;
        for (int i = 0; i < tmp.length(); i++) {
            asciitmp = tmp.charAt(i);
            tmpchar = "" + asciitmp;
            while (tmpchar.length() < 3) {
                tmpchar = "0" + tmpchar;
            }
            tmpencoded = tmpencoded + tmpchar;
        }
        return tmpencoded;
    }

    private String decodeValue(String text2) {
        String tmp = text2;
        String tmpdecoded = "";
        String tmpchar = "";
        try {
            while (tmp.length() > 0) {
                tmpchar = tmp.substring(0, 3);
                tmp = tmp.substring(3, tmp.length());
                log("tmpchar..... "+tmpchar);
                char[] asciiChar = { (char) Integer.valueOf(tmpchar).intValue() };
                String asciiChar_string = new String(asciiChar);
                tmpdecoded = tmpdecoded + asciiChar_string;
            }
        } catch (Exception ex) {
            log("exception raised from FormFieldPopulateUtility-decodeValues..... " + ex);
        }
        return tmpdecoded;
    }

    public String getFormPopulateJS(Object beanInstance, java.util.Hashtable validationErrors) {
        String lineBreak = "\n";
        String javaScript = getFormPopulateJS(beanInstance);
        if (validationErrors == null) {
            return javaScript;
        }
        javaScript += "<SCRIPT>";
        javaScript += lineBreak;
        javaScript += "function populateFormFromErr() {";
        javaScript += lineBreak;

        Iterator keys = validationErrors.keySet().iterator();
        log("validationErrors.size: " + validationErrors.size());
        while (keys.hasNext()) {
            String propName = (String) keys.next();
            log("propName: " + propName);
            dev.zing.framework.services.validation.ValidationError validationError = (dev.zing.framework.services.validation.ValidationError) validationErrors.get(propName);
            if (validationError.getPropertyValues() != null && validationError.getPropertyValues().length > 0) {
                for (int i = 0; i < validationError.getPropertyValues().length; i++) {
                    javaScript += getFormFieldPopulateJS(propName, validationError.getPropertyValues()[i], validationError.getErrorMessage(), "InputPage");
                }
            } else {
                log("Generating JS for... " + propName);
                javaScript += getFormFieldPopulateJS(propName, validationError.getPropertyValue(), validationError.getErrorMessage(), "InputPage");
                log("Generated JS... " + javaScript);
            }
        }
        javaScript += "}";
        javaScript += lineBreak;
        //javaScript += "addEvent(window, \"load\", populateFormFromErr);";
        javaScript += "populateFormFromErr();";
        javaScript += lineBreak;
        javaScript += "</SCRIPT>";
        javaScript += lineBreak;
        return javaScript;
    }

    public String getFormPopulateJS(Object beanInstance) {
        if (beanInstance == null) {
            return "";
        }
        String lineBreak = "\n";
        String javaScript = "<SCRIPT>";
        javaScript += lineBreak;
        javaScript += "function populateFormFromModel() {";
        javaScript += lineBreak;
        javaScript += getJSMethodBody(beanInstance, "InputPage");
        javaScript += "}";
        javaScript += lineBreak;
        javaScript += "populateFormFromModel();";
        javaScript += lineBreak;
        javaScript += "</SCRIPT>";
        javaScript += lineBreak;
        return javaScript;
    }

    public String getViewPagePopulateJS(Object beanInstance) {
        if (beanInstance == null) {
            return "";
        }
        String lineBreak = "\n";
        String javaScript = "<SCRIPT>";
        javaScript += lineBreak;
        javaScript += "function populateViewPageFromModel() {";
        javaScript += lineBreak;
        javaScript += getJSMethodBody(beanInstance, "ViewPage");
        javaScript += "}";
        javaScript += lineBreak;
        javaScript += "populateViewPageFromModel();";
        javaScript += lineBreak;
        javaScript += "</SCRIPT>";
        javaScript += lineBreak;
        return javaScript;
    }
    
    private String getJSMethodBody(Object beanInstance, String pageType) {
        String javaScript = "";
        dev.zing.framework.util.BeanUtils.getInstance().trimProperties(beanInstance);
        Class cls = beanInstance.getClass();
        //System.out.println("beanInstance Class is:= " + cls);
        try {
            Map map = BeanUtils.describe(beanInstance);
            Iterator keys = map.keySet().iterator();
            while (keys.hasNext()) {
                String propName = (String) keys.next();
                //System.out.println(propName + " - ");
                if (propName.trim().endsWith("class")) {
                    continue;
                }
                Object valueObject = map.get(propName);
                //System.out.println(propName + " - " + valueObject);
                if (valueObject == null) {
                    continue;
                }

                Field field = null;
                try {
                    field = cls.getDeclaredField(propName);
                } catch (SecurityException e) {
                    continue; // Skip this property setter
                } catch (NoSuchFieldException e) {
                    continue; // Skip this property setter
                }
                Class type = field.getType();
                //System.out.println(propName + " - " + type);
                
                if (propName.equals("id")) {
                    //log(propName + " is id field.");
                    //log(" type.getSuperclass(): "+type.getSuperclass());
                    if (type.getSuperclass().toString().equals("class dev.zing.framework.businesstier.model.ModelImpl")) {
                        javaScript += getJSMethodBody(getPropertyUtils().getProperty(beanInstance, propName), pageType);
                    }
                }                
                
                if (type.isInstance(new java.util.Date())) {
                    log(propName + " is DATE type.");
                    Date date = (Date) getPropertyUtils().getProperty(beanInstance, propName);
                    if (date.toString().trim().length() > 0) {
                        log(propName + " - " + getConvertDateToString(date));
                        javaScript += getFormFieldPopulateJS(propName, getConvertDateToString(date), null, pageType);
                    }
                } else {
                    try {
                        String value = (String) valueObject;
                        javaScript += getFormFieldPopulateJS(propName, value, null, pageType);
                    } catch (ClassCastException e) {
                        // We do not want to handle non-String properties
                    }
                }
            }
        } catch (IllegalAccessException e) {
            // No Action to be taken
        } catch (InvocationTargetException e) {
            // No Action to be taken
        } catch (NoSuchMethodException e) {
            // No Action to be taken
        }
        return javaScript;
    }

    private String getFormFieldPopulateJS(String name, String value, String errorMessage, String pageType) {
        String javaScript = "";
        String lineBreak = "\n";
        if (!GenericValidator.isBlankOrNull(value)) {
            if (pageType.equals("InputPage")) {
                javaScript += "if (document.form." + name + ") {";
                javaScript += lineBreak;
                //javaScript += "alert(decodeValues('" + encodeValue(value) + "'));";
                javaScript += "document.form." + name + ".value=decodeValues('" + encodeValue(value) + "');";
                //javaScript += "alert(document.form." + name + ".value);";
                javaScript += lineBreak;
                javaScript += "}";
                javaScript += lineBreak;
            } else if (pageType.equals("ViewPage")) {
                javaScript += lineBreak;
                //javaScript += "alert(decodeValues('" + encodeValue(value) + "'));";
                javaScript += "setViewDIVValue('" + name + "-view-fld', '" + encodeValue(value) + "');";
                //javaScript += "alert(document.form." + name + ".value);";
                javaScript += lineBreak;
            }
        }
        if (!GenericValidator.isBlankOrNull(errorMessage)) {
            javaScript += "if (document.form." + name + ") {";
            javaScript += lineBreak;
            javaScript += "document.form." + name + ".className += ' errFld ';";
            javaScript += "launchCalloutBox('" + name + "',decodeValues('" + encodeValue(errorMessage) + "'),'errMsg');";
            javaScript += lineBreak;
            javaScript += "}";
            javaScript += lineBreak;
        }
        return javaScript;
    }

    public String getViewPagePopulateJS(Map map) {
        if (map == null || map.size() == 0) {
            return "";
        }
        String lineBreak = "\n";
        String javaScript = "<SCRIPT>";
        javaScript += lineBreak;
        javaScript += "function populateViewPageForFormattedValues() {";

        Iterator keys = map.keySet().iterator();
        log("map.size: " + map.size());
        while (keys.hasNext()) {
            String propName = (String) keys.next();
            javaScript += lineBreak;
            javaScript += "setViewDIVValue('" + propName + "-view-fld', '" + encodeValue((String)map.get(propName)) + "');";
        }
        javaScript += "}";
        javaScript += lineBreak;
        javaScript += "populateViewPageForFormattedValues();";
        javaScript += lineBreak;
        javaScript += "</SCRIPT>";
        javaScript += lineBreak;
        return javaScript;
    }
    
    private String getConvertDateToString(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    public PropertyUtilsBean getPropertyUtils() {
        return propertyUtilsBean;
    }
}
