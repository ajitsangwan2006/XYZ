
package dev.zing.framework.util;

import java.util.Date;

import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

import org.apache.commons.lang.time.DateFormatUtils;

public class DateValueProcessor implements JsonValueProcessor {

    public Object processArrayValue(Object arg0, JsonConfig arg1) {
        if (arg0 == null) {
            return null;
        }
        Date date = (Date) arg0;
        return DateFormatUtils.format(date, "dd/MM/yyyy");
    }

    public Object processObjectValue(String arg0, Object arg1, JsonConfig arg2) {
        if (arg1 == null) {
            return null;
        }
        Date date = (Date) arg1;
        return DateFormatUtils.format(date, "dd/MM/yyyy");
    }        
}
