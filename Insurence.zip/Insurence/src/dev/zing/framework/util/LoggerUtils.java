
package dev.zing.framework.util;

import java.util.Hashtable;

import dev.zing.framework.services.logging.LoggerAdapter;
import dev.zing.framework.services.logging.LoggerAdapterImpl;


public class LoggerUtils {
    private static LoggerAdapterImpl jdbcWrapperLogger = new LoggerAdapterImpl("app.jwrap");
    private static LoggerAdapterImpl dbConnectionPoolLogger = new LoggerAdapterImpl("app.conpool");
    private static LoggerAdapterImpl daoLogger = new LoggerAdapterImpl("app.dao");
    private static LoggerAdapterImpl btoLogger = new LoggerAdapterImpl("app.bto");
    private static LoggerAdapterImpl webTierControllerLogger = new LoggerAdapterImpl("app.webtier.controller");
    private static LoggerAdapterImpl webTierViewLogger = new LoggerAdapterImpl("app.webtier.view");
    private static LoggerAdapterImpl activityLogger = new LoggerAdapterImpl("app.activity");
    private static LoggerAdapterImpl dailyServiceSentinelLogger = new LoggerAdapterImpl("app.dailyService.sentinel");
    private static LoggerAdapterImpl dailyServiceCleanupLogger = new LoggerAdapterImpl("app.dailyService.cleanup");
    private static LoggerAdapterImpl classNameLogger = null;
    private static LoggerAdapterImpl namedLoggerIns = null;
    private static Hashtable namedLogger = new Hashtable();
		
	public synchronized static LoggerAdapter getJdbcWrapperLogger() {
		return jdbcWrapperLogger;
	}
	
	public synchronized static LoggerAdapter getDBConnectionPoolLogger() {
		return dbConnectionPoolLogger;
	}
	
	public synchronized static LoggerAdapter getDaoLogger() {
		return daoLogger;
	}
	
	public synchronized static LoggerAdapter getBTOLogger() {
		return btoLogger;
	}

	public synchronized static LoggerAdapter getWebTierControllerLogger() {
		return webTierControllerLogger;
	}

	public synchronized static LoggerAdapter getWebTierViewLogger() {
		return webTierViewLogger;
	}
	
	public synchronized static LoggerAdapter getActivityLogger() {
		return activityLogger;
	}

	public synchronized static LoggerAdapter getDailyServiceSentinelLogger() {
		return dailyServiceSentinelLogger;
	}

	public synchronized static LoggerAdapter getDailyServiceCleanupLogger() {
		return dailyServiceCleanupLogger;
	}

	public synchronized static LoggerAdapter getLogger() {
	    if (classNameLogger == null) {
	        classNameLogger = new LoggerAdapterImpl(getCallerClass());
	    }
		return classNameLogger;
	}
	
	public synchronized static LoggerAdapter getLogger(String loggerName) {
	    if (!namedLogger.containsKey("loggerName")) {
	        namedLogger.put("loggerName", new LoggerAdapterImpl(loggerName));
	    }
	    return (LoggerAdapterImpl) namedLogger.get("loggerName");
	}
	
    private static String getCallerMethod() {
	      String methodName = "";
	      StackTraceElement[] stackTrace = new Throwable().getStackTrace();
	      if (stackTrace != null) {
	         methodName = stackTrace[2].getClassName() + "." + stackTrace[2].getMethodName();
	      }
	
	      return methodName;
    }

    private static String getCallerClass() {
	      String className = "";
	      StackTraceElement[] stackTrace = new Throwable().getStackTrace();
	      if (stackTrace != null) {
	         className = stackTrace[2].getClassName();
	      }
	      return className;
    }
}
