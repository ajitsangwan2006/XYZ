package dev.zing.framework.util.image;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public class ImageUtils {
    
    public static ImageDimension getImageDimension(byte[] imageData) {
        ImageHandler imageHandler = getImageHandler();
        return imageHandler.getImageDimension(imageData);
    }
    
    public static byte[] resizeImageDimension(byte[] imageData, int newWidth, int newHeight) throws IOException {
        ImageHandler imageHandler = getImageHandler();
        return imageHandler.resizeImageDimension(imageData, newWidth, newHeight);        
    }    

    private static ImageHandler getImageHandler() {
        return new ImageHandlerImpl();
    } 

    public static void main(String[] args) throws InvalidArgumentException {        
        String sourceFilename = "E:\\Temp\\26.jpg";
        String targetFilename = "E:\\Temp\\1_m3.png";
        int newWidth = 150;
        int newHeight = 150;
        int quality = 100;
        byte[] fileBytes;
        try {
            fileBytes = FileUtils.readFileToByteArray(new File(sourceFilename));
            ImageDimension imageDimension = getImageDimension(fileBytes);
            System.err.println("Width: " + imageDimension.getWidth());
            System.err.println("Height: " + imageDimension.getHeight());
            FileUtils.writeByteArrayToFile(new File(targetFilename), resizeImageDimension(fileBytes, 80, 80));
        } catch (IOException e) {
            e.printStackTrace();
        }        
        System.out.println("Done.");
    }
}
