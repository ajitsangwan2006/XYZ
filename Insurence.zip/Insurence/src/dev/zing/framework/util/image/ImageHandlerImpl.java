
package dev.zing.framework.util.image;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class ImageHandlerImpl implements ImageHandler {

    private static final int VERTICAL = 0;

    private static final int HORIZONTAL = 1;

    private static final String IMAGE_JPEG = "jpeg";

    private static final String IMAGE_JPG = "jpg";

    private static final String IMAGE_PNG = "png";
    
    public ImageDimension getImageDimension(byte[] imageData) {
        Image image = (new ImageIcon(imageData)).getImage();
        return new ImageDimension(image.getWidth(null), image.getHeight(null));
    }

    public byte[] resizeImageDimension(byte[] imageData, int newWidth, int newHeight) throws IOException {               
        ImageIcon image = new ImageIcon(imageData);
        Image newImage = getThumbnail(image, newWidth, HORIZONTAL, Image.SCALE_SMOOTH);
        int imageWidth = newImage.getWidth(null);
        int imageHeight = newImage.getHeight(null);
        System.err.println("imageWidth: "+imageWidth);
        System.err.println("imageHeight: "+imageHeight);
        if (imageHeight > newHeight) {
            newImage = getThumbnail(new ImageIcon(newImage), newHeight, VERTICAL, Image.SCALE_SMOOTH);
        }        
        ImageIcon newImageIcon = new ImageIcon(newImage);
        BufferedImage bi = new BufferedImage(newImageIcon.getIconWidth(), newImageIcon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics g = bi.getGraphics();
        g.drawImage(newImageIcon.getImage(), 0, 0, null);
        
        ByteArrayOutputStream ios = new ByteArrayOutputStream();
        ImageIO.write(bi, IMAGE_PNG, ios);
        return ios.toByteArray();
    }

    private Image getThumbnail(ImageIcon image, int size, int dir, int scale) {
        ImageIcon thumb;
        if (dir == HORIZONTAL) {
            thumb = new ImageIcon(image.getImage().getScaledInstance(size, -1, scale));
        } else {
            thumb = new ImageIcon(image.getImage().getScaledInstance(-1, size, scale));
        }
        return thumb.getImage();
    }

}
