
package dev.zing.framework.util.image;

import java.io.IOException;

public interface ImageHandler {
    
    public ImageDimension getImageDimension(byte[] imageData);
    
    public byte[] resizeImageDimension(byte[] imageData, int newWidth, int newHeight) throws IOException;
}
