package dev.zing.framework.util;

import java.util.Date;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonBeanProcessor;

import org.apache.commons.lang.time.DateFormatUtils;

public class DateBeanProcessor implements JsonBeanProcessor {

	public JSONObject processBean(Object arg0, JsonConfig arg1) {
		Date date = (Date) arg0;
		return JSONObject
				.fromObject(DateFormatUtils.format(date, "dd/MM/yyyy"));
	}
}
