package dev.zing.framework.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.StringTokenizer;
import org.apache.commons.validator.GenericValidator;

import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;


public class ValidationUtils {

    private String phoneRegexp = "\\(\\d{2}\\)(\\d{2}-\\d{4} \\d{4})";

    private static ValidationUtils instance = new ValidationUtils();

    private ValidationUtils() {
        super();
    }

    public static ValidationUtils getInstance() {
        return instance;
    }

    public Object trimProperties(Object instance) {
        return dev.zing.framework.util.BeanUtils.getInstance().trimProperties(instance);
    }

    private String getMutatorCompatible(String name) {
        String str1 = name.substring(0, 1);
        String str2 = name.substring(1, name.length());
        return str1.toUpperCase().concat(str2);
    }

    public void required(Object instance, String fieldsName, ValidationErrors errors) {
        if (errors == null) {
            errors = new ValidationErrors();
        }
        ValidationError error = new ValidationError();
        Class cls = instance.getClass();
        StringTokenizer token = new StringTokenizer(fieldsName, ",");
        while (token.hasMoreTokens()) {
            String propName = token.nextToken().trim();

            try {
                Class partypes[] = new Class[0];
                Method getMeth = cls.getMethod("get" + getMutatorCompatible(propName), partypes);
                Object arglist[] = new Object[0];
                Object getRetobj = getMeth.invoke(instance, arglist);
                if (getRetobj == null) {
                    error = new ValidationError();
                    error.setPropertyName(propName);
                    error.setErrorCode("OZA-40003-1");
                    error.setErrorMessage("This field is required.");
                    errors.addValidationError(propName, error);
                    return;
                }
                if (getRetobj instanceof String) {
                    if (((String)getRetobj).trim().length() == 0) {
                        error = new ValidationError();
                        error.setPropertyName(propName);
                        error.setErrorCode("OZA-40003-1");
                        error.setErrorMessage("This field is required.");
                        errors.addValidationError(propName, error);
                        return;
                    }
                }
            } catch (IllegalArgumentException e) {
                // DO nothing
            } catch (IllegalAccessException e) {
                // DO nothing
            } catch (SecurityException e) {
                // DO nothing
            } catch (NoSuchMethodException e) {
                // DO nothing
            } catch (InvocationTargetException e) {
                // DO nothing
            }
        }
    }

    public void required(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (GenericValidator.isBlankOrNull(value)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("This field is required.");
            errors.addValidationError(fieldName, error);
        }
    }
    
    public void requiredObjectValue(String fieldName, Object value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (value == null) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("This field is required.");
            errors.addValidationError(fieldName, error);
        }
    }
    
    public void isEmail(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (!GenericValidator.isEmail(value)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("Invalid Email Address.");
            errors.addValidationError(fieldName, error);
        }
    }

    public void isAlphaNumeric(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (!GenericValidator.isEmail(value)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("Invalid Email Address.");
            //errors.addValidationError(fieldName, error);
        }
    }

    public void isAlpha(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (!GenericValidator.isEmail(value)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("Invalid Email Address.");
            //errors.addValidationError(fieldName, error);
        }
    }
    
    public void isNumeric(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (!(GenericValidator.isFloat(value) || GenericValidator.isDouble(value))) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("Invalid value, decimal value expected.");
            errors.addValidationError(fieldName, error);
        }
    }
    
    public void isInteger(String fieldName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (!(GenericValidator.isInt(value) || GenericValidator.isLong(value) ||  GenericValidator.isShort(value))) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-2");
            error.setErrorMessage("Invalid value, integer value expected.");
            errors.addValidationError(fieldName, error);
        }
    }
        
    public void isIntegerInRange(String fieldName, Integer value, int min, int max, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (value == null || !GenericValidator.isInRange(value.intValue(), min, max)) {
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-4");
            error.setErrorMessage("Invalid Integer Value. Integer value is expected between " + min + " and " + max + ".");
            errors.addValidationError(fieldName, error);
        }
    }
    
    public void isFloatInRange(String fieldName, Float value, float min, float max, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        if (value == null || !GenericValidator.isInRange(value.floatValue(), min, max)) {
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-4");
            error.setErrorMessage("Invalid Decimal Value. Decimal value is expected between " + min + " and " + max + ".");
            errors.addValidationError(fieldName, error);
        }
    }
    
    public ValidationErrors validatePassword(String fieldName, String passwordValue, String confirmPasswordValue, ValidationErrors errors) {
        if (errors == null) {
            errors = new ValidationErrors();
        }
        ValidationError error = null;
        if (passwordValue == null) {
            error = new ValidationError();
            error.setPropertyName("GLOBALMSG");
            error.setErrorCode("OZA-40000-0");
            error.setErrorMessage("Field Password is missing.");
            errors.addValidationError("GLOBALMSG", error);
            return errors;
        }
        if (confirmPasswordValue == null) {
            error = new ValidationError();
            error.setPropertyName("GLOBALMSG");
            error.setErrorCode("OZA-40000-0");
            error.setErrorMessage("Field Confirm Password is missing.");
            errors.addValidationError("GLOBALMSG", error);
            return errors;
        }
        if (!passwordValue.equals(confirmPasswordValue)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-5");
            error.setErrorMessage("The passwords don't match.");
            errors.addValidationError(fieldName, error);
            return errors;
        }
        int minLength = 4;
        int maxLength = 20; 
        if (!GenericValidator.minLength(passwordValue, minLength)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-5");
            error.setErrorMessage("Minimum length required for Password is " + minLength + " characters.");
            errors.addValidationError(fieldName, error);
            return errors;
        }
        if (!GenericValidator.maxLength(passwordValue, maxLength)) {
            error = new ValidationError();
            error.setPropertyName(fieldName);
            error.setErrorCode("OZA-40003-6");
            error.setErrorMessage("Maximum length required for Password is " + maxLength + " characters.");
            errors.addValidationError(fieldName, error);
            return errors;
        }
        return errors;
    }
}
