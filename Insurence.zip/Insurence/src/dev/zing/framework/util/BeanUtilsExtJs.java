
package dev.zing.framework.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.validator.GenericValidator;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;

public class BeanUtilsExtJs {
    
    private static BeanUtilsExtJs instance = new BeanUtilsExtJs();
    private HTTPRequestUtils httpRequestUtils = HTTPRequestUtils.getInstance();
    private static PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();
    private static ConvertUtilsBean convertUtilsBean = new ConvertUtilsBean();
    private boolean traceEnabled = false;
    
    private BeanUtilsExtJs() {
        super();
    }
    
    public static BeanUtilsExtJs getInstance(){
        return instance;
    }
    
    public boolean isTraceEnabled() {
        return traceEnabled;
    }
    
    public void setTraceEnabled(boolean traceEnabled) {
        this.traceEnabled = traceEnabled;
    }
    public void log(String str) {
        System.out.println(str);
    }
    
	private String getMutatorCompatible(String name) {
	    String str1 = name.substring(0, 1);
	    String str2 = name.substring(1, name.length());
	    return str1.toUpperCase().concat(str2);
	}
	
	public Object trimProperties(Object bean) {
	    Class cls = bean.getClass();
	    Field[] fields = cls.getDeclaredFields();
	    for (int i=0; i < fields.length; i++) {
	        if (fields[i].getType().isInstance(new String())) {
                try {
                    Class partypes[] = new Class[0];
                    Method getMeth = cls.getMethod("get"+getMutatorCompatible(fields[i].getName()), partypes);
                    Object  arglist[] = new Object[0];
                    Object getRetobj = getMeth.invoke(bean, arglist);
                    if (getRetobj == null)
                        continue;
                    String value = (String) getRetobj;
                    value = value.trim();
                    
                    Class partypes1[] = new Class[1];
                    partypes1[0] = String.class;
                    Method setMeth = cls.getMethod("set"+getMutatorCompatible(fields[i].getName()), partypes1);
                    Object  arglist1[] = new Object[1];
                    arglist1[0] = value;
                    Object setRetobj = setMeth.invoke(bean, arglist1);

                } catch (IllegalArgumentException e) {
                    // DO nothing
                } catch (IllegalAccessException e) {
                    // DO nothing
                } catch (SecurityException e) {
                    // DO nothing
                } catch (NoSuchMethodException e) {
                    // DO nothing
                } catch (InvocationTargetException e) {
                    // DO nothing
                }
	        }
	    }
	    return bean;
	}
	
	public Map getStringProperties(Object bean) {
		HashMap map = new HashMap();
	    Class cls = bean.getClass();
	    Field[] fields = cls.getDeclaredFields();
	    for (int i=0; i < fields.length; i++) {
	        if (fields[i].getType().isInstance(new String())) {
                try {
                    Class partypes[] = new Class[0];
                    Method getMeth = cls.getMethod("get"+getMutatorCompatible(fields[i].getName()), partypes);
                    Object  arglist[] = new Object[0];
                    Object getRetobj = getMeth.invoke(bean, arglist);
                    if (getRetobj == null)
                        continue;
                    String value = (String) getRetobj;
                    value = value.trim();
                    
                    map.put(fields[i].getName(), value);
                    
                } catch (IllegalArgumentException e) {
                    // DO nothing
                } catch (IllegalAccessException e) {
                    // DO nothing
                } catch (SecurityException e) {
                    // DO nothing
                } catch (NoSuchMethodException e) {
                    // DO nothing
                } catch (InvocationTargetException e) {
                    // DO nothing
                }
	        }
	    }
	    return map;
	}
	
	public void populate(HttpServletRequest request, java.lang.Object bean, ValidationErrors errors)  throws IllegalAccessException, InvocationTargetException {
	    Map map = getMapFromHTTPRequest(request);
	    populate(map, bean, errors);
	}

    public void populate(Map properties, java.lang.Object bean, ValidationErrors errors)  throws IllegalAccessException, InvocationTargetException {
        if ((bean == null) || (properties == null) || (errors == null)) {
            return;
        }
        // Loop through the property name/value pairs to be set
        Iterator names = properties.keySet().iterator();
        while (names.hasNext()) {

            // Identify the property name and value(s) to be assigned
            String name = (String) names.next();
            if (name == null) {
                continue;
            }
            Object value = properties.get(name);

            // Perform the assignment for this property
            setProperty(bean, name, value, errors);

        }
        try {
            Object idInstance = getPropertyUtils().getProperty(bean, "id");
            //System.out.println("idInstance Class - " + idInstance.getClass());
            //System.out.println("idInstance Super Class Name is - " + idInstance.getClass().getSuperclass());
            populate(properties, idInstance, errors);
        } catch (IllegalAccessException e) {
            // Skip this property setter in Id Object
        } catch (InvocationTargetException e) {
            // Skip this property setter in Id Object
        } catch (NoSuchMethodException e) {
            // Skip this property setter in Id Object
        }
    }
    
    public void setProperty(Object bean, String name, Object value, ValidationErrors errors) throws IllegalAccessException, InvocationTargetException {
        if (bean == null || name == null || value == null || errors == null) {
            return;
        }
        Class cls = bean.getClass();
        // Trace logging (if enabled)
        if (isTraceEnabled()) {
            StringBuffer sb = new StringBuffer("  setProperty(");
            sb.append(bean);
            sb.append(", ");
            sb.append(name);
            sb.append(", ");
            if (value == null) {
                sb.append("<NULL>");
            } else if (value instanceof String) {
                sb.append((String) value);
            } else if (value instanceof String[]) {
                String values[] = (String[]) value;
                sb.append('[');
                for (int i = 0; i < values.length; i++) {
                    if (i > 0) {
                        sb.append(',');
                    }
                    sb.append(values[i]);
                }
                sb.append(']');
            } else {
                sb.append(value.toString());
            }
            sb.append(')');
            log(sb.toString());
        }
        
        // Resolve any nested expression to get the actual target bean
        Object target = bean;
        int delim = findLastNestedIndex(name);
        if (delim >= 0) {
            try {
                target = getPropertyUtils().getProperty(bean, name.substring(0, delim));
            } catch (NoSuchMethodException e) {
                return; // Skip this property setter
            }
            name = name.substring(delim + 1);
            if (isTraceEnabled()) {
                log("    Target bean = " + target);
                log("    Target name = " + name);
            }
        }
        
        Field field = null;
        try {
            field = cls.getDeclaredField(name);
        } catch (SecurityException e) {
            return; // Skip this property setter
        } catch (NoSuchFieldException e) {
            return; // Skip this property setter
        }
        if (isTraceEnabled()) {
            log("    Target Property name = " + name);
            log("    Target Property value = " + value);
        }
        
        String[] values = getHTTPRequestValues(value);
        Class type = field.getType();

        if (type.isInstance(new java.lang.String())) {
            if (type.isArray()) {
                setStringProperty(bean, name, values, errors, field.getType());
            } else {
                setStringProperty(bean, name, (String)values[0], errors, field.getType());
            }
        }
        if (type.isInstance(new java.lang.Integer(0))) {
            if (type.isArray()) {
                setIntegerProperty(bean, name, values, errors, field.getType());
            } else {
                setIntegerProperty(bean, name, (String)values[0], errors, field.getType());
            }
        }
        if (type.isInstance(new java.lang.Long(0))) {
            if (type.isArray()) {
                setLongProperty(bean, name, values, errors, field.getType());
            } else {
                setLongProperty(bean, name, (String)values[0], errors, field.getType());
            }
        }
        if (type.isInstance(new java.math.BigDecimal(0.00))) {
            if (type.isArray()) {
                setBigDecimalProperty(bean, name, values, errors, field.getType());
            } else {
                setBigDecimalProperty(bean, name, (String)values[0], errors, field.getType());
            }
        }
        if (type.isInstance(new java.util.Date())) {
            if (type.isArray()) {
                setDateProperty(bean, name, values, errors, field.getType());
            } else {
                setDateProperty(bean, name, (String)values[0], errors, field.getType());
            }
        }
        if (type.isPrimitive()) {
            if (type.toString().equals("int")) {
                if (type.isArray()) {
                    setIntegerProperty(bean, name, values, errors, field.getType());
                } else {
                    setIntegerProperty(bean, name, (String)values[0], errors, field.getType());
                }
            }
            if (type.toString().equals("long")) {
                if (type.isArray()) {
                    setLongProperty(bean, name, values, errors, field.getType());
                } else {
                    setLongProperty(bean, name, (String)values[0], errors, field.getType());
                }
            }
            if (type.toString().equals("float")) {
                if (type.isArray()) {
                    setFloatProperty(bean, name, values, errors, field.getType());
                } else {
                    setFloatProperty(bean, name, (String)values[0], errors, field.getType());
                }
            }
            if (type.toString().equals("double")) {
                if (type.isArray()) {
                    setDoubleProperty(bean, name, values, errors, field.getType());
                } else {
                    setDoubleProperty(bean, name, (String)values[0], errors, field.getType());
                }
            }
            if (type.toString().equals("Boolean")) {
                if (type.isArray()) {
                    setBooleanProperty(bean, name, values, errors, field.getType());
                } else {
                    setBooleanProperty(bean, name, (String)values[0], errors, field.getType());
                }
            }
        }
    }

    public void setStringProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setStringProperty(bean, propName, value[i], errors, type);
        }
    }
    
    public void setStringProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        try {
            getPropertyUtils().setProperty(bean, propName, value);
        } catch (NoSuchMethodException e) {
            return; // Skip this property setter
        }
    }

    public void setBigDecimalProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setBigDecimalProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setBigDecimalProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.math.BigDecimal newValue = new java.math.BigDecimal(value);
            getPropertyUtils().setProperty(bean, propName, newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Decimal value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            return; // Skip this property setter
        }
    }
    
    public void setDateProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setDateProperty(bean, propName, value[i], errors, type);
        }
    }
    
    public void setDateProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            Date newValue = getDateFromStringFormat(value);
            if (newValue == null) {
                throw new NullPointerException();
            }
            getPropertyUtils().setProperty(bean, propName, newValue);
        } catch (NullPointerException e) {
            setDatePropertyError(propName, value, errors);
        } catch (ParseException e) {
            setDatePropertyError(propName, value, errors);
        } catch (NoSuchMethodException e) {
            return; // Skip this property setter
        } 
    }
        
    private void setDatePropertyError(String propName, String value, ValidationErrors errors) {
        ValidationError error = new ValidationError();
        error.setPropertyName(propName);
        error.setPropertyValue(value);
        error.setErrorCode("OZA-40004-8");
        error.setErrorMessage("Date Format [dd/mm/yyyy] expected in this field.");
        errors.addValidationError(propName, error);
    }

    public void setIntegerProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setIntegerProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setIntegerProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.lang.Integer newValue = new java.lang.Integer(value);
            getPropertyUtils().setProperty(bean, propName,newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Numeric value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return; // Skip this property setter
        }
    }

    public void setLongProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setLongProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setLongProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.lang.Long newValue = new java.lang.Long(value);
            getPropertyUtils().setProperty(bean, propName,newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Numeric value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return; // Skip this property setter
        }
    }
    
    public void setFloatProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setFloatProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setFloatProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.lang.Float newValue = new java.lang.Float(value);
            getPropertyUtils().setProperty(bean, propName,newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Decimal value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return; // Skip this property setter
        }
    }
    public void setDoubleProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setDoubleProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setDoubleProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.lang.Double newValue = new java.lang.Double(value);
            getPropertyUtils().setProperty(bean, propName,newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Decimal value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return; // Skip this property setter
        }
    }
    
    public void setBooleanProperty(Object bean, String propName, String[] value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        for (int i=0; i < value.length; i++) {
            setBooleanProperty(bean, propName, value[i], errors, type);
        }
    }

    public void setBooleanProperty(Object bean, String propName, String value, ValidationErrors errors, Class type) throws IllegalAccessException, InvocationTargetException {
        if (GenericValidator.isBlankOrNull(value)) {
            return;
        }
        try {
            java.lang.Boolean newValue = new java.lang.Boolean(value);
            getPropertyUtils().setProperty(bean, propName,newValue);
        } catch (NumberFormatException e) {
            ValidationError error = new ValidationError();
	        error.setPropertyName(propName);
	        error.setPropertyValue(value);
	        error.setErrorCode("OZA-40004-7");
	        error.setErrorMessage("Valid Boolean value expected in this field.");
	        errors.addValidationError(propName, error);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return; // Skip this property setter
        }
    }
    
    private String[] getHTTPRequestValues(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof String) {
            String[] values = new String[1];
            values[0] = (String) value;
            return values;
        } else if (value instanceof String[]) {
            return (String[]) value;
        }
        return null;
    }
    
    private int findLastNestedIndex(String expression) {
        // walk back from the end to the start
        // and find the first index that
        int bracketCount = 0;
        for (int i = expression.length() - 1; i >= 0; i--) {
            char at = expression.charAt(i);
            switch (at) {
            case PropertyUtils.NESTED_DELIM:
                if (bracketCount < 1) {
                    return i;
                }
                break;

            case PropertyUtils.MAPPED_DELIM:
            case PropertyUtils.INDEXED_DELIM:
                // not bothered which
                --bracketCount;
                break;

            case PropertyUtils.MAPPED_DELIM2:
            case PropertyUtils.INDEXED_DELIM2:
                // not bothered which
                ++bracketCount;
                break;
            }
        }
        // can't find any
        return -1;
    }

    public PropertyUtilsBean getPropertyUtils() {
        return propertyUtilsBean;
    }
    
    public ConvertUtilsBean getConvertUtils() {
        return convertUtilsBean;
    }
    
    public void populateUsingCommons(HttpServletRequest request, java.lang.Object bean, ValidationErrors errors) throws IllegalAccessException, InvocationTargetException {
        HashMap map = getMapFromHTTPRequest(request);
        try {
            org.apache.commons.beanutils.BeanUtils.populate(bean, map);
        } catch (ConversionException e) {
            
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private HashMap getMapFromHTTPRequest(HttpServletRequest request) {
        HashMap map = new HashMap();
        Enumeration names = request.getParameterNames();
        while (names.hasMoreElements()) {
          String name = (String) names.nextElement();
          map.put(name, request.getParameterValues(name));
        }
        return map;
    }
    
    private Date getDateFromStringFormat(String stringDate) throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.parse(stringDate, new ParsePosition(0));
    }
    
}
