package dev.zing.framework.util;

import java.util.Date;

public class ListDateHelper {

    private String comparisonType;

    private Date comparisonDate;


    public ListDateHelper() {
        super();
    }
    
    public ListDateHelper(String comparisonType, Date comparisonDate) {
        super();
        this.comparisonType = comparisonType;
        this.comparisonDate = comparisonDate;
    }
    
    public Date getComparisonDate() {
        return comparisonDate;
    }

    public void setComparisonDate(Date comparisonDate) {
        this.comparisonDate = comparisonDate;
    }

    public String getComparisonType() {
        return comparisonType;
    }

    public void setComparisonType(String comparisonType) {
        this.comparisonType = comparisonType;
    }
}
