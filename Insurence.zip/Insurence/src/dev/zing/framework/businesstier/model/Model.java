package dev.zing.framework.businesstier.model;

import java.io.Serializable;

import net.sf.json.JSONObject;
import dev.zing.framework.services.validation.ValidationErrors;

public interface Model extends Serializable {
	public ValidationErrors validate();

	public void registerJavaScriptValidation();

	public JSONObject toJSONObject();
}
