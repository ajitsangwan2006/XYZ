package dev.zing.framework.businesstier.model;

import dev.zing.framework.services.validation.ValidationErrors;

public class JSONResponse extends ModelImpl implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private boolean success;

    private String error;

    private String id;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public ValidationErrors validate() {
        return null;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
