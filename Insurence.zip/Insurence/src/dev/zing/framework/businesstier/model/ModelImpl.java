package dev.zing.framework.businesstier.model;

import net.sf.json.JSONObject;
import dev.zing.framework.services.validation.ValidationRegisterer;


public abstract class ModelImpl implements Model {
    
	private static final long serialVersionUID = 1L;
	
	protected ValidationRegisterer validationRegisterer = ValidationRegisterer.getInstance();
    
    protected void log(String logMessage) {
        System.out.println(logMessage);
    }

    public void registerJavaScriptValidation() {
        
    }

    public JSONObject toJSONObject() {
        return null;
    }
    
    protected void validateEmail(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "email");
        }
    }
    protected void validateAlphaNumeric(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "alphaNumeric");
        }
    }

    protected void validateNotNull(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "notNull");
        }
    }

    protected void validateDateNotNull(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "dateNotNull");
        }
    }
    
    protected void validateNumeric(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "numeric");
        }
    }
    
    protected void validateInteger(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "integer");
        }
    }
    
    protected void validateAlpha(String propertyNames) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "alpha");
        }
    }
    
    protected void validateInIntegerRange(String propertyNames, int lowerBound, int upperBound) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "inIntegerRange", lowerBound, upperBound);
        }
    }
    
    protected void validateInFloatRange(String propertyNames, float lowerBound, float upperBound) {
        String[] propertyName = propertyNames.split(",");
        for (int x=0; x < propertyName.length; x++) {
            validationRegisterer.registerProperty(this.getClass().getName(), propertyName[x].trim(), "inFloatRange", lowerBound, upperBound);
        }
    }
    
}
