package dev.zing.framework.businesstier.listpages;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;


public interface PageDAOProvider {
 
    public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue);
}