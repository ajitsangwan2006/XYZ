package dev.zing.framework.businesstier.listpages;

import dev.zing.framework.services.exception.application.bto.BTOException;


public interface PageHandler {

    public Page getCurrentPage();

    public Page getFirstPage();

    public Page getNextPage() throws BTOException;

    public Page getPreviousPage() throws BTOException;

    public Page getLastPage();

    public Page getPage(int pageNumber) throws BTOException;

    public Page getPageForStartRowNo(int startRowNo) throws BTOException;
    
    public boolean isNextPageAvailable();

    public boolean isPreviousPageAvailable();

    public Page getAllRecords();
}