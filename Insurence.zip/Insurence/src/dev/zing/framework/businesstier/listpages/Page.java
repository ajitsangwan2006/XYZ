package dev.zing.framework.businesstier.listpages;

import java.util.List;

import dev.zing.framework.businesstier.listhelper.ListHelper;


public interface Page {

    public List getList();

    public int getStartingNumber();

    public int getEndingNumber();

    public int getPageSize();

    public int getTotalSize();

    public boolean isMultiPageAvailable();

    public boolean isNextPageAvailable();

    public boolean isPreviousPageAvailable();

    public ListHelper getPageListHelper();
}