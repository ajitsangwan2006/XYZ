package dev.zing.framework.businesstier.listpages;

import java.util.Hashtable;
import java.util.Map;


public class PageHandlerHolder {
    
    private Map pageHandler = null;
        
    public PageHandlerHolder() {
        super();
        pageHandler = new Hashtable();
    }
    
    public PageHandlerImpl getPageHandler(String entityName) {
        return (PageHandlerImpl)pageHandler.get(entityName);
    }
    
    public void setPageHandler(String entityName, PageHandlerImpl pageHandler) {
        this.pageHandler.put(entityName, pageHandler);
    }
}
