package dev.zing.framework.businesstier.listpages;

import java.util.List;
import java.util.Vector;

import dev.zing.framework.services.exception.application.bto.BTOException;




public abstract class AbstractPageHandler implements PageHandler {

    private List objects;

    private int start = 0;

    private int pageScrollValue;

    private int containingListSize;

    protected boolean isFirstPageAccessed = false;
    
    public AbstractPageHandler(int pageScrollValue) {
        reset(pageScrollValue);
    }

    protected void reset(int pageScrollValue) {
        this.objects = new Vector();
        this.start = 0;
        this.pageScrollValue = pageScrollValue;
        this.containingListSize = 0;
    }

    abstract public Page getCurrentPage();
  
    abstract public Page getFirstPage();

    abstract public Page getNextPage() throws BTOException;

    abstract public Page getPreviousPage() throws BTOException;
    
    abstract public Page getLastPage();
  
    abstract public Page getPage(int pageNumber) throws BTOException;
 
    public boolean isNextPageAvailable() {
        if (!isFirstPageAccessed) {
            return true;
        }
        return (start + objects.size()) + 1 <= containingListSize;
    }
 
    public boolean isPreviousPageAvailable() {
        return start > 1;
    }

    protected int getPageScrollValue() {
        return this.pageScrollValue;
    }

    protected int getTotalSize() {
        return containingListSize;
    }
    
    protected int getStartOfCurrentPage() {
        return start;
    }
    
    protected int getStartOfFirstPage() {
        return 0;
    }
    
    protected int getStartOfNextPage() {
        return start + objects.size();
    }
   
    protected int getStartOfPreviousPage() {
        return Math.max(start - getPageScrollValue(), 0);
    }

    protected int getStartOfLastPage() {
        int mod = getTotalSize() % getPageScrollValue();
        int lastPageStart = (mod > 0) ? (getTotalSize() - mod) : (getTotalSize() - getPageScrollValue());
        return Math.max(lastPageStart, 0);
    }

    protected int getStartOfSpecificPage(int pageNumber) {
        return (getPageScrollValue() * (pageNumber - 1)) + 1;
    }

    protected void setStartState(int start) {
        this.start = start;
    }

    public void setObjectsListState(List objects) {
        this.objects = objects;
    }

    public void setTotalRecordSizeState(int containingListSize) {
        this.containingListSize = containingListSize;
    }
}