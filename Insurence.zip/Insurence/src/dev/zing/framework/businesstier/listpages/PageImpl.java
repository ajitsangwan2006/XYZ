
package dev.zing.framework.businesstier.listpages;

import java.util.List;
import java.util.Vector;

import dev.zing.framework.businesstier.listhelper.ListHelper;



public class PageImpl implements Page {
    
    private List objects;
    private int start;
    private int containingListSize;
    private int pageScrollValue;
    private ListHelper criteria;

    public PageImpl(List list, int start, int containingListSize, int pageScrollValue, ListHelper criteria) {
        reset(list, start, containingListSize, pageScrollValue, criteria);
    }

    private void reset(List list, int start, int containingListSize, int pageScrollValue, ListHelper criteria) {
    	this.objects = new Vector(list);
        this.start = start;
        this.containingListSize = containingListSize;
        this.pageScrollValue = pageScrollValue;
        this.criteria = criteria;
    }
    
    public List getList() { 
    	return objects; 
    }

    public int getStartingNumber() { 
        if (getTotalSize() > 0) {
            return start;
        }
        return start - 1;
    }

    public int getEndingNumber() { 
    	return start + getPageSize() - 1; 
    }

    public int getPageSize() { 
    	return objects.size(); 
    }
    
    public int getTotalSize() { 
    	return containingListSize; 
    }

    
    public boolean isNextPageAvailable() {
        return containingListSize > (start + objects.size() - 1);
    }

    public boolean isPreviousPageAvailable() { 
        return start > 1;
    }
    
    public boolean isMultiPageAvailable() {
        return containingListSize > pageScrollValue;
    }
    
    public ListHelper getPageListHelper() {
        return this.criteria;
    }
}
