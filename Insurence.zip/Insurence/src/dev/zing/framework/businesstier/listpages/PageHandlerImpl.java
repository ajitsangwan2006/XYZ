package dev.zing.framework.businesstier.listpages;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.services.exception.application.bto.BTOException;

public class PageHandlerImpl extends AbstractPageHandler {

    private ListHelper criteria = null;

    private PageDAOProvider pageDAOProvider = null;    

    public PageHandlerImpl(ListHelper criteria, int pageScrollValue, PageDAOProvider pageDAOProvider) {
        super(pageScrollValue);
        this.reset(criteria, pageScrollValue, pageDAOProvider);
    }

    public void reset(ListHelper criteria, int pageScrollValue, PageDAOProvider pageDAOProvider) {
        super.reset(pageScrollValue);
        this.criteria = criteria;
        this.pageDAOProvider = pageDAOProvider;
    }

    public Page getCurrentPage() {
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, getStartOfCurrentPage(), getPageScrollValue());
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), getStartOfCurrentPage() + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
        setState(getStartOfCurrentPage(), listDAO);
        return pageImpl;
    }

    public Page getFirstPage() {
        isFirstPageAccessed = true;
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, getStartOfFirstPage(), getPageScrollValue());
        setState(getStartOfFirstPage(), listDAO);
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), getStartOfFirstPage() + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
        return pageImpl;
    }

    public Page getNextPage() throws BTOException {
        System.out.println("isFirstPageAccessed "+isFirstPageAccessed);
        if (!isFirstPageAccessed) {
            return getFirstPage();
        }
        if (isNextPageAvailable()) {
            PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, getStartOfNextPage(), getPageScrollValue());
            PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), getStartOfNextPage() + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
            setState(getStartOfNextPage(), listDAO);
            return pageImpl;
        }
        throw new BTOException("Next Page is not Available.");
    }

    public Page getPreviousPage() throws BTOException {
        if (isPreviousPageAvailable()) {
            PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, getStartOfPreviousPage(), getPageScrollValue());
            PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), getStartOfPreviousPage() + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
            setState(getStartOfPreviousPage(), listDAO);
            return pageImpl;
        }
        throw new BTOException("Previous Page is not Available.");
    }

    public Page getLastPage() {
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, getStartOfLastPage(), getPageScrollValue());
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), getStartOfLastPage() + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
        setState(getStartOfLastPage(), listDAO);
        return pageImpl;
    }

    public Page getPage(int pageNumber) throws BTOException {
        int randomPageStart = getStartOfSpecificPage(pageNumber);
        if (randomPageStart > getTotalSize()) {
            throw new BTOException("Page " + pageNumber + " is not Available.");
        }
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, randomPageStart, getPageScrollValue());
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), randomPageStart + getCounterSupplementer(listDAO.getTotalSize()), listDAO.getTotalSize(), getPageScrollValue(), criteria);
        setState(randomPageStart, listDAO);
        return pageImpl;
    }

    public Page getPageForStartRowNo(int startRowNo) throws BTOException {       
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, startRowNo, getPageScrollValue());
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), startRowNo, listDAO.getTotalSize(), getPageScrollValue(), criteria);
        return pageImpl;
    }
    
    private void setState(int startState, PageDAO listDAO) {
        setStartState(startState);
        setObjectsListState(listDAO.getCurrentPageData());
        setTotalRecordSizeState(listDAO.getTotalSize());
    }

    private int getCounterSupplementer(int totalsize) {
        return 1;
    }

    public Page getAllRecords() {
        PageDAO listDAO = pageDAOProvider.getPageDAO(criteria, -1, -1);
        PageImpl pageImpl = new PageImpl(listDAO.getCurrentPageData(), -1, listDAO.getTotalSize(), -1, criteria);
        return pageImpl;
    }

}