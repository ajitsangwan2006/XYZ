package dev.zing.framework.businesstier.facade;

import java.io.File;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.businesstier.listpages.PageHandlerImpl;

public abstract class BTO {

    public Object getSpringUtil() {
        return null;
    }

    public void setSpringUtil(Object springUtil) {
        
    }

    protected PageHandlerImpl getPageHandler(PageHandlerHolder pageHandlerHolder, ListHelper listHelper, PageDAOProvider pageDAOProvider, int pageScrollValue) {
        return getPageHandler(pageHandlerHolder, listHelper, pageDAOProvider.getClass().getName(), pageDAOProvider, pageScrollValue);
    }

    private PageHandlerImpl getPageHandler(PageHandlerHolder pageHandlerHolder, ListHelper listHelper, String entityName, PageDAOProvider pageDAOProvider, int pageScrollValue) {
        if (pageHandlerHolder.getPageHandler(entityName) == null) {
            pageHandlerHolder.setPageHandler(entityName, new PageHandlerImpl(listHelper, pageScrollValue, pageDAOProvider));
        } else {
            pageHandlerHolder.getPageHandler(entityName).reset(listHelper, pageScrollValue, pageDAOProvider);
        }
        return pageHandlerHolder.getPageHandler(entityName);
    }
    
    protected void log(String logMessage) {
        System.err.println(logMessage);
    }

    protected void createFolder(String folderPath) {
        File folder = new File(folderPath);	    
	    if (!folder.exists()) {
	        folder.mkdirs();
	    }
    }
    
}
