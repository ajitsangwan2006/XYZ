
package dev.zing.framework.businesstier.facade;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;

public interface Environment {
    
    public void changePassword(String newPassword) throws InvalidPasswordException;
    
    public void changeListPageScrollValue(int newscrollValue) throws InvalidArgumentException;
}
