
package dev.zing.framework.businesstier.listhelper;

import java.io.Serializable;

public interface ListHelper extends Serializable {
    
}
