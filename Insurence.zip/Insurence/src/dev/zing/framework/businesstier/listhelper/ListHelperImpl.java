package dev.zing.framework.businesstier.listhelper;

import java.util.Vector;

import net.sf.json.JSONObject;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.validation.ValidationErrors;

public class ListHelperImpl implements ListHelper, Model {
    
	private static final long serialVersionUID = 1L;

	public final static String ORDERBYFLOW_ASC = "ASC";

    public final static String ORDERBYFLOW_DESC = "DESC";
    
    private String orderByParam;

    private String orderByFlow;

    private String criteriaRestrictionType;
    
    private Vector criteriaRestrictions = new Vector();

    
    public String getOrderByFlow() {
        return orderByFlow;
    }

    public void setOrderByFlow(String orderByFlow) {
        this.orderByFlow = orderByFlow;
    }

    public String getOrderByParam() {
        return orderByParam;
    }

    public void setOrderByParam(String orderByParam) {
        this.orderByParam = orderByParam;
    }

    public String getCriteriaRestrictionType() {
        return criteriaRestrictionType;
    }

    public void setCriteriaRestrictionType(String criteriaRestriction) {
        this.criteriaRestrictionType = criteriaRestriction;
    }

    public void setCriteriaRestriction(Object criteriaRestrictionField) {
        this.criteriaRestrictions.add(criteriaRestrictionField);
    }

    public Vector getCriteriaRestrictions() {
        return criteriaRestrictions;
    }
    
    public void registerJavaScriptValidation() {
    }
    
    public ValidationErrors validate() {
        return null;
    }

    public JSONObject toJSONObject() {
        return null;
    }
}