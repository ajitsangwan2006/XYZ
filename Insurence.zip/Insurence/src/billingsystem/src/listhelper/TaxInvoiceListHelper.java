package billingsystem.src.listhelper;

import java.math.BigDecimal;
import java.util.Date;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;


public class TaxInvoiceListHelper extends ListHelperImpl {	

	private String selInvoiceNumber;

	private Date selInvoiceIssueDate;

	private String selSiteId;

	private Integer selStatus;

	private BigDecimal selInvoiceAmount;
	
	private String selInvoiceIssueMonth;
	
	private String selInvoiceIssueYear;
	
	private String invoiceStatus;

	public BigDecimal getSelInvoiceAmount() {
		return selInvoiceAmount;
	}
	public void setSelInvoiceAmount(BigDecimal selInvoiceAmount) {
		this.selInvoiceAmount = selInvoiceAmount;
	}
	public Date getSelInvoiceIssueDate() {
		return selInvoiceIssueDate;
	}
	public void setSelInvoiceIssueDate(Date selInvoiceIssueDate) {
		this.selInvoiceIssueDate = selInvoiceIssueDate;
	}
	public String getSelInvoiceIssueMonth() {
		return selInvoiceIssueMonth;
	}
	public void setSelInvoiceIssueMonth(String selInvoiceIssueMonth) {
		this.selInvoiceIssueMonth = selInvoiceIssueMonth;
	}
	public String getSelInvoiceIssueYear() {
		return selInvoiceIssueYear;
	}
	public void setSelInvoiceIssueYear(String selInvoiceIssueYear) {
		this.selInvoiceIssueYear = selInvoiceIssueYear;
	}
	public String getSelInvoiceNumber() {
		return selInvoiceNumber;
	}
	public void setSelInvoiceNumber(String selInvoiceNumber) {
		this.selInvoiceNumber = selInvoiceNumber;
	}
	public String getSelSiteId() {
		return selSiteId;
	}
	public void setSelSiteId(String selSiteId) {
		this.selSiteId = selSiteId;
	}
	public Integer getSelStatus() {
		return selStatus;
	}
	public void setSelStatus(Integer selStatus) {
		this.selStatus = selStatus;
	}
	
	public String getInvoiceStatus() {
		return invoiceStatus;
	}
	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}
}
