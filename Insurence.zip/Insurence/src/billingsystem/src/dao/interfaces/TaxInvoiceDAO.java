package billingsystem.src.dao.interfaces;

import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public interface TaxInvoiceDAO extends DAO {

	public int getNumberOfUnpaidTaxInvoices(String companyId) throws DAOException, InvalidDAOArgumentException ;
	
}