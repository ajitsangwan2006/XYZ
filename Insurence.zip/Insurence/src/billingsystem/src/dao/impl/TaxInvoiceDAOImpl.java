package billingsystem.src.dao.impl;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import billingsystem.src.dao.interfaces.TaxInvoiceDAO;
import billingsystem.src.dto.TaxInvoice;
import billingsystem.src.listhelper.TaxInvoiceListHelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public class TaxInvoiceDAOImpl extends DAOImpl implements TaxInvoiceDAO {

    public PageDAO getTaxInvoiceList(TaxInvoiceListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        PageDAOImpl page = null;
        Session session = null;
        try {
            session = getHibernateSession();
            session.clear();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);

            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            session.clear();
            session.flush();
            closeSession(session);
        }
    }

    public int getNumberOfUnpaidTaxInvoices(String companyId) throws DAOException, InvalidDAOArgumentException {
        if (companyId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        TaxInvoiceListHelper taxInvoiceListHelper = new TaxInvoiceListHelper();
        taxInvoiceListHelper.setInvoiceStatus("0");
        taxInvoiceListHelper.setSelSiteId(companyId);
        return getTaxInvoiceList(taxInvoiceListHelper, -1, -1).getCurrentPageData().size();
    }

    private Criteria buildCriteria(TaxInvoiceListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(TaxInvoice.class);

        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getSelSiteId())) {
                criteria.add(Restrictions.like("siteId", prepareWildcardSearchString(listHelper.getSelSiteId())));
            }           
            if (!GenericValidator.isBlankOrNull(listHelper.getSelInvoiceIssueYear()) && !GenericValidator.isBlankOrNull(listHelper.getSelInvoiceIssueMonth())) {
                criteria.add(Restrictions.like("invoiceNumber", prepareWildcardSearchString(listHelper.getSelInvoiceIssueYear() + listHelper.getSelInvoiceIssueMonth() + "*")));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getInvoiceStatus())) {
                criteria.add(Restrictions.like("invoiceStatus", new Integer(listHelper.getInvoiceStatus())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(TaxInvoiceListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("invoiceNumber");
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_DESC);
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }

        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

}
