package billingsystem.src.dto;

import java.math.BigDecimal;
import java.util.Date;
import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class TaxInvoice extends ModelImpl implements java.io.Serializable {

    private String invoiceNumber;

    private Date invoiceIssueDate;

    private Date invoiceDueDate;

    private String siteId;

    private int invoiceStatus;

    private String invoiceCurrency;

    private BigDecimal invoiceAmount;

    private BigDecimal outstandingAmount;

    private BigDecimal gst;

    private BigDecimal finalAmount;

    private BigDecimal amountDue;
    
    private Date paymentDate;

    private String paymentMethod;

    private BigDecimal paidAmount;

    private String paidStatusRecordedBy;

    private Date paidStatusRecordedOn;

    private byte[] invoicePDF;

    public TaxInvoice() {
    }

    public String getInvoiceNumber() {
        return this.invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Date getInvoiceIssueDate() {
        return this.invoiceIssueDate;
    }

    public void setInvoiceIssueDate(Date invoiceIssueDate) {
        this.invoiceIssueDate = invoiceIssueDate;
    }

    public Date getInvoiceDueDate() {
        return this.invoiceDueDate;
    }

    public void setInvoiceDueDate(Date invoiceDueDate) {
        this.invoiceDueDate = invoiceDueDate;
    }

    public String getSiteId() {
        return this.siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public int getInvoiceStatus() {
        return this.invoiceStatus;
    }

    public String getInvoiceStatusDescription() {
        String statusDesc = "";
        if (this.invoiceStatus == 0) {
            statusDesc = "UNPAID";
        } else if (this.invoiceStatus == 1) {
            statusDesc = "VOID";
        } else if (this.invoiceStatus == 2) {
            statusDesc = "PAID";
        } else if (this.invoiceStatus == 3) {
            statusDesc = "PARTIAL PAID";
        } else if (this.invoiceStatus == 4) {
            statusDesc = "ADJUSTED";
        }
        return statusDesc;
    }

    public void setInvoiceStatus(int invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getInvoiceCurrency() {
        return this.invoiceCurrency;
    }

    public void setInvoiceCurrency(String invoiceCurrency) {
        this.invoiceCurrency = invoiceCurrency;
    }

    public BigDecimal getInvoiceAmount() {
        return this.invoiceAmount;
    }

    public void setInvoiceAmount(BigDecimal invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public Date getPaymentDate() {
        return this.paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public BigDecimal getPaidAmount() {
        return this.paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public String getPaidStatusRecordedBy() {
        return this.paidStatusRecordedBy;
    }

    public void setPaidStatusRecordedBy(String paidStatusRecordedBy) {
        this.paidStatusRecordedBy = paidStatusRecordedBy;
    }

    public Date getPaidStatusRecordedOn() {
        return this.paidStatusRecordedOn;
    }

    public void setPaidStatusRecordedOn(Date paidStatusRecordedOn) {
        this.paidStatusRecordedOn = paidStatusRecordedOn;
    }

    public byte[] getInvoicePDF() {
        return invoicePDF;
    }

    public void setInvoicePDF(byte[] invoicePDF) {
        this.invoicePDF = invoicePDF;
    }

    public ValidationErrors validate() {
        return null;
    }

    public BigDecimal getFinalAmount() {
        return finalAmount;
    }

    public void setFinalAmount(BigDecimal finalAmount) {
        this.finalAmount = finalAmount;
    }

    public BigDecimal getGst() {
        return gst;
    }

    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }

    public BigDecimal getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(BigDecimal outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }
    public BigDecimal getAmountDue() {
        return getFinalAmount().subtract(getPaidAmount());
    }
}
