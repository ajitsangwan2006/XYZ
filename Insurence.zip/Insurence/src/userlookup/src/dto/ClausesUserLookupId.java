package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class ClausesUserLookupId extends ModelImpl implements java.io.Serializable {

	// Fields    

	private String siteId;

	private String userId;

	private String clauseId;

	// Constructors

	/** default constructor */
	public ClausesUserLookupId() {
	}

	/** full constructor */
	public ClausesUserLookupId(String siteId, String userId, String clauseId) {
		this.siteId = siteId;
		this.userId = userId;
		this.clauseId = clauseId;
	}

	// Property accessors
	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getClauseId() {
		return this.clauseId;
	}

	public void setClauseId(String clauseId) {
		this.clauseId = clauseId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ClausesUserLookupId))
			return false;
		ClausesUserLookupId castOther = (ClausesUserLookupId) other;

		return ((this.getSiteId() == castOther.getSiteId()) || (this
				.getSiteId() != null
				&& castOther.getSiteId() != null && this.getSiteId().equals(
				castOther.getSiteId())))
				&& ((this.getUserId() == castOther.getUserId()) || (this
						.getUserId() != null
						&& castOther.getUserId() != null && this.getUserId()
						.equals(castOther.getUserId())))
				&& ((this.getClauseId() == castOther.getClauseId()) || (this
						.getClauseId() != null
						&& castOther.getClauseId() != null && this
						.getClauseId().equals(castOther.getClauseId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getSiteId() == null ? 0 : this.getSiteId().hashCode());
		result = 37 * result
				+ (getUserId() == null ? 0 : this.getUserId().hashCode());
		result = 37 * result
				+ (getClauseId() == null ? 0 : this.getClauseId().hashCode());
		return result;
	}

	public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
                
        validationUtil.required(this.clauseId, "clauseId", errors);
       
      
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }
}
