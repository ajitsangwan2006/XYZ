package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class TradingPartnerLookup extends ModelImpl implements java.io.Serializable {

    private TradingPartnerLookupId id;

    private String name;

    private String abnNo;

    private String streetNo;

    private String streetName;

    private String city;

    private String state;

    private String country;

    private String emailId;

    private Integer isExporter;

    private Integer isConsignee;

    private Integer isBuyer;

    private Integer isForwardingAgent;

    private Integer isManufacturer;

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public TradingPartnerLookup() {
        id = new TradingPartnerLookupId();
    }

    public TradingPartnerLookupId getId() {
        return this.id;
    }

    public void setId(TradingPartnerLookupId id) {
        this.id = id;
    }

    public String getAbnNo() {
        return this.abnNo;
    }

    public void setAbnNo(String abnNo) {
        this.abnNo = abnNo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getIsBuyer() {
        return isBuyer;
    }

    public void setIsBuyer(Integer isBuyer) {
        this.isBuyer = isBuyer;
    }

    public Integer getIsConsignee() {
        return isConsignee;
    }

    public void setIsConsignee(Integer isConsignee) {
        this.isConsignee = isConsignee;
    }

    public Integer getIsExporter() {
        return isExporter;
    }

    public void setIsExporter(Integer isExporter) {
        this.isExporter = isExporter;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getStreetNo() {
        return streetNo;
    }

    public void setStreetNo(String streetNo) {
        this.streetNo = streetNo;
    }

    public Integer getIsForwardingAgent() {
        return isForwardingAgent;
    }

    public void setIsForwardingAgent(Integer isForwardingAgent) {
        this.isForwardingAgent = isForwardingAgent;
    }

    public Integer getIsManufacturer() {
        return isManufacturer;
    }

    public void setIsManufacturer(Integer isManufacturer) {
        this.isManufacturer = isManufacturer;
    }

    public void registerJavaScriptValidation() {

    }

    public ValidationErrors validate() {
        return null;
    }

}
