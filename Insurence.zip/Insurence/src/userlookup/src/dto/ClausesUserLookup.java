package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class ClausesUserLookup extends ModelImpl implements java.io.Serializable {

    // Fields

    private ClausesUserLookupId id;    

    private String line1;

    private String line2;

    private String line3;

    private String line4;

    private String line5;

    private String line6;

    private String line7;

    private String line8;

    private String line9;
    
    private Integer isPaymentTerm;

    private Integer isPrintClause;

    private Integer isAdditionalClause;
    
    private Integer isExporterDeclClause;
    
    private String clauseType;

    private String clauseTitle;
	
    // Constructors

    /** default constructor */
    public ClausesUserLookup() {
        id = new ClausesUserLookupId();
    }

    /** minimal constructor */
    public ClausesUserLookup(ClausesUserLookupId id) {
        this.id = id;
    }

    /** full constructor */
    public ClausesUserLookup(ClausesUserLookupId id, String line1, String line2, String line3, String line4, String line5, String line6, String line7, String line8,
            String line9) {
        this.id = id;
        this.line1 = line1;
        this.line2 = line2;
        this.line3 = line3;
        this.line4 = line4;
        this.line5 = line5;
        this.line6 = line6;
        this.line7 = line7;
        this.line8 = line8;
        this.line9 = line9;        
    }

    // Property accessors
    public ClausesUserLookupId getId() {
        return this.id;
    }

    public void setId(ClausesUserLookupId id) {
        this.id = id;
    }

    public String getLine1() {
        return this.line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return this.line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return this.line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getLine4() {
        return this.line4;
    }

    public void setLine4(String line4) {
        this.line4 = line4;
    }

    public String getLine5() {
        return this.line5;
    }

    public void setLine5(String line5) {
        this.line5 = line5;
    }

    public String getLine6() {
        return this.line6;
    }

    public void setLine6(String line6) {
        this.line6 = line6;
    }

    public String getLine7() {
        return this.line7;
    }

    public void setLine7(String line7) {
        this.line7 = line7;
    }

    public String getLine8() {
        return this.line8;
    }

    public void setLine8(String line8) {
        this.line8 = line8;
    }

    public String getLine9() {
        return this.line9;
    }

    public void setLine9(String line9) {
        this.line9 = line9;
    }    
    
    public String getClauseType() {
		return clauseType;
	}
	public void setClauseType(String clauseType) {
		this.clauseType = clauseType;
	}
	public Integer getIsAdditionalClause() {
		return isAdditionalClause;
	}
	public void setIsAdditionalClause(Integer isAdditionalClause) {
		this.isAdditionalClause = isAdditionalClause;
	}
	public Integer getIsExporterDeclClause() {
		return isExporterDeclClause;
	}
	public void setIsExporterDeclClause(Integer isExporterDeclClause) {
		this.isExporterDeclClause = isExporterDeclClause;
	}
	public Integer getIsPaymentTerm() {
		return isPaymentTerm;
	}
	public void setIsPaymentTerm(Integer isPaymentTerm) {
		this.isPaymentTerm = isPaymentTerm;
	}
	public Integer getIsPrintClause() {
		return isPrintClause;
	}
	public void setIsPrintClause(Integer isPrintClause) {
		this.isPrintClause = isPrintClause;
	}
	public String getClauseTitle() {
		return clauseTitle;
	}
	public void setClauseTitle(String clauseTitle) {
		this.clauseTitle = clauseTitle;
	}
   
    
    public void registerJavaScriptValidation() {
        validateNotNull("id.clauseId");
        validateNotNull("line1");
        validateAlphaNumeric("id.clauseId");
        validateAlphaNumeric("line1,line2,line3,line4,line5,line6,line7,line8,line9");
	}
    
    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        validationUtil.trimProperties(this.getId());

        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true,"siteId, userId"));

        errors.add(validationRegisterer.validate(this));

        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }
	
}
