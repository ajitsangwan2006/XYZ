package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class ProductUserLookup extends ModelImpl implements java.io.Serializable {

    private ProductUserLookupId id;

    private String hscode;

	private String description;

	private String quantity;

	private String unitPrice;

	private String prefCrit;

	private String producer;

	private String countryOfOrigin;

	private String netCost;

	private String unitOfMeasures;

	private String numberOfPackages;

    // Constructors

    /** default constructor */
    public ProductUserLookup() {
        id = new ProductUserLookupId();
    }

    /** minimal constructor */
    public ProductUserLookup(ProductUserLookupId id, String unitPrice, String netCost, String numberOfPackages) {
        this.id = id;
        this.unitPrice = unitPrice;
        this.netCost = netCost;
        this.numberOfPackages = numberOfPackages;
    }

    /** full constructor */
    public ProductUserLookup(ProductUserLookupId id, String hscode,
			String description, String quantity, String unitPrice,
			String prefCrit, String producer, String countryOfOrigin,
			String netCost, String unitOfMeasures, String numberOfPackages) {
		super();
		this.id = id;
		this.hscode = hscode;
		this.description = description;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
		this.prefCrit = prefCrit;
		this.producer = producer;
		this.countryOfOrigin = countryOfOrigin;
		this.netCost = netCost;
		this.unitOfMeasures = unitOfMeasures;
		this.numberOfPackages = numberOfPackages;
	}

    // Property accessors
    public ProductUserLookupId getId() {
        return this.id;
    }

    public void setId(ProductUserLookupId id) {
        this.id = id;
    }

    public String getHscode() {
		return this.hscode;
	}

	public void setHscode(String hscode) {
		this.hscode = hscode;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getPrefCrit() {
		return this.prefCrit;
	}

	public void setPrefCrit(String prefCrit) {
		this.prefCrit = prefCrit;
	}

	public String getProducer() {
		return this.producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public String getCountryOfOrigin() {
		return this.countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public String getNetCost() {
		return this.netCost;
	}

	public void setNetCost(String netCost) {
		this.netCost = netCost;
	}

	public String getUnitOfMeasures() {
		return this.unitOfMeasures;
	}

	public void setUnitOfMeasures(String unitOfMeasures) {
		this.unitOfMeasures = unitOfMeasures;
	}

	public String getNumberOfPackages() {
		return this.numberOfPackages;
	}

	public void setNumberOfPackages(String numberOfPackages) {
		this.numberOfPackages = numberOfPackages;
	}

    public ValidationErrors validate() {
		return null;
     
    }
}
