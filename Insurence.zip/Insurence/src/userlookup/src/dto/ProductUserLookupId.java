package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;


public class ProductUserLookupId extends ModelImpl implements java.io.Serializable {

	private String siteId;

	private String userId;

	private String productCode;

	// Constructors

	/** default constructor */
	public ProductUserLookupId() {
	}

	/** full constructor */
	public ProductUserLookupId(String siteId, String userId, String productCode) {
		this.siteId = siteId;
		this.userId = userId;
		this.productCode = productCode;
	}

	// Property accessors
	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ProductUserLookupId))
			return false;
		ProductUserLookupId castOther = (ProductUserLookupId) other;

		return ((this.getSiteId() == castOther.getSiteId()) || (this
				.getSiteId() != null
				&& castOther.getSiteId() != null && this.getSiteId().equals(
				castOther.getSiteId())))
				&& ((this.getUserId() == castOther.getUserId()) || (this
						.getUserId() != null
						&& castOther.getUserId() != null && this.getUserId()
						.equals(castOther.getUserId())))
				&& ((this.getProductCode() == castOther.getProductCode()) || (this
						.getProductCode() != null
						&& castOther.getProductCode() != null && this
						.getProductCode().equals(castOther.getProductCode())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getSiteId() == null ? 0 : this.getSiteId().hashCode());
		result = 37 * result
				+ (getUserId() == null ? 0 : this.getUserId().hashCode());
		result = 37
				* result
				+ (getProductCode() == null ? 0 : this.getProductCode()
						.hashCode());
		return result;
	}

	
    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);                
        validationUtil.required(this, "userId, siteId, productCode", errors);        
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }

}
