package userlookup.src.dto;

import java.util.Date;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class CurrencyUserLookup extends ModelImpl implements java.io.Serializable {
   
    private String currencyCode;

    private String currencyName;
    
    private String countryName;

	private String fob;

	private String exchangeRate;

	private Date rateDate;
     
    public CurrencyUserLookup() {
    }
   
    public CurrencyUserLookup(String currencyCode) {
        this.currencyCode = currencyCode;
    }
    
	public CurrencyUserLookup(String currencyCode, String currencyName,
			String countryName, String fob, String exchangeRate, Date rateDate) {
		super();
		this.currencyCode = currencyCode;
		this.currencyName = currencyName;
		this.countryName = countryName;
		this.fob = fob;
		this.exchangeRate = exchangeRate;
		this.rateDate = rateDate;
	}
	
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getCurrencyName() {
		return currencyName;
	}
	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}
	public String getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public String getFob() {
		return fob;
	}
	public void setFob(String fob) {
		this.fob = fob;
	}
	public Date getRateDate() {
		return rateDate;
	}
	public void setRateDate(Date rateDate) {
		this.rateDate = rateDate;
	}
    public void registerJavaScriptValidation() {
        validateNotNull("currencyName");
        validateAlphaNumeric("currencyCode, currencyName");
    }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true));

        errors.add(validationRegisterer.validate(this));

        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }
}