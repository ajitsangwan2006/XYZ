package userlookup.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class TradingPartnerLookupId extends ModelImpl implements java.io.Serializable {

    private String siteId;

    private String partnerId;

    public TradingPartnerLookupId() {
    }

    public TradingPartnerLookupId(String siteId, String partnerId) {
        this.siteId = siteId;
        this.partnerId = partnerId;
    }

    public String getSiteId() {
        return this.siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }
    
	public String getPartnerId() {
		return partnerId;
	}
	
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	
    public boolean equals(Object other) {
        if ((this == other))
            return true;
        if ((other == null))
            return false;
        if (!(other instanceof TradingPartnerLookupId))
            return false;
        TradingPartnerLookupId castOther = (TradingPartnerLookupId) other;

        return ((this.getSiteId() == castOther.getSiteId()) || (this.getSiteId() != null && castOther.getSiteId() != null && this.getSiteId().equals(castOther.getSiteId()))) && ((this.getPartnerId() == castOther.getPartnerId()) || (this.getPartnerId() != null && castOther.getPartnerId() != null && this.getPartnerId().equals(castOther.getPartnerId())));
    }

    public int hashCode() {
        int result = 17;

        result = 37 * result + (getSiteId() == null ? 0 : this.getSiteId().hashCode());
        result = 37 * result + (getPartnerId() == null ? 0 : this.getPartnerId().hashCode());
        return result;
    }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "siteId, partnerId"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }

}
