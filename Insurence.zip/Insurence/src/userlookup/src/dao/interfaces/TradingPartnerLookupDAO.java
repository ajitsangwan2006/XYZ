package userlookup.src.dao.interfaces;

import userlookup.src.dto.TradingPartnerLookup;
import userlookup.src.dto.TradingPartnerLookupId;
import userlookup.src.listhelper.TradingPartnerLookupListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public interface TradingPartnerLookupDAO extends DAO {    

	public PageDAO getTradingPartnerLookupList(TradingPartnerLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;

    public TradingPartnerLookup get(TradingPartnerLookupId id)throws DAOException, InvalidDAOArgumentException;
        
    public void create(TradingPartnerLookup instance)throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
    
    public void update(TradingPartnerLookup instance)throws DAOException, InvalidDAOArgumentException, RecordNotFoundException; 
    
    public void delete(TradingPartnerLookup instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
}