package userlookup.src.dao.interfaces;

import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import userlookup.src.dto.CurrencyUserLookup;
import userlookup.src.listhelper.CurrencyUserLookupListHelper;

public interface CurrencyUserLookupDAO extends DAO {
	
	public PageDAO getCurrencyLookup(CurrencyUserLookupListHelper criteria, int startRowNo, int scrollValue) throws DAOException;
	
	public PageDAO getCurrencyLookup(CurrencyUserLookupListHelper criteria) throws DAOException;
	
	public CurrencyUserLookup getCurrencyLookup(String currencyCode) throws DAOException, InvalidDAOArgumentException;
	
	public CurrencyUserLookup create(CurrencyUserLookup criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
	
	public void update(CurrencyUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
	
	public void delete(CurrencyUserLookup instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
		
	
}