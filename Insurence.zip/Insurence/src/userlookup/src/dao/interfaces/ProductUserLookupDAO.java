package userlookup.src.dao.interfaces;

import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import userlookup.src.dto.ProductUserLookup;
import userlookup.src.listhelper.ProductUserLookupListHelper;

public interface ProductUserLookupDAO extends DAO {
	
	public PageDAO getProduct(ProductUserLookupListHelper criteria, int startRowNo, int scrollValue) throws DAOException;
	
	public ProductUserLookup getProduct(String siteId,String productCode) throws DAOException, InvalidDAOArgumentException;
	
	public ProductUserLookup create(ProductUserLookup criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
	
	public void update(ProductUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
	
	public void delete(ProductUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
			
	
}