package userlookup.src.dao.interfaces;

import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;



public interface ClausesUserLookupDAO extends DAO {
	
	public PageDAO getClausesUserLookup(ClausesUserLookupListHelper criteria, int startRowNo, int scrollValue) throws DAOException;
	public PageDAO getClausesUserLookup(ClausesUserLookupListHelper criteria) throws DAOException;
	
	public ClausesUserLookup getClausesUserLookup(String siteId,String userId,String clauseId) throws DAOException, InvalidDAOArgumentException;
	
	public ClausesUserLookup createClausesUserLookup(ClausesUserLookup criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
	
	public void updateClausesUserLookup(ClausesUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
	
	public void delete(ClausesUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
		
	
}