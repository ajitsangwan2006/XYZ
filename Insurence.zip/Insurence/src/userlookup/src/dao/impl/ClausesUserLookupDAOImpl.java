package userlookup.src.dao.impl;

import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import userlookup.src.dao.interfaces.ClausesUserLookupDAO;
import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;

public class ClausesUserLookupDAOImpl extends DAOImpl implements ClausesUserLookupDAO {

    public PageDAO getClausesUserLookup(ClausesUserLookupListHelper criteria, int startRowNo, int scrollValue) throws DAOException {

        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getSession();
            Criteria criteriaForCounter = buildCriteria(criteria, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);
            Criteria criteriaForList = buildCriteria(criteria, session, false);
            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();
            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());
        } catch (HibernateException e) {
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return page;
    }

    public PageDAO getClausesUserLookup(ClausesUserLookupListHelper criteria) throws DAOException {
        return getClausesUserLookup(criteria, -1, -1);
    }

    public ClausesUserLookup getClausesUserLookup(String siteId, String userId, String clauseId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        if (userId == null) {
            throw new InvalidDAOArgumentException("User Id can not be NULL.");
        }
        if (clauseId == null) {
            throw new InvalidDAOArgumentException("Clause Id can not be NULL.");
        }
        ClausesUserLookupListHelper criteria = new ClausesUserLookupListHelper();
        criteria.setSiteId(siteId);
        criteria.setUserId(userId);
        criteria.setClauseId(clauseId);
        List list = getClausesUserLookup(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (ClausesUserLookup) list.get(0);
        } else {
            return null;
        }
    }
    
    private ClausesUserLookup getClausesUserLookup(String siteId, String clauseId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Site Id can not be NULL.");
        }
        if (clauseId == null) {
            throw new InvalidDAOArgumentException("Clause Id can not be NULL.");
        }
        ClausesUserLookupListHelper criteria = new ClausesUserLookupListHelper();
        criteria.setSiteId(siteId);
        criteria.setClauseId(clauseId);
        List list = getClausesUserLookup(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (ClausesUserLookup) list.get(0);
        } else {
            return null;
        }
    }

    public ClausesUserLookup createClausesUserLookup(ClausesUserLookup dto) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        Session session = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        ClausesUserLookup isUsersExist = getClausesUserLookup(dto.getId().getSiteId(), dto.getId().getClauseId());
        if (isUsersExist != null) {
        	ValidationError error = new ValidationError();
            error.setPropertyName("id.clauseId");
            error.setErrorCode("OZA-80003-1");
            error.setErrorMessage("Duplicate Entry exists for this  Clause Id.");
            ValidationErrors errors = new ValidationErrors();
            errors.addValidationError("clauseId", error);
            throw new DuplicateRecordException(errors);
        }
        
        try {
              session = getSession();
              session.save(dto);
              session.flush();
        } catch (HibernateException hex) {

            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return dto;
    }

    public void updateClausesUserLookup(ClausesUserLookup dto) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            
            session = getSession();
            session.saveOrUpdate(dto);
            session.flush();
        } catch (HibernateException hex) {
            ClausesUserLookup isUsersExist = getClausesUserLookup(dto.getId().getSiteId(), dto.getId().getUserId(), dto.getId().getClauseId());
            if (isUsersExist == null) {
                throw new RecordNotFoundException("No Entry exists for this Clause ID.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    public void delete(ClausesUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            
            session = getSession();
            session.delete(criteria);
            session.flush();
        } catch (HibernateException hex) {
            ClausesUserLookup isClauseExist = getClausesUserLookup(criteria.getId().getSiteId(), criteria.getId().getUserId(), criteria.getId().getClauseId());
            if (isClauseExist == null) {
                throw new RecordNotFoundException("No Entry exists for this Clause ID.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    private Criteria buildCriteria(ClausesUserLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(ClausesUserLookup.class);
        String orderByParam = "id.clauseId";
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);            
            if (!GenericValidator.isBlankOrNull(listHelper.getUserId())) {
                criteria.add(Restrictions.like("id.userId", prepareWildcardSearchString(listHelper.getUserId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getSiteId())) {
                criteria.add(Restrictions.like("id.siteId", prepareWildcardSearchString(listHelper.getSiteId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getClauseId())) {
                criteria.add(Restrictions.like("id.clauseId", prepareWildcardSearchString(listHelper.getClauseId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getLine1())) {
                criteria.add(Restrictions.like("line1", prepareWildcardSearchString(listHelper.getLine1())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getLine2())) {
                criteria.add(Restrictions.like("line2", prepareWildcardSearchString(listHelper.getLine2())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getLine3())) {
                criteria.add(Restrictions.like("line3", prepareWildcardSearchString(listHelper.getLine3())));
            }
            if (listHelper.getIsPaymentTerm() != null) {
                criteria.add(Restrictions.eq("isPaymentTerm", listHelper.getIsPaymentTerm()));
            }
            if (listHelper.getIsPrintClause() != null) {
                criteria.add(Restrictions.eq("isPrintClause", listHelper.getIsPrintClause()));
            }
            if (listHelper.getIsAdditionalClause() != null) {
                criteria.add(Restrictions.eq("isAdditionalClause", listHelper.getIsAdditionalClause()));
            }
            if (listHelper.getIsExporterDeclClause() != null) {
                criteria.add(Restrictions.eq("isExporterDeclClause", listHelper.getIsExporterDeclClause()));
            }
           
        }
        return criteria;
    }
    
    private void buildCriteriaOrder(ClausesUserLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("id.clauseId");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("id.clauseId")) {
                criteria.addOrder(Order.asc("id.clauseId"));
            }
            if (!orderByParam.equals("id.siteId")) {
                criteria.addOrder(Order.asc("id.siteId"));
            }
            if (!orderByParam.equals("id.userId")) {
                criteria.addOrder(Order.asc("id.userId"));
            }
        }
    }
        

    private String getPropertyNameFromColumnName(String columnName) {
        if (columnName.equalsIgnoreCase("userId")) {
            return "id.userId";
        } else if (columnName.equalsIgnoreCase("siteId")) {
            return "id.siteId";
        } else if (columnName.equalsIgnoreCase("clauseId")) {
            return "id.clauseId";
        } else
            return columnName;
    }

}