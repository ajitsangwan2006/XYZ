package userlookup.src.dao.impl;

import java.util.List;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import userlookup.src.dao.interfaces.CurrencyUserLookupDAO;
import userlookup.src.dto.CurrencyUserLookup;
import userlookup.src.listhelper.CurrencyUserLookupListHelper;

public class CurrencyUserLookupDAOImpl extends DAOImpl implements CurrencyUserLookupDAO {

    public PageDAO getCurrencyLookup(CurrencyUserLookupListHelper criteria, int startRowNo, int scrollValue) throws DAOException {

        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getSession();
            Criteria criteriaForCounter = buildCriteria(criteria, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);
            Criteria criteriaForList = buildCriteria(criteria, session, false);
            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();
            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());
        } catch (HibernateException e) {
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return page;
    }

    public PageDAO getCurrencyLookup(CurrencyUserLookupListHelper criteria) throws DAOException {

        return getCurrencyLookup(criteria, -1, -1);
    }

    public CurrencyUserLookup getCurrencyLookup(String currencyCode) throws DAOException, InvalidDAOArgumentException {

        if (currencyCode == null) {
            throw new InvalidDAOArgumentException("Currency Code can not be NULL.");
        }
        CurrencyUserLookupListHelper criteria = new CurrencyUserLookupListHelper();
        criteria.setCurrencyCode(currencyCode);
        
        List list = getCurrencyLookup(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (CurrencyUserLookup) list.get(0);
        } else {
            return null;
        }
    }

    public CurrencyUserLookup create(CurrencyUserLookup dto) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        Session session = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        CurrencyUserLookup isCurrencyExist = getCurrencyLookup(dto.getCurrencyCode());
        if (isCurrencyExist != null) {
        	ValidationError error = new ValidationError();
       	    error.setPropertyName("currencyCode");
            error.setErrorCode("OZA-80003-3");
            error.setErrorMessage("Duplicate Entry exists for this  Currency Code.");
            ValidationErrors errors = new ValidationErrors();
            errors.addValidationError("currencyCode", error);
            throw new DuplicateRecordException(errors);
       }
        try {
            session = getSession();
            session.save(dto);
            session.flush();
        } catch (HibernateException hex) {

            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return dto;
    }

    public void update(CurrencyUserLookup dto) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.saveOrUpdate(dto);
            session.flush();
        } catch (HibernateException hex) {
            CurrencyUserLookup isCurrencyExist = getCurrencyLookup(dto.getCurrencyCode());
            if (isCurrencyExist == null) {
                throw new RecordNotFoundException("No Entry exists for this Currency Code.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    public void delete(CurrencyUserLookup instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.delete(instance);
            session.flush();
        } catch (HibernateException hex) {
            CurrencyUserLookup isCurrencyExist = getCurrencyLookup(instance.getCurrencyCode());
            if (isCurrencyExist == null) {
                throw new RecordNotFoundException("No Entry exists for this Currency Code .");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    private Criteria buildCriteria(CurrencyUserLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(CurrencyUserLookup.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getCurrencyCode())) {
                criteria.add(Restrictions.like("currencyCode", prepareWildcardSearchString(listHelper.getCurrencyCode())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCurrencyName())) {
                criteria.add(Restrictions.like("currencyName", prepareWildcardSearchString(listHelper.getCurrencyName())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(CurrencyUserLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("currencyCode");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("currencyCode")) {
                criteria.addOrder(Order.asc("currencyCode"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

}