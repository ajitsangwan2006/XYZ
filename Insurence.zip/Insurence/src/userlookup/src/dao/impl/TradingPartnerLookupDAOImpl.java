package userlookup.src.dao.impl;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import userlookup.src.dao.interfaces.TradingPartnerLookupDAO;
import userlookup.src.dto.TradingPartnerLookup;
import userlookup.src.dto.TradingPartnerLookupId;
import userlookup.src.listhelper.TradingPartnerLookupListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public class TradingPartnerLookupDAOImpl extends DAOImpl implements TradingPartnerLookupDAO {

    public PageDAO getTradingPartnerLookupList(TradingPartnerLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
    	Session session = null;
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace(System.err);
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }
    public PageDAO getTradingPartnerLookupList(TradingPartnerLookupListHelper criteria) throws DAOException {
        return getTradingPartnerLookupList(criteria, -1, -1);
    }

    public TradingPartnerLookup get(TradingPartnerLookupId id) {
        if (id == null) {
            throw new InvalidDAOArgumentException("Trading Partner Id can not be NULL.");
        }
        Session session = null;
        try {
            session = getHibernateSession();
            return (TradingPartnerLookup) session.get(TradingPartnerLookup.class, id);
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }        
    }
        
    public void create(TradingPartnerLookup instance)throws DAOException, InvalidDAOArgumentException, DuplicateRecordException{
    	if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        Session session = null;
        try {
            session = getHibernateSession();
            session.save(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }
    
    public void update(TradingPartnerLookup instance) {
    	if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        Session session = null;
        try {
            session = getHibernateSession();
            session.clear();
            session.saveOrUpdate(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }
    public void delete(TradingPartnerLookup instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
    	  Session session = null;
          if (instance == null) {
              throw new InvalidDAOArgumentException("Argument can not be NULL.");
          }
          try {
              session = getSession();
              session.delete(instance);
              session.flush();
          } catch (HibernateException hex) {
          	TradingPartnerLookup isTradingPartnerExist = get(instance.getId());
              if (isTradingPartnerExist == null) {
                  throw new RecordNotFoundException("No Entry exists for this PartnerId .");
              }
              throw new DAOException(hex);
          } finally {
              closeSession(session);
          }
		
	}
    
    private Criteria buildCriteria(TradingPartnerLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(TradingPartnerLookup.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getSiteId())) {
                criteria.add(Restrictions.like("id.siteId", listHelper.getSiteId()));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getPartnerId())) {
                criteria.add(Restrictions.like("id.partnerId", prepareWildcardSearchString(listHelper.getPartnerId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getName())) {
                criteria.add(Restrictions.like("name", prepareWildcardSearchString(listHelper.getName())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCity())) {
                criteria.add(Restrictions.like("city", prepareWildcardSearchString(listHelper.getCity())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getState())) {
                criteria.add(Restrictions.like("state", prepareWildcardSearchString(listHelper.getState())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getAbnNo())) {
                criteria.add(Restrictions.like("abnNo", prepareWildcardSearchString(listHelper.getAbnNo())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCountry())) {
                criteria.add(Restrictions.like("country", prepareWildcardSearchString(listHelper.getCountry())));
            }
            if(!GenericValidator.isBlankOrNull(listHelper.getAddressType())){
            	addStringListCriteria(criteria,"addressType", listHelper.getAddressType());
            }
            if (listHelper.getIsExporter() != null) {
                criteria.add(Restrictions.eq("isExporter", listHelper.getIsExporter()));
            }
            if (listHelper.getIsConsignee() != null) {
                criteria.add(Restrictions.eq("isConsignee", listHelper.getIsConsignee()));
            }
            if (listHelper.getIsBuyer() != null) {
                criteria.add(Restrictions.eq("isBuyer", listHelper.getIsBuyer()));
            }
            if (listHelper.getIsForwardingAgent() != null) {
                criteria.add(Restrictions.eq("isForwardingAgent", listHelper.getIsForwardingAgent()));
            }
            if (listHelper.getIsManufacturer() != null) {
                criteria.add(Restrictions.eq("isManufacturer", listHelper.getIsManufacturer()));
            }
        }
        return criteria;
    }
   
    private void buildCriteriaOrder(TradingPartnerLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {            
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("id.partnerId");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().toUpperCase().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().toUpperCase().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("id.partnerId")) {
                criteria.addOrder(Order.asc("id.partnerId"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        if (columnName.equals("siteId")) {
            return "id.siteId";
        }
        if (columnName.equals("partnerId")) {
            return "id.partnerId";
        }
        return columnName;
    }
	
	
}
