package userlookup.src.dao.impl;

import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import userlookup.src.dao.interfaces.ProductUserLookupDAO;
import userlookup.src.dto.ProductUserLookup;
import userlookup.src.listhelper.ProductUserLookupListHelper;

public class ProductUserLookupDAOImpl extends DAOImpl implements ProductUserLookupDAO {

    public PageDAO getProduct(ProductUserLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {

        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();
            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());
        } catch (HibernateException e) {
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return page;

    }
    public PageDAO getProduct(ProductUserLookupListHelper criteria) throws DAOException {
        return getProduct(criteria, -1, -1);
    }

     
    public ProductUserLookup getProduct(String siteId, String productCode) throws DAOException, InvalidDAOArgumentException {

        if (siteId == null) {
            throw new InvalidDAOArgumentException("Site Id can not be NULL.");
        }
        if (productCode == null) {
            throw new InvalidDAOArgumentException("product Code can not be NULL.");
        }

        ProductUserLookupListHelper criteria = new ProductUserLookupListHelper();
        criteria.setSiteId(siteId);
        criteria.setProductCode(productCode);
        List list = getProduct(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (ProductUserLookup) list.get(0);
        } else {
            return null;
        }
    }
    public ProductUserLookup create(ProductUserLookup instance) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {

        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        ProductUserLookup isProductUserLookupExist = getProduct(instance.getId().getSiteId(), instance.getId().getProductCode());
        if (isProductUserLookupExist != null) {
        	ValidationError error = new ValidationError();
       	    error.setPropertyName("id.productCode");
            error.setErrorCode("OZA-80003-13");
            error.setErrorMessage("Duplicate Entry exists for this Product code.");
            ValidationErrors errors = new ValidationErrors();
            errors.addValidationError("productCode", error);
            throw new DuplicateRecordException(errors);
        }
    	try {
            session = getSession();
            session.save(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return instance;

    }
    public void update(ProductUserLookup instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {

        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.saveOrUpdate(instance);
            session.flush();
        } catch (HibernateException hex) {
        	 ProductUserLookup isProductUserLookupExist = getProduct(instance.getId().getSiteId(), instance.getId().getProductCode());
             if (isProductUserLookupExist == null) {
                 throw new RecordNotFoundException("No Entry exists for this SiteId and Product code.");
             }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    public void delete(ProductUserLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {

        Session session = null;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.delete(criteria);
            session.flush();
        } catch (HibernateException hex) {
            ProductUserLookup isProductExist = getProduct(criteria.getId().getSiteId(), criteria.getId().getProductCode());
            if (isProductExist == null) {
                throw new RecordNotFoundException("No Entry exists for this SiteId and Product code.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
   }
   private Criteria buildCriteria(ProductUserLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(ProductUserLookup.class);
        String orderByParam = "id.productCode";
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria); 
           
            if ( ! GenericValidator.isBlankOrNull(listHelper.getSiteId())) {
                criteria.add(Restrictions.like("id.siteId", prepareWildcardSearchString(listHelper.getSiteId())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getProductCode())) {
                criteria.add(Restrictions.like("id.productCode", prepareWildcardSearchString(listHelper.getProductCode())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getHscode())) {
                criteria.add(Restrictions.like("hscode", prepareWildcardSearchString(listHelper.getHscode())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getCountryOfOrigin())) {
                criteria.add(Restrictions.like("countryOfOrigin", prepareWildcardSearchString(listHelper.getCountryOfOrigin())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getDescription())) {
                criteria.add(Restrictions.like("description", prepareWildcardSearchString(listHelper.getDescription())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getUnitPrice())) {
                criteria.add(Restrictions.like("unitPrice", prepareWildcardSearchString(listHelper.getUnitPrice())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getQuantity())) {
                criteria.add(Restrictions.like("quantity", prepareWildcardSearchString(listHelper.getQuantity())));
            }
            if (! GenericValidator.isBlankOrNull(listHelper.getUnitOfMeasures())) {
                criteria.add(Restrictions.like("unitOfMeasures", prepareWildcardSearchString(listHelper.getUnitOfMeasures())));
            }
        }
        return criteria;
    }
   
   private void buildCriteriaOrder(ProductUserLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
       if (!isTotalCount) {
           
           if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
               listHelper.setOrderByParam("id.productCode");
           }
           if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
               listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
           }
           String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
           if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
               criteria.addOrder(Order.asc(orderByParam));
           } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
               criteria.addOrder(Order.desc(orderByParam));
           }
           if (!orderByParam.equals("id.productCode")) {
               criteria.addOrder(Order.asc("id.productCode"));
           }
           if (!orderByParam.equals("id.siteId")) {
               criteria.addOrder(Order.asc("id.siteId"));
           }
           
       }
   }

    private String getPropertyNameFromColumnName(String columnName) {
        
         if (columnName.equalsIgnoreCase("siteId")) {
            return "id.siteId";
        } else if (columnName.equalsIgnoreCase("productCode")) {
            return "id.productCode";
        } else
            return columnName;
    }

}