package userlookup.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class TradingPartnerLookupListHelper extends ListHelperImpl {

    private String siteId;

    private String partnerId;

    private String name;

    private String country;

    private String parttyType;

    private String city;

    private String state;

    private Integer isExporter;

    private Integer isConsignee;

    private Integer isBuyer;
    
    private Integer isForwardingAgent;

    private Integer isManufacturer;
    
    private String addressType;
    
    private String abnNo;
    

    public String getCity() {
        return city;
    }

    public void setCity(String selCity) {
        this.city = selCity;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String selCountry) {
        this.country = selCountry;
    }

    public String getParttyType() {
        return parttyType;
    }

    public void setParttyType(String selParttyType) {
        this.parttyType = selParttyType;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String selPartyId) {
        this.partnerId = selPartyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String selPartyNameLine1) {
        this.name = selPartyNameLine1;
    }

    public String getState() {
        return state;
    }

    public void setState(String selState) {
        this.state = selState;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public Integer getIsBuyer() {
        return isBuyer;
    }

    public void setIsBuyer(Integer isBuyer) {
        this.isBuyer = isBuyer;
    }

    public Integer getIsConsignee() {
        return isConsignee;
    }

    public void setIsConsignee(Integer isConsignee) {
        this.isConsignee = isConsignee;
    }

    public Integer getIsExporter() {
        return isExporter;
    }

    public void setIsExporter(Integer isExporter) {
        this.isExporter = isExporter;
    }

	public Integer getIsForwardingAgent() {
		return isForwardingAgent;
	}
	public void setIsForwardingAgent(Integer isForwardingAgent) {
		this.isForwardingAgent = isForwardingAgent;
	}
	public Integer getIsManufacturer() {
		return isManufacturer;
	}
	public void setIsManufacturer(Integer isManufacturer) {
		this.isManufacturer = isManufacturer;
	}
	
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	
	public String getAbnNo() {
		return abnNo;
	}
	public void setAbnNo(String abnNo) {
		this.abnNo = abnNo;
	}
}
