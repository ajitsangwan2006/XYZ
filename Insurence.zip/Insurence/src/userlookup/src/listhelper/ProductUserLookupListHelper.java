package userlookup.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ProductUserLookupListHelper extends ListHelperImpl {
	
    private String productCode;

    private String siteId;

    private String userId;

    private String hscode;
    
    private String countryOfOrigin;
    
    private String description;

	private String unitPrice;
	
	private String quantity;
	
	private String unitOfMeasures;

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getHscode() {
        return hscode;
    }

    public void setHscode(String hscode) {
        this.hscode = hscode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
    
    public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
    
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getQuantity() {
		return quantity;
	}
	
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	public String getUnitOfMeasures() {
		return unitOfMeasures;
	}
	
	public void setUnitOfMeasures(String unitOfMeasures) {
		this.unitOfMeasures = unitOfMeasures;
	}
	
	public String getUnitPrice() {
		return unitPrice;
	}
	
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
}