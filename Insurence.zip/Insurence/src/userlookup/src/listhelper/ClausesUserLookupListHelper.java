package userlookup.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ClausesUserLookupListHelper extends ListHelperImpl {

    private String siteId;

    private String userId;

    private String clauseId;
    
    private String line1;
    
    private String line2;
    
    private String line3;
 
    private Integer isPaymentTerm;

    private Integer isPrintClause;

    private Integer isAdditionalClause;
 	
    private Integer isExporterDeclClause;
    

    public String getClauseId() {
        return clauseId;
    }

    public void setClauseId(String clausesId) {
        this.clauseId = clausesId;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
	public String getLine1() {
		return line1;
	}
	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}
	public void setLine2(String line2) {
		this.line2 = line2;
	}
	public String getLine3() {
		return line3;
	}
	public void setLine3(String line3) {
		this.line3 = line3;
	}
	public Integer getIsAdditionalClause() {
		return isAdditionalClause;
	}
	public void setIsAdditionalClause(Integer isAdditionalClause) {
		this.isAdditionalClause = isAdditionalClause;
	}
	
	public Integer getIsExporterDeclClause() {
		return isExporterDeclClause;
	}
	public void setIsExporterDeclClause(Integer isExporterDeclClause) {
		this.isExporterDeclClause = isExporterDeclClause;
	}
	public Integer getIsPaymentTerm() {
		return isPaymentTerm;
	}
	public void setIsPaymentTerm(Integer isPaymentTerm) {
		this.isPaymentTerm = isPaymentTerm;
	}
	public Integer getIsPrintClause() {
		return isPrintClause;
	}
	public void setIsPrintClause(Integer isPrintClause) {
		this.isPrintClause = isPrintClause;
	}
	
}