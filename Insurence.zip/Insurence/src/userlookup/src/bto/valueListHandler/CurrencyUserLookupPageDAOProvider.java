package userlookup.src.bto.valueListHandler;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.daotier.listpages.PageDAO;
import docprep.src.bto.base.BTOBase;
import userlookup.src.listhelper.CurrencyUserLookupListHelper;
public class CurrencyUserLookupPageDAOProvider extends BTOBase implements PageDAOProvider {

	public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue) {
        PageDAO pageDAO = null;
        pageDAO = getCurrencyUserLookupDAO().getCurrencyLookup((CurrencyUserLookupListHelper) criteria, startRowNo, pageScrollValue);
        return pageDAO;
    }


}