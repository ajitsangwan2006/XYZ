package userlookup.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import userlookup.src.bto.controller.TradingPartnerLookupManager;
import userlookup.src.bto.valueListHandler.TradingPartnerLookupPageDAOProvider;
import userlookup.src.dto.TradingPartnerLookup;
import userlookup.src.dto.TradingPartnerLookupId;
import userlookup.src.listhelper.TradingPartnerLookupListHelper;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;

public class TradingPartnerLookupManagerImpl extends BTOBase implements TradingPartnerLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }
  
	public PageHandler getTradingPartnerLookup(TradingPartnerLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new TradingPartnerLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        criteria.setSiteId(this.siteId);
        TradingPartnerLookupPageDAOProvider tradingPartnerLookupPageDAOProvider = (TradingPartnerLookupPageDAOProvider) springFactory.getBean("tradingPartnerLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, tradingPartnerLookupPageDAOProvider, pageScrollValue);
    }

	public TradingPartnerLookup get(String partnerId) {
	    return getTradingPartnerLookupDAO().get(new TradingPartnerLookupId(this.siteId,partnerId));
	}
		
    public void create(TradingPartnerLookup instance) throws InvalidArgumentException, DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        if (instance == null) {
            throw new InvalidArgumentException("Trading Partner Lookup connot be null.");
        }
        instance.getId().setSiteId(this.siteId);
        
        TradingPartnerLookup dbInstance = getTradingPartnerLookupDAO().get(instance.getId());        
        if (dbInstance != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("partnerId");
            error.setErrorCode("OZA-80003-13");
            error.setErrorMessage("Duplicate Trading Partner Id is NOT allowed.");
            ValidationErrors errores = new ValidationErrors();
            errores.addValidationError("partnerId", error);
            throw new InvalidArgumentException(errores);
        } 
		getTradingPartnerLookupDAO().create(instance);
		                
    }
    
    public void update(TradingPartnerLookup instance) throws InvalidArgumentException {
        if (instance == null) {
            throw new InvalidArgumentException("TradingPartnerLookup connot be null.");
        }
        instance.getId().setSiteId(this.siteId);                      
        getTradingPartnerLookupDAO().update(instance);
        
    }

	
	public boolean delete(TradingPartnerLookup instance) throws InvalidArgumentException {
		 if (instance == null) {
            throw new InvalidArgumentException("Lookup cannot be null");
        }
        if (instance.getId().getPartnerId() == null || instance.getId().getPartnerId().trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.PartnerId");
            invalidArgumentException.setErrorOzCode("system.errors.PartnerId");
            throw invalidArgumentException;
        }
        boolean result = false;
        instance.getId().setSiteId(this.siteId);
        instance.getId().setPartnerId(instance.getId().getPartnerId());
        getTradingPartnerLookupDAO().delete(instance);
        result = true;
        return result;
	}
    
}