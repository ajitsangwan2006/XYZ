package userlookup.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.LoggerUtils;
import docprep.src.bto.base.BTOBase;
import userlookup.src.bto.controller.ProductUserLookupManager;
import userlookup.src.bto.valueListHandler.ProductUserLookupPageDAOProvider;
import docprep.src.bto.base.SpringFactoryUtil;
import userlookup.src.dto.ProductUserLookup;
import userlookup.src.listhelper.ProductUserLookupListHelper;

public class ProductUserLookupManagerImpl extends BTOBase implements ProductUserLookupManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;
		
    public void initialize(int pageScrollValue, dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder, String siteId, String userId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.siteId = siteId;
        this.userId = userId;
        this.ipAddress = ipAddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       
    }

    public ProductUserLookup getProduct(String productCode) throws InvalidArgumentException {
        if (productCode == null || productCode.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.ProductCode");
            invalidArgumentException.setErrorOzCode("system.errors.ProductCode");
            throw invalidArgumentException;
        }
        if (userId == null || userId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.UserId");
            invalidArgumentException.setErrorOzCode("system.errors.UserId");
            throw invalidArgumentException;
        }
        ProductUserLookup product = null;
        product = getProductUserLookupDAO().getProduct(this.siteId,productCode);
        return product;
    }
    public PageHandler getProductList(ProductUserLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new ProductUserLookupListHelper();
        }
        criteria.setSiteId(siteId);
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ProductUserLookupPageDAOProvider productPageDAOProvider = (ProductUserLookupPageDAOProvider) springFactory.getBean("productUserLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, productPageDAOProvider, pageScrollValue);
    }
    public ProductUserLookup create(ProductUserLookup criteria) throws InvalidArgumentException, DuplicateRecordException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Product");
            invalidArgumentException.setErrorOzCode("system.errors.Product");
            throw invalidArgumentException;
        }
        criteria.getId().setSiteId(this.siteId);
        criteria.getId().setUserId(this.userId);
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            LoggerUtils.getBTOLogger().info("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }

       criteria = getProductUserLookupDAO().create(criteria);
       
        return criteria;
      
    }      
    public void update(ProductUserLookup criteria) throws InvalidArgumentException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Product");
            invalidArgumentException.setErrorOzCode("system.errors.Product");
            throw invalidArgumentException;
        }
        criteria.getId().setSiteId(this.siteId);
        criteria.getId().setUserId(this.userId);
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            LoggerUtils.getBTOLogger().info("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        getProductUserLookupDAO().update(criteria);
        
    }
    public boolean delete(String productCode) throws InvalidArgumentException {
        if (productCode == null) {
            throw new InvalidArgumentException("Lookup cannot be null");
        }
        ProductUserLookup productUserLookup = getProductUserLookupDAO().getProduct(this.siteId,productCode);
        boolean result = false;
        getProductUserLookupDAO().delete(productUserLookup);
        result = true;

        return result;
    }
    
}
