package userlookup.src.bto.controllerImpl;

import java.util.Date;

import org.apache.commons.validator.GenericValidator;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import userlookup.src.bto.controller.CurrencyUserLookupManager;
import userlookup.src.bto.valueListHandler.CurrencyUserLookupPageDAOProvider;
import userlookup.src.dto.CurrencyUserLookup;
import userlookup.src.listhelper.CurrencyUserLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;

public class CurrencyUserLookupManagerImpl extends BTOBase implements CurrencyUserLookupManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();

    }

    public CurrencyUserLookup getCurrency(String currencyCode) throws InvalidArgumentException {

        if (currencyCode == null || currencyCode.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Currency");
            invalidArgumentException.setErrorOzCode("system.errors.Currency");
            throw invalidArgumentException;
        }
        CurrencyUserLookup currency = null;
        currency = getCurrencyUserLookupDAO().getCurrencyLookup(currencyCode);

        return currency;
    }

    public PageHandler getCurrencyList(CurrencyUserLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new CurrencyUserLookupListHelper();
        }

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CurrencyUserLookupPageDAOProvider currencyPageDAOProvider = (CurrencyUserLookupPageDAOProvider) springFactory.getBean("currencyUserLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, currencyPageDAOProvider, pageScrollValue);
    }

    public CurrencyUserLookup create(CurrencyUserLookup instance) throws InvalidArgumentException, DuplicateRecordException {
        if (instance == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Currency");
            invalidArgumentException.setErrorOzCode("system.errors.Currency");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = instance.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        CurrencyUserLookup currencyLookup = getCurrencyUserLookupDAO().getCurrencyLookup(instance.getCurrencyCode());
        if (currencyLookup != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("currencyCode");
            error.setErrorCode("OZA-80003-13");
            error.setErrorMessage("Duplicate  Currency Code is NOT allowed.");
            ValidationErrors errores = new ValidationErrors();
            errores.addValidationError("currencyCode", error);
            throw new InvalidArgumentException(errores);
        }
        instance.setRateDate(new Date());
        getCurrencyUserLookupDAO().create(instance);
        return instance;
    }

    public CurrencyUserLookup update(CurrencyUserLookup instance) throws InvalidArgumentException {
        if (instance == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Currency");
            invalidArgumentException.setErrorOzCode("system.errors.Currency");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = instance.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        instance.setRateDate(new Date());
        getCurrencyUserLookupDAO().update(instance);

        return instance;
    }

    public boolean delete(String currencyCode) throws RecordNotFoundException, InvalidArgumentException {

        if (GenericValidator.isBlankOrNull(currencyCode)) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Currencydelete");
            throw invalidArgumentException;
        }
        boolean result = false;
        CurrencyUserLookup currency = getCurrencyUserLookupDAO().getCurrencyLookup(currencyCode);
        getCurrencyUserLookupDAO().delete(currency);
        result = true;

        return result;
    }

}
