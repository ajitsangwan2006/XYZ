package userlookup.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.handler.ProgrammingExceptionHandler;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.LoggerUtils;
import docprep.src.bto.base.BTOBase;
import userlookup.src.bto.controller.ClausesUserLookupManager;
import userlookup.src.bto.valueListHandler.ClausesUserLookupPageDAOProvider;
import docprep.src.bto.base.SpringFactoryUtil;
import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;

public class ClausesUserLookupManagerImpl extends BTOBase implements ClausesUserLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String siteId, String userId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.siteId = siteId;
        this.userId = userId;
        this.ipAddress = ipAddress;
    }

    public PageHandler getClausesList(ClausesUserLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new ClausesUserLookupListHelper();
        }
        criteria.setSiteId(siteId);
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ClausesUserLookupPageDAOProvider clausesPageDAOProvider = (ClausesUserLookupPageDAOProvider) springFactory.getBean("clausesUserLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, clausesPageDAOProvider, pageScrollValue);
    }
    
    public ClausesUserLookup getClauses(String clauseId) throws InvalidArgumentException {
        if (clauseId == null || clauseId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Clause");
            invalidArgumentException.setErrorOzCode("system.errors.Clause");
            throw invalidArgumentException;
        }
       ClausesUserLookup clauses = null;
        try {
        	clauses = getClausesUserLookupDAO().getClausesUserLookup(this.siteId, this.userId, clauseId);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return clauses;
    }
    
    public void createClauses(ClausesUserLookup criteria) throws InvalidArgumentException, DuplicateRecordException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Clause");
            invalidArgumentException.setErrorOzCode("system.errors.Clause");
            throw invalidArgumentException;
        }
        criteria.getId().setSiteId(this.siteId);
        criteria.getId().setUserId(this.userId);
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            LoggerUtils.getBTOLogger().info("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        criteria.setIsPaymentTerm(new Integer(0));
        criteria.setIsPrintClause(new Integer(0));
        criteria.setIsAdditionalClause(new Integer(0));
        criteria.setIsExporterDeclClause(new Integer(0));
  
        if(criteria.getClauseType().equalsIgnoreCase("Payment Term")){
        	criteria.setIsPaymentTerm(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Print Clause")){
        	criteria.setIsPrintClause(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Additional Clause")){
        	criteria.setIsAdditionalClause(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Exporter Declaration Clause")){
        	criteria.setIsExporterDeclClause(new Integer(1));
        }
    	ClausesUserLookup clausesUserLookup = getClausesUserLookupDAO().getClausesUserLookup(this.siteId,this.userId,criteria.getId().getClauseId());
    	if(clausesUserLookup != null){
    		ValidationError error = new ValidationError();
            error.setPropertyName("clauseId");
            error.setErrorCode("OZA-80003-13");
            error.setErrorMessage("Duplicate Trading Clause Id is NOT allowed.");
            ValidationErrors errores = new ValidationErrors();
            errores.addValidationError("clauseId", error);
            throw new InvalidArgumentException(errores);
    	}
    	getClausesUserLookupDAO().createClausesUserLookup(criteria);           
       
      }

    public ClausesUserLookup updateClauses(ClausesUserLookup criteria) throws InvalidArgumentException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Clause");
            invalidArgumentException.setErrorOzCode("system.errors.Clause");
            throw invalidArgumentException;
        }
        criteria.getId().setSiteId(this.siteId);
        criteria.getId().setUserId(this.userId);
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            LoggerUtils.getBTOLogger().info("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        criteria.setIsPaymentTerm(new Integer(0));
        criteria.setIsPrintClause(new Integer(0));
        criteria.setIsAdditionalClause(new Integer(0));
        criteria.setIsExporterDeclClause(new Integer(0));
  
        if(criteria.getClauseType().equalsIgnoreCase("Payment Term")){
        	criteria.setIsPaymentTerm(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Print Clause")){
        	criteria.setIsPrintClause(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Additional Clause")){
        	criteria.setIsAdditionalClause(new Integer(1));
        }else if(criteria.getClauseType().equalsIgnoreCase("Exporter Declaration Clause")){
        	criteria.setIsExporterDeclClause(new Integer(1));
        }
        getClausesUserLookupDAO().updateClausesUserLookup(criteria);     
        return criteria;
    }
    
    public boolean deleteClauses(String clauseId) throws InvalidArgumentException {
        if (clauseId == null) {
            throw new InvalidArgumentException("clauseId cannot be null");
        }
        ClausesUserLookup clausesUserLookup = getClausesUserLookupDAO().getClausesUserLookup(this.siteId,this.userId,clauseId);
        boolean result = false;
        getClausesUserLookupDAO().delete(clausesUserLookup);
        result = true;
        return result;
    }


}
