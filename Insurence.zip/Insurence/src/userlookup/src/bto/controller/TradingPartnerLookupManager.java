
package userlookup.src.bto.controller;

import userlookup.src.dto.TradingPartnerLookup;
import userlookup.src.listhelper.TradingPartnerLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;

public interface TradingPartnerLookupManager {
    
    public PageHandler getTradingPartnerLookup(TradingPartnerLookupListHelper criteria);
    
    public TradingPartnerLookup get(String partnerId)throws InvalidArgumentException;
    
    public void create(TradingPartnerLookup instance) throws InvalidArgumentException, DuplicateRecordException;
    
    public void update(TradingPartnerLookup instance) throws InvalidArgumentException;
    
    public boolean delete(TradingPartnerLookup instance) throws InvalidArgumentException;
 }