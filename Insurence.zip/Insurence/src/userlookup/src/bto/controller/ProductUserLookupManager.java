package userlookup.src.bto.controller;

import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import userlookup.src.dto.ProductUserLookup;
import userlookup.src.listhelper.ProductUserLookupListHelper;

public interface ProductUserLookupManager {
	
    public PageHandler getProductList(ProductUserLookupListHelper criteria);
    
    public ProductUserLookup getProduct(String productCode) throws InvalidArgumentException;
    
    public ProductUserLookup create(ProductUserLookup criteria) throws InvalidArgumentException, DuplicateRecordException;
    
    public void update(ProductUserLookup criteria) throws InvalidArgumentException;    

    public boolean delete(String productCode) throws InvalidArgumentException;
    
       
}

