
package userlookup.src.bto.controller;

import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import userlookup.src.listhelper.CurrencyUserLookupListHelper;
import userlookup.src.dto.CurrencyUserLookup;

public interface CurrencyUserLookupManager {
    
    public PageHandler getCurrencyList(CurrencyUserLookupListHelper criteria);

    public CurrencyUserLookup getCurrency(String currencyCode) throws InvalidArgumentException;

    public CurrencyUserLookup create(CurrencyUserLookup criteria) throws InvalidArgumentException, DuplicateRecordException;

   public CurrencyUserLookup update(CurrencyUserLookup criteria) throws InvalidArgumentException;

    public boolean delete(String currencyCode ) throws RecordNotFoundException, InvalidArgumentException;
    
}

