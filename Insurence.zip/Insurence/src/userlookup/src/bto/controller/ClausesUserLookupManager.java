package userlookup.src.bto.controller;

import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;

public interface ClausesUserLookupManager {
	
    public PageHandler getClausesList(ClausesUserLookupListHelper criteria);
    
    public ClausesUserLookup getClauses(String clauseId) throws InvalidArgumentException;
    
    public void createClauses(ClausesUserLookup criteria) throws InvalidArgumentException, DuplicateRecordException;
    
    public ClausesUserLookup updateClauses(ClausesUserLookup criteria) throws InvalidArgumentException;

    public boolean deleteClauses(String clauseId) throws InvalidArgumentException;
   
}

