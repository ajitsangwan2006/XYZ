package codemaintenance.src.dao.interfaces;



import codemaintenance.src.dto.VesselLookup;
import codemaintenance.src.listhelper.VesselLookupListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public interface VesselLookupDAO extends DAO {    
   
	public PageDAO getVesselLookupList(VesselLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;
			
	public VesselLookup getVesselLookup(String code)throws DAOException, InvalidDAOArgumentException;

	
} 