package codemaintenance.src.dao.interfaces;

import codemaintenance.src.dto.CurrencyLookup;
import codemaintenance.src.listhelper.CurrencyLookupListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;


public interface CurrencyLookupDAO extends DAO {    
   
	public PageDAO getCurrencyLookupList(CurrencyLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;
	
	public CurrencyLookup getCurrencyLookup(String code)throws DAOException, InvalidDAOArgumentException;

	public CurrencyLookup createCurrencyLookup(CurrencyLookup criteria) throws DAOException,InvalidDAOArgumentException,DuplicateRecordException ;

	public void updateCurrencyLookup(CurrencyLookup criteria)	throws DAOException, InvalidDAOArgumentException,RecordNotFoundException;

    public void deleteCurrencyLookup(CurrencyLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
}