package codemaintenance.src.dao.interfaces;

import codemaintenance.src.dto.CountryLookup;
import codemaintenance.src.listhelper.CountryLookupListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;



public interface CountryLookupDAO extends DAO {    
   
	public PageDAO getCountryCodeList(CountryLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;
	
	public CountryLookup getCountryCode(String countryCode)throws DAOException, InvalidDAOArgumentException;
	
	public CountryLookup getCountryCode2(String countryCode2)throws DAOException, InvalidDAOArgumentException;

}