package codemaintenance.src.dao.interfaces;


import codemaintenance.src.dto.PortLookup;
import codemaintenance.src.dto.PortLookupId;
import codemaintenance.src.listhelper.PortLookupListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;

import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public interface PortLookupDAO extends DAO {    
   
	public PageDAO getPortLookupList(PortLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException ;
			
	public PortLookup getPortLookUp(PortLookupId id)throws DAOException, InvalidDAOArgumentException;

	
} 