package codemaintenance.src.dao.impl;

import java.util.List;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import codemaintenance.src.dao.interfaces.CountryLookupDAO;
import codemaintenance.src.dto.CountryLookup;
import codemaintenance.src.listhelper.CountryLookupListHelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public class CountryLookupDAOImpl extends DAOImpl implements CountryLookupDAO {

    public PageDAO getCountryCodeList(CountryLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);

            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace(System.err);
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public CountryLookup getCountryCode(String countryCode) throws DAOException, InvalidDAOArgumentException {
        if (countryCode == null) {
            throw new InvalidDAOArgumentException("Country Code can not be NULL.");
        }
        CountryLookupListHelper criteria = new CountryLookupListHelper();
        criteria.setCountryCode(countryCode);
        List list = getCountryCodeList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (CountryLookup) list.get(0);
        } else {
            return null;
        }
    }
    
    public CountryLookup getCountryCode2(String countryCode2) throws DAOException, InvalidDAOArgumentException {
    	 if (countryCode2 == null) {
            throw new InvalidDAOArgumentException("Country Code can not be NULL.");
        }
        CountryLookupListHelper criteria = new CountryLookupListHelper();
        criteria.setCountryCode2(countryCode2);
        List list = getCountryCodeList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (CountryLookup) list.get(0);
        } else {
            return null;
        }
	}

    private Criteria buildCriteria(CountryLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(CountryLookup.class);

        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getCountryCode())) {
                criteria.add(Restrictions.like("countryCode", prepareWildcardSearchString(listHelper.getCountryCode())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCountryCode2())) {
                criteria.add(Restrictions.like("countryCode2", prepareWildcardSearchString(listHelper.getCountryCode2())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCountryName())) {
                criteria.add(Restrictions.like("countryName", prepareWildcardSearchString(listHelper.getCountryName())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(CountryLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("countryCode");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("countryCode")) {
                criteria.addOrder(Order.asc("countryCode"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

	
}
