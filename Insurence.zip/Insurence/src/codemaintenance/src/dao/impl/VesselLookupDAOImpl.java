package codemaintenance.src.dao.impl;

import java.util.List;
import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import codemaintenance.src.dao.interfaces.VesselLookupDAO;
import codemaintenance.src.dto.VesselLookup;
import codemaintenance.src.listhelper.VesselLookupListHelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;




public class VesselLookupDAOImpl extends DAOImpl implements VesselLookupDAO {

    public PageDAO getVesselLookupList(VesselLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace(System.err);
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public VesselLookup getVesselLookup(String code) throws DAOException, InvalidDAOArgumentException {
        if (code == null) {
            throw new InvalidDAOArgumentException("Acos Code can not be NULL.");
        }
        VesselLookupListHelper criteria = new VesselLookupListHelper();
        criteria.setVesselCode(code);
        List list = getVesselLookupList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (VesselLookup) list.get(0);
        } else {
            return null;
        }
    }
        
    private Criteria buildCriteria(VesselLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(VesselLookup.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getVesselCode())) {
                criteria.add(Restrictions.like("vesselCode", prepareWildcardSearchString(listHelper.getVesselCode())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getVesselName())) {
                criteria.add(Restrictions.like("vesselName", prepareWildcardSearchString(listHelper.getVesselName())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(VesselLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("vesselCode");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("vesselCode")) {
                criteria.addOrder(Order.asc("vesselCode"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

}
