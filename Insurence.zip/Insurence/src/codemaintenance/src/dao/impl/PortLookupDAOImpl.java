package codemaintenance.src.dao.impl;

import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import codemaintenance.src.dao.interfaces.PortLookupDAO;
import codemaintenance.src.dto.PortLookup;
import codemaintenance.src.dto.PortLookupId;
import codemaintenance.src.listhelper.PortLookupListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;




public class PortLookupDAOImpl extends DAOImpl implements PortLookupDAO {

    public PageDAO getPortLookupList(PortLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);
            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public PortLookup getPortLookUp(PortLookupId id) throws DAOException, InvalidDAOArgumentException {
        if (id == null) {
            throw new InvalidDAOArgumentException("PortLookup Id  can not be NULL.");
        }
        PortLookupListHelper criteria = new PortLookupListHelper();
        criteria.setPortCode(id.getPortCode());
        criteria.setIsoCode(id.getIsoCode());
        List list = getPortLookupList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (PortLookup) list.get(0);
        } else {
            return null;
        }
    }

    private Criteria buildCriteria(PortLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(PortLookup.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getPortCode())) {
                criteria.add(Restrictions.like("id.portCode", prepareWildcardSearchString(listHelper.getPortCode())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getPortName())) {
                criteria.add(Restrictions.like("portName", prepareWildcardSearchString(listHelper.getPortName())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getIsoCode())) {
                criteria.add(Restrictions.like("id.isoCode", prepareWildcardSearchString(listHelper.getIsoCode())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(PortLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("id.portCode");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("id.portCode")) {
                criteria.addOrder(Order.asc("id.portCode"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        if (columnName.equals("portCode")) {
            return "id.portCode";
        } else if (columnName.equals("isoCode")) {
            return "id.isoCode";
        }
        return columnName;
    }
}
