package codemaintenance.src.dao.impl;

import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import codemaintenance.src.dao.interfaces.CurrencyLookupDAO;
import codemaintenance.src.dto.CurrencyLookup;
import codemaintenance.src.listhelper.CurrencyLookupListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;

public class CurrencyLookupDAOImpl extends DAOImpl implements CurrencyLookupDAO {

    public PageDAO getCurrencyLookupList(CurrencyLookupListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            int totalRecords = getTotalRecords(criteriaForCounter);

            Criteria criteriaForList = buildCriteria(listHelper, session, false);
            PageDAOImpl page = buildPageDAO(startRowNo, scrollValue, totalRecords, criteriaForList);
            return page;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public CurrencyLookup getCurrencyLookup(String currencyCode) throws DAOException, InvalidDAOArgumentException {
        if (currencyCode == null) {
            throw new InvalidDAOArgumentException("Currency Code can not be NULL.");
        }
        CurrencyLookupListHelper criteria = new CurrencyLookupListHelper();
        criteria.setCurrencyCode(currencyCode);
        List list = getCurrencyLookupList(criteria, -1, -1).getCurrentPageData();
        if (list.size() > 0) {
            return (CurrencyLookup) list.get(0);
        } else {
            return null;
        }
    }

    public CurrencyLookup createCurrencyLookup(CurrencyLookup criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        Session session = null;
        int resultint = 0;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        if (criteria.getCurrencyCode() == null) {
            throw new InvalidDAOArgumentException("Currency Code can not be NULL.");
        }

        CurrencyLookup isCurrencyLookupExist = getCurrencyLookup(criteria.getCurrencyCode());
        if (isCurrencyLookupExist != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("currencyCode");
            error.setErrorCode("OZA-80003-2");
            error.setErrorMessage("Currency already exist with this Code, please enter another Code.");
            ValidationErrors errors = new ValidationErrors();
            errors.addValidationError("currencyCode", error);
            throw new DuplicateRecordException(errors);
        }
        try {
            session = getHibernateSession();
            session.save(criteria);
            session.flush();

        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return criteria;
    }

    public void updateCurrencyLookup(CurrencyLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;

        int resultint = 0;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        if (criteria.getCurrencyCode() == null) {
            throw new InvalidDAOArgumentException("Currency Code can not be NULL.");
        }
        try {
            session = getHibernateSession();
            session.clear();
            session.update(criteria);
            session.flush();
        } catch (HibernateException hex) {
            CurrencyLookup isCurrencyLookupExist = getCurrencyLookup(criteria.getCurrencyCode());
            if (isCurrencyLookupExist == null) {
                throw new RecordNotFoundException("No Country Code found for this Criteria.");
            }
        } finally {
            closeSession(session);
        }
    }

    public void deleteCurrencyLookup(CurrencyLookup criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {

        Session session = null;
        if (criteria == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            Query hqlDelete = session.getNamedQuery("hql.Currencydelete");
            hqlDelete.setString("SelcurrencyCode", criteria.getCurrencyCode());
            int deletedEntities = hqlDelete.executeUpdate();
            session.flush();
        } catch (HibernateException hex) {
            CurrencyLookup isCurrencyLookupExist = getCurrencyLookup(criteria.getCurrencyCode());
            if (isCurrencyLookupExist == null) {
                throw new RecordNotFoundException("No Currency found for this Criteria.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    private Criteria buildCriteria(CurrencyLookupListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(CurrencyLookup.class);

        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            loadBTOCriteria(listHelper, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getCurrencyCode())) {
                criteria.add(Restrictions.like("currencyCode", prepareWildcardSearchString(listHelper.getCurrencyCode())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getCurrencyName())) {
                criteria.add(Restrictions.like("currencyName", prepareWildcardSearchString(listHelper.getCurrencyName())));
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(CurrencyLookupListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("currencyCode");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("currencyCode")) {
                criteria.addOrder(Order.asc("currencyCode"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {

        return columnName;
    }

}
