package codemaintenance.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import codemaintenance.src.bto.controller.CountryLookupManager;
import codemaintenance.src.bto.valueListHandler.CountryLookupPageDAOProvider;
import codemaintenance.src.dto.CountryLookup;
import codemaintenance.src.listhelper.CountryLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;



public class CountryLookupManagerImpl extends BTOBase implements CountryLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getCountryLookup(CountryLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new CountryLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CountryLookupPageDAOProvider countryLookupPageDAOProvider = (CountryLookupPageDAOProvider) springFactory.getBean("countryLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, countryLookupPageDAOProvider, pageScrollValue);
    }
    
    public CountryLookup getCountryLookup(String countryCode) throws InvalidArgumentException {
        if (countryCode == null || countryCode.trim().length() <= 0) {
            throw new InvalidArgumentException("CountryCode connot be null.");
        }
        CountryLookup countryLookup = null;
        countryLookup = getCountryLookupDAO().getCountryCode(countryCode);
        return countryLookup;
    }

}
