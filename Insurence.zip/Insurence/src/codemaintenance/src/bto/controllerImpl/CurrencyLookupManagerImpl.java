package codemaintenance.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import codemaintenance.src.bto.controller.CurrencyLookupManager;
import codemaintenance.src.bto.valueListHandler.CurrencyLookupPageDAOProvider;
import codemaintenance.src.dto.CurrencyLookup;
import codemaintenance.src.listhelper.CurrencyLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;

public class CurrencyLookupManagerImpl extends BTOBase implements CurrencyLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getCurrencyList(CurrencyLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new CurrencyLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CurrencyLookupPageDAOProvider currencyLookupPageDAOProvider = (CurrencyLookupPageDAOProvider) springFactory.getBean("currencyLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, currencyLookupPageDAOProvider, pageScrollValue);
    }

    public CurrencyLookup getCurrency(String currencyCode) throws InvalidArgumentException {
        if (currencyCode == null || currencyCode.trim().length() <= 0) {
            throw new InvalidArgumentException("Currency Code connot be null.");
        }
        CurrencyLookup CurrencyLookup = null;
        CurrencyLookup = getCurrencyLookupDAO().getCurrencyLookup(currencyCode);
        return CurrencyLookup;
    }
}