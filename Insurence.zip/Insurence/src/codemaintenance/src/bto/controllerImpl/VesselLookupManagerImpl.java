package codemaintenance.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import codemaintenance.src.bto.controller.VesselLookupManager;
import codemaintenance.src.bto.valueListHandler.VesselLookupPageDAOProvider;
import codemaintenance.src.dto.VesselLookup;
import codemaintenance.src.listhelper.VesselLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public class VesselLookupManagerImpl extends BTOBase implements VesselLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getVesselLookup(VesselLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new VesselLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        VesselLookupPageDAOProvider portLookupPageDAOProvider = (VesselLookupPageDAOProvider) springFactory.getBean("vesselLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, portLookupPageDAOProvider, pageScrollValue);
    }

    public VesselLookup getVesselLookup(String code) throws InvalidArgumentException {
        if (code == null || code.trim().length() <= 0) {
            throw new InvalidArgumentException("Code connot be null.");
        }
        VesselLookup vesselLookup = null;
        vesselLookup = getVesselLookupDAO().getVesselLookup(code);
        return vesselLookup;
    }

}
