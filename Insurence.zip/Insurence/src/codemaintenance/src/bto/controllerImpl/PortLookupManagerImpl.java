package codemaintenance.src.bto.controllerImpl;


import org.hibernate.criterion.Restrictions;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import codemaintenance.src.bto.controller.PortLookupManager;
import codemaintenance.src.bto.valueListHandler.PortLookupPageDAOProvider;
import codemaintenance.src.dto.PortLookup;
import codemaintenance.src.dto.PortLookupId;
import codemaintenance.src.listhelper.PortLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public class PortLookupManagerImpl extends BTOBase implements PortLookupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public PageHandler getPort(PortLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new PortLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();        
        PortLookupPageDAOProvider portLookupPageDAOProvider = (PortLookupPageDAOProvider) springFactory.getBean("portLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, portLookupPageDAOProvider, pageScrollValue);
    }

    public PageHandler getLoadingPort(PortLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new PortLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();        
        criteria.setCriteriaRestrictionType("Expression");
        criteria.setCriteriaRestriction(Restrictions.like("id.isoCode", "AU"));
        PortLookupPageDAOProvider portLookupPageDAOProvider = (PortLookupPageDAOProvider) springFactory.getBean("portLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, portLookupPageDAOProvider, pageScrollValue);
    }

    public PageHandler getDischargePort(PortLookupListHelper criteria) {
        if (criteria == null) {
            criteria = new PortLookupListHelper();
        }
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();             
        criteria.setCriteriaRestrictionType("Expression");
        criteria.setCriteriaRestriction(Restrictions.ne("id.isoCode", "AU"));
        PortLookupPageDAOProvider portLookupPageDAOProvider = (PortLookupPageDAOProvider) springFactory.getBean("portLookupPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, portLookupPageDAOProvider, pageScrollValue);
    }

    public PortLookup getPort(PortLookupId id) throws InvalidArgumentException {       
        if (id == null) {
            throw new InvalidDAOArgumentException("Port ID can not be NULL.");
        }
        PortLookup portLookup = null;
        portLookup = getPortLookupDAO().getPortLookUp(id);
        return portLookup;
    }

}
