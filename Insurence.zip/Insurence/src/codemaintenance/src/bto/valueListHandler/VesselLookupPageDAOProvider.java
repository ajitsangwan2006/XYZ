package codemaintenance.src.bto.valueListHandler;



import codemaintenance.src.listhelper.VesselLookupListHelper;
import docprep.src.bto.base.BTOBase;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.daotier.listpages.PageDAO;

public class VesselLookupPageDAOProvider extends BTOBase implements PageDAOProvider {
    public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue) {
        PageDAO pageDAO = null;
        pageDAO = getVesselLookupDAO().getVesselLookupList((VesselLookupListHelper) criteria, startRowNo, pageScrollValue);
        return pageDAO;
    }
}
