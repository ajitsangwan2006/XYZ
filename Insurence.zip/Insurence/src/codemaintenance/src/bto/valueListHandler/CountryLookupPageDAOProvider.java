package codemaintenance.src.bto.valueListHandler;

import codemaintenance.src.listhelper.CountryLookupListHelper;
import docprep.src.bto.base.BTOBase;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.daotier.listpages.PageDAO;




public class CountryLookupPageDAOProvider extends BTOBase implements PageDAOProvider {
    public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue) {
        PageDAO pageDAO = null;
        pageDAO = getCountryLookupDAO().getCountryCodeList((CountryLookupListHelper) criteria, startRowNo, pageScrollValue);
        return pageDAO;
    }
}
