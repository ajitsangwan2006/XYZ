package codemaintenance.src.bto.controller;




import codemaintenance.src.dto.PortLookup;
import codemaintenance.src.dto.PortLookupId;
import codemaintenance.src.listhelper.PortLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;


public interface PortLookupManager {
    

    public PageHandler getPort(PortLookupListHelper criteria);
    
    public PageHandler getLoadingPort(PortLookupListHelper criteria);
    
    public PageHandler getDischargePort(PortLookupListHelper criteria);
    
    public PortLookup getPort(PortLookupId id) throws InvalidArgumentException;        
    
    
}