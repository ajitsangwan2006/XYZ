package codemaintenance.src.bto.controller;

import codemaintenance.src.dto.CurrencyLookup;
import codemaintenance.src.listhelper.CurrencyLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public interface CurrencyLookupManager {
    
    public PageHandler getCurrencyList(CurrencyLookupListHelper criteria);
     
    public CurrencyLookup getCurrency(String currencyCode) throws InvalidArgumentException;    
}