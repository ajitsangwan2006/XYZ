package codemaintenance.src.bto.controller;



import codemaintenance.src.dto.VesselLookup;
import codemaintenance.src.listhelper.VesselLookupListHelper;


import dev.zing.framework.businesstier.listpages.PageHandler;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public interface VesselLookupManager {
    
    public PageHandler getVesselLookup(VesselLookupListHelper criteria);
    
    public VesselLookup getVesselLookup(String code) throws InvalidArgumentException;
        
}