package codemaintenance.src.bto.controller;

import codemaintenance.src.dto.CountryLookup;
import codemaintenance.src.listhelper.CountryLookupListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;



public interface CountryLookupManager {
    
    public PageHandler getCountryLookup(CountryLookupListHelper criteria);
    
    public CountryLookup getCountryLookup(String countryCode) throws InvalidArgumentException;    
    
}