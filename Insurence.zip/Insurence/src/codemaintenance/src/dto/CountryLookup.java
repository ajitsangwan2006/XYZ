package codemaintenance.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class CountryLookup extends ModelImpl implements java.io.Serializable {

    private String countryCode;

    private String countryName;
    
    private String countryCode2;

    public CountryLookup() {
    }

    public CountryLookup(String countryCode, String countryName,String countryCode2) {
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.countryCode2 = countryCode2;
    }

    public String getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return this.countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    
  	public String getCountryCode2() {
		return countryCode2;
	}
	public void setCountryCode2(String countryCode2) {
		this.countryCode2 = countryCode2;
	}
	
    public void registerJavaScriptValidation() {
        validateNotNull("countryCode");
        validateNotNull("countryName");
        validateAlphaNumeric("countryCode,countryName");
    }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "countryCode"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }

    }

}
