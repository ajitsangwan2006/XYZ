package codemaintenance.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class VesselLookup extends ModelImpl implements java.io.Serializable {

    private String vesselCode;

    private String vesselName;

    public VesselLookup() {
    }

    public VesselLookup(String vesselCode, String vesselName) {
        this.vesselCode = vesselCode;
        this.vesselName = vesselName;
    }

    public String getVesselCode() {
        return this.vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getVesselName() {
        return this.vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }
    
    public void registerJavaScriptValidation() {
        validateNotNull("vesselCode");
        validateAlphaNumeric("vesselCode");
    }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "vesselCode"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }

}
