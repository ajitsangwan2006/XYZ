package codemaintenance.src.dto;

import java.io.Serializable;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class PortLookup extends ModelImpl implements Serializable {

	
	private PortLookupId id;

	private String portName;

	  public PortLookup() {
        id = new PortLookupId();
    }


	public PortLookup(PortLookupId id,
			String portName) {
		this.id = id;
		this.portName = portName;
	}

	public PortLookupId getId() {
		return this.id;
	}

	public void setId(PortLookupId id) {
		this.id = id;
	}

	public String getPortName() {
		return this.portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	
	 public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "id.portName, id.isoCode"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }
}