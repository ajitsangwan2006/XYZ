package codemaintenance.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class CurrencyLookup extends ModelImpl implements java.io.Serializable {

    private String currencyCode;

    private String currencyName;
    
    private String countryName;
   
    public CurrencyLookup() {
    }

    public CurrencyLookup(String currencyCode, String currencyName, String countryName) {
        this.currencyCode = currencyCode;
        this.currencyCode = currencyCode;
        this.countryName=countryName;
       
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyName() {
        return this.currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
    public void registerJavaScriptValidation() {
        validateNotNull("currencyCode");
        validateNotNull("currencyName");
        validateNotNull("countryName");
        validateAlpha("currencyCode");
        validateAlphaNumeric("currencyName");
        validateAlphaNumeric("countryName");
  }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "currencyCode"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }        
    }

}
