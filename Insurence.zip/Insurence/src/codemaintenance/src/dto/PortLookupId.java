package codemaintenance.src.dto;

import java.io.Serializable;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.hbnateValidation.HbnateValidator;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;


public class PortLookupId extends ModelImpl implements Serializable {


	private String portCode;

	private String isoCode;

	
	public PortLookupId() {
	}

	public PortLookupId(String portCode, String isoCode) {
		this.portCode = portCode;
		this.isoCode = isoCode;
	}

	public String getPortCode() {
		return this.portCode;
	}

	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}

	public String getIsoCode() {
		return this.isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof PortLookupId))
			return false;
		PortLookupId castOther = (PortLookupId) other;

		return ((this.getPortCode() == castOther.getPortCode()) || (this
				.getPortCode() != null
				&& castOther.getPortCode() != null && this.getPortCode()
				.equals(castOther.getPortCode())))
				&& ((this.getIsoCode() == castOther.getIsoCode()) || (this
						.getIsoCode() != null
						&& castOther.getIsoCode() != null && this.getIsoCode()
						.equals(castOther.getIsoCode())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getPortCode() == null ? 0 : this.getPortCode().hashCode());
		result = 37 * result
				+ (getIsoCode() == null ? 0 : this.getIsoCode().hashCode());
		return result;
	}

	
	public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        HbnateValidator hbnateValidator = HbnateValidator.getInstance();
        errors.add(hbnateValidator.validate(this, true, "portCode, isoCode"));
        errors.add(validationRegisterer.validate(this));
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }

}
