package codemaintenance.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class PortLookupListHelper extends ListHelperImpl {

    private String portCode;

    private String portName;

    private String isoCode;

    public String getIsoCode() {
        return isoCode;
    }
    
    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }
    
    public String getPortCode() {
        return portCode;
    }
    
    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }
    
    public String getPortName() {
        return portName;
    }
    
    public void setPortName(String portName) {
        this.portName = portName;
    }

}
