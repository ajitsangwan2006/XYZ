package codemaintenance.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class CurrencyLookupListHelper extends ListHelperImpl {

    private String currencyCode;

    private String currencyName;

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String selCurrencyCode) {
        this.currencyCode = selCurrencyCode;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String selCurrencyName) {
        this.currencyName = selCurrencyName;
    }
}
