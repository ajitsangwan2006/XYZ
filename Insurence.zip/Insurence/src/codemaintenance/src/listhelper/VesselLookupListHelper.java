package codemaintenance.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class VesselLookupListHelper extends ListHelperImpl {	

	private String vesselCode;
	
	private String vesselName;

	public String getVesselCode() {
		return vesselCode;
	}
	public void setVesselCode(String vesselCode) {
		this.vesselCode = vesselCode;
	}
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
}
 