package codemaintenance.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class CountryLookupListHelper extends ListHelperImpl {

    private String countryCode;
    
    private String countryCode2;

    private String countryName;

    private String lookupType;

    private String frameMode;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getFrameMode() {
        return frameMode;
    }

    public void setFrameMode(String frameMode) {
        this.frameMode = frameMode;
    }

    public String getLookupType() {
        return lookupType;
    }

    public void setLookupType(String lookupType) {
        this.lookupType = lookupType;
    }
    
	public String getCountryCode2() {
		return countryCode2;
	}
	public void setCountryCode2(String countryCode2) {
		this.countryCode2 = countryCode2;
	}
}
