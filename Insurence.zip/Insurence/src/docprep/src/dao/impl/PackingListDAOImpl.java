package docprep.src.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dao.interfaces.PackingListDAO;
import docprep.src.dto.PackingList;

public class PackingListDAOImpl extends DAOImpl implements PackingListDAO {

    public PackingList get(String sysDocId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(PackingList.class);
            criteria.add(Restrictions.like("sysDocId", new Long(sysDocId)));
            List list = criteria.list();
            if (list.size() > 0) {
                return (PackingList) list.get(0);
            }
            return null;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public PackingList get(String sysDocId, Integer packingListId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(PackingList.class);
            criteria.add(Restrictions.like("sysDocId", new Long(sysDocId)));
            criteria.add(Restrictions.eq("packingListId", packingListId));
            List list = criteria.list();
            if (list.size() > 0) {
                return (PackingList) list.get(0);
            }
            return null;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public void create(PackingList instance) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        Session session = null;
        int resultint = 0;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            session.save(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    public void update(PackingList instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.clear();
            session.saveOrUpdate(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (sysDocId == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            Query hqlDelete = session.getNamedQuery("hql.DeletePackingList");
            hqlDelete.setString("selSysDocId", sysDocId);
            int deletedEntities = hqlDelete.executeUpdate();
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

}