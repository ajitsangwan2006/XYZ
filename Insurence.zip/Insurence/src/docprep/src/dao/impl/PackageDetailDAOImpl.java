package docprep.src.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import docprep.src.dao.interfaces.PackageDetailDAO;
import docprep.src.dto.PackageDetail;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public class PackageDetailDAOImpl extends DAOImpl implements PackageDetailDAO {

    public List get(String docId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(PackageDetail.class);
            criteria.add(Restrictions.like("id.sysDocId", new Long(docId)));
            return criteria.list();
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public PackageDetail get(String sysDocId, Integer lineNumber) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(PackageDetail.class);
            criteria.add(Restrictions.like("id.sysDocId", new Long(sysDocId)));
            criteria.add(Restrictions.like("id.lineNumber", lineNumber));
            List list = criteria.list();
            if (list.size() > 0) {
                return (PackageDetail) list.get(0);
            }
            return null;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public void create(PackageDetail instance) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        int resultint = 0;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            session.save(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        if (sysDocId == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            Query hqlDelete = session.getNamedQuery("hql.DeletePackageDetailLines");
            hqlDelete.setString("selSysDocId", sysDocId);
            int deletedEntities = hqlDelete.executeUpdate();
            session.flush();
        } catch (HibernateException hex) {
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }
}
