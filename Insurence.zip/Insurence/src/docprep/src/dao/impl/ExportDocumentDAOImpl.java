package docprep.src.dao.impl;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dao.interfaces.ExportDocumentDAO;
import docprep.src.dto.ExportDocument;
import docprep.src.listhelper.ExportDocumentListHelper;

public class ExportDocumentDAOImpl extends DAOImpl implements ExportDocumentDAO {

    public PageDAO getList(ExportDocumentListHelper criteria, int startRowNo, int scrollValue) throws DAOException {

        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getHibernateSession();
            Criteria criteriaForCounter = buildCriteria(criteria, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);
            Criteria criteriaForList = buildCriteria(criteria, session, false);
            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();
            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());
        } catch (HibernateException e) {
            throw new DAOException(e);
        } catch (ParseException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
        return page;
    }

    public PageDAO getList(ExportDocumentListHelper criteria) throws DAOException {
        return getList(criteria, -1, -1);
    }

    public ExportDocument get(String siteId, String userId, String sysDocId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        if (userId == null) {
            throw new InvalidDAOArgumentException("User Id can not be NULL.");
        }
        if (sysDocId == null) {
            throw new InvalidDAOArgumentException("SysDocId  can not be NULL.");
        }
        ExportDocumentListHelper criteria = new ExportDocumentListHelper();
        criteria.setSiteId(siteId);
        criteria.setUserId(userId);
        criteria.setSysDocId(new Long(sysDocId));
        List list = getList(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (ExportDocument) list.get(0);
        } else {
            return null;
        }
    }

    public ExportDocument getByDocumentType(String siteId, Long parentId, String docTypeCode) throws DAOException, InvalidDAOArgumentException {
        ExportDocumentListHelper criteria = new ExportDocumentListHelper();
        criteria.setSiteId(siteId);
        criteria.setParentId(parentId);
        criteria.setDocTypeCode(docTypeCode);
        List list = getList(criteria).getCurrentPageData();
        if (list.size() > 0) {
            return (ExportDocument) list.get(0);
        } else {
            return null;
        }
    }

    public ExportDocument create(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {

        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.clear();
            Long sysDocId = (Long) session.save(instance);
            instance.setSysDocId(sysDocId);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return instance;
    }

    public void update(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.clear();
            session.saveOrUpdate(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace();
            ExportDocument isDocumentsExist = get(instance.getSiteId(), instance.getUserId(), instance.getSysDocId().toString());
            if (isDocumentsExist == null) {
                throw new RecordNotFoundException("No Entry exists for this SiteId, UserId and  SysDocId ");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    public void delete(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.clear();
            session.delete(instance);
            session.flush();
        } catch (HibernateException hex) {
            ExportDocument isDocumentsExist = get(instance.getSiteId(), instance.getUserId(), instance.getSysDocId().toString());
            if (isDocumentsExist == null) {
                throw new RecordNotFoundException("No Entry exists for this SiteId, UserId, SysDocId and Document Type Code.");
            }
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }

    }

    public Long getSysDocId(String siteId, String userId) throws DAOException, InvalidDAOArgumentException {
        if (siteId == null) {
            throw new InvalidDAOArgumentException("Company Id can not be NULL.");
        }
        if (userId == null) {
            throw new InvalidDAOArgumentException("User Id can not be NULL.");
        }
        Session session = null;
        Long sysDocId = new Long(1);
        try {
            session = getSession();
            session.clear();
            Query sqlQuery = null;
            sqlQuery = session.getNamedQuery("sql.findSysDocId");
            sqlQuery.setString("SelSiteId", siteId);
            Integer x = (Integer) (sqlQuery.uniqueResult());
            if (x == null) {
                return sysDocId;
            } else {
                sysDocId = new Long(x.intValue() + 1);
            }

            session.flush();
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }

        return sysDocId;

    }

    private Criteria buildCriteria(ExportDocumentListHelper listHelper, Session session, boolean isTotalCount) throws ParseException {
        Criteria criteria = session.createCriteria(ExportDocument.class);
        if (listHelper != null) {
            buildCriteriaOrder(listHelper, isTotalCount, criteria);
            if (!GenericValidator.isBlankOrNull(listHelper.getUserId())) {
                criteria.add(Restrictions.like("userId", prepareWildcardSearchString(listHelper.getUserId())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getSiteId())) {
                criteria.add(Restrictions.like("siteId", prepareWildcardSearchString(listHelper.getSiteId())));
            }
            if (listHelper.getSysDocId() != null) {
                criteria.add(Restrictions.eq("sysDocId", listHelper.getSysDocId()));
            }
            if (listHelper.getParentId() != null) {
                criteria.add(Restrictions.eq("parentId", listHelper.getParentId()));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getDocId())) {
                criteria.add(Restrictions.like("docId", prepareWildcardSearchString(listHelper.getDocId())));
            }            
            if (!GenericValidator.isBlankOrNull(listHelper.getInvoiceNumber())) {
                criteria.add(Restrictions.like("invoiceNumber", prepareWildcardSearchString(listHelper.getInvoiceNumber())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getBuyerName())) {
                criteria.add(Restrictions.like("buyerName", prepareWildcardSearchString(listHelper.getBuyerName())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getExporterReference())) {
                criteria.add(Restrictions.like("exporterReference", prepareWildcardSearchString(listHelper.getExporterReference())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getDocTypeCode())) {
                criteria.add(Restrictions.like("docTypeCode", prepareWildcardSearchString(listHelper.getDocTypeCode())));
            }
            if (listHelper.getStatus() != null) {
                criteria.add(Restrictions.like("status", listHelper.getStatus()));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getBuyerReference())) {
                criteria.add(Restrictions.like("buyerReference", prepareWildcardSearchString(listHelper.getBuyerReference())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getEdn())) {
                criteria.add(Restrictions.like("edn", prepareWildcardSearchString(listHelper.getEdn())));
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getInvoiceDate())) {
                addDateCriteria(criteria, "invoiceDate", listHelper.getInvoiceDate());
            }
            if (!GenericValidator.isBlankOrNull(listHelper.getLastUpdateDate())) {
                addDateCriteria(criteria, "lastUpdateDate", listHelper.getLastUpdateDate());
            }
        }
        return criteria;
    }

    private void buildCriteriaOrder(ExportDocumentListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("sysDocId");
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_DESC);
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());

            if (listHelper.getOrderByFlow().equalsIgnoreCase(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equalsIgnoreCase(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("sysDocId")) {
                criteria.addOrder(Order.asc("sysDocId"));
            }
            if (!orderByParam.equals("userId")) {
                criteria.addOrder(Order.asc("userId"));
            }
            if (!orderByParam.equals("siteId")) {
                criteria.addOrder(Order.asc("siteId"));
            }

        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }

}