package docprep.src.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import docprep.src.dao.interfaces.MasterDocumentDAO;
import docprep.src.dto.MasterDocument;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public class MasterDocumentDAOImpl extends DAOImpl implements MasterDocumentDAO {

    public MasterDocument get(String sysDocId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        try {
            log("getUserList-obtaining the Hibernate Session...");
            session = getHibernateSession();
            log("getUserList-Hibernate Session obtained...");
            Criteria criteria = session.createCriteria(MasterDocument.class);
            criteria.add(Restrictions.like("sysDocId", new Long(sysDocId)));            
            List list = criteria.list();
            if (list.size() > 0) {
                return (MasterDocument) list.get(0);
            }
            return null;
        } catch (HibernateException e) {
            e.printStackTrace();
            throw new DAOException(e);
        } finally {
            closeSession(session);
        }
    }

    public void create(MasterDocument instance) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        int resultint = 0;
        if (instance == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            session.save(instance);
            session.flush();
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    public void update(MasterDocument instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
		  Session session = null;
	        if (instance == null) {
	            throw new InvalidDAOArgumentException("Argument can not be NULL.");
	        }
	        try {
	            session = getSession();
	            session.clear();	            
	            session.saveOrUpdate(instance);
	            session.flush();
	        } catch (HibernateException hex) {
	        	hex.printStackTrace();	        	
	            throw new DAOException(hex);
	        } finally {
	            closeSession(session);
	        }		
	}

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        if (sysDocId == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getHibernateSession();
            Query hqlDelete = session.getNamedQuery("hql.DeleteMasterDocument");
            hqlDelete.setString("selSysDocId", sysDocId);
            int deletedEntities = hqlDelete.executeUpdate();
            session.flush();
        } catch (HibernateException hex) {
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }
}
