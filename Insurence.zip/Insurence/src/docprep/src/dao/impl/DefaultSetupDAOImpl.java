package docprep.src.dao.impl;


import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dao.interfaces.DefaultSetupDAO;
import docprep.src.dto.DefaultSetup;
import docprep.src.dto.DefaultSetupId;


public class DefaultSetupDAOImpl extends DAOImpl implements DefaultSetupDAO {

	
	 public DefaultSetup getDefaultSetup(DefaultSetupId defaultSetupId) throws DAOException, InvalidDAOArgumentException {
        if (defaultSetupId == null) {
            throw new InvalidDAOArgumentException("Id can not be NULL.");
        }
        Session session = null;
        DefaultSetup defaultSetup = null;
        try {
            session = getHibernateSession();
            session.clear();
            defaultSetup = (DefaultSetup) session.get(DefaultSetup.class, defaultSetupId);
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return defaultSetup;
    }
	 
	 public DefaultSetup getDefaultSetup(String userId) throws DAOException, InvalidDAOArgumentException {
        if (GenericValidator.isBlankOrNull(userId)) {
            throw new InvalidDAOArgumentException("User Id can not be NULL.");
        }
        Session session = null;
        try {
            session = getHibernateSession();
            session.clear();
            Criteria criteria = session.createCriteria(DefaultSetup.class);
            criteria.add(Restrictions.like("id.userId", prepareWildcardSearchString(userId)));
            List list = criteria.list();            
            if(list != null && list.size() > 0){
            	return (DefaultSetup)list.get(0);
            }
        } catch (HibernateException hex) {
            hex.printStackTrace(System.err);
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
        return  null;
    }

    public void updateDefaultSetup(DefaultSetup defaultSetup) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException {
        Session session = null;
        if (defaultSetup == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        if (defaultSetup.getId().getUserId() == null) {
            throw new InvalidDAOArgumentException("UserId can not be NULL.");
        }
        if (defaultSetup.getId().getSiteId() == null) {
            throw new InvalidDAOArgumentException("SiteId can not be NULL.");
        }

        try {
            session = getHibernateSession();
            session.clear();
            session.saveOrUpdate(defaultSetup);
            session.flush();
        } catch (HibernateException hex) {
        	DefaultSetup isDefaultSetupExist = getDefaultSetup(defaultSetup.getId());
            if (isDefaultSetupExist == null) {
                throw new RecordNotFoundException("No DefaultSetup found for this Criteria.");
            }
        } finally {
            closeSession(session);
        }
    }
	

}
