package docprep.src.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.validator.GenericValidator;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import docprep.src.dao.interfaces.ActivityLogDAO;
import docprep.src.dto.Activitylog;
import docprep.src.listhelper.ActivityLogListHelper;
import docprep.src.services.SystemUtil;
import dev.zing.framework.businesstier.listhelper.ListHelperImpl;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.listpages.PageDAOImpl;
import dev.zing.framework.daotier.spring.hbnate.DAOImpl;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public class ActivityLogDAOImpl extends DAOImpl implements ActivityLogDAO {

    public void create(Activitylog dto) throws DAOException, InvalidDAOArgumentException {
        Session session = null;
        if (dto == null) {
            throw new InvalidDAOArgumentException("Argument can not be NULL.");
        }
        try {
            session = getSession();
            session.save(dto);
            session.flush();
        } catch (HibernateException hex) {
            throw new DAOException(hex);
        } finally {
            closeSession(session);
        }
    }

    public PageDAO getActivityLogs(ActivityLogListHelper listHelper, int startRowNo, int scrollValue) throws DAOException {
        Session session = null;
        PageDAOImpl page = new PageDAOImpl();
        try {
            session = getSession();

            Criteria criteriaForCounter = buildCriteria(listHelper, session, true);
            criteriaForCounter.setProjection(Projections.rowCount());
            int totalRecords = ((Integer) criteriaForCounter.uniqueResult()).intValue();
            page.setTotalSize(totalRecords);

            Criteria criteriaForList = buildCriteria(listHelper, session, false);

            if (startRowNo > -1) {
                criteriaForList.setFirstResult(startRowNo);
            }
            if (scrollValue > -1) {
                criteriaForList.setMaxResults(scrollValue);
            }
            List list = criteriaForList.list();

            page.setCurrentPageData(list);
            page.setCurrentOffset(startRowNo);
            page.setCurrentLength(list.size());

            return page;
        } finally {
            closeSession(session);
        }
    }

    private Criteria buildCriteria(ActivityLogListHelper listHelper, Session session, boolean isTotalCount) {
        Criteria criteria = session.createCriteria(Activitylog.class);
        buildCriteriaOrder(listHelper, isTotalCount, criteria);
        if (!GenericValidator.isBlankOrNull(listHelper.getSelUserId())) {
            criteria.add(Restrictions.like("userId", prepareWildcardSearchString(listHelper.getSelUserId())));
        }
        if (!GenericValidator.isBlankOrNull(listHelper.getSelSiteId())) {
            criteria.add(Restrictions.like("siteId", prepareWildcardSearchString(listHelper.getSelSiteId())));
        }
        if (!GenericValidator.isBlankOrNull(listHelper.getSelActivityType())) {
            criteria.add(Restrictions.like("activityType", prepareWildcardSearchString(listHelper.getSelActivityType())));
        }

        if (listHelper.getSelActivityDate() != null) {
            Date dateFrom = listHelper.getSelActivityDate();
            Date dateTo = listHelper.getSelActivityDateTo();

            if (dateTo == null) {
                if (listHelper.getSelDateBoundry() == null || listHelper.getSelDateBoundry().equals("On")) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(dateFrom);
                    calendar.set(Calendar.HOUR, 23);
                    calendar.set(Calendar.MINUTE, 59);
                    calendar.set(Calendar.SECOND, 59);
                    dateTo = calendar.getTime();
                } else if (listHelper.getSelDateBoundry().equals("Before")) {
                    dateTo = dateFrom;
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.YEAR, 1950);
                    dateFrom = calendar.getTime();
                } else if (listHelper.getSelDateBoundry().equals("After")) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.YEAR, 2090);
                    dateTo = calendar.getTime();
                }
            } else {
                dateTo = SystemUtil.adjustDateBy(dateTo, 1);
            }
            criteria.add(Restrictions.between("activityDate", dateFrom, dateTo));
        }

        return criteria;
    }

    private void buildCriteriaOrder(ActivityLogListHelper listHelper, boolean isTotalCount, Criteria criteria) {
        if (!isTotalCount) {
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByParam())) {
                listHelper.setOrderByParam("activityDate");
            }
            if (GenericValidator.isBlankOrNull(listHelper.getOrderByFlow())) {
                listHelper.setOrderByFlow(ListHelperImpl.ORDERBYFLOW_ASC);
            }
            String orderByParam = getPropertyNameFromColumnName(listHelper.getOrderByParam());
            if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_ASC)) {
                criteria.addOrder(Order.asc(orderByParam));
            } else if (listHelper.getOrderByFlow().equals(ListHelperImpl.ORDERBYFLOW_DESC)) {
                criteria.addOrder(Order.desc(orderByParam));
            }
            if (!orderByParam.equals("activityDate")) {
                criteria.addOrder(Order.asc("activityDate"));
            }
        }
    }

    private String getPropertyNameFromColumnName(String columnName) {
        return columnName;
    }
}