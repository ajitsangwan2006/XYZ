package docprep.src.dao.interfaces;

import java.util.List;

import docprep.src.dto.ItemDetail;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public interface ItemDetailDAO extends DAO {

    public List get(String sysDocId) throws DAOException, InvalidDAOArgumentException;

    public ItemDetail get(String sysDocId, Integer lineNumber) throws DAOException, InvalidDAOArgumentException;
    
    public void create(ItemDetail instance) throws DAOException, InvalidDAOArgumentException;

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException;
}