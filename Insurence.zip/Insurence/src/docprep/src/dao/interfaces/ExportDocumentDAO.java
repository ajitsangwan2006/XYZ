package docprep.src.dao.interfaces;

import docprep.src.dto.ExportDocument;
import docprep.src.listhelper.ExportDocumentListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public interface ExportDocumentDAO extends DAO {

	public PageDAO getList(ExportDocumentListHelper criteria, int startRowNo, int scrollValue) throws DAOException;

    public PageDAO getList(ExportDocumentListHelper criteria) throws DAOException;

    public ExportDocument get(String siteId, String userId,String sysDocId) throws DAOException, InvalidDAOArgumentException;
    
    public ExportDocument getByDocumentType(String siteId, Long parentId, String docTypeCode) throws DAOException, InvalidDAOArgumentException;
    
    public ExportDocument create(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;

    public void update(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;

    public void delete(ExportDocument instance) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
  
    public Long getSysDocId(String siteId, String userId) throws DAOException, InvalidDAOArgumentException;
}