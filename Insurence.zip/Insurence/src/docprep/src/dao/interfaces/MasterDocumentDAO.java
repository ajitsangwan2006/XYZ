package docprep.src.dao.interfaces;

import docprep.src.dto.MasterDocument;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;

public interface MasterDocumentDAO extends DAO {   

    public MasterDocument get(String sysDocId) throws DAOException, InvalidDAOArgumentException;
    
    public void create(MasterDocument instance) throws DAOException, InvalidDAOArgumentException;

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException;
}