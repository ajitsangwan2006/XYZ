package docprep.src.dao.interfaces;

import docprep.src.dto.DefaultSetup;
import docprep.src.dto.DefaultSetupId;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;

public interface DefaultSetupDAO extends DAO {

	 public DefaultSetup getDefaultSetup(DefaultSetupId defaultSetupId) throws DAOException, InvalidDAOArgumentException;    

	 public DefaultSetup getDefaultSetup(String userId) throws DAOException, InvalidDAOArgumentException;
    
    public void updateDefaultSetup(DefaultSetup defaultSetup) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
}