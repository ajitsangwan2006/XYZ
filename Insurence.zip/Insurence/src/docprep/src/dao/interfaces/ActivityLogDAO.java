package docprep.src.dao.interfaces;

import docprep.src.dto.Activitylog;
import docprep.src.listhelper.ActivityLogListHelper;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;


public interface ActivityLogDAO extends DAO {

    public PageDAO getActivityLogs(ActivityLogListHelper listHelper, int startRowNo, int scrollValue) throws DAOException;

    public void create(Activitylog criteria) throws DAOException, InvalidDAOArgumentException;

}