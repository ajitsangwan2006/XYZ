package docprep.src.dao.interfaces;

import dev.zing.framework.daotier.spring.hbnate.DAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dto.ForwardingList;

public interface ForwardingListDAO extends DAO {

    public ForwardingList get(String sysDocId) throws DAOException, InvalidDAOArgumentException;

    public void create(ForwardingList criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;

    public void update(ForwardingList criteria) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;

    public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
}
