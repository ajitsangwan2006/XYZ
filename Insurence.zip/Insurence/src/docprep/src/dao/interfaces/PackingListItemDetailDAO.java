package docprep.src.dao.interfaces;

import java.util.List;

import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dto.PackingListItemDetail;

public interface PackingListItemDetailDAO {
	
	public List get(String sysDocId) throws DAOException, InvalidDAOArgumentException;
	
	public PackingListItemDetail get(String sysDocId,Integer packingListId) throws DAOException, InvalidDAOArgumentException;
	
	public void create(PackingListItemDetail criteria) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException;
	
	public void delete(String sysDocId) throws DAOException, InvalidDAOArgumentException, RecordNotFoundException;
			

}
