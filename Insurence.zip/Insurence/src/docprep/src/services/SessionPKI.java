package docprep.src.services;

public class SessionPKI {

	public SessionPKI() {
		super();		
	}
	
	public String getPKI(String userID) {		
		try{
			String pkid = "";
			String rand =  new Double(Math.random()).toString();
			String temp =  new Long(System.currentTimeMillis()).toString()+rand.substring(2,4);
			pkid = ""+(temp + userID).hashCode();
			return pkid;
		}catch(Throwable t){
		}
		return null;
	}
}
