package docprep.src.services.util;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public class CurrencyLookupBean extends java.lang.Object implements java.io.Serializable {

    private String[] ones = { "", "One ", "Two ", "Three ", "Four ", "Five ", "Six ", "Seven ", "Eight ", "Nine ", "Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen " };

    private String[] tens = { "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety " };

    private String[] hundreds = { " ", "Thousand ", "Million ", "Billion ", "Trillion ", "Quadrillion ", "Quintillion ", "Sextillion  ", "Septillion ", "Octillion ", "Nonillion ", "Decillion ", "Undecillion ", "Duodecillion ", "Tredecillion ", "Quattuordecillion ", "Quindecillion ", "Sexdecillion ", "Septendecillion ", "Octodecillion ", "Novemdecillion " };

    private String getWord(int i, int j) {
        String word = "";
        int k = j * 10 + i;
        if (k < 20) {
            word = ones[k];
        } else {
            word += tens[j - 2] + ones[i];
        }
        return word;
    }

    private String getWord(int i, int j, int k) {
        String word = "";
        int l = k * 100 + j * 10 + i;
        if (l < 100) {
            word = getWord(i, j);
        } else if (l == 100 || l == 200 || l == 300 || l == 400 || l == 500 || l == 600 || l == 700 || l == 800 || l == 900) {
            word = ones[k] + "Hundred ";
        } else {
            word = ones[k] + "Hundred and " + getWord(i, j);
        }
        return word;
    }

    public String getWord(String val, String noteType, String coinsType) throws InvalidArgumentException {
        String val1 = "";
        String val2 = "";
        if (val.indexOf(".") >= 0) {
            val1 = val.substring(0, val.indexOf("."));
            val2 = val.substring(val.indexOf(".") + 1, val.length());
        } else {
            val1 = val;
            val2 = "0";
        }
        if (val1.indexOf("-") == 0) {
            val1 = val1.substring(1, val.length());
        }
        int zeros = 0;
        String finalWord = "";
        while (val1.length() > 0) {
            if (zeros > hundreds.length) {
                //Such a big number not supported.
                InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Invoice_Id");
                invalidArgumentException.setErrorOzCode("system.errors.Invoice_Id");
                throw invalidArgumentException;
            }
            int r1 = 0;
            int r2 = 0;
            int r3 = 0;
            r1 = Integer.parseInt(val1.charAt(val1.length() - 1) + "");
            val1 = val1.substring(0, val1.length() - 1);
            if (val1.length() > 0) {
                r2 = Integer.parseInt(val1.charAt(val1.length() - 1) + "");
                val1 = val1.substring(0, val1.length() - 1);
                if (val1.length() > 0) {
                    r3 = Integer.parseInt(val1.charAt(val1.length() - 1) + "");
                    val1 = val1.substring(0, val1.length() - 1);
                }
            }
            if (r1 + r2 + r3 > 0) {
                finalWord = getWord(r1, r2, r3) + hundreds[zeros] + finalWord;
            }
            zeros++;
        }
        if (finalWord.trim().length() <= 0) {
            finalWord = "Zero";
        }
        finalWord = finalWord.trim();
        if (finalWord.trim().equalsIgnoreCase("One")) {
            finalWord = finalWord + " " + noteType.trim() + " and ";
        } else {
            finalWord = finalWord + " " + noteType.trim() + " and ";
        }
        if (val2.length() < 3) {
            int r1 = 0;
            int r2 = 0;
            if (val2.length() > 0) {
                r1 = Integer.parseInt(val2.charAt(val2.length() - 1) + "");
                val2 = val2.substring(0, val2.length() - 1);
                if (val2.length() > 0) {
                    r2 = Integer.parseInt(val2.charAt(val2.length() - 1) + "");
                    val2 = val2.substring(0, val2.length() - 1);
                }
            }
            if (r1 + r2 > 0) {
                finalWord = finalWord + getWord(r1, r2);
                finalWord = finalWord.trim();
                finalWord = finalWord + " " + coinsType.trim();
            } else {
                finalWord = finalWord + "Zero";
                finalWord = finalWord.trim();
                finalWord = finalWord + " " + coinsType.trim();
            }
            finalWord = finalWord.trim();
        } else {
            //Value after decimal can not be more that 99.
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Invoice_Id");
            invalidArgumentException.setErrorOzCode("system.errors.Invoice_Id");
            throw invalidArgumentException;
        }
        return finalWord;
    }
    
    public static void main(String[] args) {
        CurrencyLookupBean test = new CurrencyLookupBean();
        try {
            String value = test.getWord("256.98", "Rs", "Paisa");
            System.err.println(value);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
}
