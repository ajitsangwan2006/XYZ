package docprep.src.services.util;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

public class BarcodeGenerator {

    private Long sysDocId = null; 
    
    public BarcodeGenerator() {
        super();        
    }
    
    public BarcodeGenerator(Long sysDocId) {
        this.sysDocId = sysDocId;   
    }    
    
    public byte[] getBarCodeBytes() {
        InputStream barCodeInputStream = null;
        Code128Bean bean = new Code128Bean();        
        final int dpi = 150;
        bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi));
        bean.setHeight(6);
        bean.setFontSize(1);
        bean.doQuietZone(false);        
        try {
	        ByteArrayOutputStream output = new ByteArrayOutputStream();
	        BitmapCanvasProvider canvas = new BitmapCanvasProvider(output, "image/x-png", 300, BufferedImage.TYPE_BYTE_GRAY, true, 0);
	        bean.generateBarcode(canvas, ""+sysDocId);        
            canvas.finish();     
            byte[] content=output.toByteArray();
            output.close();
            return content;
        } catch (IOException e) {
            e.printStackTrace();
        } 
        return null;
    }    
}
