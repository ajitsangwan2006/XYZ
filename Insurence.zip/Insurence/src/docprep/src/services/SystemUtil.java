package docprep.src.services;

import java.io.File;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemUtil {

    public static String getCurrentDateTimeFormat1() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return sdf.format(new Date());
    }

    public static String getCurrentDateTimeFormat1(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return sdf.format(date);
    }

    public static Date getCurrentDateTimeFormat() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            date = sdf.parse(sdf.format(date));
        } catch (ParseException e) {
        }
        return date;
    }

    public static String getPrintFolder() {
        return System.getProperty("user.dir") + File.separator + "DocPrepPrint";
    }

    public static String getCurrentDateTimeFormat3() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }

    public static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }

    public static String getCurrentDateTimeFormat3(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }

    public static String getCurrentDateTimeFormat4(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.format(date);
    }

    public static String getCurrentDateTimeFormat5(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }

    public static String getCurrentDateTimeFormat2() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE d MMM yyyy hh:mm aaa");
        return sdf.format(new Date());
    }

    public static String getCurrentDateTimeFormat2(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE d MMM yyyy hh:mm aaa");
        return sdf.format(date);
    }

    public static String getCurrentDateTimeFormat8(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }

    public static Date getCurrentDateTimeFormat4() throws ParseException {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        date = sdf.parse(sdf.format(date));

        return date;
    }

    public static Date getDateFromStringFormat1(String stringDate) {
        Date date = new Date();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            date = sdf.parse(stringDate);
        } catch (ParseException ex) {

        }
        return date;
    }

    public static Date getDateFromStringFormat4(String stringDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.parse(stringDate, new ParsePosition(0));
    }

    public static Date getDateFromStringFormat5(String stringDate) {
        Date date = new Date();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            date = sdf.parse(stringDate);
        } catch (ParseException ex) {
        }
        return date;
    }

    public static Date getDateFromStringFormat3(String stringDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.parse(stringDate);
    }

    public static Date getDateFromStringFormat2(String stringDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.parse(stringDate);
    }

    public static String getCurrentDateTimeFormat6(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return sdf.format(date);
    }

    public static java.util.Date adjustDateBy(java.util.Date d, int numberOfDays) {
        java.util.GregorianCalendar cal = new java.util.GregorianCalendar();
        cal.setTime(d);
        cal.add(java.util.GregorianCalendar.DATE, numberOfDays);
        return cal.getTime();
    }

    public static String getWorkingFolder() {
        return System.getProperty("user.dir");
    }

    public static String getTempFolder() {
        return System.getProperty("user.dir" + File.separator + "Temp");
    }

    public static Date getCurrentDateFormat() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            date = sdf.parse(sdf.format(date));
        } catch (ParseException e) {
        }
        return date;
    }

    public static String getCommifiedValue(String val) {
        String Num = val + "";
        String sign = "";
        if (Num.indexOf("-") != -1) {
            Num = Num.substring(1, Num.length());
            sign = "-";
        }
        String newNum = "";
        String newNum2 = "";
        String firstPart = "";
        String secondPart = "";
        int count = 0;
        if (Num.indexOf('.') != -1) {
            if (Num.indexOf('.') == Num.length() - 1) {
                Num += "00";
            }
            if (Num.indexOf('.') == Num.length() - 2) {
                Num += "0";
            }
            firstPart = Num.substring(0, Num.indexOf('.'));
            secondPart = Num.substring(Num.indexOf('.') + 1);
            Num = firstPart;
        } else {
            secondPart = "";
        }
        for (int k = Num.length() - 1; k >= 0; k--) {
            char oneChar = Num.charAt(k);
            if (count == 3) {
                newNum += ",";
                newNum += oneChar;
                count = 1;
                continue;
            } else {
                newNum += oneChar;
                count++;
            }
        }
        for (int k = newNum.length() - 1; k >= 0; k--) {
            char oneChar = newNum.charAt(k);
            newNum2 += oneChar;
        }
        if (secondPart.length() > 0) {
            newNum2 = newNum2 + "." + secondPart;
        }
        return (sign + newNum2);
    }
}