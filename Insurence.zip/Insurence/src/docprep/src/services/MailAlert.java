package docprep.src.services;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailAlert {
	
	private String smtpServer;
	
	private String toAddress;
	
	private String fromAddress;
	
	private String bcc;
	
	private String[] cc;
	
	private String subject;
	
	private StringBuffer bodyConetnt;
	
	private Map attachments = new HashMap();
	
	private String userName;
	
	private String password;
	
	private boolean isHtml;

	public MailAlert(String smtpServer, String toAddress, String fromAddress, String bcc, String[] cc, String subject, StringBuffer bodyConetnt,  Map attachments, String userName, String password, boolean isHtml) {
		this.smtpServer = smtpServer;
		this.toAddress = toAddress;
		this.fromAddress = fromAddress;
		this.bcc = bcc;
		this.cc = cc;
		this.subject = subject;
		this.bodyConetnt = bodyConetnt;
		this.attachments = attachments;
		this.userName = userName;
		this.password = password;
		this.isHtml = isHtml;
	}	
	
	public MailAlert(String smtpServer, String toAddress, String fromAddress, String bcc, String[] cc, String subject, StringBuffer bodyConetnt, String userName, String password, boolean isHtml) {
		this.smtpServer = smtpServer;
		this.toAddress = toAddress;
		this.fromAddress = fromAddress;
		this.bcc = bcc;
		this.cc = cc;
		this.subject = subject;
		this.bodyConetnt = bodyConetnt;
		attachments = new HashMap();
		this.userName = userName;
		this.password = password;
		this.isHtml = isHtml;
	}
	
	public Map getAttachments() {
		return attachments;
	}
	
	public void addAttachments(String name, byte[] content) {
		attachments.put(name, content);
	}
	
	public String getBcc() {
		return bcc;
	}
	
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}
	
	public String[] getCc() {
		return cc;
	}
	
	public void setCc(String[] cc) {
		this.cc = cc;
	}
	
	public String getFromAddress() {
		return fromAddress;
	}
	
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	
	public String getSmtpServer() {
		return smtpServer;
	}
	
	public void setSmtpServer(String smtpServer) {
		this.smtpServer = smtpServer;
	}
	
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getToAddress() {
		return toAddress;
	}
	
	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}	
	
	public StringBuffer getBodyConetnt() {
		return bodyConetnt;
	}	
	public void setBodyConetnt(StringBuffer bodyConetnt) {
		this.bodyConetnt = bodyConetnt;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public boolean isHtml() {
		return isHtml;
	}
	
	public void setHtml(boolean isHtml) {
		this.isHtml = isHtml;
	}
	
	public void sendMail(String emailType){
		try {
		JavaMailSenderImpl sender = new JavaMailSenderImpl();
		sender.setHost(this.smtpServer);
	//	java.util.Properties props = System.getProperties();
    //    props.put("mail.smtp.auth", "true");
    //    sender.setJavaMailProperties(props);
		System.err.println("Email SMTP Server: " + this.smtpServer);
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		helper.setTo(this.toAddress);
		System.err.println("Email TO Address: " + this.toAddress);
		if (bcc != null) {
			helper.setBcc(this.bcc);
			System.err.println("Email bcc Address: " + this.bcc);
		}
		helper.setSubject(this.subject);
		helper.setText(bodyConetnt != null ? bodyConetnt.toString() : "", this.isHtml);
		helper.setFrom(this.fromAddress);
		System.err.println("Email From Address: " + this.fromAddress);
		Iterator iterator = attachments.keySet().iterator();
		while (iterator.hasNext()) {
			String fileName = (String) iterator.next();
			ByteArrayResource resource = new ByteArrayResource((byte[]) attachments.get(fileName));
			helper.addAttachment(fileName, resource);
		}
		sender.send(message);
		System.err.println(emailType +" successfully sent to : " + toAddress + ".");
		}catch (MessagingException e) {
	         this.toAddress = "vaibhav@ozdocs.com.au";
	         this.bodyConetnt.append("\n\nSystem was unable to send this email, please investigate.");
	         this.sendMail(emailType);
	     }
	}
}
