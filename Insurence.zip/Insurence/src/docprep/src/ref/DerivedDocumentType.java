package docprep.src.ref;

public class DerivedDocumentType {

    public final static int PACKING_LIST = 1;
    
    public final static int FORWARDING_INSTRUCTIONS = 2;
    
    public static String getDocTypeCode(int code) {
        switch (code) {
            case 1: return "PackingList";
            case 2: return "ForwardingInstructions";            
        }
        return String.valueOf(code);
    }
    
    public static String getDocTypeShortName(String docTypeCode) {
        if (docTypeCode.equals("PackingList")) {
            return "Packing List";
        }
        if (docTypeCode.equals("ForwardingInstructions")) {
            return "Forwarding Instructions";
        }
        return null;
    }
    
    public static String getDocTypeCode(String longName) {
        if (longName.equals("Packing List")) {
            return "PackingList";
        }
        if (longName.equals("Forwarding Instructions")) {
            return "ForwardingInstructions";
        }
        return null;
    }

}
