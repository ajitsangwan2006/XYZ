package docprep.src.webtier.startup;

import java.util.TimeZone;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServlet;

import docprep.src.reports.ResourceFileAccess;

public class StartupConfigServlet extends HttpServlet implements Servlet {
	
	private static final long serialVersionUID = -4351033382510367067L;

	public StartupConfigServlet() {
		super();		
		TimeZone.setDefault(TimeZone.getTimeZone("Australia/Sydney"));
		ResourceFileAccess resourceAccess = ResourceFileAccess.getInstance();
		resourceAccess.createResources();		
	}
	
}