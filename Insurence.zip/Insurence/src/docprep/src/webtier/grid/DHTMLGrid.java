package docprep.src.webtier.grid;

import java.util.Hashtable;

public class DHTMLGrid {
    private String gridName;
    private Hashtable gridRows = new Hashtable();

    public Hashtable getGridRows() {
        return gridRows;
    }

    public void addRow(int index, Object row) {
        gridRows.put(String.valueOf(index), row);
    }
    
    public String getName() {
        return gridName;
    }
    
    public void setName(String gridName) {
        this.gridName = gridName;
    }
}
