package docprep.src.webtier.framework.extension;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.webtier.adapter.SignedInUser;
import dev.zing.framework.webtier.struts.ExtJsDataEntryPageAction;

public abstract class ExtJsAdminDataEntryPageAction extends ExtJsDataEntryPageAction {

    public ExtJsAdminDataEntryPageAction() {
        super();
    }

    protected Environment getEnvironment(SignedInUser signedInUser) throws AccessDeniedException {
    	docprep.src.bto.main.SignedInUser user = (docprep.src.bto.main.SignedInUser) signedInUser;
        return user.getAdminEnvironment();
    }

}
