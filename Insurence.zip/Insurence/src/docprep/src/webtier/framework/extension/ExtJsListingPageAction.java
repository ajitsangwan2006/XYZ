package docprep.src.webtier.framework.extension;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public abstract class ExtJsListingPageAction extends dev.zing.framework.webtier.struts.ExtJsListingPageAction {
    
    public ExtJsListingPageAction() {
        super();
    }

    public PageHandler getPageHandler(ListHelper listHelper, dev.zing.framework.webtier.adapter.SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException {
    	docprep.src.bto.main.SignedInUser user = (docprep.src.bto.main.SignedInUser) signedInUser;
        return getPageHandler(listHelper, user, httpservletrequest);
    }

    abstract protected PageHandler getPageHandler(ListHelper listHelper, docprep.src.bto.main.SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException;
    

    public List[] getPageHandlers(ListHelper listHelper, dev.zing.framework.webtier.adapter.SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException {
        docprep.src.bto.main.SignedInUser user = (docprep.src.bto.main.SignedInUser) signedInUser;
        return getPageHandlers(listHelper, user, httpservletrequest);
    }
    
    protected List[] getPageHandlers(ListHelper listHelper, docprep.src.bto.main.SignedInUser signedInUser, HttpServletRequest httpservletrequest) throws AccessDeniedException, InvalidArgumentException {
        return null;
    }
}
