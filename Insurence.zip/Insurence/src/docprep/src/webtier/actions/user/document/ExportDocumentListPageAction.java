package docprep.src.webtier.actions.user.document;

import javax.servlet.http.HttpServletRequest;

import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.ExportDocument;
import docprep.src.listhelper.ExportDocumentListHelper;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class ExportDocumentListPageAction extends ExtJsListingPageAction {

    protected Class getListHelper() {
        return ExportDocumentListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
        ExportDocumentListHelper criteria = (ExportDocumentListHelper) listHelper;
        EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        String docTypeCode = request.getParameter("docTypeCode");
        log("docTypeCode: " + docTypeCode);
        if (docTypeCode != null && docTypeCode.equals("MasterDocument")) {
            criteria.setDocTypeCode(docTypeCode);
            System.err.println("chance--------->" + request.getParameter("chance"));
        } else {
            String parentId = request.getParameter("parentId");
            if (parentId != null) {
                criteria.setParentId(new Long(parentId));
            }
        }
        log("ExportDocumentListPageAction-getSysDocId:- " + criteria.getSysDocId());
        PageHandler pageHandler = env.getDocumentMgmtManager().getExportDocumentManager().getList(criteria);
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
        ExportDocument instance = (ExportDocument) model;
        RowData rowData = new RowData();        
        rowData.addColumn("sysDocId", instance.getSysDocId().toString());
        rowData.addColumn("docId", instance.getDocId());
        rowData.addColumn("invoiceNumber", instance.getInvoiceNumber());
        rowData.addColumn("invoiceDate", getFormattedDate(instance.getInvoiceDate()));
        rowData.addColumn("exporterReference", instance.getExporterReference());
        rowData.addColumn("buyerName", instance.getBuyerName());
        rowData.addColumn("buyerReference", instance.getBuyerReference() != null ? instance.getBuyerReference() : "");
        rowData.addColumn("edn", instance.getEdn() != null ? instance.getEdn() : "");
        rowData.addColumn("docTypeCode", instance.getDocTypeCode());
        rowData.addColumn("status", getDocStatus(instance.getStatus().intValue()));
        rowData.addColumn("lastUpdateDate", getFormattedDateTime(instance.getLastUpdateDate()));
        return rowData;
    }

    private String getDocStatus(int docStatus) {
        String docStatusValue = null;
        if (docStatus == 0) {
            docStatusValue = "Transaction Closed";
        } else if (docStatus == 1) {
            docStatusValue = "Documentation Printed";
        } else if (docStatus == 2) {
            docStatusValue = "Documentation Sent";
        } else if (docStatus == 3) {
            docStatusValue = "ECN Received";
        } else if (docStatus == 4) {
            docStatusValue = "EDN Received";
        } else if (docStatus == 5) {
            docStatusValue = "Transaction Initiated";
        } else if (docStatus == 6) {
            docStatusValue = "Invoice Sent";
        } else if (docStatus == 7) {
            docStatusValue = "Goods Packed";
        } else if (docStatus == 8) {
            docStatusValue = "Payment Received";
        } else if (docStatus == 9) {
            docStatusValue = "Vessel Booked";
        } else if (docStatus == 10) {
            docStatusValue = "Goods Shipped";
        }
        return docStatusValue;
    }
}