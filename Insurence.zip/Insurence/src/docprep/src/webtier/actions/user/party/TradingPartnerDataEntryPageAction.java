package docprep.src.webtier.actions.user.party;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;

import net.sf.json.JSONObject;
import userlookup.src.dto.TradingPartnerLookup;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;

public class TradingPartnerDataEntryPageAction extends ExtJsUserDataEntryPageAction {

    protected Model getPageModel(FormField formFields) {
        return new TradingPartnerLookup();
    }

    protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, IOException {
    	EndUserEnvironment env = (EndUserEnvironment) enviornment;
        TradingPartnerLookup instance = (TradingPartnerLookup) model;
        log("TradingPartnerDataEntryAction - performAddAction - 1"); 
        setPartnerTypes(request, instance);
        env.getTradingPartnerLookupManager().create(instance);
        
        // Send success json {success:true, level:10} to browser
        JSONObject json = getSuccessJSON();
        log("json String:" + json.toString());
        return json;
    }

    protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
    	EndUserEnvironment env = (EndUserEnvironment) enviornment;
        TradingPartnerLookup instance = (TradingPartnerLookup) model;
        log("TradingPartnerDataEntryAction - performModifyAction - 1");    
        setPartnerTypes(request, instance);
        env.getTradingPartnerLookupManager().update(instance);
        
        // Send success json {success:true, level:10} to browser
        JSONObject json = getSuccessJSON();
        log("json String:" + json.toString());
        return json;
    }   

    private void setPartnerTypes(HttpServletRequest request, TradingPartnerLookup instance) {
        String exporterFlag = request.getParameter("exporterFlag");
        if (!GenericValidator.isBlankOrNull(exporterFlag) && exporterFlag.equals("on")) {
            instance.setIsExporter(new Integer(1));
        } else {
            instance.setIsExporter(new Integer(0));
        }
        String consigneeFlag = request.getParameter("consigneeFlag");
        if (!GenericValidator.isBlankOrNull(consigneeFlag) && consigneeFlag.equals("on")) {
            instance.setIsConsignee(new Integer(1));
        } else {
            instance.setIsConsignee(new Integer(0));
        }
        String buyerFlag = request.getParameter("buyerFlag");
        if (!GenericValidator.isBlankOrNull(buyerFlag) && buyerFlag.equals("on")) {
            instance.setIsBuyer(new Integer(1));
        } else {
            instance.setIsBuyer(new Integer(0));
        }
        String forwardingAgentFlag = request.getParameter("forwardingAgentFlag");
        if (!GenericValidator.isBlankOrNull(forwardingAgentFlag) && forwardingAgentFlag.equals("on")) {
            instance.setIsForwardingAgent(new Integer(1));
        } else {
            instance.setIsForwardingAgent(new Integer(0));
        }
        String manufacturerFlag = request.getParameter("manufacturerFlag");
        if (!GenericValidator.isBlankOrNull(manufacturerFlag) && manufacturerFlag.equals("on")) {
            instance.setIsManufacturer(new Integer(1));
        } else {
            instance.setIsManufacturer(new Integer(0));
        }
        
    }
}
