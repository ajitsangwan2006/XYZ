package docprep.src.webtier.actions.user.countryLookup;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;

import codemaintenance.src.dto.CountryLookup;
import codemaintenance.src.listhelper.CountryLookupListHelper;

import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class CountryLookupListPageAction extends ExtJsListingPageAction {
    
    protected Class getListHelper() {
        return CountryLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
    	CountryLookupListHelper criteria = (CountryLookupListHelper) listHelper;
    	EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getCountryCode())) {
                criteria.setCountryCode(criteria.getCountryCode() + "*");
            } 
            if (!GenericValidator.isBlankOrNull(criteria.getCountryName())) {
                criteria.setCountryName(criteria.getCountryName() + "*");
            }
        }                
        System.out.println("criteria.getCountryCode(): "+criteria.getCountryCode());
        PageHandler pageHandler = env.getCountryLookupManager().getCountryLookup(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
    	CountryLookup instance = (CountryLookup) model;
        RowData rowData = new RowData();
        rowData.addColumn("countryCode", instance.getCountryCode()); 
        rowData.addColumn("countryCode2", instance.getCountryCode2()); 
        rowData.addColumn("countryName", instance.getCountryName());         
        return rowData;
    }
}