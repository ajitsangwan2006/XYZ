package docprep.src.webtier.actions.user.product;

import java.io.IOException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import userlookup.src.bto.controller.ProductUserLookupManager;
import userlookup.src.dto.ProductUserLookup;
import com.ibm.wsspi.sib.exitpoint.ra.HashMap;
import com.lowagie.text.DocumentException;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;

public class ProductCommandPageAction extends ExtJsUserCommandPageAction {
    
    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IllegalAccessException, DuplicateRecordException, InvalidArgumentException, IOException, DocumentException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
        	if (actionMode.equalsIgnoreCase("NEW")) {
                doNew(env, request, response);
            }else if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            }else if (actionMode.equalsIgnoreCase("DELETE")) {
                doDelete(env, request, response);
            }

        }
    }
    protected void doNew(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
    	ProductUserLookupManager product = env.getProductUserLookupManager();
    	Map map = new HashMap();                        
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}
   
    private void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
        String productCode = request.getParameter("ProductCode");    
        //String hscode = request.getParameter("hscode"); 
        log("productCode:- "+productCode);
		ProductUserLookup product = env.getProductUserLookupManager().getProduct(productCode);
		
		Map map = new HashMap();
        map.put("FormData", getModelData(product));
        map.put("productCode",product.getId().getProductCode());
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
		
    }
	protected void doDelete(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
		String productCode = request.getParameter("ProductCode");
		log("productCode:- "+productCode);     
		env.getProductUserLookupManager().delete(productCode);
	}
	
   
}

