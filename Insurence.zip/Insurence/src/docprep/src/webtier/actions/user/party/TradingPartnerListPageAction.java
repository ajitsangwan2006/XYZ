package docprep.src.webtier.actions.user.party;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;

import userlookup.src.dto.TradingPartnerLookup;
import userlookup.src.listhelper.TradingPartnerLookupListHelper;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class TradingPartnerListPageAction extends ExtJsListingPageAction {
    
    protected Class getListHelper() {
        return TradingPartnerLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
        TradingPartnerLookupListHelper criteria = (TradingPartnerLookupListHelper) listHelper;
        EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getName())) {
                criteria.setName(criteria.getName() + "*");
            }            
        }        
        System.err.println(" criteria.getName(): "+criteria.getName());
        PageHandler pageHandler = env.getTradingPartnerLookupManager().getTradingPartnerLookup(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
        TradingPartnerLookup instance = (TradingPartnerLookup) model;
        RowData rowData = new RowData();
              
        rowData.addColumn("siteId", instance.getId().getSiteId()); 
        rowData.addColumn("partnerId", instance.getId().getPartnerId());  
        rowData.addColumn("name", instance.getName());   
        rowData.addColumn("abnNo", instance.getAbnNo());
        rowData.addColumn("streetNo", instance.getStreetNo());
        rowData.addColumn("streetName", instance.getStreetName());
        rowData.addColumn("city", instance.getCity());
        rowData.addColumn("state", instance.getState());
        rowData.addColumn("country", instance.getCountry());
        return rowData;
    }
}