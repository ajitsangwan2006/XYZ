package docprep.src.webtier.actions.user.clause;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.validator.GenericValidator;
import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;

public class ClauseLookupListPageAction extends ExtJsListingPageAction {
	 protected Class getListHelper() {
        return ClausesUserLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
        ClausesUserLookupListHelper criteria = (ClausesUserLookupListHelper) listHelper;
    	EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getLine1())) {
                criteria.setLine1(criteria.getLine1() + "*");
            } 
            if (!GenericValidator.isBlankOrNull(criteria.getLine2())) {
                criteria.setLine2(criteria.getLine2() + "*");
            }
            if (!GenericValidator.isBlankOrNull(criteria.getLine3())) {
                criteria.setLine3(criteria.getLine3() + "*");
            }
        }                
        PageHandler pageHandler = env.getClausesUserLookupManager().getClausesList(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
        ClausesUserLookup instance = (ClausesUserLookup) model;
        RowData rowData = new RowData();              
        rowData.addColumn("clauseId", instance.getId().getClauseId());
        
        if(instance.getIsPaymentTerm()!=null && instance.getIsPaymentTerm().intValue()==1){	    	
    		rowData.addColumn("clauseType","Payment Term");
    	}else if(instance.getIsPrintClause()!=null && instance.getIsPrintClause().intValue()==1){
    		rowData.addColumn("clauseType","Print Clause");	    		
    	}else if(instance.getIsAdditionalClause()!=null && instance.getIsAdditionalClause().intValue()==1){	    		
    		rowData.addColumn("clauseType","Additional Clause");
    	}else if(instance.getIsExporterDeclClause()!=null && instance.getIsExporterDeclClause().intValue()==1){	    
    		rowData.addColumn("clauseType","Exporter Declaration Clause");
    	
    	}	
        rowData.addColumn("line1", instance.getLine1()); 
        rowData.addColumn("line2", instance.getLine2());
        rowData.addColumn("line3", instance.getLine3());
                                  
        return rowData;
    }

}
