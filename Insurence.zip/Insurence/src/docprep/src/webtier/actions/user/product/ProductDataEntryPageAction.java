
package docprep.src.webtier.actions.user.product;

import java.io.IOException;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.validator.GenericValidator;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import userlookup.src.dto.ProductUserLookup;

import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;
public class ProductDataEntryPageAction  extends ExtJsUserDataEntryPageAction  {

	 protected Model getPageModel(FormField formFields) {
		ProductUserLookup product = new ProductUserLookup();
        return product;
    }	
	 protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {
		EndUserEnvironment userEnv = (EndUserEnvironment) enviornment;
    	ProductUserLookup product = (ProductUserLookup) model; 
    	System.err.println("product Code"+product.getId().getProductCode());
        log("ProductDataEntryPageAction - performAddAction");
    	userEnv.getProductUserLookupManager().create(product);
        return null;
   	}
	 private ProductUserLookup[] getProductRows(HttpServletRequest request) throws IOException {
        String rootname = "productform";
        String json_String = request.getParameter(rootname);
        if (GenericValidator.isBlankOrNull(json_String)) {
          return null;
        }
        Collection collection = this.toCollection(json_String, rootname, ProductUserLookup.class);
        log(rootname + " - jsonArray Size: " + collection.size());
        ProductUserLookup[] productRows = (ProductUserLookup[]) collection.toArray(new ProductUserLookup[collection.size()]);
        log(rootname + " - jsonArray Size -2: " + productRows.length);
        return productRows;
    }
	 protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
		EndUserEnvironment userEnv = (EndUserEnvironment) enviornment;
	    ProductUserLookup product = (ProductUserLookup) model;
	    //product.getId().setUserId(formFields.getParameter("userId"));
	    product.getId().setProductCode(formFields.getParameter("productCode"));
	    
	    userEnv.getProductUserLookupManager().update(product);
	    String statusMessage = "Product has been updated in database with Id [ "+product.getId().getProductCode()+" ].";
	     return null;
	}	
     private Collection toCollection(String json, String rootname, Class beanClass) throws IOException {
        JSONObject jsonObject = JSONObject.fromObject(json);
        JSONArray jsonArray = jsonObject.getJSONArray(rootname);
        Collection collection = JSONArray.toCollection(jsonArray, beanClass);
        return collection;
    }   
	
}
