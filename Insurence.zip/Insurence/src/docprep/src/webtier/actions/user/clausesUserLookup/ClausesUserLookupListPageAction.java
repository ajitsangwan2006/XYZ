package docprep.src.webtier.actions.user.clausesUserLookup;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;

import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.listhelper.ClausesUserLookupListHelper;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class ClausesUserLookupListPageAction extends ExtJsListingPageAction {
    
    protected Class getListHelper() {
        return ClausesUserLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
        ClausesUserLookupListHelper criteria = (ClausesUserLookupListHelper) listHelper;
    	EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getLine1())) {
                criteria.setLine1(criteria.getLine1() + "*");
            }            
        }                
        System.out.println("criteria.getLine1(): "+criteria.getLine1());
        PageHandler pageHandler = env.getClausesUserLookupManager().getClausesList(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
        ClausesUserLookup instance = (ClausesUserLookup) model;
        RowData rowData = new RowData();              
        rowData.addColumn("clauseId", instance.getId().getClauseId());
        rowData.addColumn("clauseTitle", instance.getClauseTitle());
        rowData.addColumn("line1", instance.getLine1()); 
        rowData.addColumn("line2", instance.getLine2());
        rowData.addColumn("line3", instance.getLine3());
        rowData.addColumn("line4", instance.getLine4());
        rowData.addColumn("line5", instance.getLine5());
        rowData.addColumn("line6", instance.getLine6());
        rowData.addColumn("line7", instance.getLine7());
        rowData.addColumn("line8", instance.getLine8());
        rowData.addColumn("line9", instance.getLine9());                
        return rowData;
    }
}
