package docprep.src.webtier.actions.user.defaultSetup;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.DefaultSetup;
import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;


public class DefaultSetupDataEntryPageAction extends ExtJsUserDataEntryPageAction {

	protected Model getPageModel(FormField formFields) {
		DefaultSetup defaultSetup = new DefaultSetup();
        return defaultSetup;
	}
	
	protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {
		EndUserEnvironment endUserEnv = (EndUserEnvironment)enviornment;					 
		DefaultSetup defaultSetup = (DefaultSetup) model;  	    	        	        	        	      
        endUserEnv.getDefaultSetupManager().updateDefaultSetup(defaultSetup);	        	        
		return null;
	}

	protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
		EndUserEnvironment endUserEnv = (EndUserEnvironment)enviornment;			
		DefaultSetup defaultSetup = (DefaultSetup) model;    		             				
		endUserEnv.getDefaultSetupManager().updateDefaultSetup(defaultSetup);		
		return null;
	}	

}
