package docprep.src.webtier.actions.user.currencyUserLookup;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;

import userlookup.src.listhelper.CurrencyUserLookupListHelper;
import codemaintenance.src.dto.CurrencyLookup;
import codemaintenance.src.listhelper.CurrencyLookupListHelper;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;

public class CurrencyUserLookupListPageAction extends ExtJsListingPageAction {
    
    protected Class getListHelper() {
        return CurrencyLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
    	CurrencyLookupListHelper criteria = (CurrencyLookupListHelper) listHelper;
    	EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getCurrencyCode())) {
                criteria.setCurrencyCode(criteria.getCurrencyCode() + "*");
            }            
        }                
        System.out.println("criteria.getCurrencyCode(): "+criteria.getCurrencyCode());
        PageHandler pageHandler = env.getCurrencyLookupManager().getCurrencyList(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
    	CurrencyLookup instance = (CurrencyLookup) model;
        RowData rowData = new RowData();
        rowData.addColumn("currencyCode", instance.getCurrencyCode()); 
        rowData.addColumn("currencyName", instance.getCurrencyName()); 
        rowData.addColumn("countryName", instance.getCountryName());  
        return rowData;
    }
}