package docprep.src.webtier.actions.user.product;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.validator.GenericValidator;
import userlookup.src.dto.ProductUserLookup;
import userlookup.src.listhelper.ProductUserLookupListHelper;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class ProductListPageAction extends ExtJsListingPageAction {
	    
	    protected Class getListHelper() {
	        return ProductUserLookupListHelper.class;
	    }

	    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
	    	ProductUserLookupListHelper criteria = (ProductUserLookupListHelper) listHelper;
	        EndUserEnvironment env = signedInUser.getEndUserEnvironment();
	        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
	            if (!GenericValidator.isBlankOrNull(criteria.getProductCode())) {
	                criteria.setProductCode(criteria.getProductCode() + "*");
	            }            
	        }        
	        System.err.println(" criteria.getProductCode(): "+criteria.getProductCode());
	        PageHandler pageHandler = env.getProductUserLookupManager().getProductList(criteria);        
	        return pageHandler;
	    }

	    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
	        return;
	    }

	    public RowData getListRowData(Model model) {
	    	ProductUserLookup instance = (ProductUserLookup) model;
	        RowData rowData = new RowData();
	              
	        rowData.addColumn("productCode", instance.getId().getProductCode()); 
	        rowData.addColumn("description", instance.getDescription()); 
	        rowData.addColumn("quantity", instance.getQuantity()); 
	        rowData.addColumn("unitPrice", instance.getUnitPrice()); 
	        rowData.addColumn("hscode", instance.getHscode()); 
	        rowData.addColumn("unitOfMeasures", instance.getUnitOfMeasures()); 
	        rowData.addColumn("countryOfOrigin", instance.getCountryOfOrigin()); 
	             
	        return rowData;
	    }
	}