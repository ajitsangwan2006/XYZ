package docprep.src.webtier.actions.user.vesselLookup;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;

import codemaintenance.src.dto.VesselLookup;
import codemaintenance.src.listhelper.VesselLookupListHelper;

import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsListingPageAction;
import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.webtier.ui.table.RowData;

public class VesselLookupListPageAction extends ExtJsListingPageAction {
    
    protected Class getListHelper() {
        return VesselLookupListHelper.class;
    }

    public PageHandler getPageHandler(ListHelper listHelper, SignedInUser signedInUser, HttpServletRequest request) throws AccessDeniedException {
    	VesselLookupListHelper criteria = (VesselLookupListHelper) listHelper;
        EndUserEnvironment env = signedInUser.getEndUserEnvironment();
        if (request.getParameter("requestType") != null && request.getParameter("requestType").equals("ComboList")) {
            if (!GenericValidator.isBlankOrNull(criteria.getVesselCode())) {
                criteria.setVesselCode(criteria.getVesselCode() + "*");
            }            
        }        
        PageHandler pageHandler = env.getVesselLookupManager().getVesselLookup(criteria);        
        return pageHandler;
    }

    public void postProcessListHelper(ListHelper listHelper, HttpServletRequest httpservletrequest, ValidationErrors errors) throws AccessDeniedException {
        return;
    }

    public RowData getListRowData(Model model) {
    	VesselLookup instance = (VesselLookup) model;
        RowData rowData = new RowData();
        rowData.addColumn("vesselCode", instance.getVesselCode()); 
        rowData.addColumn("vesselName", instance.getVesselName());  
     
        return rowData;
    }
}