package docprep.src.webtier.actions.user.document;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.ItemDetail;
import docprep.src.dto.MasterDocument;
import docprep.src.dto.PackageDetail;
import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;


public class ExportDocumentDataEntryPageAction extends ExtJsUserDataEntryPageAction {

	protected Model getPageModel(FormField formFields) {
		MasterDocument masterDocTO = new MasterDocument();
        return masterDocTO;
	}

	
	protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {
		EndUserEnvironment endUserEnv = (EndUserEnvironment)enviornment;
		///to be set////
		   //String docTypeCode = formFields.getParameter("docTypeCode");					 	
	        MasterDocument masterDocTO = (MasterDocument) model;  	    
	        masterDocTO.setDocTypeCode("MasterDocument");	        
	        masterDocTO.setItemDetails(getItemDetailRows(request));
	        masterDocTO.setPackageDetails(getPackageDetailRows(request));	        
	        endUserEnv.getDocumentMgmtManager().getExportDocumentManager().createMaster(masterDocTO);	        	        
		return null;
	}

	 private PackageDetail[] getPackageDetailRows(HttpServletRequest request) throws IOException {
        String rootname = "packageDetailsGrid";
        String json_String = request.getParameter(rootname);
        if (GenericValidator.isBlankOrNull(json_String)) {
            return null;
        }

        Collection collection = this.toCollection(json_String, rootname, PackageDetail.class);
        log(rootname + " - jsonArray Size: " + collection.size());

        PackageDetail[] packageDetailRows = (PackageDetail[]) collection.toArray(new PackageDetail[collection.size()]);
        log(rootname + " - jsonArray Size -2: " + packageDetailRows.length);

        return packageDetailRows;
    }
	 
	 private ItemDetail[] getItemDetailRows(HttpServletRequest request) throws IOException {
        String rootname = "itemDetailsGrid";
        String json_String = request.getParameter(rootname);
        if (GenericValidator.isBlankOrNull(json_String)) {
            return null;
        }

        Collection collection = this.toCollection(json_String, rootname, ItemDetail.class);
        log(rootname + " - jsonArray Size: " + collection.size());

        ItemDetail[] itemDetailRows = (ItemDetail[]) collection.toArray(new ItemDetail[collection.size()]);
        log(rootname + " - jsonArray Size -2: " + itemDetailRows.length);

        return itemDetailRows;
    }	 	

	protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
		EndUserEnvironment endUserEnv = (EndUserEnvironment)enviornment;		
		String docId = formFields.getParameter("docId");
		String sysDocId = formFields.getParameter("sysDocId");		
        MasterDocument masterDocTO = (MasterDocument) model;    
        masterDocTO.setSysDocId(new Long(sysDocId));
        masterDocTO.setDocId(docId);
        masterDocTO.setDocTypeCode("MasterDocument");        
        masterDocTO.setItemDetails(getItemDetailRows(request));
        masterDocTO.setPackageDetails(getPackageDetailRows(request));	               
        endUserEnv.getDocumentMgmtManager().getExportDocumentManager().updateMaster(masterDocTO);
		return null;
	}
	
	 private Collection toCollection(String json, String rootname, Class beanClass) throws IOException {
        JSONObject jsonObject = JSONObject.fromObject(json);
        JSONArray jsonArray = jsonObject.getJSONArray(rootname);
        Collection collection = JSONArray.toCollection(jsonArray, beanClass);
        return collection;
    }   

	

}
