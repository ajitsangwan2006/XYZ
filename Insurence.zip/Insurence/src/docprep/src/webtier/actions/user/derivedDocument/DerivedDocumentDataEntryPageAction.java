package docprep.src.webtier.actions.user.derivedDocument;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.validator.GenericValidator;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.PackingList;
import docprep.src.dto.PackingListItemDetail;
import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;

public class DerivedDocumentDataEntryPageAction extends ExtJsUserDataEntryPageAction {

    protected Model getPageModel(FormField formFields) {
        log("formFields.getParameter(\"docTypeCode\"): " + formFields.getParameter("docTypeCode"));
        if (formFields.getParameter("docTypeCode").equalsIgnoreCase("PackingList")) {
            log("formFields.getParameter(\"docTypeCode\"): " + formFields.getParameter("docTypeCode"));
            return new PackingList();
        }
        return null;
    }

    protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {
        EndUserEnvironment endUserEnv = (EndUserEnvironment) enviornment;
        String docTypeCode = formFields.getParameter("docTypeCode");
        String docStatus = formFields.getParameter("docStatus");
        DerivedDocument derivedDocument = new DerivedDocument();
        if (docTypeCode != null && docTypeCode.equalsIgnoreCase("PackingList")) {
            PackingList packingList = (PackingList) model;
            packingList.setPackingListItemDetails(getPackingListDetailRows(request));
            derivedDocument.setBody(packingList);
        }
        ExportDocument header = new ExportDocument();
        header.setDocTypeCode(docTypeCode);
        derivedDocument.setHeader(header);
        endUserEnv.getDocumentMgmtManager().getExportDocumentManager().createDerived(derivedDocument);
        return null;
    }

    protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
        EndUserEnvironment endUserEnv = (EndUserEnvironment) enviornment;
        String sysDocId = formFields.getParameter("sysDocId");
        String docTypeCode = request.getParameter("docTypeCode");
        DerivedDocument derivedDocument = new DerivedDocument();
        ExportDocument header = new ExportDocument();
        header.setDocTypeCode(docTypeCode);
        header.setSysDocId(new Long(sysDocId));
        if (docTypeCode != null && docTypeCode.equalsIgnoreCase("PackingList")) {
            PackingList packingList = (PackingList) model;
            log("packingList: " + packingList);
            packingList.setPackingListItemDetails(getPackingListDetailRows(request));
            derivedDocument.setBody(packingList);
        }
        derivedDocument.setHeader(header);
        endUserEnv.getDocumentMgmtManager().getExportDocumentManager().updateDerived(derivedDocument);
        return null;
    }
    
    private PackingListItemDetail[] getPackingListDetailRows(HttpServletRequest request) throws IOException {
        String rootname = "packingListItemDetailsGrid";
        String json_String = request.getParameter(rootname);
        if (GenericValidator.isBlankOrNull(json_String)) {
            return null;
        }

        Collection collection = this.toCollection(json_String, rootname, PackingListItemDetail.class);
        log(rootname + " - jsonArray Size: " + collection.size());

        PackingListItemDetail[] itemDetailRows = (PackingListItemDetail[]) collection.toArray(new PackingListItemDetail[collection.size()]);
        log(rootname + " - jsonArray Size -2: " + itemDetailRows.length);

        return itemDetailRows;
    }

    private Collection toCollection(String json, String rootname, Class beanClass) throws IOException {
        JSONObject jsonObject = JSONObject.fromObject(json);
        JSONArray jsonArray = jsonObject.getJSONArray(rootname);
        Collection collection = JSONArray.toCollection(jsonArray, beanClass);
        return collection;
    }

}
