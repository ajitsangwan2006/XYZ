package docprep.src.webtier.actions.user.report;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionMapping;

import net.sf.json.JSONObject;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.UserReportTO;
import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;


public class ReportDataEntryPageAction extends ExtJsUserDataEntryPageAction {

	protected Model getPageModel(FormField formFields) {
		UserReportTO masterDocTO = new UserReportTO();
        return masterDocTO;
	}

	
	protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {			        
		return null;
	}	

	protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {		
		return null;
	}
	 
	protected JSONObject doEmail(Environment enviornment, Model model, HttpServletRequest httpservletrequest, FormField formFields, dev.zing.framework.webtier.adapter.FormFile formFiles, ActionMapping mapping) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException {
		System.err.println("I am called inside Email Method");
		EndUserEnvironment useEnv = (EndUserEnvironment)enviornment;
		UserReportTO reportTo = (UserReportTO) model;		
		boolean isMailSendSuccessfully = false;		
	//	isMailSendSuccessfully = useEnv.getDocumentMgmtManager().getDocReportManager().sendEndUserReport("ExportDocs Master Report", reportTo);		
        return null;
    }

	

}
