package docprep.src.webtier.actions.user.party;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import userlookup.src.dto.TradingPartnerLookup;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;

public class TradingPartnerCommandPageAction extends ExtJsUserCommandPageAction {

    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, InvalidArgumentException, IllegalAccessException, DuplicateRecordException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            }
        }
    }

    protected void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
        String partnerId = request.getParameter("partnerId");
        log("partnerId:- " + partnerId);
        TradingPartnerLookup instance = env.getTradingPartnerLookupManager().get(partnerId);
        JSONObject json = getJSON(instance);
        json.getJSONObject("data").accumulate("exporterFlag", instance.getIsExporter() == null ? 0 : instance.getIsExporter().intValue());
        json.getJSONObject("data").accumulate("consigneeFlag", instance.getIsConsignee() == null ? 0 : instance.getIsConsignee().intValue());
        json.getJSONObject("data").accumulate("buyerFlag", instance.getIsBuyer() == null ? 0 : instance.getIsBuyer().intValue());
        json.getJSONObject("data").accumulate("forwardingAgentFlag", instance.getIsForwardingAgent() == null ? 0 : instance.getIsForwardingAgent().intValue());
        json.getJSONObject("data").accumulate("manufacturerFlag", instance.getIsManufacturer() == null ? 0 : instance.getIsManufacturer().intValue());
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
    }
}
