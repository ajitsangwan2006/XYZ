package docprep.src.webtier.actions.user.derivedDocument;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.lowagie.text.DocumentException;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.PackingList;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;

public class DerivedDocumentCommandPageAction extends ExtJsUserCommandPageAction {

    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IllegalAccessException, DuplicateRecordException, InvalidArgumentException, IOException, DocumentException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("NEW")) {
                doNew(env, request, response);
            } else if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            } else if (actionMode.equalsIgnoreCase("DOWNLOAD")) {
            	doDownload(env, request, response);
            } else if (actionMode.equalsIgnoreCase("DELETE")) {
            	doDelete(env, request, response);
            }
        }
    }

    protected void doNew(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
    	String docTypeCode = request.getParameter("docTypeCode");
        log("docTypeCode:-" + docTypeCode);
        Long parentId = new Long(request.getParameter("parentId"));
        log("parentId:-" + parentId);
        Map map = new HashMap(); 
        JSONObject json = getJSON(map);
        ExportDocument document = env.getDocumentMgmtManager().getExportDocumentManager().getByDocumentType(parentId,docTypeCode);
        if (document != null) {
            json.put("documentExist", "true");
        }        
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
    }

    protected void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
        String sysDocId = request.getParameter("sysDocId");
        String docTypeCode = request.getParameter("docTypeCode");
        log("sysDocId:- " + sysDocId);
        DerivedDocument deriveDocument = env.getDocumentMgmtManager().getExportDocumentManager().getDeriveDocumentDetails(sysDocId, docTypeCode);
        Map map = new HashMap();
        PackingList packingList = null;
        packingList = (PackingList) deriveDocument.getBody();
        packingList.setDocTypeCode(deriveDocument.getHeader().getDocTypeCode());
        map.put("packingListItemDetailsGrid", getPackingListItemDetailList(packingList));
        map.put("FormData", getModelData(packingList));
        map.put("parentId", deriveDocument.getHeader().getParentId());
        map.put("docId", deriveDocument.getHeader().getDocId());
        map.put("docTypeCode", deriveDocument.getHeader().getDocTypeCode());
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
    }
    
    protected void doDownload(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, DuplicateRecordException, IOException {
    	String sysDocId = request.getParameter("sysDocId");
    	String docTypeCode = request.getParameter("docTypeCode");
        
    	log("sysDocId:- " + sysDocId);
        log("selDocType:- " + docTypeCode);
        
        byte[] bytes = null;
        bytes = env.getDocReportManager().getReportBytes(sysDocId, docTypeCode);
        
        response.setContentType("application/pdf");
        response.setContentLength(bytes.length);
        response.setHeader("Content-disposition", "attachment; filename=" + sysDocId + ".pdf");
        try {
            ServletOutputStream servletoutputstream = response.getOutputStream();
            servletoutputstream.write(bytes);
            servletoutputstream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public JSONObject getPackingListItemDetailList(PackingList packingList) {
        JSONObject json = new JSONObject();
        if (packingList.getPackingListItemDetails() != null) {
            json = getGridData(packingList.getPackingListItemDetails());
        } else {
            json = getDefaultListData();
        }
        log("json String:" + json.toString());
        return json;
    }

    public JSONObject getDefaultListData() {
        JSONObject json = new JSONObject();
        json.put("totalCount", new Integer(0));
        json.put("results", new JSONArray());
        return json;
    }
    
    protected void doDelete(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
		String sysDocId = request.getParameter("sysDocId");		
		log("sysDocId:- "+sysDocId);     
		env.getDocumentMgmtManager().getExportDocumentManager().deleteDerivedDocument(sysDocId);
	 }
}
