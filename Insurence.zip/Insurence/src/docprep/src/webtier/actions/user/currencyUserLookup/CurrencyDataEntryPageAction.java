package docprep.src.webtier.actions.user.currencyUserLookup;
 
import java.io.IOException;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.validator.GenericValidator;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.businesstier.model.Model;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.webtier.adapter.FormField;
import dev.zing.framework.webtier.adapter.FormFile;
import docprep.src.bto.userAccess.EndUserEnvironment;
import userlookup.src.dto.CurrencyUserLookup;


import docprep.src.webtier.framework.extension.ExtJsUserDataEntryPageAction;
public class CurrencyDataEntryPageAction  extends ExtJsUserDataEntryPageAction  {

	 protected Model getPageModel(FormField formFields) {
		CurrencyUserLookup currency = new CurrencyUserLookup();
        return currency;
    }	
	 protected JSONObject performAddAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, DuplicateRecordException, InvalidPasswordException, IOException {
		EndUserEnvironment userEnv = (EndUserEnvironment) enviornment;
		CurrencyUserLookup currency = (CurrencyUserLookup) model; 
    	System.err.println("Currency Code"+currency.getCurrencyCode());
        log("CurrencyDataEntryPageAction - performAddAction");
    	userEnv.getCurrencyUserLookupManager().create(currency);
        return null;
   	}
	 private CurrencyUserLookup[] getCurrencyRows(HttpServletRequest request) throws IOException {
        String rootname = "currencyform";
        String json_String = request.getParameter(rootname);
        if (GenericValidator.isBlankOrNull(json_String)) {
          return null;
        }
        Collection collection = this.toCollection(json_String, rootname,CurrencyUserLookup.class);
        log(rootname + " - jsonArray Size: " + collection.size());
        CurrencyUserLookup[] currencyRows = (CurrencyUserLookup[]) collection.toArray(new CurrencyUserLookup[collection.size()]);
        log(rootname + " - jsonArray Size -2: " + currencyRows.length);
        return currencyRows;
    }
	 protected JSONObject performModifyAction(Environment enviornment, Model model, HttpServletRequest request, HttpServletResponse response, FormField formFields, FormFile formFiles) throws InvalidArgumentException, RecordNotFoundException, InvalidPasswordException, IOException {
		EndUserEnvironment userEnv = (EndUserEnvironment) enviornment;
		CurrencyUserLookup currency = (CurrencyUserLookup) model;
	    //product.getId().setUserId(formFields.getParameter("userId"));
	    currency.setCurrencyCode(formFields.getParameter("currencyCode"));
	    
	    userEnv.getCurrencyUserLookupManager().update(currency);
	    String statusMessage = "Currency has been updated in database with Id [ "+currency.getCurrencyCode()+" ].";
	     return null;
	}	
     private Collection toCollection(String json, String rootname, Class beanClass) throws IOException {
        JSONObject jsonObject = JSONObject.fromObject(json);
        JSONArray jsonArray = jsonObject.getJSONArray(rootname);
        Collection collection = JSONArray.toCollection(jsonArray, beanClass);
        return collection;
    }   
	
}
