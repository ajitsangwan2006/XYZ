
package docprep.src.webtier.actions.user.currencyUserLookup;

import java.io.IOException;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import userlookup.src.bto.controller.CurrencyUserLookupManager;
import userlookup.src.dto.CurrencyUserLookup;
import com.ibm.wsspi.sib.exitpoint.ra.HashMap;
import com.lowagie.text.DocumentException;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;

public class CurrencyCommandPageAction extends ExtJsUserCommandPageAction {
    
    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IllegalAccessException, DuplicateRecordException, InvalidArgumentException, IOException, DocumentException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
        	if (actionMode.equalsIgnoreCase("NEW")) {
                doNew(env, request, response);
            }else if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            }else if (actionMode.equalsIgnoreCase("DELETE")) {
                doDelete(env, request, response);
            }

        }
    }
    protected void doNew(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
    	CurrencyUserLookupManager currency = env.getCurrencyUserLookupManager();
    	Map map = new HashMap();                        
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}
   
    private void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
        String currencyCode = request.getParameter("currencyCode");    
        log("currencyCode:- "+currencyCode);
        CurrencyUserLookup currency = env.getCurrencyUserLookupManager().getCurrency(currencyCode);
		
		Map map = new HashMap();
        map.put("FormData", getModelData(currency));
        map.put("currencyCode",currency.getCurrencyCode());
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
		
    }
	protected void doDelete(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
		String currencyCode = request.getParameter("currencyCode");
		log("currencyCode:- "+currencyCode);     
		env.getCurrencyUserLookupManager().delete(currencyCode);
	}
	
   
}
