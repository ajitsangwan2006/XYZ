package docprep.src.webtier.actions.user.defaultSetup;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.lowagie.text.DocumentException;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.DefaultSetup;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;

public class DefaultSetupCommandPageAction extends ExtJsUserCommandPageAction {
    
    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IllegalAccessException, DuplicateRecordException, InvalidArgumentException, IOException, DocumentException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            }
        }
    }
    
	protected void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {	            
        DefaultSetup defaultSetup  = env.getDefaultSetupManager().getDefaultSetup();        
        Map map = new HashMap();
        if(defaultSetup!=null){
        	map.put("FormData", getModelData(defaultSetup));
        }else{
        	map.put("FormData", null);
        }
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}	
}
