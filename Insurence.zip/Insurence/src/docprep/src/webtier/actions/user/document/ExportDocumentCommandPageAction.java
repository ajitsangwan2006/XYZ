package docprep.src.webtier.actions.user.document;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import usermgmt.src.dto.CompanyModule;
import usermgmt.src.dto.Module;
import usermgmt.src.listhelper.ModuleListHelper;

import com.lowagie.text.DocumentException;

import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.controller.ExportDocumentManager;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.MasterDocument;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;

public class ExportDocumentCommandPageAction extends ExtJsUserCommandPageAction {
    
    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IllegalAccessException, DuplicateRecordException, InvalidArgumentException, IOException, DocumentException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
        	if (actionMode.equalsIgnoreCase("NEW")) {
                doNew(env, request, response);
            }else if (actionMode.equalsIgnoreCase("EDIT")) {
                doEdit(env, request, response);
            }else if (actionMode.equalsIgnoreCase("CLONE")) {
                doClone(env, request, response);
            }else if (actionMode.equalsIgnoreCase("DELETE")) {
                doDelete(env, request, response);
            }else if(actionMode.equalsIgnoreCase("DOWNLOAD")){
            	doDownload(env, request, response);
            }else if (actionMode.equalsIgnoreCase("SEND_TO_CHAMBER")) {
                doSendToChamber(env, request, response);
            }else if (actionMode.equalsIgnoreCase("GET_ASSIGNED_CHAMBER")) {
            	getAssignedChamber(env, request, response);
            }
        }
    }
    
    protected void doNew(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {	            
        MasterDocument masterDocument  = env.getDefaultSetupManager().getDefaultValues(); 
        masterDocument.setDocStatus(new Integer(0));
        Map map = new HashMap();                        
        map.put("FormData", getModelData(masterDocument));       
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}
    
	protected void doEdit(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {	    
        String sysDocId = request.getParameter("sysDocId");
        String docTypeCode = request.getParameter("docTypeCode");
        log("sysDocId:- "+sysDocId);
        
        MasterDocument masterDocument  = env.getDocumentMgmtManager().getExportDocumentManager().getMasterDocDetails(sysDocId);        
        Map map = new HashMap();                
        map.put("PackageDetailsGridList", getPackageDetailList(masterDocument));
        map.put("ItemDetailsGridList", getItemDetailList(masterDocument));
        map.put("FormData", getModelData(masterDocument));
        map.put("docId",masterDocument.getDocId());
        map.put("sysDocId",sysDocId);
        map.put("docStatus",masterDocument.getDocStatus());
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}
	
	protected void doClone(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {	    
        String sysDocId = request.getParameter("sysDocId");
        String docTypeCode = request.getParameter("docTypeCode");
        log("sysDocId:- "+sysDocId);
        
        MasterDocument masterDocument  = env.getDocumentMgmtManager().getExportDocumentManager().getMasterDocDetails(sysDocId);        
        Map map = new HashMap();                
        map.put("PackageDetailsGridList", getPackageDetailList(masterDocument));
        map.put("ItemDetailsGridList", getItemDetailList(masterDocument));
        map.put("FormData", getModelData(masterDocument));
        map.put("docId",masterDocument.getDocId());
        map.put("docStatus",masterDocument.getDocStatus());
        JSONObject json = getJSON(map);
        log("overrideDataBatch - json String:" + json.toString());
        if (json != null) {
            jsonResponse(json, request, response);
        }
	}
	
	public JSONObject getPackageDetailList(MasterDocument masterDto) {
		JSONObject json = new JSONObject();
		if(masterDto.getPackageDetails()!=null){
			 json = getGridData(masterDto.getPackageDetails());
		}else{
			json = getDefaultListData();
		}		
        log("json String:" + json.toString());
        return json;
    }		
	
    public JSONObject getItemDetailList(MasterDocument masterDto) {
    	JSONObject json = new JSONObject();
    	if(masterDto.getItemDetails()!=null){
    		json = getGridData(masterDto.getItemDetails());
    	}else{
    		json = getDefaultListData();
    	}    	
        log("json String:" + json.toString());
        return json;
    }
    
	public JSONObject getDefaultListData() {
		JSONObject json = new JSONObject();		
		json.put("totalCount", new Integer(0));
		json.put("results",  new JSONArray());		
        return json;
	} 
	
	protected void doDelete(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
		String sysDocId = request.getParameter("sysDocId");
		log("sysDocId:- "+sysDocId);     
		env.getDocumentMgmtManager().getExportDocumentManager().delete(sysDocId);
	}
	
	protected void doDownload(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
	       String sysDocId = request.getParameter("sysDocId");
	       int printTemplateId = Integer.parseInt(request.getParameter("printTemplateId"));
	       log("sysDocId:- "+sysDocId);
	        try {	        		        
	        	byte[] bytes = env.getDocumentMgmtManager().getDocReportManager().getMasterReportAsPDF(sysDocId, printTemplateId);	        		           
	            log("PDF Content: " + bytes.toString());
	            response.setContentType("application/pdf");
	            response.setContentLength(bytes.length);
	            response.setHeader("Content-disposition", "attachment; filename=" + sysDocId + ".pdf");
	            ServletOutputStream servletoutputstream = response.getOutputStream();
	            servletoutputstream.write(bytes);
	            servletoutputstream.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}
	
	protected void doSendToChamber(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException, IOException, DocumentException {	    
        String sysDocId = request.getParameter("sysDocId");
        log("SysDocId:- "+sysDocId);
        Integer moduleId = new Integer(request.getParameter("moduleId"));
        String printTemplate = request.getParameter("printTemplate");
	    String deliveryMode = request.getParameter("deliveryMode");  
        String noOfCopies = request.getParameter("noOfCopies");  
        String requestedTargetDate = request.getParameter("requestedTargetDate");
        ExportDocumentManager exportDocumentManager = env.getDocumentMgmtManager().getExportDocumentManager();
        ExportDocument document = exportDocumentManager.get(sysDocId);
        byte[] bytes = env.getDocumentMgmtManager().getDocReportManager().getMasterReportAsPDF(sysDocId, Integer.parseInt(printTemplate));
        env.getDocumentMgmtManager().getExportDocumentManager().sendDocumentToChamber(moduleId, document.getExporterReference(), printTemplate, deliveryMode, noOfCopies, requestedTargetDate, bytes);	
	}
	
	protected void getAssignedChamber(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {        
        ModuleListHelper listHelper = new ModuleListHelper();
        List moduleList = env.getModuleManager().getList(listHelper);
        SignedInUser user = (SignedInUser)request.getSession().getAttribute("SignedInUser");   
        Vector vector = new Vector();         
        int assignedChannel = 0;
        Integer channelId = null;
        String moduleName="";       
        JSONObject json = null;
        for(int i=0; i < moduleList.size(); i++) {
            Module module = (Module) moduleList.get(i);
            if(module.getModuleId().intValue()== 1 || module.getModuleId().intValue()== 2  || module.getModuleId().intValue()== 3 || module.getModuleId().intValue()== 4 || module.getModuleId().intValue()== 9 || module.getModuleId().intValue()==10){
                continue;
            }
            CompanyModule companyModule = env.getCompanyModuleManager().get(user.getSiteId(), module.getModuleId());            
            Map map = new HashMap();
            if (companyModule != null && companyModule.getStatus() == 1) {
	            map.put("moduleCode", module.getModuleId());	            	            
	            if(module.getModuleId().intValue() == 5){
	                moduleName = "Victorian Employer's Chamber";
	            }else if(module.getModuleId().intValue() == 6){
	                moduleName = "Australian Arab Chamber";
	            }else if(module.getModuleId().intValue() == 7){
	                moduleName = "NSW Business Chamber";
	            }else if(module.getModuleId().intValue() == 8){
	                moduleName = "Business SA";
	            }else if(module.getModuleId().intValue() == 11){
	                moduleName = "CCI Western Australia";
	            }else if(module.getModuleId().intValue() == 12){
	                moduleName = "Tasmanian Chamber";
	            }	            
	            map.put("moduleName", moduleName);	            
	            vector.add(map);
	            assignedChannel++;
            }
            if(assignedChannel==1){
                channelId = module.getModuleId();
            }
        }     
        if(vector.isEmpty()){
        	getFailureJSON(response, 602, "No chamber module assigned for the logged in user");
        }else{
        	HashMap[] hashMap = (HashMap[]) vector.toArray(new HashMap[vector.size()]);
            json = getGridData(hashMap);
            json.put("channelId", channelId);
            log("json String:" + json.toString());
            jsonResponse(json, request, response); 
        }
    }

}
