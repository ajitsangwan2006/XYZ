package docprep.src.webtier.actions.common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.MessageResources;
import dev.zing.framework.services.exception.application.bto.AuthenticationFailureException;
import dev.zing.framework.services.exception.application.bto.InactiveUserException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.system.ConfigurationException;
import dev.zing.framework.webtier.struts.WebTierAction;
import docprep.src.bto.main.Server;
import docprep.src.bto.main.SignedInUser;

public class LoginAction extends WebTierAction {
    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        ActionErrors errors = new ActionErrors();
        ActionForward forward = new ActionForward();
        
        String siteId = request.getParameter("SiteId");
        String userName = request.getParameter("UserId");
        String password = request.getParameter("Password");
        String ipAddress = request.getRemoteAddr();
        MessageResources messageResources = getResources(request);
        log("siteId: " + siteId);
        log("userName: " + userName);
        log("password: " + password);
        log("ipAddress: " + ipAddress);

        boolean isUser = false;
        try {
            isUser = Server.checkUser(userName, password);
        } catch (InvalidArgumentException e) {
            String[] messageCodes = e.getErrorOzCode();
            String exceptionMessage = "";
            if (messageCodes != null && messageCodes.length > 0) {
                for (int excp = 0; excp < messageCodes.length; excp++) {
                    exceptionMessage = exceptionMessage + messageResources.getMessage(messageCodes[excp], request);
                    if (exceptionMessage != null && exceptionMessage.trim().length() > 0) {
                        exceptionMessage = exceptionMessage + "<BR>&nbsp;&nbsp;&nbsp;";
                    }
                }
            }
            request.setAttribute("InvalidUserMessage", "Incorrect User ID/Password.");
            forward = mapping.findForward("InvalidUser");
            return forward;
        }
        
        
        SignedInUser user = null;

        if (isUser) {
            log("userName '" + userName + "' does exist on server.");
            try {
                user = Server.login(userName, password, ipAddress);
            } catch (InvalidArgumentException e1) {
                e1.printStackTrace();
                String[] messageCodes = e1.getErrorOzCode();
                String exceptionMessage = "";
                if (messageCodes != null && messageCodes.length > 0) {
                    for (int excp = 0; excp < messageCodes.length; excp++) {
                        exceptionMessage = exceptionMessage + messageResources.getMessage(messageCodes[excp], request);
                        if (exceptionMessage != null && exceptionMessage.trim().length() > 0) {
                            exceptionMessage = exceptionMessage + "<BR>&nbsp;&nbsp;&nbsp;";
                        }
                    }
                }
                request.setAttribute("message", "Incorrect User ID/Password.");
                forward = mapping.findForward("InvalidUser");
                return forward;
            } catch (AuthenticationFailureException e1) {
                e1.printStackTrace();
                request.setAttribute("InvalidUserMessage", "Incorrect User ID/Password.");
                forward = mapping.findForward("InvalidUser");
                return forward;
            } catch (InactiveUserException e1) {
                e1.printStackTrace();
                request.setAttribute("InvalidUserMessage", "The User status is inactive.");
                forward = mapping.findForward("InvalidUser");
                return forward;
            } catch (ConfigurationException e1) {
                e1.printStackTrace();
                request.setAttribute("InvalidUserMessage", e1.getMessage());
                forward = mapping.findForward("InvalidUser");
                return forward;
            }
        } else {
            log("userName '" + userName + "' does NOT exist on server.");
            request.setAttribute("InvalidUserMessage", "Incorrect User ID/Password.");
            forward = mapping.findForward("InvalidUser");
            return forward;
        }

        request.getSession().setAttribute("Search", "FALSE");
        request.getSession().setAttribute("MessageResource", messageResources);

        if (!user.isActive()) {
            request.setAttribute("InvalidUserMessage", "Unable to login as End User (" + user.getUserId() + "). The user status is inactive.");
            forward = mapping.findForward("InvalidUser");
            log("Unable to login as End User (" + user.getUserId() + "). The user status is inactive.");
            return (forward);
        }

        if (user.isUser()) {
            request.getSession().setAttribute("SignedInUser", user);
            forward = mapping.findForward("success");
            log("The End User (" + user.getUserId() + ") has been logged in successfully.");
        } else {
            request.setAttribute("InvalidUserMessage", "The user (" + userName + ") is not registered to Document Preparation System.");
            forward = mapping.findForward("InvalidUser");
            log("The user (" + userName + ") is not registered to EDNDocs Online System.");
        }
        return (forward);
    }
}