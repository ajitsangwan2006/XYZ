package docprep.src.webtier.actions.common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import dev.zing.framework.webtier.struts.WebTierAction;
import docprep.src.bto.main.SignedInUser;

public class WelcomeAction extends WebTierAction {

    public ActionForward executePageAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

        ActionErrors errors = new ActionErrors();
        ActionForward forward = new ActionForward();

        SignedInUser signedInUser = (SignedInUser) request.getSession().getAttribute("SignedInUser");
        if (signedInUser == null) {
            forward = mapping.findForward("SessionExpired");
            return (forward);
        }
        if (signedInUser.isUser()) {
            request.setAttribute("userName", signedInUser.getUserId());
            request.setAttribute("scrollValue", new Integer(signedInUser.getPageScrollValue()));
            forward = mapping.findForward("EndUser");
        }else if (signedInUser.isAdmin()) {
            request.setAttribute("userName", signedInUser.getUserId());
            request.setAttribute("scrollValue", new Integer(signedInUser.getPageScrollValue()));
            forward = mapping.findForward("Admin");
        } else {
            forward = mapping.findForward("ResourcesUnavailable");
        }
        return (forward);
    }
}
