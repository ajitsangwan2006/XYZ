package docprep.src.webtier.actions.common.module;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import usermgmt.src.dto.CompanyModule;
import usermgmt.src.dto.Module;
import usermgmt.src.dto.Person;
import usermgmt.src.listhelper.ModuleListHelper;
import docprep.src.bto.main.SignedInUser;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.webtier.framework.extension.ExtJsUserCommandPageAction;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;

public class ModuleCommandPageAction extends ExtJsUserCommandPageAction {

    protected void executeAction(Environment enviornment, String actionMode, ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, InvalidArgumentException, IllegalAccessException, DuplicateRecordException {
        log("Inside method serviceCommand..");
        EndUserEnvironment env = (EndUserEnvironment) enviornment;
        if (actionMode != null && actionMode.trim().length() > 0) {
            if (actionMode.equalsIgnoreCase("OtherModuleList")) {
                doGetOtherModuleList(env, request, response);
            } else if (actionMode.equalsIgnoreCase("SWITCH")) {
                doSwitch(env, request, response);
            }
        }
    }

    protected void doGetOtherModuleList(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {        
        ModuleListHelper listHelper = new ModuleListHelper();
        listHelper.setEnduserPrivilege(new Integer(1));
        List moduleList = env.getModuleManager().getList(listHelper);
        SignedInUser user = (SignedInUser)request.getSession().getAttribute("SignedInUser");
        Vector vector = new Vector();  
        for(int i=0; i < moduleList.size(); i++) {
            Module module = (Module) moduleList.get(i);
            if(module.getModuleId().intValue()==1){
                continue;
            }
            CompanyModule companyModule = env.getCompanyModuleManager().get(user.getSiteId(), module.getModuleId());
            Map map = new HashMap();
            String moduleName = "";
            if (companyModule != null && companyModule.getStatus() == 1) {
                moduleName += ">> ";
            }            
            moduleName += module.getModuleDescription();
            map.put("moduleCode", moduleName);
            map.put("moduleName", moduleName);
            vector.add(map);
        }        
        HashMap[] hashMap = (HashMap[]) vector.toArray(new HashMap[vector.size()]);
        JSONObject json = getGridData(hashMap);
        log("json String:" + json.toString());
        jsonResponse(json, request, response);  
    }

    protected void doSwitch(EndUserEnvironment env, HttpServletRequest request, HttpServletResponse response) throws InvalidArgumentException {
        String moduleName = request.getParameter("moduleName");
        log("moduleName:- " + moduleName);
        moduleName = moduleName.substring(3, moduleName.length());
        log("moduleName:- " + moduleName);
        Module module = env.getModuleManager().getByDescription(moduleName);
        log("Module DeploymentUrl:- " + module.getDeploymentUrl());
        
        String deploymentUrl = module.getDeploymentUrl();
        StringBuffer moduleURL = new StringBuffer(module.getDeploymentUrl());
        
        log("ServerName:- " + request.getServerName());
        if (!deploymentUrl.toUpperCase().startsWith("HTTP://")) {
            moduleURL = new StringBuffer("http://");
            moduleURL.append(request.getServerName()); 
            if (request.getServerPort() != 80) {
                moduleURL.append(":" + request.getServerPort());
            }            
            moduleURL.append("/");
            moduleURL.append(deploymentUrl);
          //  moduleURL.append("/login.do");
        }   
        Person person = env.getPersonManager().getPerson();
        
        Map map = new HashMap();  
        map.put("deploymentUrl", moduleURL.toString());
        map.put("SiteId", person.getSiteId());
        map.put("UserId", person.getUserId());
        map.put("Password", person.getPassword());
                
        JSONObject json = getJSON(map);
        log("json String:" + json.toString());
        jsonResponse(json, request, response);  
    }    
}
