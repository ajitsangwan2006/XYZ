package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class DefaultSetup extends ModelImpl implements java.io.Serializable {

	// Fields    

	private DefaultSetupId id;

	private String transferExportname;

	private String countryCode;

	private String currencyCode;

	private String formatofDate;

	private Integer maxEntries;

	private byte[] printLogo;

	private byte[] printSignature;

	private Integer defaultDocIdFlag;

	private Integer defaultDocId;

	private String docIdBeginsWith;

	private Integer currentDocId;

	private String buyerId;

	private String consigneeId;

	private String exporterId;

	private String manufacturerId;

	private String forwardingAgentId;

	private String termId;

	private String clauseId;

	private String portCode;
	
	private String isoCode;

	private String portofDischarge1;
	
	private String portofDischarge2;

	private String specialConditionsId;

	private String finalDestCode;
	
	private String finalDestIsoCode;

	private String finalDestination1;
	
	private String finalDestination2;
	
	private String comments;

	// Constructors

	/** default constructor */
	public DefaultSetup() {
		id = new DefaultSetupId();
	}

	/** minimal constructor */
	public DefaultSetup(DefaultSetupId id) {
		this.id = id;
	}
		
	public DefaultSetup(DefaultSetupId id, String transferExportname,
			String countryCode, String currencyCode, String formatofDate,
			Integer maxEntries, byte[] printLogo, byte[] printSignature,
			Integer defaultExporterRefFlag, Integer defaultExporterRef,
			String exporterRefBeginsWith, Integer currentExporterRef,
			String buyerId, String consigneeId, String exporterId,
			String manufacturerId, String forwardingAgentId, String termId,
			String clauseId, String portCode, String isoCode,
			String portofDischarge1, String portofDischarge2,
			String specialConditionsId, String finalDestCode,
			String finalDestIsoCode, String finalDestination1,
			String finalDestination2, String comments) {
		super();
		this.id = id;
		this.transferExportname = transferExportname;
		this.countryCode = countryCode;
		this.currencyCode = currencyCode;
		this.formatofDate = formatofDate;
		this.maxEntries = maxEntries;
		this.printLogo = printLogo;
		this.printSignature = printSignature;
		this.defaultDocIdFlag = defaultExporterRefFlag;
		this.defaultDocId = defaultExporterRef;
		this.docIdBeginsWith = exporterRefBeginsWith;
		this.currentDocId = currentExporterRef;
		this.buyerId = buyerId;
		this.consigneeId = consigneeId;
		this.exporterId = exporterId;
		this.manufacturerId = manufacturerId;
		this.forwardingAgentId = forwardingAgentId;
		this.termId = termId;
		this.clauseId = clauseId;
		this.portCode = portCode;
		this.isoCode = isoCode;
		this.portofDischarge1 = portofDischarge1;
		this.portofDischarge2 = portofDischarge2;
		this.specialConditionsId = specialConditionsId;
		this.finalDestCode = finalDestCode;
		this.finalDestIsoCode = finalDestIsoCode;
		this.finalDestination1 = finalDestination1;
		this.finalDestination2 = finalDestination2;
		this.comments = comments;
	}
	// Property accessors
	public DefaultSetupId getId() {
		return this.id;
	}

	public void setId(DefaultSetupId id) {
		this.id = id;
	}

	public String getTransferExportname() {
		return this.transferExportname;
	}

	public void setTransferExportname(String transferExportname) {
		this.transferExportname = transferExportname;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getFormatofDate() {
		return this.formatofDate;
	}

	public void setFormatofDate(String formatofDate) {
		this.formatofDate = formatofDate;
	}

	public Integer getMaxEntries() {
		return this.maxEntries;
	}

	public void setMaxEntries(Integer maxEntries) {
		this.maxEntries = maxEntries;
	}

	public byte[] getPrintLogo() {
		return this.printLogo;
	}

	public void setPrintLogo(byte[] printLogo) {
		this.printLogo = printLogo;
	}

	public byte[] getPrintSignature() {
		return this.printSignature;
	}

	public void setPrintSignature(byte[] printSignature) {
		this.printSignature = printSignature;
	}

	public Integer getDefaultDocIdFlag() {
		return this.defaultDocIdFlag;
	}

	public void setDefaultDocIdFlag(Integer defaultDocIdFlag) {
		this.defaultDocIdFlag = defaultDocIdFlag;
	}

	public Integer getDefaultDocId() {
		return this.defaultDocId;
	}

	public void setDefaultDocId(Integer defaultDocId) {
		this.defaultDocId = defaultDocId;
	}

	public String getDocIdBeginsWith() {
		return this.docIdBeginsWith;
	}

	public void setDocIdBeginsWith(String docIdBeginsWith) {
		this.docIdBeginsWith = docIdBeginsWith;
	}

	public Integer getCurrentDocId() {
		return this.currentDocId;
	}

	public void setCurrentDocId(Integer currentDocId) {
		this.currentDocId = currentDocId;
	}

	public String getBuyerId() {
		return this.buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getConsigneeId() {
		return this.consigneeId;
	}

	public void setConsigneeId(String consigneeId) {
		this.consigneeId = consigneeId;
	}

	public String getExporterId() {
		return this.exporterId;
	}

	public void setExporterId(String exporterId) {
		this.exporterId = exporterId;
	}

	public String getManufacturerId() {
		return this.manufacturerId;
	}

	public void setManufacturerId(String manufacturerId) {
		this.manufacturerId = manufacturerId;
	}

	public String getForwardingAgentId() {
		return this.forwardingAgentId;
	}

	public void setForwardingAgentId(String forwardingAgentId) {
		this.forwardingAgentId = forwardingAgentId;
	}

	public String getTermId() {
		return this.termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getClauseId() {
		return this.clauseId;
	}

	public void setClauseId(String clauseId) {
		this.clauseId = clauseId;
	}

	public String getSpecialConditionsId() {
		return this.specialConditionsId;
	}

	public void setSpecialConditionsId(String specialConditionsId) {
		this.specialConditionsId = specialConditionsId;
	}

	public String getFinalDestCode() {
		return this.finalDestCode;
	}

	public void setFinalDestCode(String finalDestCode) {
		this.finalDestCode = finalDestCode;
	}

	public String getFinalDestination1() {
		return finalDestination1;
	}
	public void setFinalDestination1(String finalDestination1) {
		this.finalDestination1 = finalDestination1;
	}
	public String getFinalDestination2() {
		return finalDestination2;
	}
	public void setFinalDestination2(String finalDestination2) {
		this.finalDestination2 = finalDestination2;
	}
	public String getPortCode() {
		return portCode;
	}
	public void setPortCode(String portCode) {
		this.portCode = portCode;
	}
	public String getPortofDischarge1() {
		return portofDischarge1;
	}
	public void setPortofDischarge1(String portofDischarge1) {
		this.portofDischarge1 = portofDischarge1;
	}
	public String getPortofDischarge2() {
		return portofDischarge2;
	}
	public void setPortofDischarge2(String portofDischarge2) {
		this.portofDischarge2 = portofDischarge2;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getFinalDestIsoCode() {
		return finalDestIsoCode;
	}
	public void setFinalDestIsoCode(String finalDestIsoCode) {
		this.finalDestIsoCode = finalDestIsoCode;
	}
	public String getIsoCode() {
		return isoCode;
	}
	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}
	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
