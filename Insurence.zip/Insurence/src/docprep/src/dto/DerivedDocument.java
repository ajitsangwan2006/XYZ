package docprep.src.dto;

public class DerivedDocument {
	private ExportDocument header;
	private Body body;

	public Body getBody() {
		return body;
	}
	
	public void setBody(Body body) {
		this.body = body;
	}
	
	public ExportDocument getHeader() {
		return header;
	}
	
	public void setHeader(ExportDocument header) {
		this.header = header;
	}
}
