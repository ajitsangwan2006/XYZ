package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class DefaultSetupId extends ModelImpl implements java.io.Serializable {

	// Fields    

	private String siteId;

	private String userId;

	// Constructors

	/** default constructor */
	public DefaultSetupId() {
	}

	/** full constructor */
	public DefaultSetupId(String siteId, String userId) {
		this.siteId = siteId;
		this.userId = userId;
	}

	// Property accessors
	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof DefaultSetupId))
			return false;
		DefaultSetupId castOther = (DefaultSetupId) other;

		return ((this.getSiteId() == castOther.getSiteId()) || (this
				.getSiteId() != null
				&& castOther.getSiteId() != null && this.getSiteId().equals(
				castOther.getSiteId())))
				&& ((this.getUserId() == castOther.getUserId()) || (this
						.getUserId() != null
						&& castOther.getUserId() != null && this.getUserId()
						.equals(castOther.getUserId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getSiteId() == null ? 0 : this.getSiteId().hashCode());
		result = 37 * result
				+ (getUserId() == null ? 0 : this.getUserId().hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
