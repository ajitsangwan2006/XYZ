package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class PackageDetail extends ModelImpl implements java.io.Serializable {

	private PackageDetailId id;

	private String marks;

	private String pckg;

	private String descriptionofgoods;

	private String grossMass;

	private String cubic;

	
	public PackageDetail() {
	}

	
	public PackageDetail(PackageDetailId id) {
		this.id = id;
	}
	
	public PackageDetail(PackageDetailId id, String marks, String pckg,
			String descriptionofgoods, String grossMass, String cubic) {
		this.id = id;
		this.marks = marks;
		this.pckg = pckg;
		this.descriptionofgoods = descriptionofgoods;
		this.grossMass = grossMass;
		this.cubic = cubic;
	}

	public PackageDetailId getId() {
		return this.id;
	}

	public void setId(PackageDetailId id) {
		this.id = id;
	}

	public String getMarks() {
		return this.marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getPckg() {
		return this.pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getDescriptionofgoods() {
		return this.descriptionofgoods;
	}

	public void setDescriptionofgoods(String descriptionofgoods) {
		this.descriptionofgoods = descriptionofgoods;
	}

	public String getGrossMass() {
		return this.grossMass;
	}

	public void setGrossMass(String grossMass) {
		this.grossMass = grossMass;
	}

	public String getCubic() {
		return this.cubic;
	}

	public void setCubic(String cubic) {
		this.cubic = cubic;
	}


	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
