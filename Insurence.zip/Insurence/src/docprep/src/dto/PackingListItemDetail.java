package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class PackingListItemDetail extends ModelImpl implements java.io.Serializable {

	// Fields    
	
	private PackingListItemDetailId id;

	private String packListNo;

	private Integer pageNo;

	private String productCode;

	private String marksOrDetail;

	private String quantity;

	private String netWeight;

	private String grossWeight;

	private String cubicWeight;

	private String detail;

	// Constructors

	/** default constructor */
	public PackingListItemDetail() {
		id = new PackingListItemDetailId();
	}
	
	public PackingListItemDetail(PackingListItemDetailId id) {
		this.id = id;
	}

	public PackingListItemDetail(PackingListItemDetailId id, String packListNo,
			Integer pageNo, String productCode, String marksOrDetail,
			String quantity, String netWeight, String grossWeight,
			String cubicWeight, String detail) {
		this.id = id;
		this.packListNo = packListNo;
		this.pageNo = pageNo;
		this.productCode = productCode;
		this.marksOrDetail = marksOrDetail;
		this.quantity = quantity;
		this.netWeight = netWeight;
		this.grossWeight = grossWeight;
		this.cubicWeight = cubicWeight;
		this.detail = detail;
	}
	public PackingListItemDetailId getId() {
		return id;
	}
	public void setId(PackingListItemDetailId id) {
		this.id = id;
	}

	public String getPackListNo() {
		return this.packListNo;
	}

	public void setPackListNo(String packListNo) {
		this.packListNo = packListNo;
	}

	public Integer getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getMarksOrDetail() {
		return this.marksOrDetail;
	}

	public void setMarksOrDetail(String marksOrDetail) {
		this.marksOrDetail = marksOrDetail;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getNetWeight() {
		return this.netWeight;
	}

	public void setNetWeight(String netWeight) {
		this.netWeight = netWeight;
	}

	public String getGrossWeight() {
		return this.grossWeight;
	}

	public void setGrossWeight(String grossWeight) {
		this.grossWeight = grossWeight;
	}

	public String getCubicWeight() {
		return cubicWeight;
	}
	public void setCubicWeight(String cubicWeight) {
		this.cubicWeight = cubicWeight;
	}
	public String getDetail() {
		return this.detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
