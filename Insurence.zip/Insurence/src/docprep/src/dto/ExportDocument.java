package docprep.src.dto;
import java.util.Date;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class ExportDocument extends ModelImpl implements java.io.Serializable {

	// Fields    

	private Long sysDocId;

	private String docId;

	private String siteId;

	private String userId;

	private Long parentId;

	private String docTypeCode;

	private Integer docTypeVersion;

	private String exporterReference;

	private String buyerName;

	private String invoiceNumber;

	private Date invoiceDate;

	private Integer status;

	private Date inceptionDate;

	private Date lastUpdateDate;
	
	private Integer formTemplateCode;

	private Integer printTemplateCode;

	private Integer sendToFreightForwarder;	
	
	private String edn;
	
	private String buyerReference; 

	
	// Constructors

	/** default constructor */
	public ExportDocument() {
	}

	/** minimal constructor */
	public ExportDocument(Long sysDocId, String docId, String siteId,
			String userId, Long parentId, String docTypeCode,
			Integer docTypeVersion, String exporterReference, String buyerName,
			String invoiceNumber, Date invoiceDate, Integer status,
			Date inceptionDate, Date lastUpdateDate, Integer formTemplateCode,
			Integer printTemplateCode) {
		this.sysDocId = sysDocId;
		this.docId = docId;
		this.siteId = siteId;
		this.userId = userId;
		this.parentId = parentId;
		this.docTypeCode = docTypeCode;
		this.docTypeVersion = docTypeVersion;
		this.exporterReference = exporterReference;
		this.buyerName = buyerName;
		this.invoiceNumber = invoiceNumber;
		this.invoiceDate = invoiceDate;
		this.status = status;
		this.inceptionDate = inceptionDate;
		this.lastUpdateDate = lastUpdateDate;
		this.formTemplateCode = formTemplateCode;
		this.printTemplateCode = printTemplateCode;
	}

	/** full constructor */
	public ExportDocument(Long sysDocId, String docId, String siteId,
			String userId, Long parentId, String docTypeCode,
			Integer docTypeVersion, 
			String exporterReference, String buyerName, String invoiceNumber,
			Date invoiceDate, Integer status, Date inceptionDate,
			Date lastUpdateDate, Integer formTemplateCode,
			Integer printTemplateCode, Integer sendToFreightForwarder,
			String edn, String buyerReference) {
		super();
		this.sysDocId = sysDocId;
		this.docId = docId;
		this.siteId = siteId;
		this.userId = userId;
		this.parentId = parentId;
		this.docTypeCode = docTypeCode;
		this.docTypeVersion = docTypeVersion;
		this.exporterReference = exporterReference;
		this.buyerName = buyerName;
		this.invoiceNumber = invoiceNumber;
		this.invoiceDate = invoiceDate;
		this.status = status;
		this.inceptionDate = inceptionDate;
		this.lastUpdateDate = lastUpdateDate;
		this.formTemplateCode = formTemplateCode;
		this.printTemplateCode = printTemplateCode;
		this.sendToFreightForwarder = sendToFreightForwarder;
		this.edn = edn;
		this.buyerReference = buyerReference;
	}
	
	// Property accessors
	public Long getSysDocId() {
		return this.sysDocId;
	}

	public void setSysDocId(Long sysDocId) {
		this.sysDocId = sysDocId;
	}

	public String getDocId() {
		return this.docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getParentId() {
		return this.parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getDocTypeCode() {
		return this.docTypeCode;
	}

	public void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public Integer getDocTypeVersion() {
		return this.docTypeVersion;
	}

	public void setDocTypeVersion(Integer docTypeVersion) {
		this.docTypeVersion = docTypeVersion;
	}

	public String getExporterReference() {
		return this.exporterReference;
	}

	public void setExporterReference(String exporterReference) {
		this.exporterReference = exporterReference;
	}

	public String getBuyerName() {
		return this.buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getInceptionDate() {
		return this.inceptionDate;
	}

	public void setInceptionDate(Date inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public Date getLastUpdateDate() {
		return this.lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Integer getFormTemplateCode() {
		return this.formTemplateCode;
	}

	public void setFormTemplateCode(Integer formTemplateCode) {
		this.formTemplateCode = formTemplateCode;
	}

	public Integer getPrintTemplateCode() {
		return this.printTemplateCode;
	}

	public void setPrintTemplateCode(Integer printTemplateCode) {
		this.printTemplateCode = printTemplateCode;
	}

	public Integer getSendToFreightForwarder() {
		return this.sendToFreightForwarder;
	}

	public void setSendToFreightForwarder(Integer sendToFreightForwarder) {
		this.sendToFreightForwarder = sendToFreightForwarder;
	}
	
	public String getBuyerReference() {
		return buyerReference;
	}
	public void setBuyerReference(String buyerReference) {
		this.buyerReference = buyerReference;
	}
	public String getEdn() {
		return edn;
	}
	public void setEdn(String edn) {
		this.edn = edn;
	}
	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
