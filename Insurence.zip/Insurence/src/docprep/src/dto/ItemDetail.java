package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class ItemDetail extends ModelImpl implements java.io.Serializable {

	private ItemDetailId id;

	private String productCode;

	private String description;

	private String quantity;

	private String unitPrice;

	private String hsCode;

	private String unitOfMeasure;

	private String countryOfOrigin;

	private String numberOfPackages;

	private String netCost;

	private String producer;

	private String prefCrit;

	private String totalPrice;

	private String containerNo;

	private String sealNo;

	public ItemDetail() {
	}

	public ItemDetail(ItemDetailId id) {
		this.id = id;
	}

	public ItemDetail(ItemDetailId id, String productCode,
			String description, String quantity, String unitPrice,
			String hsCode, String unitOfMeasure, String countryOfOrigin,
			String numberOfPackages, String netCost, String producer,
			String prefCrit, String totalPrice, String containerNo,
			String sealNo) {
		this.id = id;
		this.productCode = productCode;
		this.description = description;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
		this.hsCode = hsCode;
		this.unitOfMeasure = unitOfMeasure;
		this.countryOfOrigin = countryOfOrigin;
		this.numberOfPackages = numberOfPackages;
		this.netCost = netCost;
		this.producer = producer;
		this.prefCrit = prefCrit;
		this.totalPrice = totalPrice;
		this.containerNo = containerNo;
		this.sealNo = sealNo;
	}

	public ItemDetailId getId() {
		return this.id;
	}

	public void setId(ItemDetailId id) {
		this.id = id;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getHsCode() {
		return this.hsCode;
	}

	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}

	public String getUnitOfMeasure() {
		return this.unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getCountryOfOrigin() {
		return this.countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public String getNumberOfPackages() {
		return this.numberOfPackages;
	}

	public void setNumberOfPackages(String numberOfPackages) {
		this.numberOfPackages = numberOfPackages;
	}

	public String getNetCost() {
		return this.netCost;
	}

	public void setNetCost(String netCost) {
		this.netCost = netCost;
	}

	public String getProducer() {
		return this.producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public String getPrefCrit() {
		return this.prefCrit;
	}

	public void setPrefCrit(String prefCrit) {
		this.prefCrit = prefCrit;
	}

	public String getTotalPrice() {
		return this.totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getContainerNo() {
		return this.containerNo;
	}

	public void setContainerNo(String containerNo) {
		this.containerNo = containerNo;
	}

	public String getSealNo() {
		return this.sealNo;
	}

	public void setSealNo(String sealNo) {
		this.sealNo = sealNo;
	}
	
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
