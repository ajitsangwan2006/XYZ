package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class CreditNoteTO extends ModelImpl implements java.io.Serializable {
	private String siteId = null;

	private String userId = null;

	private String creditNoteNumber = null;

	private String creditDetail1 = null;

	private String creditDetail2 = null;

	private String creditDetail3 = null;

	private String creditDetail4 = null;

	private String creditDetail5 = null;

	private String creditDetail6 = null;

	private String creditDetail7 = null;

	private Integer multiplier = null;

	private Double totalCreditValue =null; 

	private String agentName = null;

	private String agentAddress1 = null;

	private String agentAddress2 = null;

	private String agentCity = null;
	
	private String agentState = null;

	private String agentCountry = null;

	private String internalLine1 = null;

	private String internalLine2 = null;

	private String internalLine3 = null;

	private String internalLine4 = null;

	private String issBKLC = null;

	private String authorizedSignatory = null;

	private String placeofIssue = null;

	private String dateofIssue = null;

	private String docDesc = null;
	
	private String signatoryCompanyName = null;
	
	private String clause1 = null;

    private String clause2 = null;

    private String clause3 = null;

    private String clause4 = null;

    private String clause5 = null;

    private String clause6 = null;

    private String clause7 = null;

    private String clause8 = null;

    private String clause9 = null;

	public String getAgentAddress1() {
		return agentAddress1;
	}

	public void setAgentAddress1(String agentAddress1) {
		this.agentAddress1 = agentAddress1;
	}

	public String getAgentAddress2() {
		return agentAddress2;
	}

	public void setAgentAddress2(String agentAddress2) {
		this.agentAddress2 = agentAddress2;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAuthorizedSignatory() {
		return authorizedSignatory;
	}

	public void setAuthorizedSignatory(String authorizedSignatory) {
		this.authorizedSignatory = authorizedSignatory;
	}

	public String getAgentCity() {
		return agentCity;
	}

	public void setAgentCity(String agentCity) {
		this.agentCity = agentCity;
	}

	public String getCreditDetail1() {
		return creditDetail1;
	}

	public void setCreditDetail1(String creditDetail1) {
		this.creditDetail1 = creditDetail1;
	}

	public String getCreditDetail2() {
		return creditDetail2;
	}

	public void setCreditDetail2(String creditDetail2) {
		this.creditDetail2 = creditDetail2;
	}

	public String getCreditDetail3() {
		return creditDetail3;
	}

	public void setCreditDetail3(String creditDetail3) {
		this.creditDetail3 = creditDetail3;
	}

	public String getCreditDetail4() {
		return creditDetail4;
	}

	public void setCreditDetail4(String creditDetail4) {
		this.creditDetail4 = creditDetail4;
	}

	public String getCreditDetail5() {
		return creditDetail5;
	}

	public void setCreditDetail5(String creditDetail5) {
		this.creditDetail5 = creditDetail5;
	}

	public String getCreditDetail6() {
		return creditDetail6;
	}

	public void setCreditDetail6(String creditDetail6) {
		this.creditDetail6 = creditDetail6;
	}

	public String getCreditDetail7() {
		return creditDetail7;
	}

	public void setCreditDetail7(String creditDetail7) {
		this.creditDetail7 = creditDetail7;
	}


	public Integer getMultiplier() {
		return multiplier;
	}

	public void setMultiplier(Integer multiplier) {
		this.multiplier = multiplier;
	}
	public String getCreditNoteNumber() {
		return creditNoteNumber;
	}

	public void setCreditNoteNumber(String creditNoteNumber) {
		this.creditNoteNumber = creditNoteNumber;
	}

	public String getDateofIssue() {
		return dateofIssue;
	}

	public void setDateofIssue(String dateofIssue) {
		this.dateofIssue = dateofIssue;
	}

	public String getDocDesc() {
		return docDesc;
	}

	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}

	public String getInternalLine1() {
		return internalLine1;
	}

	public void setInternalLine1(String internalLine1) {
		this.internalLine1 = internalLine1;
	}

	public String getInternalLine2() {
		return internalLine2;
	}

	public void setInternalLine2(String internalLine2) {
		this.internalLine2 = internalLine2;
	}

	public String getInternalLine3() {
		return internalLine3;
	}

	public void setInternalLine3(String internalLine3) {
		this.internalLine3 = internalLine3;
	}

	public String getInternalLine4() {
		return internalLine4;
	}

	public void setInternalLine4(String internalLine4) {
		this.internalLine4 = internalLine4;
	}

	public String getIssBKLC() {
		return issBKLC;
	}

	public void setIssBKLC(String issBKLC) {
		this.issBKLC = issBKLC;
	}



	public String getPlaceofIssue() {
		return placeofIssue;
	}

	public void setPlaceofIssue(String placeofIssue) {
		this.placeofIssue = placeofIssue;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	
	public Double getTotalCreditValue() {
		return totalCreditValue;
	}
	
	public void setTotalCreditValue(Double totalCreditValue) {
		this.totalCreditValue = totalCreditValue;
	}
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getSignatoryCompanyName() {
		return signatoryCompanyName;
	}
	
	public void setSignatoryCompanyName(String signatoryCompanyName) {
		this.signatoryCompanyName = signatoryCompanyName;
	}
	
	public String getAgentCountry() {
		return agentCountry;
	}
	public void setAgentCountry(String agentCountry) {
		this.agentCountry = agentCountry;
	}
	public String getAgentState() {
		return agentState;
	}
	public void setAgentState(String agentState) {
		this.agentState = agentState;
	}
	public String getClause1() {
		return clause1;
	}
	public void setClause1(String clause1) {
		this.clause1 = clause1;
	}
	public String getClause2() {
		return clause2;
	}
	public void setClause2(String clause2) {
		this.clause2 = clause2;
	}
	public String getClause3() {
		return clause3;
	}
	public void setClause3(String clause3) {
		this.clause3 = clause3;
	}
	public String getClause4() {
		return clause4;
	}
	public void setClause4(String clause4) {
		this.clause4 = clause4;
	}
	public String getClause5() {
		return clause5;
	}
	public void setClause5(String clause5) {
		this.clause5 = clause5;
	}
	public String getClause6() {
		return clause6;
	}
	public void setClause6(String clause6) {
		this.clause6 = clause6;
	}
	public String getClause7() {
		return clause7;
	}
	public void setClause7(String clause7) {
		this.clause7 = clause7;
	}
	public String getClause8() {
		return clause8;
	}
	public void setClause8(String clause8) {
		this.clause8 = clause8;
	}
	public String getClause9() {
		return clause9;
	}
	public void setClause9(String clause9) {
		this.clause9 = clause9;
	}
	 public void registerJavaScriptValidation() {
        validateNotNull("creditNoteNumber");
        validateNotNull("totalCreditValue");
        validateNotNull("multiplier");
        validateNumeric("totalCreditValue");
        validateInteger("multiplier");
        validateAlphaNumeric("clause1, clause2, clause3, clause4, clause5, clause6, clause7, clause8, clause9");
    }

	public ValidationErrors validate() {

        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }   
	
	}
}
