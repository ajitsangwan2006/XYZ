package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class PackageDetailId extends ModelImpl implements java.io.Serializable {

	private Long sysDocId;

	private Integer lineNumber;

	public PackageDetailId() {
	}

	
	public PackageDetailId(Long sysDocId, Integer lineNumber) {
		this.sysDocId = sysDocId;
		this.lineNumber = lineNumber;
	}

	
	public Long getSysDocId() {
		return this.sysDocId;
	}

	public void setSysDocId(Long sysDocId) {
		this.sysDocId = sysDocId;
	}

	public Integer getLineNumber() {
		return this.lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof PackageDetailId))
			return false;
		PackageDetailId castOther = (PackageDetailId) other;

		return (this.getSysDocId() == castOther.getSysDocId())
				&& (this.getLineNumber() == castOther.getLineNumber());
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (int) this.getSysDocId().longValue();
		result = 37 * result + this.getLineNumber().intValue();
		return result;
	}


	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
