package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class MasterDocument extends ModelImpl implements java.io.Serializable {
	
	public static final int STATUS_TRANSACTION_CLOSED = 0;
	public static final int STATUS_DOCUMENTATION_PRINTED = 1;
	public static final int STATUS_DOCUMENTATION_SENT = 2;
	public static final int STATUS_ECN_RECEIVED = 3;
	public static final int STATUS_EDN_RECEIVED = 4;
	public static final int STATUS_TRANSACTION_INITIATED = 5;
	public static final int STATUS_INVOICE_SENT = 6;
	public static final int STATUS_GOODS_PACKED = 7;
	public static final int STATUS_PAYMENT_RECEIVED = 8;
	public static final int STATUS_VESSEL_BOOKED = 9;
	public static final int STATUS_GOODS_SHIPPED = 10;
	
	
	private Long sysDocId;

	private String docId;
	
	private String docTypeCode;
	
	private Integer docStatus;
	
	private String exporterReference;

	private String buyerReference;

	private String shippingCo;

	private String advisingBKRef;

	private String exportPermitNo;

	private String agentReference;

	private String nameofShipping;

	private String edn;

	private String ednStatus;

	private String invoiceNumber;

	private String invoiceDate;

	private String invoiceValueUSD;

	private String exchangeRate;

	private String insuredValue;

	private String onBoardBLDate;

	private String numberofOriginal;

	private String numberofcopy;

	private String exporterName;

	private String exporterAbnNo;

	private String exporterStreetNo;

	private String exporterStreetName;

	private String exporterCity;

	private String exporterState;

	private String exporterCountry;

	private String agentName;

	private String agentStreetNo;

	private String agentStreetName;

	private String agentCity;

	private String agentState;

	private String agentCountry;

	private String buyerName;

	private String buyerStreetNo;

	private String buyerStreetName;

	private String buyerCity;

	private String buyerState;

	private String buyerCountry;

	private String consigneeName;

	private String consigneeStreetNo;

	private String consigneeStreetName;

	private String consigneeCity;

	private String consigneeState;

	private String consigneeCountry;

	private String manufacturerName;

	private String manufacturerStreetNo;

	private String manufacturerStreetName;

	private String manufacturerCity;

	private String manufacturerState;

	private String manufacturerCountry;

	private String freightStatus;

	private String frightcharge;

	private String totalWeight;

	private String freightPayableAt;

	private String countryofOrigin;

	private String countryOriginCode;

	private String countryofdestination;
	
	private String countryDestCode;

	private String dateofDeparture1;

	private String dateofDeparture2;
	
	private String finalDestCode;
	
	private String finalDestIsoCode;

	private String finalDestination1;

	private String finalDestination2;
	
	private String portofLoadingCode;
	
	private String portofLoadingIsoCode;

	private String portofLoading1;

	private String portofLoading2;
	
	private String portofDischargeCode;
	
	private String portofDischargeIsoCode;

	private String portofDischarge1;

	private String portofDischarge2;

	private String marineTerminal;

	private String modeOfTransport;

	private String vessel;

	private String voyageNumber;

	private String airlineCode;

	private String flightNo;

	private String railCarNumber;

	private String bookingNumber;

	private String carrierCode;

	private String carrierName;

	private String cargoType;

	private String totalNumberofPackages;

	private String totalNumberofContainers;

	private String dockContBase;

	private String producedAt;

	private String hsts;

	private String receivingDate;

	private String placeofReceipt;

	private String qtyDescription;

	private String priceDescription;

	private String additionalChargesDesc1;

	private String additionalChargesDesc2;

	private String additionalChargesDesc3;

	private String additionalChargesDesc4;

	private String additionalCharges1;

	private String additionalCharges2;

	private String additionalCharges3;

	private String additionalCharges4;

	private String invoiceSubtotal;

	private String invoiceTotal;

	private String currencyCode;

	private String comments;

	private String exporterDeclaration1;

	private String exporterDeclaration2;

	private String exporterDeclaration3;

	private String exporterDeclaration4;

	private String exporterDeclaration5;

	private String exporterDeclaration6;

	private String exporterDeclaration7;

	private String issueDate;

	private String issuePlace;

	private String signatoryCompanyName;

	private String nameofAuthorizedSignatory;

	private String finePrintClauseId;

	private String finePrintClauseTitle;

	private String finePrintLine1;

	private String finePrintLine2;

	private String finePrintLine3;

	private String finePrintLine4;

	private String finePrintLine5;

	private String finePrintLine6;

	private String finePrintLine7;

	private String clause1;

	private String clause2;

	private String clause3;

	private String clause4;

	private String clause5;

	private String clause6;

	private String clause7;

	private String clause8;

	private String clause9;
	
	private String terms;

	private String termsLine1;

	private String termsLine2;

	private String termsLine3;

	private String termsLine4;

	private String termsLine5;
	
	private String termsLine6;
	
	private String exportLicenceNo;
	
	private String dpiPermitNo;
	
	private String establishmentNo;
	
	private String fecNo;
	
	private String special1;
	
	private String special2;
	
	private String special3;
	
	private String special4;
	
	private String special5;
	
	private String originalOrCopy;
	
	private ItemDetail[] itemDetails;

	private PackageDetail[] packageDetails;
	
	private String statusDesc;

	
	public MasterDocument() {
	}

	
	public MasterDocument(Long sysDocId) {
		this.sysDocId = sysDocId;
	}
	
	
	public Long getSysDocId() {
		return this.sysDocId;
	}
	
	public String getDocId() {
		return docId;
	}
	
	public void setDocId(String docId) {
		this.docId = docId;
	}
	
	public Integer getDocStatus() {
		  return docStatus;
	}
	
	public void setDocStatus(Integer docStatus) {
		this.docStatus = docStatus;
	}
	
	public String getStatusDesc() {
		return getStatus(this.docStatus.intValue());
	}

	public static String getStatus(int docStatus) {
	 	if(docStatus == STATUS_TRANSACTION_CLOSED){
            return "Transaction Closed";
        }else if(docStatus==STATUS_DOCUMENTATION_PRINTED){
            return "Documentation Printed";
        }else if(docStatus == STATUS_DOCUMENTATION_SENT){
            return "Documentation Sent";
        }else if(docStatus == STATUS_ECN_RECEIVED){
            return "ECN Received";
        }else if(docStatus == STATUS_EDN_RECEIVED){
            return "EDN Received";
        }else if(docStatus == STATUS_TRANSACTION_INITIATED){
            return "Transaction Initiated";
        }else if(docStatus == STATUS_INVOICE_SENT){
            return "Invoice Sent";
        }else if(docStatus == STATUS_GOODS_PACKED){
            return "Goods Packed";
        }else if(docStatus == STATUS_PAYMENT_RECEIVED){
            return "Payment Received";
        }else if(docStatus == STATUS_VESSEL_BOOKED){
            return "Vessel Booked";
        }else if(docStatus == STATUS_GOODS_SHIPPED){
            return "Goods Shipped";
        }
        return  String.valueOf(docStatus);
    }

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	
	public String getDocTypeCode() {
		return docTypeCode;
	}
	
	public void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}
	
	public void setSysDocId(Long sysDocId) {
		this.sysDocId = sysDocId;
	}

	public String getExporterReference() {
		return this.exporterReference;
	}

	public void setExporterReference(String exporterReference) {
		this.exporterReference = exporterReference;
	}

	public String getBuyerReference() {
		return this.buyerReference;
	}

	public void setBuyerReference(String buyerReference) {
		this.buyerReference = buyerReference;
	}

	public String getShippingCo() {
		return this.shippingCo;
	}

	public void setShippingCo(String shippingCo) {
		this.shippingCo = shippingCo;
	}
	
	public String getAdvisingBKRef() {
		return advisingBKRef;
	}
	
	public void setAdvisingBKRef(String advisingBKRef) {
		this.advisingBKRef = advisingBKRef;
	}
	
	public String getExportPermitNo() {
		return this.exportPermitNo;
	}

	public void setExportPermitNo(String exportPermitNo) {
		this.exportPermitNo = exportPermitNo;
	}

	public String getAgentReference() {
		return this.agentReference;
	}

	public void setAgentReference(String agentReference) {
		this.agentReference = agentReference;
	}

	public String getNameofShipping() {
		return this.nameofShipping;
	}

	public void setNameofShipping(String nameofShipping) {
		this.nameofShipping = nameofShipping;
	}

	public String getEdn() {
		return this.edn;
	}

	public void setEdn(String edn) {
		this.edn = edn;
	}

	public String getEdnStatus() {
		return this.ednStatus;
	}

	public void setEdnStatus(String ednStatus) {
		this.ednStatus = ednStatus;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}	
	
	public String getInvoiceValueUSD() {
		return invoiceValueUSD;
	}
	
	public void setInvoiceValueUSD(String invoiceValueUSD) {
		this.invoiceValueUSD = invoiceValueUSD;
	}
	
	public String getExchangeRate() {
		return this.exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getInsuredValue() {
		return this.insuredValue;
	}

	public void setInsuredValue(String insuredValue) {
		this.insuredValue = insuredValue;
	}

	
	public String getNumberofOriginal() {
		return this.numberofOriginal;
	}

	public void setNumberofOriginal(String numberofOriginal) {
		this.numberofOriginal = numberofOriginal;
	}

	public String getNumberofcopy() {
		return this.numberofcopy;
	}

	public void setNumberofcopy(String numberofcopy) {
		this.numberofcopy = numberofcopy;
	}

	public String getExporterName() {
		return this.exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	public String getExporterAbnNo() {
		return this.exporterAbnNo;
	}

	public void setExporterAbnNo(String exporterAbnNo) {
		this.exporterAbnNo = exporterAbnNo;
	}

	public String getExporterCity() {
		return this.exporterCity;
	}

	public void setExporterCity(String exporterCity) {
		this.exporterCity = exporterCity;
	}

	public String getExporterState() {
		return this.exporterState;
	}

	public void setExporterState(String exporterState) {
		this.exporterState = exporterState;
	}

	public String getExporterCountry() {
		return this.exporterCountry;
	}

	public void setExporterCountry(String exporterCountry) {
		this.exporterCountry = exporterCountry;
	}

	public String getAgentName() {
		return this.agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgentCity() {
		return this.agentCity;
	}

	public void setAgentCity(String agentCity) {
		this.agentCity = agentCity;
	}

	public String getAgentState() {
		return this.agentState;
	}

	public void setAgentState(String agentState) {
		this.agentState = agentState;
	}

	public String getAgentCountry() {
		return this.agentCountry;
	}

	public void setAgentCountry(String agentCountry) {
		this.agentCountry = agentCountry;
	}

	public String getBuyerName() {
		return this.buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getBuyerCity() {
		return this.buyerCity;
	}

	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	public String getBuyerState() {
		return this.buyerState;
	}

	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	public String getBuyerCountry() {
		return this.buyerCountry;
	}

	public void setBuyerCountry(String buyerCountry) {
		this.buyerCountry = buyerCountry;
	}

	public String getConsigneeName() {
		return this.consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	public String getConsigneeCity() {
		return this.consigneeCity;
	}

	public void setConsigneeCity(String consigneeCity) {
		this.consigneeCity = consigneeCity;
	}

	public String getConsigneeState() {
		return this.consigneeState;
	}

	public void setConsigneeState(String consigneeState) {
		this.consigneeState = consigneeState;
	}

	public String getConsigneeCountry() {
		return this.consigneeCountry;
	}

	public void setConsigneeCountry(String consigneeCountry) {
		this.consigneeCountry = consigneeCountry;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	
	public String getManufacturerCity() {
		return this.manufacturerCity;
	}

	public void setManufacturerCity(String manufacturerCity) {
		this.manufacturerCity = manufacturerCity;
	}

	public String getManufacturerState() {
		return this.manufacturerState;
	}

	public void setManufacturerState(String manufacturerState) {
		this.manufacturerState = manufacturerState;
	}

	public String getManufacturerCountry() {
		return this.manufacturerCountry;
	}

	public void setManufacturerCountry(String manufacturerCountry) {
		this.manufacturerCountry = manufacturerCountry;
	}
	public String getAgentStreetName() {
		return agentStreetName;
	}
	public void setAgentStreetName(String agentStreetName) {
		this.agentStreetName = agentStreetName;
	}
	public String getAgentStreetNo() {
		return agentStreetNo;
	}
	public void setAgentStreetNo(String agentStreetNo) {
		this.agentStreetNo = agentStreetNo;
	}
	public String getBuyerStreetName() {
		return buyerStreetName;
	}
	public void setBuyerStreetName(String buyerStreetName) {
		this.buyerStreetName = buyerStreetName;
	}
	public String getBuyerStreetNo() {
		return buyerStreetNo;
	}
	public void setBuyerStreetNo(String buyerStreetNo) {
		this.buyerStreetNo = buyerStreetNo;
	}
	public String getConsigneeStreetName() {
		return consigneeStreetName;
	}
	public void setConsigneeStreetName(String consigneeStreetName) {
		this.consigneeStreetName = consigneeStreetName;
	}
	public String getConsigneeStreetNo() {
		return consigneeStreetNo;
	}
	public void setConsigneeStreetNo(String consigneeStreetNo) {
		this.consigneeStreetNo = consigneeStreetNo;
	}
	public String getExporterStreetName() {
		return exporterStreetName;
	}
	public void setExporterStreetName(String exporterStreetName) {
		this.exporterStreetName = exporterStreetName;
	}
	public String getExporterStreetNo() {
		return exporterStreetNo;
	}
	public void setExporterStreetNo(String exporterStreetNo) {
		this.exporterStreetNo = exporterStreetNo;
	}
	public String getManufacturerStreetName() {
		return manufacturerStreetName;
	}
	public void setManufacturerStreetName(String manufacturerStreetName) {
		this.manufacturerStreetName = manufacturerStreetName;
	}
	public String getManufacturerStreetNo() {
		return manufacturerStreetNo;
	}
	public void setManufacturerStreetNo(String manufacturerStreetNo) {
		this.manufacturerStreetNo = manufacturerStreetNo;
	}
	public String getFreightStatus() {
		return this.freightStatus;
	}

	public void setFreightStatus(String freightStatus) {
		this.freightStatus = freightStatus;
	}

	public String getFrightcharge() {
		return this.frightcharge;
	}

	public void setFrightcharge(String frightcharge) {
		this.frightcharge = frightcharge;
	}

	public String getTotalWeight() {
		return this.totalWeight;
	}

	public void setTotalWeight(String totalWeight) {
		this.totalWeight = totalWeight;
	}

	public String getFreightPayableAt() {
		return this.freightPayableAt;
	}

	public void setFreightPayableAt(String freightPayableAt) {
		this.freightPayableAt = freightPayableAt;
	}

	public String getCountryofOrigin() {
		return this.countryofOrigin;
	}

	public void setCountryofOrigin(String countryofOrigin) {
		this.countryofOrigin = countryofOrigin;
	}

	public String getCountryOriginCode() {
		return this.countryOriginCode;
	}

	public void setCountryOriginCode(String countryOriginCode) {
		this.countryOriginCode = countryOriginCode;
	}

	public String getCountryofdestination() {
		return this.countryofdestination;
	}

	public void setCountryofdestination(String countryofdestination) {
		this.countryofdestination = countryofdestination;
	}

	public String getCountryDestCode() {
		return this.countryDestCode;
	}

	public void setCountryDestCode(String countryDestCode) {
		this.countryDestCode = countryDestCode;
	}

	public String getDateofDeparture1() {
		return this.dateofDeparture1;
	}

	public void setDateofDeparture1(String dateofDeparture1) {
		this.dateofDeparture1 = dateofDeparture1;
	}

	public String getDateofDeparture2() {
		return this.dateofDeparture2;
	}

	public void setDateofDeparture2(String dateofDeparture2) {
		this.dateofDeparture2 = dateofDeparture2;
	}

	public String getFinalDestination1() {
		return this.finalDestination1;
	}

	public void setFinalDestination1(String finalDestination1) {
		this.finalDestination1 = finalDestination1;
	}

	public String getFinalDestination2() {
		return this.finalDestination2;
	}

	public void setFinalDestination2(String finalDestination2) {
		this.finalDestination2 = finalDestination2;
	}

	public String getPortofLoading1() {
		return this.portofLoading1;
	}

	public void setPortofLoading1(String portofLoading1) {
		this.portofLoading1 = portofLoading1;
	}

	public String getPortofLoading2() {
		return this.portofLoading2;
	}

	public void setPortofLoading2(String portofLoading2) {
		this.portofLoading2 = portofLoading2;
	}

	public String getPortofDischarge1() {
		return this.portofDischarge1;
	}

	public void setPortofDischarge1(String portofDischarge1) {
		this.portofDischarge1 = portofDischarge1;
	}

	public String getPortofDischarge2() {
		return this.portofDischarge2;
	}

	public void setPortofDischarge2(String portofDischarge2) {
		this.portofDischarge2 = portofDischarge2;
	}

	public String getMarineTerminal() {
		return this.marineTerminal;
	}

	public void setMarineTerminal(String marineTerminal) {
		this.marineTerminal = marineTerminal;
	}

	public String getModeOfTransport() {
		return this.modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}

	public String getVessel() {
		return this.vessel;
	}

	public void setVessel(String vessel) {
		this.vessel = vessel;
	}

	public String getVoyageNumber() {
		return this.voyageNumber;
	}

	public void setVoyageNumber(String voyageNumber) {
		this.voyageNumber = voyageNumber;
	}

	public String getAirlineCode() {
		return this.airlineCode;
	}

	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	public String getFlightNo() {
		return this.flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getRailCarNumber() {
		return this.railCarNumber;
	}

	public void setRailCarNumber(String railCarNumber) {
		this.railCarNumber = railCarNumber;
	}

	public String getBookingNumber() {
		return this.bookingNumber;
	}

	public void setBookingNumber(String bookingNumber) {
		this.bookingNumber = bookingNumber;
	}

	public String getCarrierCode() {
		return this.carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getCargoType() {
		return this.cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public String getTotalNumberofPackages() {
		return this.totalNumberofPackages;
	}

	public void setTotalNumberofPackages(String totalNumberofPackages) {
		this.totalNumberofPackages = totalNumberofPackages;
	}

	public String getTotalNumberofContainers() {
		return this.totalNumberofContainers;
	}

	public void setTotalNumberofContainers(String totalNumberofContainers) {
		this.totalNumberofContainers = totalNumberofContainers;
	}

	public String getDockContBase() {
		return this.dockContBase;
	}

	public void setDockContBase(String dockContBase) {
		this.dockContBase = dockContBase;
	}

	public String getProducedAt() {
		return this.producedAt;
	}

	public void setProducedAt(String producedAt) {
		this.producedAt = producedAt;
	}

	public String getHsts() {
		return this.hsts;
	}

	public void setHsts(String hsts) {
		this.hsts = hsts;
	}

	public String getReceivingDate() {
		return this.receivingDate;
	}

	public void setReceivingDate(String receivingDate) {
		this.receivingDate = receivingDate;
	}

	public String getPlaceofReceipt() {
		return this.placeofReceipt;
	}

	public void setPlaceofReceipt(String placeofReceipt) {
		this.placeofReceipt = placeofReceipt;
	}

	public String getQtyDescription() {
		return this.qtyDescription;
	}

	public void setQtyDescription(String qtyDescription) {
		this.qtyDescription = qtyDescription;
	}

	public String getPriceDescription() {
		return this.priceDescription;
	}

	public void setPriceDescription(String priceDescription) {
		this.priceDescription = priceDescription;
	}

	public String getAdditionalChargesDesc1() {
		return this.additionalChargesDesc1;
	}

	public void setAdditionalChargesDesc1(String additionalChargesDesc1) {
		this.additionalChargesDesc1 = additionalChargesDesc1;
	}

	public String getAdditionalChargesDesc2() {
		return this.additionalChargesDesc2;
	}

	public void setAdditionalChargesDesc2(String additionalChargesDesc2) {
		this.additionalChargesDesc2 = additionalChargesDesc2;
	}

	public String getAdditionalChargesDesc3() {
		return this.additionalChargesDesc3;
	}

	public void setAdditionalChargesDesc3(String additionalChargesDesc3) {
		this.additionalChargesDesc3 = additionalChargesDesc3;
	}

	public String getAdditionalChargesDesc4() {
		return this.additionalChargesDesc4;
	}

	public void setAdditionalChargesDesc4(String additionalChargesDesc4) {
		this.additionalChargesDesc4 = additionalChargesDesc4;
	}

	public String getAdditionalCharges1() {
		return this.additionalCharges1;
	}

	public void setAdditionalCharges1(String additionalCharges1) {
		this.additionalCharges1 = additionalCharges1;
	}

	public String getAdditionalCharges2() {
		return this.additionalCharges2;
	}

	public void setAdditionalCharges2(String additionalCharges2) {
		this.additionalCharges2 = additionalCharges2;
	}

	public String getAdditionalCharges3() {
		return this.additionalCharges3;
	}

	public void setAdditionalCharges3(String additionalCharges3) {
		this.additionalCharges3 = additionalCharges3;
	}

	public String getAdditionalCharges4() {
		return this.additionalCharges4;
	}

	public void setAdditionalCharges4(String additionalCharges4) {
		this.additionalCharges4 = additionalCharges4;
	}

	public String getInvoiceSubtotal() {
		return this.invoiceSubtotal;
	}

	public void setInvoiceSubtotal(String invoiceSubtotal) {
		this.invoiceSubtotal = invoiceSubtotal;
	}

	public String getInvoiceTotal() {
		return this.invoiceTotal;
	}

	public void setInvoiceTotal(String invoiceTotal) {
		this.invoiceTotal = invoiceTotal;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getExporterDeclaration1() {
		return this.exporterDeclaration1;
	}

	public void setExporterDeclaration1(String exporterDeclaration1) {
		this.exporterDeclaration1 = exporterDeclaration1;
	}

	public String getExporterDeclaration2() {
		return this.exporterDeclaration2;
	}

	public void setExporterDeclaration2(String exporterDeclaration2) {
		this.exporterDeclaration2 = exporterDeclaration2;
	}

	public String getExporterDeclaration3() {
		return this.exporterDeclaration3;
	}

	public void setExporterDeclaration3(String exporterDeclaration3) {
		this.exporterDeclaration3 = exporterDeclaration3;
	}

	public String getExporterDeclaration4() {
		return this.exporterDeclaration4;
	}

	public void setExporterDeclaration4(String exporterDeclaration4) {
		this.exporterDeclaration4 = exporterDeclaration4;
	}

	public String getExporterDeclaration5() {
		return this.exporterDeclaration5;
	}

	public void setExporterDeclaration5(String exporterDeclaration5) {
		this.exporterDeclaration5 = exporterDeclaration5;
	}

	public String getExporterDeclaration6() {
		return this.exporterDeclaration6;
	}

	public void setExporterDeclaration6(String exporterDeclaration6) {
		this.exporterDeclaration6 = exporterDeclaration6;
	}

	public String getExporterDeclaration7() {
		return this.exporterDeclaration7;
	}

	public void setExporterDeclaration7(String exporterDeclaration7) {
		this.exporterDeclaration7 = exporterDeclaration7;
	}

	public String getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuePlace() {
		return this.issuePlace;
	}

	public void setIssuePlace(String issuePlace) {
		this.issuePlace = issuePlace;
	}

	public String getSignatoryCompanyName() {
		return this.signatoryCompanyName;
	}

	public void setSignatoryCompanyName(String signatoryCompanyName) {
		this.signatoryCompanyName = signatoryCompanyName;
	}

	public String getNameofAuthorizedSignatory() {
		return this.nameofAuthorizedSignatory;
	}

	public void setNameofAuthorizedSignatory(String nameofAuthorizedSignatory) {
		this.nameofAuthorizedSignatory = nameofAuthorizedSignatory;
	}

	public String getFinePrintClauseId() {
		return this.finePrintClauseId;
	}

	public void setFinePrintClauseId(String finePrintClauseId) {
		this.finePrintClauseId = finePrintClauseId;
	}

	public String getFinePrintClauseTitle() {
		return this.finePrintClauseTitle;
	}

	public void setFinePrintClauseTitle(String finePrintClauseTitle) {
		this.finePrintClauseTitle = finePrintClauseTitle;
	}

	public String getFinePrintLine1() {
		return this.finePrintLine1;
	}

	public void setFinePrintLine1(String finePrintLine1) {
		this.finePrintLine1 = finePrintLine1;
	}

	public String getFinePrintLine2() {
		return this.finePrintLine2;
	}

	public void setFinePrintLine2(String finePrintLine2) {
		this.finePrintLine2 = finePrintLine2;
	}

	public String getFinePrintLine3() {
		return this.finePrintLine3;
	}

	public void setFinePrintLine3(String finePrintLine3) {
		this.finePrintLine3 = finePrintLine3;
	}

	public String getFinePrintLine4() {
		return this.finePrintLine4;
	}

	public void setFinePrintLine4(String finePrintLine4) {
		this.finePrintLine4 = finePrintLine4;
	}

	public String getFinePrintLine5() {
		return this.finePrintLine5;
	}

	public void setFinePrintLine5(String finePrintLine5) {
		this.finePrintLine5 = finePrintLine5;
	}

	public String getFinePrintLine6() {
		return this.finePrintLine6;
	}

	public void setFinePrintLine6(String finePrintLine6) {
		this.finePrintLine6 = finePrintLine6;
	}

	public String getFinePrintLine7() {
		return this.finePrintLine7;
	}

	public void setFinePrintLine7(String finePrintLine7) {
		this.finePrintLine7 = finePrintLine7;
	}

	public String getClause1() {
		return this.clause1;
	}

	public void setClause1(String clause1) {
		this.clause1 = clause1;
	}

	public String getClause2() {
		return this.clause2;
	}

	public void setClause2(String clause2) {
		this.clause2 = clause2;
	}

	public String getClause3() {
		return this.clause3;
	}

	public void setClause3(String clause3) {
		this.clause3 = clause3;
	}

	public String getClause4() {
		return this.clause4;
	}

	public void setClause4(String clause4) {
		this.clause4 = clause4;
	}

	public String getClause5() {
		return this.clause5;
	}

	public void setClause5(String clause5) {
		this.clause5 = clause5;
	}

	public String getClause6() {
		return this.clause6;
	}

	public void setClause6(String clause6) {
		this.clause6 = clause6;
	}

	public String getClause7() {
		return this.clause7;
	}

	public void setClause7(String clause7) {
		this.clause7 = clause7;
	}

	public String getClause8() {
		return this.clause8;
	}

	public void setClause8(String clause8) {
		this.clause8 = clause8;
	}

	public String getClause9() {
		return this.clause9;
	}

	public void setClause9(String clause9) {
		this.clause9 = clause9;
	}

	public String getTermsLine1() {
		return this.termsLine1;
	}

	public void setTermsLine1(String termsLine1) {
		this.termsLine1 = termsLine1;
	}

	public String getTermsLine2() {
		return this.termsLine2;
	}

	public void setTermsLine2(String termsLine2) {
		this.termsLine2 = termsLine2;
	}

	public String getTermsLine3() {
		return this.termsLine3;
	}

	public void setTermsLine3(String termsLine3) {
		this.termsLine3 = termsLine3;
	}

	public String getTermsLine4() {
		return this.termsLine4;
	}

	public void setTermsLine4(String termsLine4) {
		this.termsLine4 = termsLine4;
	}

	public String getTermsLine5() {
		return this.termsLine5;
	}

	public void setTermsLine5(String termsLine5) {
		this.termsLine5 = termsLine5;
	}
	
	public ItemDetail[] getItemDetails() {
		return itemDetails;
	}
	
	public void setItemDetails(ItemDetail[] itemDetails) {
		this.itemDetails = itemDetails;
	}
	
	public PackageDetail[] getPackageDetails() {
		return packageDetails;
	}
	
	public void setPackageDetails(PackageDetail[] packageDetails) {
		this.packageDetails = packageDetails;
	}
	
	public String getOriginalOrCopy() {
		return originalOrCopy;
	}
	
	public void setOriginalOrCopy(String originalOrCopy) {
		this.originalOrCopy = originalOrCopy;
	}
	
	public String getTermsLine6() {
		return termsLine6;
	}
	
	public void setTermsLine6(String termsLine6) {
		this.termsLine6 = termsLine6;
	}
	
	public String getDpiPermitNo() {
		return dpiPermitNo;
	}
	
	public void setDpiPermitNo(String dpiPermitNo) {
		this.dpiPermitNo = dpiPermitNo;
	}
	
	public String getEstablishmentNo() {
		return establishmentNo;
	}
	
	public void setEstablishmentNo(String establishmentNo) {
		this.establishmentNo = establishmentNo;
	}
	
	public String getExportLicenceNo() {
		return exportLicenceNo;
	}
	
	public void setExportLicenceNo(String exportLicenceNo) {
		this.exportLicenceNo = exportLicenceNo;
	}
	
	public String getFecNo() {
		return fecNo;
	}
	
	public void setFecNo(String fecNo) {
		this.fecNo = fecNo;
	}
	
	public String getSpecial1() {
		return special1;
	}
	
	public void setSpecial1(String special1) {
		this.special1 = special1;
	}
	
	public String getSpecial2() {
		return special2;
	}
	
	public void setSpecial2(String special2) {
		this.special2 = special2;
	}
	
	public String getSpecial3() {
		return special3;
	}
	
	public void setSpecial3(String special3) {
		this.special3 = special3;
	}
	
	public String getSpecial4() {
		return special4;
	}
	
	public void setSpecial4(String special4) {
		this.special4 = special4;
	}
	
	public String getSpecial5() {
		return special5;
	}
	
	public void setSpecial5(String special5) {
		this.special5 = special5;
	}
	
	public String getOnBoardBLDate() {
		return onBoardBLDate;
	}
	public void setOnBoardBLDate(String onBoardBLDate) {
		this.onBoardBLDate = onBoardBLDate;
	}
	
	public String getFinalDestCode() {
		return finalDestCode;
	}
	public void setFinalDestCode(String finalDestCode) {
		this.finalDestCode = finalDestCode;
	}
	public String getPortofDischargeCode() {
		return portofDischargeCode;
	}
	public void setPortofDischargeCode(String portofDischargeCode) {
		this.portofDischargeCode = portofDischargeCode;
	}
	public String getPortofLoadingCode() {
		return portofLoadingCode;
	}
	public void setPortofLoadingCode(String portofLoadingCode) {
		this.portofLoadingCode = portofLoadingCode;
	}
	public String getPortofDischargeIsoCode() {
		return portofDischargeIsoCode;
	}
	public void setPortofDischargeIsoCode(String portofDischargeIsoCode) {
		this.portofDischargeIsoCode = portofDischargeIsoCode;
	}
	public String getPortofLoadingIsoCode() {
		return portofLoadingIsoCode;
	}
	public void setPortofLoadingIsoCode(String portofLoadingIsoCode) {
		this.portofLoadingIsoCode = portofLoadingIsoCode;
	}
	
	public String getFinalDestIsoCode() {
		return finalDestIsoCode;
	}
	public void setFinalDestIsoCode(String finalDestIsoCode) {
		this.finalDestIsoCode = finalDestIsoCode;
	}
	public String getTerms() {
		return terms;
	}
	public void setTerms(String terms) {
		this.terms = terms;
	}
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}
}
