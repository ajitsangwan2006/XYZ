package docprep.src.dto;

import dev.zing.framework.services.validation.ValidationErrors;

public class ForwardingList extends Body {

    private Long sysDocId;

    private String valueForCustoms;
    
    private Boolean hhFlag;
    
    private Boolean hpFlag;
    
    private Boolean ppFlag;
    
    private Boolean phFlag;
    
    private Boolean lclLclFlag;
    
    private Boolean fclFclFlag;
    
    private Boolean fclLclFlag;
    
    private Boolean lclFclFlag;
    
    private Boolean breakBulkFlag;
    
    private Boolean blShippingCompanyFlag;
    
    private Boolean blShipperFlag;

    public ForwardingList() {
    }

    public Boolean getBlShipperFlag() {
        return blShipperFlag;
    }
    
    public void setBlShipperFlag(Boolean blShipperFlag) {
        this.blShipperFlag = blShipperFlag;
    }
    
    public Boolean getBlShippingCompanyFlag() {
        return blShippingCompanyFlag;
    }
    
    public void setBlShippingCompanyFlag(Boolean blShippingCompanyFlag) {
        this.blShippingCompanyFlag = blShippingCompanyFlag;
    }
    
    public Boolean getBreakBulkFlag() {
        return breakBulkFlag;
    }
    
    public void setBreakBulkFlag(Boolean breakBulkFlag) {
        this.breakBulkFlag = breakBulkFlag;
    }
    
    public Boolean getFclFclFlag() {
        return fclFclFlag;
    }
    
    public void setFclFclFlag(Boolean fclFclFlag) {
        this.fclFclFlag = fclFclFlag;
    }
    
    public Boolean getFclLclFlag() {
        return fclLclFlag;
    }
    
    public void setFclLclFlag(Boolean fclLclFlag) {
        this.fclLclFlag = fclLclFlag;
    }
    
    public Boolean getHhFlag() {
        return hhFlag;
    }
    public void setHhFlag(Boolean hhFlag) {
        this.hhFlag = hhFlag;
    }
    
    public Boolean getHpFlag() {
        return hpFlag;
    }
    
    public void setHpFlag(Boolean hpFlag) {
        this.hpFlag = hpFlag;
    }
    
    public Boolean getLclFclFlag() {
        return lclFclFlag;
    }
    
    public void setLclFclFlag(Boolean lclFclFlag) {
        this.lclFclFlag = lclFclFlag;
    }
    
    public Boolean getLclLclFlag() {
        return lclLclFlag;
    }
    
    public void setLclLclFlag(Boolean lclLclFlag) {
        this.lclLclFlag = lclLclFlag;
    }
    
    public Boolean getPhFlag() {
        return phFlag;
    }
    
    public void setPhFlag(Boolean phFlag) {
        this.phFlag = phFlag;
    }
    
    public Boolean getPpFlag() {
        return ppFlag;
    }
    
    public void setPpFlag(Boolean ppFlag) {
        this.ppFlag = ppFlag;
    }
    
    public Long getSysDocId() {
        return sysDocId;
    }
    
    public void setSysDocId(Long sysDocId) {
        this.sysDocId = sysDocId;
    }
    
    public String getValueForCustoms() {
        return valueForCustoms;
    }
    
    public void setValueForCustoms(String valueForCustoms) {
        this.valueForCustoms = valueForCustoms;
    }
    
    public ValidationErrors validate() {
        return null;
    }

}
