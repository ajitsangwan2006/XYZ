package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class ReportCriteriaId extends ModelImpl implements java.io.Serializable {

	// Fields    

	private String siteId;

	private String userId;

	private String reportId;

	// Constructors

	/** default constructor */
	public ReportCriteriaId() {
	}

	/** full constructor */
	public ReportCriteriaId(String siteId, String userId, String reportId) {
		this.siteId = siteId;
		this.userId = userId;
		this.reportId = reportId;
	}

	// Property accessors
	public String getSiteId() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getReportId() {
		return this.reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof ReportCriteriaId))
			return false;
		ReportCriteriaId castOther = (ReportCriteriaId) other;

		return ((this.getSiteId() == castOther.getSiteId()) || (this
				.getSiteId() != null
				&& castOther.getSiteId() != null && this.getSiteId().equals(
				castOther.getSiteId())))
				&& ((this.getUserId() == castOther.getUserId()) || (this
						.getUserId() != null
						&& castOther.getUserId() != null && this.getUserId()
						.equals(castOther.getUserId())))
				&& ((this.getReportId() == castOther.getReportId()) || (this
						.getReportId() != null
						&& castOther.getReportId() != null && this
						.getReportId().equals(castOther.getReportId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getSiteId() == null ? 0 : this.getSiteId().hashCode());
		result = 37 * result
				+ (getUserId() == null ? 0 : this.getUserId().hashCode());
		result = 37 * result
				+ (getReportId() == null ? 0 : this.getReportId().hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
