package docprep.src.dto;

import java.io.Serializable;
import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;
import dev.zing.framework.util.ValidationUtils;

public class UserReportTO extends ModelImpl implements Serializable {

    private String siteId;

    private String userId;

    private Long sysDocId;

    private String userName;

    private String docTypeCode;

    private String emailId;

    private String status;

    private String createDoc;

    private String userType;

    private String msg;

  
    public String getCreateDoc() {
        return createDoc;
    }

    public void setCreateDoc(String createDoc) {
        this.createDoc = createDoc;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

	public String getDocTypeCode() {
		return docTypeCode;
	}
	public void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public Long getSysDocId() {
		return sysDocId;
	}
	public void setSysDocId(Long sysDocId) {
		this.sysDocId = sysDocId;
	}
    public void registerJavaScriptValidation() {
        validateNotNull("emailId");
        validateEmail("emailId");
        validateNotNull("msg");
    }

    public ValidationErrors validate() {
        ValidationErrors errors = new ValidationErrors();
        ValidationUtils validationUtil = ValidationUtils.getInstance();
        validationUtil.trimProperties(this);
        validationUtil.required(this, "emailId", errors);
        if (errors.getValidationErrors().size() == 0) {
            return null;
        } else {
            return errors;
        }
    }

}