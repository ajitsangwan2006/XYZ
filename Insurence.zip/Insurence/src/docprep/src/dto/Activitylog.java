package docprep.src.dto;

import java.util.Date;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public class Activitylog extends ModelImpl implements java.io.Serializable {

    private int activityId;

    private Date activityDate;

    private String activityType;

    private String activityDesc;

    private String ipaddress;    

    private String siteId;

    private String userId;

    // Constructors

    /** default constructor */
    public Activitylog() {
        
    }

    /** full constructor */
    public Activitylog(int activityId, Date activityDate, String activityType, String activityDesc, String ipaddress, String siteId, String userId) {
        this.activityId = activityId;
        this.activityDate = activityDate;
        this.activityType = activityType;
        this.activityDesc = activityDesc;
        this.ipaddress = ipaddress;
        this.siteId = siteId;
        this.userId = userId;        
    }

    public Date getActivityDate() {
        return this.activityDate;
    }

    public void setActivityDate(Date activityDate) {
        this.activityDate = activityDate;
    }

    public String getActivityType() {
        return this.activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityDesc() {
        return this.activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    public String getIpaddress() {
        return this.ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }    
    
    public ValidationErrors validate() {
        // TODO Auto-generated method stub
        return null;
    }
}