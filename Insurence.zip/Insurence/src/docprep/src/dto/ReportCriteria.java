package docprep.src.dto;
import java.util.Date;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;


public class ReportCriteria extends ModelImpl implements java.io.Serializable {

	// Fields    

	private ReportCriteriaId id;

	private String fieldName;

	private String reportName;

	private String transactionIdfrom;

	private String transactionIdto;

	private Date invoiceDateFrom;

	private Date invoiceDateTo;

	private String exporterReferenceFrom;

	private String exporterReferenceTo;

	private String buyerReferenceFrom;

	private String buyerReferenceTo;

	private String buyerFrom;

	private String buyerTo;

	// Constructors

	/** default constructor */
	public ReportCriteria() {
	}

	/** minimal constructor */
	public ReportCriteria(ReportCriteriaId id,
			Date invoiceDateFrom, Date invoiceDateTo) {
		this.id = id;
		this.invoiceDateFrom = invoiceDateFrom;
		this.invoiceDateTo = invoiceDateTo;
	}

	/** full constructor */
	public ReportCriteria(ReportCriteriaId id, String fieldName,
			String reportName, String transactionIdfrom,
			String transactionIdto, Date invoiceDateFrom, Date invoiceDateTo,
			String exporterReferenceFrom, String exporterReferenceTo,
			String buyerReferenceFrom, String buyerReferenceTo,
			String buyerFrom, String buyerTo) {
		this.id = id;
		this.fieldName = fieldName;
		this.reportName = reportName;
		this.transactionIdfrom = transactionIdfrom;
		this.transactionIdto = transactionIdto;
		this.invoiceDateFrom = invoiceDateFrom;
		this.invoiceDateTo = invoiceDateTo;
		this.exporterReferenceFrom = exporterReferenceFrom;
		this.exporterReferenceTo = exporterReferenceTo;
		this.buyerReferenceFrom = buyerReferenceFrom;
		this.buyerReferenceTo = buyerReferenceTo;
		this.buyerFrom = buyerFrom;
		this.buyerTo = buyerTo;
	}

	// Property accessors
	public ReportCriteriaId getId() {
		return this.id;
	}

	public void setId(ReportCriteriaId id) {
		this.id = id;
	}

	public String getFieldName() {
		return this.fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getReportName() {
		return this.reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getTransactionIdfrom() {
		return this.transactionIdfrom;
	}

	public void setTransactionIdfrom(String transactionIdfrom) {
		this.transactionIdfrom = transactionIdfrom;
	}

	public String getTransactionIdto() {
		return this.transactionIdto;
	}

	public void setTransactionIdto(String transactionIdto) {
		this.transactionIdto = transactionIdto;
	}

	public Date getInvoiceDateFrom() {
		return this.invoiceDateFrom;
	}

	public void setInvoiceDateFrom(Date invoiceDateFrom) {
		this.invoiceDateFrom = invoiceDateFrom;
	}

	public Date getInvoiceDateTo() {
		return this.invoiceDateTo;
	}

	public void setInvoiceDateTo(Date invoiceDateTo) {
		this.invoiceDateTo = invoiceDateTo;
	}

	public String getExporterReferenceFrom() {
		return this.exporterReferenceFrom;
	}

	public void setExporterReferenceFrom(String exporterReferenceFrom) {
		this.exporterReferenceFrom = exporterReferenceFrom;
	}

	public String getExporterReferenceTo() {
		return this.exporterReferenceTo;
	}

	public void setExporterReferenceTo(String exporterReferenceTo) {
		this.exporterReferenceTo = exporterReferenceTo;
	}

	public String getBuyerReferenceFrom() {
		return this.buyerReferenceFrom;
	}

	public void setBuyerReferenceFrom(String buyerReferenceFrom) {
		this.buyerReferenceFrom = buyerReferenceFrom;
	}

	public String getBuyerReferenceTo() {
		return this.buyerReferenceTo;
	}

	public void setBuyerReferenceTo(String buyerReferenceTo) {
		this.buyerReferenceTo = buyerReferenceTo;
	}

	public String getBuyerFrom() {
		return this.buyerFrom;
	}

	public void setBuyerFrom(String buyerFrom) {
		this.buyerFrom = buyerFrom;
	}

	public String getBuyerTo() {
		return this.buyerTo;
	}

	public void setBuyerTo(String buyerTo) {
		this.buyerTo = buyerTo;
	}

	/* (non-Javadoc)
	 * @see dev.zing.framework.businesstier.model.Model#validate()
	 */
	public ValidationErrors validate() {
		// TODO Auto-generated method stub
		return null;
	}

}
