package docprep.src.dto;

import dev.zing.framework.businesstier.model.ModelImpl;
import dev.zing.framework.services.validation.ValidationErrors;

public abstract class Body extends ModelImpl{
    
    private String originalOrCopy;
    
    public String getOriginalOrCopy() {
        return originalOrCopy;
    }

    public void setOriginalOrCopy(String originalOrCopy) {
        this.originalOrCopy = originalOrCopy;
    }

    public abstract ValidationErrors validate();
   
}