package docprep.src.dto;

import java.util.Date;

import dev.zing.framework.services.validation.ValidationErrors;

public class PackingList extends Body {

    // Fields

    public static final int TYPE_PACKINGLIST_1 = 1;

    public static final int TYPE_PACKINGLIST_2 = 2;

    public static final int TYPE_PACKINGLIST_3 = 3;

    private Integer packingListId;

    private Long sysDocId;

    //private String docId;

    private String docTypeCode;

    private String packListNo;

    private Integer pageNo;

    private Integer packingType;

    private Date packingDate;

    private String methodOfDispatch;

    private String internalLine1;

    private String internalLine2;

    private String internalLine3;

    private String internalLine4;

    private String internalLine5;

    private String internalLine6;

    private String internalLine7;

    private String marks1;

    private String marks2;

    private String marks3;

    private String marks4;

    private String marks5;

    private String marks6;

    private String marks7;

    private String measure1;

    private String measure2;

    private String measure3;

    private String measure4;

    private String measure5;

    private String measure6;

    private String measure7;

    private String totalQuantity;

    private String totalNetWeight;

    private String totalGrossWeight;

    private String totalCubic;

    private String packTypeDesc;

    private PackingListItemDetail[] packingListItemDetails;

    public PackingList() {
    }

    public Integer getPackingListId() {
        return this.packingListId;
    }

    public void setPackingListId(Integer packingListId) {
        this.packingListId = packingListId;
    }

    public Long getSysDocId() {
        return this.sysDocId;
    }

    public void setSysDocId(Long sysDocId) {
        this.sysDocId = sysDocId;
    }

    public String getDocTypeCode() {
        return docTypeCode;
    }

    public void setDocTypeCode(String docTypeCode) {
        this.docTypeCode = docTypeCode;
    }

    public String getPackListNo() {
        return this.packListNo;
    }

    public void setPackListNo(String packListNo) {
        this.packListNo = packListNo;
    }

    public Integer getPageNo() {
        return this.pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPackingType() {
        return this.packingType;
    }

    public void setPackingType(Integer packingType) {
        this.packingType = packingType;
    }

    public String getPackTypeDesc() {
        return getPackTypeString(this.packingType.intValue());
    }

    public void setPackTypeDesc(String packTypeDesc) {
        this.packTypeDesc = packTypeDesc;
    }

    public static String getPackTypeString(int packTypeValue) {
        if (packTypeValue == TYPE_PACKINGLIST_1) {
            return "Packing Type1";
        } else if (packTypeValue == TYPE_PACKINGLIST_2) {
            return "Packing Type2";
        } else if (packTypeValue == TYPE_PACKINGLIST_3) {
            return "Packing Type3";
        }
        return String.valueOf(packTypeValue);
    }

    public Date getPackingDate() {
        return this.packingDate;
    }

    public void setPackingDate(Date packingDate) {
        this.packingDate = packingDate;
    }

    public String getMethodOfDispatch() {
        return this.methodOfDispatch;
    }

    public void setMethodOfDispatch(String methodOfDispatch) {
        this.methodOfDispatch = methodOfDispatch;
    }

    public String getInternalLine1() {
        return this.internalLine1;
    }

    public void setInternalLine1(String internalLine1) {
        this.internalLine1 = internalLine1;
    }

    public String getInternalLine2() {
        return this.internalLine2;
    }

    public void setInternalLine2(String internalLine2) {
        this.internalLine2 = internalLine2;
    }

    public String getInternalLine3() {
        return this.internalLine3;
    }

    public void setInternalLine3(String internalLine3) {
        this.internalLine3 = internalLine3;
    }

    public String getInternalLine4() {
        return this.internalLine4;
    }

    public void setInternalLine4(String internalLine4) {
        this.internalLine4 = internalLine4;
    }

    public String getInternalLine5() {
        return this.internalLine5;
    }

    public void setInternalLine5(String internalLine5) {
        this.internalLine5 = internalLine5;
    }

    public String getInternalLine6() {
        return this.internalLine6;
    }

    public void setInternalLine6(String internalLine6) {
        this.internalLine6 = internalLine6;
    }

    public String getInternalLine7() {
        return this.internalLine7;
    }

    public void setInternalLine7(String internalLine7) {
        this.internalLine7 = internalLine7;
    }

    public String getMarks1() {
        return this.marks1;
    }

    public void setMarks1(String marks1) {
        this.marks1 = marks1;
    }

    public String getMarks2() {
        return this.marks2;
    }

    public void setMarks2(String marks2) {
        this.marks2 = marks2;
    }

    public String getMarks3() {
        return this.marks3;
    }

    public void setMarks3(String marks3) {
        this.marks3 = marks3;
    }

    public String getMarks4() {
        return this.marks4;
    }

    public void setMarks4(String marks4) {
        this.marks4 = marks4;
    }

    public String getMarks5() {
        return this.marks5;
    }

    public void setMarks5(String marks5) {
        this.marks5 = marks5;
    }

    public String getMarks6() {
        return this.marks6;
    }

    public void setMarks6(String marks6) {
        this.marks6 = marks6;
    }

    public String getMarks7() {
        return this.marks7;
    }

    public void setMarks7(String marks7) {
        this.marks7 = marks7;
    }

    public String getMeasure1() {
        return this.measure1;
    }

    public void setMeasure1(String measure1) {
        this.measure1 = measure1;
    }

    public String getMeasure2() {
        return this.measure2;
    }

    public void setMeasure2(String measure2) {
        this.measure2 = measure2;
    }

    public String getMeasure3() {
        return this.measure3;
    }

    public void setMeasure3(String measure3) {
        this.measure3 = measure3;
    }

    public String getMeasure4() {
        return this.measure4;
    }

    public void setMeasure4(String measure4) {
        this.measure4 = measure4;
    }

    public String getMeasure5() {
        return this.measure5;
    }

    public void setMeasure5(String measure5) {
        this.measure5 = measure5;
    }

    public String getMeasure6() {
        return this.measure6;
    }

    public void setMeasure6(String measure6) {
        this.measure6 = measure6;
    }

    public String getMeasure7() {
        return this.measure7;
    }

    public void setMeasure7(String measure7) {
        this.measure7 = measure7;
    }

    public String getTotalQuantity() {
        return this.totalQuantity;
    }

    public void setTotalQuantity(String totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getTotalNetWeight() {
        return this.totalNetWeight;
    }

    public void setTotalNetWeight(String totalNetWeight) {
        this.totalNetWeight = totalNetWeight;
    }

    public String getTotalGrossWeight() {
        return this.totalGrossWeight;
    }

    public void setTotalGrossWeight(String totalGrossWeight) {
        this.totalGrossWeight = totalGrossWeight;
    }

    public String getTotalCubic() {
        return this.totalCubic;
    }

    public void setTotalCubic(String totalCubic) {
        this.totalCubic = totalCubic;
    }

    public PackingListItemDetail[] getPackingListItemDetails() {
        return packingListItemDetails;
    }

    public void setPackingListItemDetails(PackingListItemDetail[] packingListItemDetails) {
        this.packingListItemDetails = packingListItemDetails;
    }

    public ValidationErrors validate() {
        // TODO Auto-generated method stub
        return null;
    }

}
