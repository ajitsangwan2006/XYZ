package docprep.src.bto.userAccess;

import usermgmt.src.bto.controller.PersonManager;
import usermgmt.src.dto.Person;
import dev.zing.framework.businesstier.facade.Environment;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;

public interface AdminEnvironment extends Environment {

    public Person getMyProfile();

    public void updateMyProfile(Person user) throws InvalidArgumentException, InvalidPasswordException;

    public PersonManager getPersonManager();
   
}
