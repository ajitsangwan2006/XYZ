package docprep.src.bto.userAccess;


import userlookup.src.bto.controller.ClausesUserLookupManager;
import userlookup.src.bto.controller.CurrencyUserLookupManager;
import userlookup.src.bto.controller.ProductUserLookupManager;
import userlookup.src.bto.controller.TradingPartnerLookupManager;
import usermgmt.src.bto.controller.CompanyManager;
import usermgmt.src.bto.controller.CompanyModuleManager;
import usermgmt.src.bto.controller.ModuleManager;
import usermgmt.src.bto.controller.PersonManager;
import codemaintenance.src.bto.controller.CountryLookupManager;
import codemaintenance.src.bto.controller.CurrencyLookupManager;
import codemaintenance.src.bto.controller.PortLookupManager;
import codemaintenance.src.bto.controller.VesselLookupManager;
import dev.zing.framework.businesstier.facade.Environment;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.controller.DefaultSetupManager;
import docprep.src.bto.controller.DocReportManager;
import docprep.src.bto.controller.DocumentMgmtManager;


public interface EndUserEnvironment extends Environment {
	
	public DocumentMgmtManager getDocumentMgmtManager();
	
	///// put it latter//////////////
	//public LetterOfCerditManager getLetterOfCerditManager();

    public TradingPartnerLookupManager getTradingPartnerLookupManager();

    public ActivityLogManager getActivityLogManager();
    
    public PersonManager getPersonManager();
    
    public CompanyModuleManager getCompanyModuleManager();

    public ModuleManager getModuleManager();

    public CompanyManager getCompanyManager();
    
    public CountryLookupManager getCountryLookupManager();
    
    public PortLookupManager getPortLookupManager();
    
    public CurrencyUserLookupManager getCurrencyUserLookupManager();
    
    public CurrencyLookupManager getCurrencyLookupManager();
    
    public VesselLookupManager getVesselLookupManager();
    
    public ProductUserLookupManager getProductUserLookupManager();
    
    public ClausesUserLookupManager getClausesUserLookupManager();
    
    public DefaultSetupManager getDefaultSetupManager();
    
    public DocReportManager getDocReportManager();
}
