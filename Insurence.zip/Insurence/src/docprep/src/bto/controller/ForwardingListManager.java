package docprep.src.bto.controller;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dto.ForwardingList;

public interface ForwardingListManager {
	
	    public ForwardingList get(String sysDocId) throws InvalidArgumentException;

	    public ForwardingList create(ForwardingList criteria) throws InvalidArgumentException, DuplicateRecordException;

	    public ForwardingList update(ForwardingList criteria) throws InvalidArgumentException;

	    public boolean delete(String sysDocId) throws RecordNotFoundException, InvalidArgumentException;	 
}
