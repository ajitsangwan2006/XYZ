package docprep.src.bto.controller;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.dto.DefaultSetup;
import docprep.src.dto.MasterDocument;

public interface DefaultSetupManager {

	  	public void updateDefaultSetup(DefaultSetup defaultSetup) throws InvalidArgumentException;

	    public DefaultSetup getDefaultSetup();
	
	    public MasterDocument getDefaultValues() throws InvalidArgumentException;
     
}