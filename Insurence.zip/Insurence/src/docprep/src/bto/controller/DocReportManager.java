package docprep.src.bto.controller;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.dto.UserReportTO;

public interface DocReportManager {

    public byte[] getMasterReportAsPDF(String sysDocId, int printTemplateId) throws InvalidArgumentException;

    public boolean sendEndUserReport(String subject, UserReportTO reportTo) throws InvalidArgumentException;

    public byte[] getReportBytes(String sysDocId, String docTypeCode) throws InvalidArgumentException;

}

