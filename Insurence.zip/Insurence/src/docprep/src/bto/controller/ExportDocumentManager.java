package docprep.src.bto.controller;

import java.io.IOException;

import com.ibm.ws.http.HttpException;

import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.MasterDocument;
import docprep.src.listhelper.ExportDocumentListHelper;

public interface ExportDocumentManager {

    public PageHandler getList(ExportDocumentListHelper criteria);

    public ExportDocument get(String sysDocId) throws InvalidArgumentException;
    
    public ExportDocument getByDocumentType(Long parentId, String docTypeCode) throws InvalidArgumentException;

    public void createMaster(MasterDocument masterDocument) throws InvalidArgumentException, DuplicateRecordException;

    public MasterDocument updateMaster(MasterDocument masterDocument) throws InvalidArgumentException;

    public void createDerived(DerivedDocument derivedDocument) throws InvalidArgumentException, DuplicateRecordException;

    public DerivedDocument updateDerived(DerivedDocument derivedDocument) throws InvalidArgumentException;

    public void delete(String sysDocId) throws InvalidArgumentException;

    public MasterDocument getMasterDocDetails(String sysDocId) throws InvalidArgumentException;

    public DerivedDocument getDeriveDocumentDetails(String sysDocId, String docTypecode) throws InvalidArgumentException;

    public void sendDocumentToChamber(Integer moduleId, String exporterReference, String printTemplate, String deliveryMode, String noOfCopies, String requestedTargetDate, byte[] pdfContent) throws HttpException, InvalidArgumentException, IOException;
    
    public void deleteDerivedDocument(String sysDocId) throws InvalidArgumentException;
    
}