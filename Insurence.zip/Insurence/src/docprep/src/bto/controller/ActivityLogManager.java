package docprep.src.bto.controller;

import docprep.src.dto.Activitylog;
import docprep.src.listhelper.ActivityLogListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public interface ActivityLogManager {

    public PageHandler getActivityLogList(ActivityLogListHelper criteria);

    public void addActivityLogEntry(Activitylog criteria) throws InvalidArgumentException;
}
