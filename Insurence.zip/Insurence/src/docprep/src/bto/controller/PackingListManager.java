package docprep.src.bto.controller;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import docprep.src.dto.PackingList;

public interface PackingListManager {
	
	    public PackingList get(String sysDocId ,Integer packingListId) throws InvalidArgumentException;

	    public PackingList create(PackingList criteria) throws InvalidArgumentException, DuplicateRecordException;

	    public PackingList update(PackingList criteria) throws InvalidArgumentException;

	    public boolean delete(Integer packingListId) throws RecordNotFoundException, InvalidArgumentException;	 
}
