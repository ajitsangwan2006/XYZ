package docprep.src.bto.controller;

public interface DocumentMgmtManager {

	public DocReportManager getDocReportManager();
    
    public ExportDocumentManager getExportDocumentManager();

     
}