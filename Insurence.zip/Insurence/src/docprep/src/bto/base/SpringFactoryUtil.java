
package docprep.src.bto.base;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SpringFactoryUtil extends HibernateDaoSupport {
	
	//private static String CONFIG_FILE_LOCATION = "/appContext-DocPrep-dao.xml";
	
	private static String[] CONFIG_FILE_LOCATION = { 
	        "/applicationContext.xml",
	        "/docprep/src/dao/appContext-ExportDocPrep-dao.xml", 
	        "/docprep/src/bto/appContext-ExportDocPrep-bto.xml",
	        "/billingsystem/src/dao/appContext-BillingSystem-dao.xml", 
	        "/codemaintenance/src/dao/appContext-CodeMaintenance-dao.xml", 
	        "/codemaintenance/src/bto/appContext-CodeMaintenance-bto.xml", 
	        "/userlookup/src/dao/appContext-UserLookups-dao.xml", 
	        "/userlookup/src/bto/appContext-UserLookups-bto.xml", 
	        "/usermgmt/src/dao/appContext-UserMgmt-dao.xml", 
	        "/usermgmt/src/bto/appContext-UserMgmt-bto.xml"
	};
	
	//private static String[] CONFIG_FILE_LOCATION = {"/appContext-DocPrep-bto.xml", "/appContext-DocPrep-dao-full.xml"};
	
	private static ClassPathXmlApplicationContext springFactory = null;
	
	static {
        init();
    }

    private static void init() {
    	springFactory = new ClassPathXmlApplicationContext(CONFIG_FILE_LOCATION);
    }
    
    public static ClassPathXmlApplicationContext getSpringFactory () {
		return springFactory;
	}    
}
