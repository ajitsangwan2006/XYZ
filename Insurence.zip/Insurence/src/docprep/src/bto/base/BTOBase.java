package docprep.src.bto.base;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import userlookup.src.dao.impl.ClausesUserLookupDAOImpl;
import userlookup.src.dao.impl.CurrencyUserLookupDAOImpl;
import userlookup.src.dao.impl.ProductUserLookupDAOImpl;
import userlookup.src.dao.impl.TradingPartnerLookupDAOImpl;
import userlookup.src.dao.interfaces.ClausesUserLookupDAO;
import userlookup.src.dao.interfaces.CurrencyUserLookupDAO;
import userlookup.src.dao.interfaces.ProductUserLookupDAO;
import userlookup.src.dao.interfaces.TradingPartnerLookupDAO;
import usermgmt.src.dao.impl.CompanyDAOImpl;
import usermgmt.src.dao.impl.CompanyModuleDAOImpl;
import usermgmt.src.dao.impl.ModuleDAOImpl;
import usermgmt.src.dao.impl.PersonDAOImpl;
import usermgmt.src.dao.interfaces.CompanyDAO;
import usermgmt.src.dao.interfaces.CompanyModuleDAO;
import usermgmt.src.dao.interfaces.ModuleDAO;
import usermgmt.src.dao.interfaces.PersonDAO;
import billingsystem.src.dao.impl.TaxInvoiceDAOImpl;
import billingsystem.src.dao.interfaces.TaxInvoiceDAO;
import codemaintenance.src.dao.impl.CountryLookupDAOImpl;
import codemaintenance.src.dao.impl.CurrencyLookupDAOImpl;
import codemaintenance.src.dao.impl.PortLookupDAOImpl;
import codemaintenance.src.dao.impl.VesselLookupDAOImpl;
import codemaintenance.src.dao.interfaces.CountryLookupDAO;
import codemaintenance.src.dao.interfaces.CurrencyLookupDAO;
import codemaintenance.src.dao.interfaces.PortLookupDAO;
import codemaintenance.src.dao.interfaces.VesselLookupDAO;
import dev.zing.framework.businesstier.facade.BTO;
import docprep.src.dao.impl.ActivityLogDAOImpl;
import docprep.src.dao.impl.DefaultSetupDAOImpl;
import docprep.src.dao.impl.ExportDocumentDAOImpl;
import docprep.src.dao.impl.ForwardingListDAOImpl;
import docprep.src.dao.impl.ItemDetailDAOImpl;
import docprep.src.dao.impl.MasterDocumentDAOImpl;
import docprep.src.dao.impl.PackageDetailDAOImpl;
import docprep.src.dao.impl.PackingListDAOImpl;
import docprep.src.dao.impl.PackingListItemDetailDAOImpl;
import docprep.src.dao.interfaces.ActivityLogDAO;
import docprep.src.dao.interfaces.DefaultSetupDAO;
import docprep.src.dao.interfaces.ExportDocumentDAO;
import docprep.src.dao.interfaces.ForwardingListDAO;
import docprep.src.dao.interfaces.ItemDetailDAO;
import docprep.src.dao.interfaces.MasterDocumentDAO;
import docprep.src.dao.interfaces.PackageDetailDAO;
import docprep.src.dao.interfaces.PackingListDAO;
import docprep.src.dao.interfaces.PackingListItemDetailDAO;

public class BTOBase extends BTO {

    public PersonDAO getPersonDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        if (springFactory == null) {
            log("springFactory is null....");
        } else {
            log("springFactory is NOT null....");
        }
        return (PersonDAOImpl) springFactory.getBean("personDAO");
    }

    public CompanyDAO getCompanyDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (CompanyDAOImpl) springFactory.getBean("companyDAO");
    }

    public ModuleDAO getModuleDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (ModuleDAOImpl) springFactory.getBean("moduleDAO");
    }
    
    public CompanyModuleDAO getCompanyModuleDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (CompanyModuleDAOImpl) springFactory.getBean("companyModuleDAO");
    }

    public TradingPartnerLookupDAO getTradingPartnerLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (TradingPartnerLookupDAOImpl) springFactory.getBean("tradingPartnerLookupDAO");
    }

    public ActivityLogDAO getActivityLogDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (ActivityLogDAOImpl) springFactory.getBean("activityLogDAO");
    }

    public TaxInvoiceDAO getTaxInvoiceDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (TaxInvoiceDAOImpl) springFactory.getBean("taxInvoiceDAO");
    }
    
    public ExportDocumentDAO getExportDocumentDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (ExportDocumentDAOImpl) springFactory.getBean("exportDocumentDAO");
    }
 
    public CountryLookupDAO getCountryLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (CountryLookupDAOImpl) springFactory.getBean("countryLookupDAO");
    }
    
   
    public PortLookupDAO getPortLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (PortLookupDAOImpl) springFactory.getBean("portLookupDAO");
    }

    public CurrencyLookupDAO getCurrencyLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (CurrencyLookupDAOImpl) springFactory.getBean("currencyLookupDAO");
    }
    
    public CurrencyUserLookupDAO getCurrencyUserLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (CurrencyUserLookupDAOImpl) springFactory.getBean("currencyUserLookupDAO");
    }
    
   
    public VesselLookupDAO getVesselLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (VesselLookupDAOImpl) springFactory.getBean("vesselLookupDAO");
     }
    
    public ProductUserLookupDAO getProductUserLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (ProductUserLookupDAOImpl) springFactory.getBean("productUserLookupDAO");
     }
    
    public ClausesUserLookupDAO getClausesUserLookupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (ClausesUserLookupDAOImpl) springFactory.getBean("clausesUserLookupDAO");
     }
    
    public MasterDocumentDAO getMasterDocumentDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (MasterDocumentDAOImpl) springFactory.getBean("masterDocumentDAO");
     }
    
    public PackageDetailDAO getPackageDetailDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (PackageDetailDAOImpl) springFactory.getBean("packageDetailDAO");
     }
    
    public ItemDetailDAO getItemDetailDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (ItemDetailDAOImpl) springFactory.getBean("itemDetailDAO");
     }
    
    public DefaultSetupDAO getDefaultSetupDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
       return (DefaultSetupDAOImpl) springFactory.getBean("defaultSetupDAO");
     }
    
    public PackingListDAO getPackingListDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (PackingListDAOImpl) springFactory.getBean("packingListDAO");
    }
    
    public PackingListItemDetailDAO getPackingListItemDetailDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (PackingListItemDetailDAOImpl) springFactory.getBean("packingListItemDetailDAO");
    }
    
    public ForwardingListDAO getForwardingListDAO() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        return (ForwardingListDAOImpl) springFactory.getBean("forwardingListDAO");
    }

}
