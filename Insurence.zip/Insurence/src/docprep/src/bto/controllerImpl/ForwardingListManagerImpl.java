package docprep.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ForwardingListManager;
import docprep.src.dto.ForwardingList;

public class ForwardingListManagerImpl extends BTOBase implements ForwardingListManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();

    }

    public ForwardingList get(String sysDocId) throws InvalidArgumentException {
        ForwardingList dto = null;
        dto = getForwardingListDAO().get(sysDocId);

        return dto;
    }

    public ForwardingList create(ForwardingList criteria) throws InvalidArgumentException, DuplicateRecordException {
        if (criteria == null) {
            throw new InvalidArgumentException("ForwardingList can not be NULL.");
        }
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        ForwardingList forwardingList = getForwardingListDAO().get(criteria.getSysDocId().toString());
        if (forwardingList != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("sysDocId");
            error.setErrorMessage("Duplicate  SysDocId is NOT allowed.");
            ValidationErrors errores = new ValidationErrors();
            errores.addValidationError("sysDocId", error);
            throw new InvalidArgumentException(errores);
        }

        getForwardingListDAO().create(criteria);
        return criteria;
    }

    public ForwardingList update(ForwardingList criteria) throws InvalidArgumentException {
        if (criteria == null) {
            throw new InvalidArgumentException("ForwardingList can not be NULL.");
        }
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        getForwardingListDAO().update(criteria);

        return criteria;
    }

    public boolean delete(String sysDocId) throws RecordNotFoundException, InvalidArgumentException {

        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.sysDocId");
            throw invalidArgumentException;
        }
        boolean result = false;

        getForwardingListDAO().delete(sysDocId);
        result = true;

        return result;
    }

}