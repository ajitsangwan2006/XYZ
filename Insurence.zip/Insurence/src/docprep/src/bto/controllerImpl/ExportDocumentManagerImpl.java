package docprep.src.bto.controllerImpl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.io.FileUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.ws.http.HttpException;

import usermgmt.src.dto.Module;
import usermgmt.src.dto.Person;

import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.controller.ExportDocumentManager;
import docprep.src.bto.valueListHandler.ExportDocumentPageDAOProvider;
import docprep.src.dto.Activitylog;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.ItemDetail;
import docprep.src.dto.ItemDetailId;
import docprep.src.dto.MasterDocument;
import docprep.src.dto.PackageDetail;
import docprep.src.dto.PackageDetailId;
import docprep.src.dto.PackingList;
import docprep.src.dto.PackingListItemDetail;
import docprep.src.dto.PackingListItemDetailId;
import docprep.src.listhelper.ExportDocumentListHelper;
import docprep.src.services.SystemUtil;

public class ExportDocumentManagerImpl extends BTOBase implements ExportDocumentManager {

    //private Long uniqueUserRef;

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    private ActivityLogManager activityLogManager;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        //	this.uniqueUserRef = uniqueUserRef;
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ActivityLogManagerImpl activityManagerImpl = (ActivityLogManagerImpl) springFactory.getBean("activityLogManager");
        activityManagerImpl.initialize(pageScrollValue, pageHandlerHolder, userId, siteId, this.ipAddress);
        this.activityLogManager = activityManagerImpl;
    }

    public PageHandler getList(ExportDocumentListHelper criteria) {
        if (criteria == null) {
            criteria = new ExportDocumentListHelper();
        }

        criteria.setSiteId(siteId);
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();

        ExportDocumentPageDAOProvider documentsPageDAOProvider = (ExportDocumentPageDAOProvider) springFactory.getBean("exportDocumentPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, documentsPageDAOProvider, pageScrollValue);
    }
  
    public ExportDocument get(String sysDocId) throws InvalidArgumentException {
        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SysDocId");
            invalidArgumentException.setErrorOzCode("system.errors.SysDocId");
            throw invalidArgumentException;
        }
        ExportDocument exportDocument = null;
        exportDocument = getExportDocumentDAO().get(this.siteId, this.userId, sysDocId);

        return exportDocument;
    }
    
    public ExportDocument getByDocumentType(Long parentId, String docTypeCode) throws InvalidArgumentException {
        return getExportDocumentDAO().getByDocumentType(this.siteId, parentId, docTypeCode);
    }

    public MasterDocument getMasterDocDetails(String sysDocId) throws InvalidArgumentException {
        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SysDocId");
            invalidArgumentException.setErrorOzCode("system.errors.SysDocId");
            throw invalidArgumentException;
        }
        MasterDocument masterDocument = null;
        masterDocument = getMasterDocumentDAO().get(sysDocId);
        List packageDetailList = getPackageDetailDAO().get(sysDocId);
        PackageDetail[] packageDetails = (PackageDetail[]) packageDetailList.toArray(new PackageDetail[packageDetailList.size()]);
        masterDocument.setPackageDetails(packageDetails);

        List itemDetailList = getItemDetailDAO().get(sysDocId);
        ItemDetail[] itemDetails = (ItemDetail[]) itemDetailList.toArray(new ItemDetail[itemDetailList.size()]);
        masterDocument.setItemDetails(itemDetails);
        return masterDocument;
    }

    public DerivedDocument getDeriveDocumentDetails(String sysDocId, String docTypeCode) throws InvalidArgumentException {
        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SysDocId");
            invalidArgumentException.setErrorOzCode("system.errors.SysDocId");
            throw invalidArgumentException;
        }
        DerivedDocument derivedDocument = new DerivedDocument();

        PackingList packingList = null;
        ExportDocument exportDocument = getExportDocumentDAO().get(this.siteId, this.userId, sysDocId);
        if (docTypeCode != null && docTypeCode.equalsIgnoreCase("PackingList")) {
            packingList = getPackingListDAO().get(sysDocId);
            List packingListItemDetailList = getPackingListItemDetailDAO().get(sysDocId);
            PackingListItemDetail[] packagelistItemDetail = (PackingListItemDetail[]) packingListItemDetailList.toArray(new PackingListItemDetail[packingListItemDetailList.size()]);
            packingList.setPackingListItemDetails(packagelistItemDetail);
        }
        derivedDocument.setHeader(exportDocument);
        derivedDocument.setBody(packingList);
        return derivedDocument;
    }

    public void createMaster(MasterDocument masterDocument) throws InvalidArgumentException, DuplicateRecordException {
        if (masterDocument == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Documents");
            invalidArgumentException.setErrorOzCode("system.errors.Documents");
            throw invalidArgumentException;
        }        
        ExportDocumentListHelper criteria = new ExportDocumentListHelper();
        criteria.setDocId(masterDocument.getDocId());
        criteria.setSiteId(siteId);
        List exportDocumentList = getExportDocumentDAO().getList(criteria).getCurrentPageData();
        ExportDocument dbInstance = null;
        if (exportDocumentList.size()>0) {
        	dbInstance = (ExportDocument)exportDocumentList.get(0);
        }
        if (dbInstance != null) {
        	 ValidationErrors validationErrors = new ValidationErrors();
        	 ValidationError validationError = new ValidationError();
             validationError.setPropertyName("docId");
             validationError.setErrorMessage("This Document Id is already taken up for another Master Document, please enter another Document Id");
             validationErrors.addValidationError(validationError.getPropertyName(), validationError);
             throw new InvalidArgumentException(validationErrors);
        }
        ExportDocument doc = new ExportDocument();
        String docId = masterDocument.getDocId();
        doc.setSiteId(siteId);
        doc.setUserId(userId);
        doc.setDocTypeCode(masterDocument.getDocTypeCode());
        doc.setDocId(docId);
        doc.setStatus(masterDocument.getDocStatus());
        doc.setEdn(masterDocument.getEdn());
        doc.setBuyerReference(masterDocument.getBuyerReference());

        if (masterDocument.getDocTypeCode() != null && masterDocument.getDocTypeCode().equalsIgnoreCase("MasterDocument")) {
            doc.setParentId(new Long(0));
        } else {
            /// set to sysDocId of Master Document.....
            doc.setParentId(new Long(0));
        }

        doc.setDocTypeVersion(new Integer(1));
        doc.setInvoiceNumber(masterDocument.getInvoiceNumber());
        doc.setBuyerName(masterDocument.getBuyerName());
        doc.setExporterReference(masterDocument.getExporterReference());
        doc.setBuyerReference(masterDocument.getBuyerReference());
        doc.setEdn(masterDocument.getEdn());

        doc.setFormTemplateCode(new Integer(0));
        doc.setPrintTemplateCode(new Integer(0));
        doc.setInceptionDate(new Date());
        doc.setLastUpdateDate(new Date());

        String date = masterDocument.getInvoiceDate();
        if (date != null && date.trim().length() > 0) {
            doc.setInvoiceDate(SystemUtil.getDateFromStringFormat4(date));
        } else {
            doc.setInvoiceDate(SystemUtil.getDateFromStringFormat4(SystemUtil.getCurrentDateTimeFormat5(new Date())));
            masterDocument.setInvoiceDate(SystemUtil.getCurrentDateTimeFormat5(new Date()));
        }
        ExportDocument exportDocument = getExportDocumentDAO().create(doc);
        masterDocument.setSysDocId(exportDocument.getSysDocId());
        updateMasterDocument(masterDocument);
        updatePackageDetailLines(masterDocument.getSysDocId(), masterDocument.getPackageDetails());
        updateItemDetailLines(masterDocument.getSysDocId(), masterDocument.getItemDetails());
        Activitylog activity = new Activitylog();
        activity.setActivityDesc("Master Document created successfully with SysDocId (" + String.valueOf(doc.getSysDocId()) + " ).");
        activity.setActivityType("3");
        activityLogManager.addActivityLogEntry(activity);

    }

    public void createDerived(DerivedDocument derivedDocument) throws InvalidArgumentException, DuplicateRecordException {
        if (derivedDocument == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.DerivedDocuments");
            invalidArgumentException.setErrorOzCode("system.errors.DerivedDocuments");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = derivedDocument.getHeader().validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        Long sysDocId = null;
        ExportDocument doc = derivedDocument.getHeader();
        if (doc.getDocTypeCode().equalsIgnoreCase("PackingList")) {
            PackingList packingList = (PackingList) derivedDocument.getBody();
            sysDocId = packingList.getSysDocId();
            if (sysDocId != null) {
                doc = get(sysDocId.toString());
            }
            doc.setDocTypeCode("PackingList");
            doc.setParentId(sysDocId);
            doc.setFormTemplateCode(new Integer(0));
            doc.setPrintTemplateCode(new Integer(0));
            doc.setInceptionDate(new Date());
            doc.setLastUpdateDate(new Date());
            ExportDocument exportDocument = getExportDocumentDAO().create(doc);
            packingList.setSysDocId(exportDocument.getSysDocId());
            updatePackingList(packingList);
            updatePackingItemDetailLines(packingList.getSysDocId(), packingList.getPackingListItemDetails());
        }
        Activitylog activity = new Activitylog();
        activity.setActivityDesc("Derived Document created successfully with SysDocId (" + String.valueOf(doc.getSysDocId()) + " ).");
        activity.setActivityType("3");
        activityLogManager.addActivityLogEntry(activity);
    }

    private void updatePackingItemDetailLines(Long sysDocId, PackingListItemDetail[] packingListItemDetails) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        System.err.println("i  m updatePackingItemDetailLines nbn" + sysDocId.toString());
        getPackingListItemDetailDAO().delete(sysDocId.toString());
        System.err.println("updatePackingItemDetailLines----------->");
        if (packingListItemDetails != null) {
            System.err.println("i m in updatePackingItemDetailLines---------------------->");
            for (int i = 0; i < packingListItemDetails.length; i++) {
                PackingListItemDetailId detailId = new PackingListItemDetailId();
                detailId.setSysDocId(sysDocId);
                detailId.setLineNumber(new Integer(i + 1));
                packingListItemDetails[i].setId(detailId);
                packingListItemDetails[i].setPageNo(new Integer(1));
                getPackingListItemDetailDAO().create(packingListItemDetails[i]);
            }
        }
    }

    private void updatePackingList(PackingList packingList) throws DAOException, InvalidDAOArgumentException, DuplicateRecordException {
        getPackingListDAO().delete(packingList.getSysDocId().toString());
        if (packingList != null) {
            if (packingList.getPageNo() != null) {
                int pageNo = packingList.getPageNo().intValue() + 1;
                System.err.println("pageNo--------->" + pageNo);
                packingList.setPageNo(new Integer(pageNo));
            } else {
                packingList.setPageNo(new Integer(1));
            }
            getPackingListDAO().create(packingList);
        }
    }

    public MasterDocument updateMaster(MasterDocument masterDocument) throws InvalidArgumentException {
        if (masterDocument == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.Documents");
            invalidArgumentException.setErrorOzCode("system.errors.Documents");
            throw invalidArgumentException;
        }

        ValidationErrors validationErrors = masterDocument.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }

        ExportDocument exportDocument = getExportDocumentDAO().get(siteId, userId, masterDocument.getSysDocId().toString());
        ExportDocument doc = new ExportDocument();
        doc.setSysDocId(masterDocument.getSysDocId());
        doc.setSiteId(siteId);
        doc.setUserId(userId);
        doc.setDocTypeCode(masterDocument.getDocTypeCode());
        doc.setStatus(masterDocument.getDocStatus());
        if (masterDocument.getDocTypeCode() != null && masterDocument.getDocTypeCode().equalsIgnoreCase("MasterDocument")) {
            doc.setParentId(new Long(0));
        } else {
            /// set to sysDocId of Master Document.....
            doc.setParentId(new Long(0));
        }
        doc.setDocId(masterDocument.getDocId());

        String invoiceNumber = masterDocument.getInvoiceNumber() == null ? "" : masterDocument.getInvoiceNumber();
        doc.setInvoiceNumber(invoiceNumber);
        doc.setBuyerName(masterDocument.getBuyerName());
        doc.setExporterReference(masterDocument.getExporterReference());
        doc.setBuyerReference(masterDocument.getBuyerReference());
        doc.setEdn(masterDocument.getEdn());

        doc.setFormTemplateCode(new Integer(0));
        doc.setPrintTemplateCode(new Integer(0));
        doc.setInceptionDate(new Date());
        doc.setLastUpdateDate(new Date());
        doc.setDocTypeVersion(new Integer(1));

        String date = masterDocument.getInvoiceDate();

        if (date != null && date.trim().length() > 0) {
            doc.setInvoiceDate(SystemUtil.getDateFromStringFormat4(date));
        } else {
            doc.setInvoiceDate(SystemUtil.getDateFromStringFormat4(SystemUtil.getCurrentDateTimeFormat5(new Date())));
            masterDocument.setInvoiceDate(SystemUtil.getCurrentDateTimeFormat5(new Date()));
        }

        getExportDocumentDAO().update(doc);
        updateMasterDocument(masterDocument);
        updatePackageDetailLines(masterDocument.getSysDocId(), masterDocument.getPackageDetails());
        updateItemDetailLines(masterDocument.getSysDocId(), masterDocument.getItemDetails());
        Activitylog activity = new Activitylog();
        activity.setActivityDesc("Export Document ( " + doc.getDocTypeCode() + " ) updated successfully with SysDocId (" + doc.getSysDocId() + " ).");
        activity.setActivityType("3");
        activityLogManager.addActivityLogEntry(activity);

        return masterDocument;
    }

    public DerivedDocument updateDerived(DerivedDocument derivedDocument) throws InvalidArgumentException {
        if (derivedDocument == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.DerivedDocuments");
            invalidArgumentException.setErrorOzCode("system.errors.DerivedDocuments");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = derivedDocument.getHeader().validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        Long sysDocId = null;
        ExportDocument doc = derivedDocument.getHeader();
        if (doc != null && doc.getDocTypeCode().equalsIgnoreCase("PackingList")) {
            PackingList packingList = (PackingList) derivedDocument.getBody();
            sysDocId = packingList.getSysDocId();
            if (sysDocId != null) {
                doc = get(sysDocId.toString());
            }
            ExportDocument exportDocument = getExportDocumentDAO().get(this.siteId, this.userId, sysDocId.toString());
            packingList.setSysDocId(exportDocument.getSysDocId());
            try {
                updatePackingList(packingList);
                updatePackingItemDetailLines(packingList.getSysDocId(), packingList.getPackingListItemDetails());
            } catch (DAOException e) {
                e.printStackTrace();
            } catch (InvalidDAOArgumentException e) {
                e.printStackTrace();
            } catch (DuplicateRecordException e) {
                e.printStackTrace();
            }
        }
        Activitylog activity = new Activitylog();
        activity.setActivityDesc("Derived Document updated successfully with SysDocId (" + String.valueOf(doc.getSysDocId()) + " ).");
        activity.setActivityType("3");
        activityLogManager.addActivityLogEntry(activity);
        return derivedDocument;
    }

    public void delete(String sysDocId) throws InvalidArgumentException {
        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SysDocId");
            invalidArgumentException.setErrorOzCode("system.errors.SysDocId");
            throw invalidArgumentException;
        }
        
        ExportDocument exportDocument = getExportDocumentDAO().get(siteId, userId, sysDocId);
        getPackageDetailDAO().delete(exportDocument.getSysDocId().toString());
        getItemDetailDAO().delete(exportDocument.getSysDocId().toString());
        Activitylog activity = new Activitylog();
        activity.setActivityDesc("Document (" + exportDocument.getDocTypeCode() + " ) deleted successfully with SysDocId (" + sysDocId + ").");
        activity.setActivityType("3");
        activityLogManager.addActivityLogEntry(activity);
        MasterDocument masterDoc = getMasterDocumentDAO().get(sysDocId);
        ExportDocumentListHelper criteria = new ExportDocumentListHelper();
        criteria.setDocId(masterDoc.getDocId());
        List exportDocList = getExportDocumentDAO().getList(criteria).getCurrentPageData();
        getMasterDocumentDAO().delete(masterDoc.getSysDocId().toString());
        if(exportDocList.size() > 0){
	        for (Iterator iter = exportDocList.iterator(); iter.hasNext();) {
	        	ExportDocument exportDoc = (ExportDocument) iter.next();
	        	deleteDerivedDocument(exportDoc.getSysDocId().toString());
	        }
        }
    }

    private void updateMasterDocument(MasterDocument masterDocument) throws InvalidArgumentException {
        getMasterDocumentDAO().delete(masterDocument.getSysDocId().toString());
        if (masterDocument != null) {
            getMasterDocumentDAO().create(masterDocument);
        }
    }

    private void updatePackageDetailLines(Long sysDocId, PackageDetail[] packageDetails) throws InvalidArgumentException {
        getPackageDetailDAO().delete(sysDocId.toString());
        if (packageDetails != null) {
            for (int i = 0; i < packageDetails.length; i++) {
                PackageDetailId detailId = new PackageDetailId();
                detailId.setSysDocId(sysDocId);
                detailId.setLineNumber(new Integer(i + 1));
                packageDetails[i].setId(detailId);
                getPackageDetailDAO().create(packageDetails[i]);
            }
        }
    }

    private void updateItemDetailLines(Long sysDocId, ItemDetail[] itemDetails) throws InvalidArgumentException {
        getItemDetailDAO().delete(sysDocId.toString());
        if (itemDetails != null) {
            for (int i = 0; i < itemDetails.length; i++) {
                ItemDetailId detailId = new ItemDetailId();
                detailId.setSysDocId(sysDocId);
                detailId.setLineNumber(new Integer(i + 1));
                itemDetails[i].setId(detailId);
                getItemDetailDAO().create(itemDetails[i]);
            }
        }
    }

    public void sendDocumentToChamber(Integer moduleId, String exporterReference, String printTemplate, String deliveryMode, String noOfCopies, String requestedTargetDate, byte[] pdfContent) throws HttpException, InvalidArgumentException, IOException {
        Person person = getPersonDAO().getPerson(this.siteId, this.userId);
        Module module = getModuleDAO().getModule(moduleId);
        String deploymentURL = module.getDeploymentUrl();
        if(!GenericValidator.isBlankOrNull(deploymentURL)){
        	String invokingURL = deploymentURL;
        	if(deploymentURL.indexOf("login.do") != -1){
        		invokingURL = deploymentURL.substring(0, deploymentURL.indexOf("login.do"));
        	}
        	invokingURL += "submitDocument";
        	log("invokingURL: "+invokingURL);
        	invokeChamberModule(invokingURL, person.getUniqueUserRef(), exporterReference, printTemplate, deliveryMode, noOfCopies, requestedTargetDate, pdfContent, module.getModuleDescription());
        }
    }
    
	private void invokeChamberModule(String invokingURL, Long uniqueUserRef, String exporterReference, String printTemplate, String deliveryMode, String noOfCopies, String requestedTargetDate, byte[] pdfContent, String moduleDesc) throws HttpException, IOException, InvalidArgumentException{
	    HttpClient client = new HttpClient();
	    PostMethod post = new PostMethod(invokingURL);
	    String tempFilePath = System.getProperty("user.dir") + File.separator + "Temp.pdf";
        File tempFile = new File(tempFilePath);  
        FileUtils.writeByteArrayToFile(tempFile, pdfContent);
        List parts = new ArrayList();
        parts.add(new FilePart("file", tempFile.getName(), tempFile));
        parts.add(new StringPart("authId", "@#123)9%!(Yt_0"));
        parts.add(new StringPart("authType", "@#123)9%!(Yt_0"));
        parts.add(new StringPart("siteId", this.siteId));
        parts.add(new StringPart("userId", this.userId));
        parts.add(new StringPart("uniqueUserRef", uniqueUserRef.toString()));
        parts.add(new StringPart("exporterReference", exporterReference));
        parts.add(new StringPart("printTemplate", printTemplate));
        parts.add(new StringPart("deliveryMode", deliveryMode));
        parts.add(new StringPart("noOfCopies", noOfCopies));
        parts.add(new StringPart("requestedTargetDate", requestedTargetDate));
        MultipartRequestEntity multipartRequestEntity = new MultipartRequestEntity(((Part[]) parts.toArray(new Part[parts.size()])), post.getParams());
        post.setRequestEntity(multipartRequestEntity);
        post.setRequestHeader("Content-length", "" + multipartRequestEntity.getContentLength());
        int status = client.executeMethod(post);
        log("HttpStatus:  "+status);
        if (HttpStatus.SC_OK == status) {
            log("Export document send successfully to: "+moduleDesc);         
        }else{
            log("Problem occured while sending document to: "+moduleDesc);
            throw new InvalidArgumentException("Problem occured while sending document to: "+moduleDesc);
        }
        tempFile.delete();
        post.releaseConnection();    
	}

	public void deleteDerivedDocument(String sysDocId) throws InvalidArgumentException {
	  ExportDocument exportDocument = getExportDocumentDAO().get(siteId, userId, sysDocId);
	  getPackingListItemDetailDAO().delete(sysDocId);
	  getPackingListDAO().delete(sysDocId);
	  getExportDocumentDAO().delete(exportDocument);
		
	}
}