package docprep.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import dev.zing.framework.services.exception.application.dao.RecordNotFoundException;
import dev.zing.framework.services.validation.ValidationError;
import dev.zing.framework.services.validation.ValidationErrors;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.PackingListManager;
import docprep.src.dto.PackingList;

public class PackingListManagerImpl extends BTOBase implements PackingListManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();

    }

    public PackingList get(String sysDocId, Integer packingListId) throws InvalidArgumentException {

        if (packingListId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.PackingListId");
            invalidArgumentException.setErrorOzCode("system.errors.PackingListId");
            throw invalidArgumentException;
        }
        PackingList dto = null;
        dto = getPackingListDAO().get(sysDocId);

        return dto;
    }

    public PackingList create(PackingList criteria) throws InvalidArgumentException, DuplicateRecordException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.PackingList");
            invalidArgumentException.setErrorOzCode("system.errors.PackingList");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        PackingList packingList = getPackingListDAO().get(criteria.getSysDocId().toString(), criteria.getPackingListId());
        if (packingList != null) {
            ValidationError error = new ValidationError();
            error.setPropertyName("packingListId");
            error.setErrorCode("OZA-80003-13");
            error.setErrorMessage("Duplicate  PackingListId is NOT allowed.");
            ValidationErrors errores = new ValidationErrors();
            errores.addValidationError("packingListId", error);
            throw new InvalidArgumentException(errores);
        }

        getPackingListDAO().create(criteria);
        return criteria;
    }

    public PackingList update(PackingList criteria) throws InvalidArgumentException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.PackingList");
            invalidArgumentException.setErrorOzCode("system.errors.PackingList");
            throw invalidArgumentException;
        }
        ValidationErrors validationErrors = criteria.validate();
        if (validationErrors != null) {
            System.out.println("Number of errors:- " + validationErrors.getValidationErrors().size());
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException(validationErrors);
            throw invalidArgumentException;
        }
        getPackingListDAO().update(criteria);

        return criteria;
    }

    public boolean delete(Integer packingListId) throws RecordNotFoundException, InvalidArgumentException {

        if (packingListId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.packingListId");
            throw invalidArgumentException;
        }
        boolean result = false;
        PackingList packingList = null;

        packingList = getPackingListDAO().get(packingList.getSysDocId().toString(), packingList.getPackingListId());

        getPackingListDAO().delete(packingList.getSysDocId().toString());
        result = true;

        return result;
    }

}