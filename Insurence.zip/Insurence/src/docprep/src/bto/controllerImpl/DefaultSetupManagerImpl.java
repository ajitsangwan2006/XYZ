package docprep.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import userlookup.src.dto.ClausesUserLookup;
import userlookup.src.dto.CurrencyUserLookup;
import userlookup.src.dto.TradingPartnerLookup;
import codemaintenance.src.dto.CountryLookup;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.DefaultSetupManager;
import docprep.src.dto.DefaultSetup;
import docprep.src.dto.DefaultSetupId;
import docprep.src.dto.MasterDocument;

public class DefaultSetupManagerImpl extends BTOBase implements DefaultSetupManager {

    private PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String siteId, String userId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.userId = userId;
        this.siteId = siteId;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public DefaultSetup getDefaultSetup() {
        DefaultSetup defaultSetup = null;
        defaultSetup = getDefaultSetupDAO().getDefaultSetup(new DefaultSetupId(this.siteId, this.userId));
        return defaultSetup;
    }

    public void updateDefaultSetup(DefaultSetup defaultSetup) throws InvalidArgumentException {
        if (defaultSetup == null) {
            throw new InvalidArgumentException("DefaultSetup connot be null.");
        }
        defaultSetup.getId().setSiteId(this.siteId);
        defaultSetup.getId().setUserId(this.userId);

        System.err.println("DefaultSetup is going to be saved");
        DefaultSetup defaultSetupDB = getDefaultSetup();
        System.err.println("defaultSetup" + defaultSetup.getId());

        if (defaultSetupDB != null) {
            defaultSetup.setDefaultDocId(defaultSetupDB.getDefaultDocId());
            defaultSetup.setCurrentDocId(defaultSetupDB.getCurrentDocId());
        } else {
            defaultSetup.setDefaultDocId(new Integer(10000000));
            defaultSetup.setCurrentDocId(new Integer(1));
        }
        getDefaultSetupDAO().updateDefaultSetup(defaultSetup);
    }

    public MasterDocument getDefaultValues() throws InvalidArgumentException {
        DefaultSetup defaultSetup = getDefaultSetupDAO().getDefaultSetup(new DefaultSetupId(this.siteId, this.userId));
        MasterDocument masterDocument = new MasterDocument();
        if (defaultSetup != null) {
            if (defaultSetup.getDefaultDocIdFlag() != null && defaultSetup.getDefaultDocIdFlag().intValue() == 0) {
                if (defaultSetup.getDefaultDocId() != null) {
                    masterDocument.setDocId(String.valueOf(defaultSetup.getDefaultDocId().intValue()));
                    defaultSetup.setDefaultDocId(new Integer(defaultSetup.getDefaultDocId().intValue() + 1));
                    getDefaultSetupDAO().updateDefaultSetup(defaultSetup);
                }
            } else if (defaultSetup.getDefaultDocIdFlag() != null && defaultSetup.getDefaultDocIdFlag().intValue() == 1) {
                String exporterRefBeginsWith = defaultSetup.getDocIdBeginsWith() != null ? defaultSetup.getDocIdBeginsWith() : "";
                if (defaultSetup.getCurrentDocId() != null) {
                    String currentExporterRef = "" + defaultSetup.getCurrentDocId();
                    masterDocument.setDocId(exporterRefBeginsWith + currentExporterRef);
                    defaultSetup.setCurrentDocId(new Integer(defaultSetup.getCurrentDocId().intValue() + 1));
                    getDefaultSetupDAO().updateDefaultSetup(defaultSetup);
                } else {
                    masterDocument.setDocId(exporterRefBeginsWith);
                }
            } else if (defaultSetup.getDefaultDocIdFlag() != null && defaultSetup.getDefaultDocIdFlag().intValue() == 2) {
                masterDocument.setDocId("");
            }
            getDefaultDestinationCountry(defaultSetup.getCountryCode(), masterDocument);
            getDefaultPartyType(defaultSetup.getBuyerId(), masterDocument, "buyer");
            getDefaultPartyType(defaultSetup.getForwardingAgentId(), masterDocument, "agent");
            getDefaultPartyType(defaultSetup.getConsigneeId(), masterDocument, "consignee");
            getDefaultPartyType(defaultSetup.getManufacturerId(), masterDocument, "manufacturer");
            getDefaultPartyType(defaultSetup.getExporterId(), masterDocument, "exporter");
            getDefaultCurrency(defaultSetup.getCurrencyCode(), masterDocument);
            getDefaultPort(defaultSetup, masterDocument, "dischargePort");
            getDefaultPort(defaultSetup, masterDocument, "finalDestination");
            getDefaultClauses(defaultSetup.getClauseId(), masterDocument, "additionalClauses");
            getDefaultClauses(defaultSetup.getSpecialConditionsId(), masterDocument, "specialConditions");
            getDefaultClauses(defaultSetup.getClauseId(), masterDocument, "terms");
            masterDocument.setComments((defaultSetup.getComments() != null && defaultSetup.getComments().trim().length() > 0) ? defaultSetup.getComments() : "");
        }
        return masterDocument;
    }

    private void getDefaultClauses(String clauseId, MasterDocument masterDocument, String clauseType) {
        if (clauseId != null && clauseId.trim().length() > 0) {
            ClausesUserLookup clausesUserLookup = getClausesUserLookupDAO().getClausesUserLookup(this.siteId, this.userId, clauseId);
            if (clausesUserLookup != null) {
                if (clauseType.equalsIgnoreCase("additionalClauses")) {
                    masterDocument.setClause1(clausesUserLookup.getLine1());
                    masterDocument.setClause2(clausesUserLookup.getLine2());
                    masterDocument.setClause3(clausesUserLookup.getLine3());
                    masterDocument.setClause4(clausesUserLookup.getLine4());
                    masterDocument.setClause5(clausesUserLookup.getLine5());
                    masterDocument.setClause6(clausesUserLookup.getLine6());
                    masterDocument.setClause7(clausesUserLookup.getLine7());
                    masterDocument.setClause8(clausesUserLookup.getLine8());
                    masterDocument.setClause9(clausesUserLookup.getLine9());
                }
                if (clauseType.equalsIgnoreCase("specialConditions")) {
                    masterDocument.setSpecial1(clausesUserLookup.getLine1());
                    masterDocument.setSpecial2(clausesUserLookup.getLine2());
                    masterDocument.setSpecial3(clausesUserLookup.getLine3());
                    masterDocument.setSpecial4(clausesUserLookup.getLine4());
                    masterDocument.setSpecial5(clausesUserLookup.getLine5());
                }
                if (clauseType.equalsIgnoreCase("terms")) {
                    masterDocument.setTerms(clausesUserLookup.getId().getClauseId());
                    masterDocument.setTermsLine1(clausesUserLookup.getLine1());
                    masterDocument.setTermsLine2(clausesUserLookup.getLine2());
                    masterDocument.setTermsLine3(clausesUserLookup.getLine3());
                    masterDocument.setTermsLine4(clausesUserLookup.getLine4());
                    masterDocument.setTermsLine5(clausesUserLookup.getLine5());
                    masterDocument.setTermsLine6(clausesUserLookup.getLine6());
                }
            }
        }
    }

    private void getDefaultPort(DefaultSetup defaultSetup, MasterDocument masterDocument, String portString) {
        if (portString.equalsIgnoreCase("dischargePort")) {            
            masterDocument.setPortofDischargeCode(defaultSetup.getPortCode());
            masterDocument.setPortofDischargeIsoCode(defaultSetup.getIsoCode());
            masterDocument.setPortofDischarge1(defaultSetup.getPortofDischarge1());
            masterDocument.setPortofDischarge2(defaultSetup.getPortofDischarge2());
        }
        if (portString.equalsIgnoreCase("finalDestination")) {            
            masterDocument.setFinalDestCode(defaultSetup.getFinalDestCode());
            masterDocument.setFinalDestIsoCode(defaultSetup.getFinalDestIsoCode());
            masterDocument.setFinalDestination1(defaultSetup.getFinalDestination1());
            masterDocument.setFinalDestination2(defaultSetup.getFinalDestination2());
        }
    }

    private void getDefaultCurrency(String currencyCode, MasterDocument masterDocument) {
        if (currencyCode != null && currencyCode.trim().length() > 0) {
            CurrencyUserLookup currencyUserLookup = getCurrencyUserLookupDAO().getCurrencyLookup(currencyCode);
            if (currencyUserLookup != null) {
                masterDocument.setExchangeRate(currencyUserLookup.getExchangeRate());
                masterDocument.setCurrencyCode(currencyCode);
            }
        }
    }

    public void getDefaultDestinationCountry(String countryCode, MasterDocument masterDocument) throws InvalidArgumentException {
        if (countryCode != null && countryCode.trim().length() > 0) {
            CountryLookup countryLookup = getCountryLookupDAO().getCountryCode2(countryCode);
            if (countryLookup != null) {
                masterDocument.setCountryDestCode(countryLookup.getCountryCode2());
                masterDocument.setCountryofdestination(countryLookup.getCountryName());
            }
        }
    }

    public void getDefaultPartyType(String partnerId, MasterDocument masterDocument, String partyType) throws InvalidArgumentException {
        if (partnerId != null && partnerId.trim().length() > 0) {
            TradingPartnerLookup tradingPartnerLookup = new TradingPartnerLookup();
            tradingPartnerLookup.getId().setSiteId(this.siteId);
            tradingPartnerLookup.getId().setPartnerId(partnerId);
            tradingPartnerLookup = getTradingPartnerLookupDAO().get(tradingPartnerLookup.getId());
            if (tradingPartnerLookup != null) {
                if (partyType.equalsIgnoreCase("buyer")) {
                    masterDocument.setBuyerName(tradingPartnerLookup.getName());
                    masterDocument.setBuyerStreetNo(tradingPartnerLookup.getStreetNo());
                    masterDocument.setBuyerStreetName(tradingPartnerLookup.getStreetName());
                    masterDocument.setBuyerCity(tradingPartnerLookup.getCity());
                    masterDocument.setBuyerState(tradingPartnerLookup.getState());
                    masterDocument.setBuyerCountry(tradingPartnerLookup.getCountry());
                }
                if (partyType.equalsIgnoreCase("agent")) {
                    masterDocument.setAgentName(tradingPartnerLookup.getName());
                    masterDocument.setAgentStreetNo(tradingPartnerLookup.getStreetNo());
                    masterDocument.setAgentStreetName(tradingPartnerLookup.getStreetName());
                    masterDocument.setAgentCity(tradingPartnerLookup.getCity());
                    masterDocument.setAgentState(tradingPartnerLookup.getState());
                    masterDocument.setAgentCountry(tradingPartnerLookup.getCountry());
                }
                if (partyType.equalsIgnoreCase("consignee")) {
                    masterDocument.setConsigneeName(tradingPartnerLookup.getName());
                    masterDocument.setConsigneeStreetNo(tradingPartnerLookup.getStreetNo());
                    masterDocument.setConsigneeStreetName(tradingPartnerLookup.getStreetName());
                    masterDocument.setConsigneeCity(tradingPartnerLookup.getCity());
                    masterDocument.setConsigneeState(tradingPartnerLookup.getState());
                    masterDocument.setConsigneeCountry(tradingPartnerLookup.getCountry());
                }
                if (partyType.equalsIgnoreCase("manufacturer")) {
                    masterDocument.setManufacturerName(tradingPartnerLookup.getName());
                    masterDocument.setManufacturerStreetNo(tradingPartnerLookup.getStreetNo());
                    masterDocument.setManufacturerStreetName(tradingPartnerLookup.getStreetName());
                    masterDocument.setManufacturerCity(tradingPartnerLookup.getCity());
                    masterDocument.setManufacturerState(tradingPartnerLookup.getState());
                    masterDocument.setManufacturerCountry(tradingPartnerLookup.getCountry());
                }
                if (partyType.equalsIgnoreCase("exporter")) {
                    masterDocument.setExporterName(tradingPartnerLookup.getName());
                    masterDocument.setExporterAbnNo(tradingPartnerLookup.getAbnNo());
                    masterDocument.setExporterStreetNo(tradingPartnerLookup.getStreetNo());
                    masterDocument.setExporterStreetName(tradingPartnerLookup.getStreetName());
                    masterDocument.setExporterCity(tradingPartnerLookup.getCity());
                    masterDocument.setExporterState(tradingPartnerLookup.getState());
                    masterDocument.setExporterCountry(tradingPartnerLookup.getCountry());
                }
            }
        }
    }
}