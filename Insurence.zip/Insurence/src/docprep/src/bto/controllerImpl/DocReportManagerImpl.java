package docprep.src.bto.controllerImpl;

import java.util.List;
import usermgmt.src.dto.Person;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.controller.DocReportManager;
import docprep.src.bto.report.ReportGenerator;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ExportDocument;
import docprep.src.dto.ForwardingList;
import docprep.src.dto.ItemDetail;
import docprep.src.dto.MasterDocument;
import docprep.src.dto.PackageDetail;
import docprep.src.dto.PackingList;
import docprep.src.dto.PackingListItemDetail;
import docprep.src.dto.UserReportTO;
import docprep.src.listhelper.ExportDocumentListHelper;
import docprep.src.reports.ReportDsioBuilderUtil;
import docprep.src.reports.dsio.ForwardingInstructionsDSIO;
import docprep.src.reports.dsio.PackingListDSIO;
import docprep.src.reports.impls.DerivedDocumentPrintImpl;
import docprep.src.reports.interfaces.DocumentPrint;


public class DocReportManagerImpl extends BTOBase implements DocReportManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String siteId;

    private String userId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String siteId, String userId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.siteId = siteId;
        this.userId = userId;
        this.ipAddress = ipAddress;
    }

    public byte[] getReportBytes(String sysDocId, String docTypeCode) throws InvalidArgumentException {
        System.err.println("INSIDE getReportBytes - sysDocId : " + sysDocId);
        System.err.println("INSIDE getReportBytes - docTypeCode : " + docTypeCode);

        DerivedDocument derivedDocument = getDeriveDocumentDetails(sysDocId, docTypeCode);

        System.err.println("getReportBytes DerivedDocument ret: " + derivedDocument.getHeader().getParentId());

        MasterDocument masterDocument = getMasterDocDetails(derivedDocument.getHeader().getParentId().toString());
        ReportDsioBuilderUtil builderUtil = new ReportDsioBuilderUtil(masterDocument, derivedDocument);

        DocumentPrint documentPrint = new DerivedDocumentPrintImpl();
        byte[] reportBytes = null;
        if (docTypeCode.equalsIgnoreCase("PackingList")) {
            PackingListDSIO packingListDSIO = builderUtil.buildPackingListDSIO();
            reportBytes = documentPrint.getPackingListBytes(packingListDSIO);
        } else if (docTypeCode.equalsIgnoreCase("ForwardingInstructions")) {
            ForwardingInstructionsDSIO forwardingInstructionsDSIO = builderUtil.buildForwardingInstructionsDSIO();
            reportBytes = documentPrint.getForwardingInstructionBytes(forwardingInstructionsDSIO);
        }
        return reportBytes;
    }

    public byte[] getMasterReportAsPDF(String sysDocId, int printTemplateId) throws InvalidArgumentException {
        if (sysDocId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.sysDocId");
            invalidArgumentException.setErrorOzCode("system.errors.sysDocId");
            throw invalidArgumentException;
        }
        String fileName = null;
        MasterDocument masterDocument = getMasterDocDetails(sysDocId);
        byte[] pdfBytes = new byte[0];
        try {

            if (masterDocument != null) {
                ReportGenerator printReportFile = new ReportGenerator();
                masterDocument.setOriginalOrCopy("ORIGINAL");
                pdfBytes = printReportFile.printMasterDocReport(masterDocument, printTemplateId);
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return pdfBytes;
    }

    private boolean sendReportSummary(String subject, String emailAddress, String userMessage, String fileName) {
        return false;
    }

    public boolean sendEndUserReport(String subject, UserReportTO reportTo) throws InvalidArgumentException {
        if (reportTo == null || reportTo.getEmailId().trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.EmailId");
            invalidArgumentException.setErrorOzCode("system.errors.EmailId");
        }
        List list = null;
        boolean result = false;
        List listItems = null;
        ExportDocumentListHelper criteria = new ExportDocumentListHelper();
        Person person = getPersonDAO().getPerson(siteId, userId);
        if (person.getUserType().equalsIgnoreCase("M")) {
            criteria.setSiteId(this.siteId);
        } else {
            criteria.setSiteId(this.siteId);
            criteria.setUserId(this.userId);
        }
        if (reportTo.getDocTypeCode().trim().length() > 0) {
            criteria.setDocTypeCode(reportTo.getDocTypeCode());
        } else {
            //criteria.setExceptMaster(true);
            criteria.setDocTypeCode("MasterDocument");
            //criteria.setEndUserderivedDocumentFlag(true);
        }
        if (reportTo.getSysDocId() != null && reportTo.getSysDocId().intValue() > 0) {
            criteria.setSysDocId(reportTo.getSysDocId());
            // criteria.setEndUserderivedDocumentFlag(true);
        }

        list = getExportDocumentDAO().getList(criteria, -1, -1).getCurrentPageData();
        //   **************** Functionality is in process *******************
        // ////////////////
        //GenerateXLSFile fileGenerator = new GenerateXLSFile();
        //String fileName = fileGenerator.generateMasterReportFile(list);
        // result = sendReportSummary(subject, reportTo.getEmailId(),
        // reportTo.getMsg(), fileName);

        return result;
    }

    private MasterDocument getMasterDocDetails(String sysDocId) throws InvalidArgumentException {
        MasterDocument masterDocument = null;
        masterDocument = getMasterDocumentDAO().get(sysDocId);
        List packageDetailList = getPackageDetailDAO().get(sysDocId);
        PackageDetail[] packageDetails = (PackageDetail[]) packageDetailList.toArray(new PackageDetail[packageDetailList.size()]);
        masterDocument.setPackageDetails(packageDetails);
        List itemDetailList = getItemDetailDAO().get(sysDocId);
        ItemDetail[] itemDetails = (ItemDetail[]) itemDetailList.toArray(new ItemDetail[itemDetailList.size()]);
        masterDocument.setItemDetails(itemDetails);
        return masterDocument;
    }

    private DerivedDocument getDeriveDocumentDetails(String sysDocId, String docTypeCode) throws InvalidArgumentException {
        DerivedDocument derivedDocument = new DerivedDocument();
        ExportDocument exportDocument = getExportDocumentDAO().get(this.siteId, this.userId, sysDocId);
        derivedDocument.setHeader(exportDocument);
        if (docTypeCode != null && docTypeCode.equalsIgnoreCase("PackingList")) {
            PackingList packingList = null;
            packingList = getPackingListDAO().get(sysDocId);
            List packingListItemDetailList = getPackingListItemDetailDAO().get(sysDocId);
            PackingListItemDetail[] packagelistItemDetail = (PackingListItemDetail[]) packingListItemDetailList.toArray(new PackingListItemDetail[packingListItemDetailList.size()]);
            packingList.setPackingListItemDetails(packagelistItemDetail);
            derivedDocument.setBody(packingList);
        } else if (docTypeCode != null && docTypeCode.equalsIgnoreCase("ForwardingInstructions")) {
            ForwardingList forwardingList = null;
            forwardingList = getForwardingListDAO().get(sysDocId);
            derivedDocument.setBody(forwardingList);
        }
        return derivedDocument;
    }

}