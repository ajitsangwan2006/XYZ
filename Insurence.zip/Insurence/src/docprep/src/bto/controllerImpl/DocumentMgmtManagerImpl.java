package docprep.src.bto.controllerImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.controller.ExportDocumentManager;
import docprep.src.bto.controller.DocReportManager;
import docprep.src.bto.controller.DocumentMgmtManager;

import docprep.src.bto.base.SpringFactoryUtil;


public class DocumentMgmtManagerImpl extends BTOBase implements DocumentMgmtManager {

    private dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder = null;

    private int pageScrollValue;

    private String siteId;

    private String userId;
    
    private String ipAddress;

    public void initialize(int pageScrollValue, dev.zing.framework.businesstier.listpages.PageHandlerHolder pageHandlerHolder, String siteId, String userId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.siteId = siteId;
        this.userId = userId;
        this.ipAddress = ipAddress;

    }

    public DocReportManager getDocReportManager() {
    	ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory(); 
    	DocReportManagerImpl docReportManagerImpl = (DocReportManagerImpl) springFactory.getBean("docReportManager"); 
    	docReportManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
    	return docReportManagerImpl;
    }
    public ExportDocumentManager getExportDocumentManager() {
		ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
		ExportDocumentManagerImpl exportDocumentManagerImpl = (ExportDocumentManagerImpl) springFactory.getBean("exportDocumentManager");
        exportDocumentManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return exportDocumentManagerImpl;
	}

}