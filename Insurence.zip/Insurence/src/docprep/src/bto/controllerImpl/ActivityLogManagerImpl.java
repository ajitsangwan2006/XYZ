package docprep.src.bto.controllerImpl;

import java.util.Date;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.valueListHandler.ActivityLogPageDAOProvider;
import docprep.src.dto.Activitylog;
import docprep.src.listhelper.ActivityLogListHelper;
import dev.zing.framework.businesstier.listpages.PageHandler;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public class ActivityLogManagerImpl extends BTOBase implements ActivityLogManager {

    private PageHandlerHolder pageHandlerHolder;

    private int pageScrollValue;

    private String userId;

    private String siteId;

    private String ipAddress;

    public void initialize(int pageScrollValue, PageHandlerHolder pageHandlerHolder, String userId, String siteId, String ipAddress) {
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        this.userId = userId;
        this.siteId = siteId;
    }

    public PageHandler getActivityLogList(ActivityLogListHelper criteria) {
        if (criteria == null) {
            criteria = new ActivityLogListHelper();
        }

        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ActivityLogPageDAOProvider activityLogPageDAOProvider = (ActivityLogPageDAOProvider) springFactory.getBean("activityLogPageDAOProvider");
        return getPageHandler(pageHandlerHolder, criteria, activityLogPageDAOProvider, pageScrollValue);
    }

    public void addActivityLogEntry(Activitylog criteria) throws InvalidArgumentException {
        if (criteria == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("Argument cannot be null.");
            throw invalidArgumentException;
        }
        criteria.setUserId(this.userId);
        criteria.setSiteId(this.siteId);
        criteria.setIpaddress(this.ipAddress);
        criteria.setActivityDate(new Date());
        getActivityLogDAO().create(criteria);
    }

}
