package docprep.src.bto.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.validator.GenericValidator;

import com.ibm.ws.sib.admin.exception.InvalidArgumentException;
import com.lowagie.text.DocumentException;

import dev.zing.framework.util.PDFAppend;
import docprep.src.dto.ItemDetail;
import docprep.src.dto.MasterDocument;
import docprep.src.dto.PackageDetail;
import docprep.src.reports.MasterDocReportDataSource;
import docprep.src.reports.dsio.MasterDocDSIO;
import docprep.src.services.util.BarcodeGenerator;

public class ReportGenerator {
    private ReportGenerator printDocumentReportPdf;

    private final int FIRST_PAGE_ROW_COUNT = 16;

    private final int CONTINUATION_PAGE_ROW_COUNT = 32;

    private double bfwdForContinuation;

    public ReportGenerator() {
        bfwdForContinuation = 0.00;
    }

    public byte[] printMasterDocReport(MasterDocument masterDocTO, int printTemplateId) throws InvalidArgumentException, IllegalAccessException, InvocationTargetException, JRException, DocumentException, IOException {
        int totalPages = 1;
        PDFAppend pdfAppend = new PDFAppend();
        byte[] allContPageBytes = null;
        ItemDetail[] itemDetails = masterDocTO.getItemDetails();
        if (itemDetails != null && itemDetails.length > FIRST_PAGE_ROW_COUNT) {
            int totalCount = itemDetails.length;
            int contLineCount = totalCount - FIRST_PAGE_ROW_COUNT;
            int remainder = contLineCount % CONTINUATION_PAGE_ROW_COUNT;
            int noOfContPages = contLineCount / CONTINUATION_PAGE_ROW_COUNT;
            noOfContPages = remainder > 0 ? ++noOfContPages : noOfContPages;
            totalPages += noOfContPages;

            int startRow = FIRST_PAGE_ROW_COUNT;
            int rowCount = 0;
            for (int i = 0; i < noOfContPages; i++) {
                rowCount = (startRow + (CONTINUATION_PAGE_ROW_COUNT - 1)) <= totalCount ? CONTINUATION_PAGE_ROW_COUNT : (totalCount - startRow);
                byte[] contPageBytes = getContinuationPageBytes(masterDocTO, startRow, rowCount, (i + 2), totalPages, printTemplateId);
                if (allContPageBytes == null) {
                    allContPageBytes = contPageBytes;
                } else {
                    allContPageBytes = pdfAppend.appendFiles(allContPageBytes, contPageBytes);
                }
                startRow = startRow + rowCount;
            }
        }
        byte[] firstPage = getFirstPageBytes(masterDocTO, 1, totalPages, printTemplateId);
        byte[] finalBytes = null;
        if (allContPageBytes != null) {
            finalBytes = pdfAppend.appendFiles(firstPage, allContPageBytes);
        } else {
            finalBytes = firstPage;
        }
        return finalBytes;
    }

    public byte[] getFirstPageBytes(MasterDocument masterDocTO, int thisPageNo, int totalPages, int printTemplateId) throws InvalidArgumentException, IllegalAccessException, InvocationTargetException, JRException, IOException {
        MasterDocDSIO masterDocDSIO = new MasterDocDSIO();        
        BeanUtils.copyProperties(masterDocDSIO, masterDocTO);        
        BarcodeGenerator barCodeGen = new BarcodeGenerator(masterDocTO.getSysDocId());
        byte[] bytesImgage = barCodeGen.getBarCodeBytes();
        InputStream imageInputStream = new ByteArrayInputStream(bytesImgage);
        masterDocDSIO.setImageName(imageInputStream);
        masterDocDSIO.setTotalNumberOfPages("Page " + thisPageNo + " of " + totalPages);
        setPackageDetails(masterDocDSIO, masterDocTO);
        int rowCountForFirstPage = 16;
        if (masterDocTO.getItemDetails() != null && masterDocTO.getItemDetails().length < 16) {
            rowCountForFirstPage = masterDocTO.getItemDetails().length;
        }
        setItemDetails(masterDocDSIO, masterDocTO, 0, rowCountForFirstPage);
        ItemDetail[] itemDetails = masterDocTO.getItemDetails();
        double bfwd = 0.00;        
        if (itemDetails != null) {
            for (int i = 0; i < itemDetails.length && i < 16; i++) {
                if (itemDetails[i] != null && itemDetails[i].getTotalPrice() != null) {
                    try {
                        bfwd = bfwd + Double.parseDouble(itemDetails[i].getTotalPrice());
                    } catch (NumberFormatException e) {
                    }
                }
            }            
            if (!GenericValidator.isBlankOrNull(masterDocTO.getInvoiceSubtotal())) {
                bfwd = Double.parseDouble(masterDocTO.getInvoiceSubtotal()) - bfwd;
            }
        }        
        masterDocDSIO.setBfwd("" + bfwd);        
        return getPDFBytesFromJasper(getJasperClasspathForFirstPage(printTemplateId), masterDocDSIO);
    }

    public byte[] getContinuationPageBytes(MasterDocument masterDocTO, int startRow, int rowCount, int thisPageNo, int totalPages, int printTemplateId) throws InvalidArgumentException, IllegalAccessException, InvocationTargetException, JRException, IOException {
        MasterDocDSIO masterDocDSIO = new MasterDocDSIO();
        BeanUtils.copyProperties(masterDocDSIO, masterDocTO);
        BarcodeGenerator barCodeGen = new BarcodeGenerator(masterDocTO.getSysDocId());
        byte[] bytesImgage = barCodeGen.getBarCodeBytes();
        InputStream imageInputStream = new ByteArrayInputStream(bytesImgage);
        masterDocDSIO.setImageName(imageInputStream);
        masterDocDSIO.setTotalNumberOfPages("Page " + thisPageNo + " of " + totalPages);
        masterDocDSIO.setContinuationPageNo("" + (thisPageNo - 1));
        masterDocDSIO.setContinuationTotalPageNo("" + (totalPages - 1));
        setPackageDetails(masterDocDSIO, masterDocTO);
        setItemDetails(masterDocDSIO, masterDocTO, startRow, rowCount);
        double totalThisPage = 0.00;
        ItemDetail[] itemDetails = masterDocTO.getItemDetails();
        for (int i = startRow; i < (startRow + rowCount); i++) {
            if (itemDetails[i] != null && itemDetails[i].getTotalPrice() != null) {
                totalThisPage = totalThisPage + Double.parseDouble(itemDetails[i].getTotalPrice());
            }
        }
        masterDocDSIO.setTotalThisPage("" + totalThisPage);
        masterDocDSIO.setBfwd("" + bfwdForContinuation);
        double totalCarriedForward = totalThisPage + bfwdForContinuation;
        masterDocDSIO.setCarriedForward("" + totalCarriedForward);
        bfwdForContinuation = totalCarriedForward;
        masterDocDSIO.setBfwdLabel("BFWD");
        masterDocDSIO.setReportTitle(getContinuationReportTitle(printTemplateId));        
        return getPDFBytesFromJasper(getJasperClasspathForContinuationPage(printTemplateId), masterDocDSIO);
    }

    public byte[] getPDFBytesFromJasper(String jasperClasspath, MasterDocDSIO masterDocDSIO) throws JRException, IOException {
        MasterDocReportDataSource masterDocReportDataSource = new MasterDocReportDataSource(masterDocDSIO);
        InputStream fs = this.getClass().getResourceAsStream(jasperClasspath);
        JasperPrint print = JasperFillManager.fillReport(fs, new HashMap(), masterDocReportDataSource.create(null));
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        JasperExportManager.exportReportToPdfStream(print, output);
        byte[] pdfBytes = output.toByteArray();
        output.close();
        fs.close();
        return pdfBytes;
    }

    private void copyImages(MasterDocDSIO masterDocDSIO) {
        /*InputStream checkedImage = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "reports" + File.separator + "jasper" + File.separator + "checked.gif");
        masterDocDSIO.setCheckedImage(checkedImage);
        InputStream uncheckedImage = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "reports" + File.separator + "jasper" + File.separator + "unchecked.gif");
        masterDocDSIO.setUncheckedImage(uncheckedImage);*/
    }

    private MasterDocDSIO setItemDetails(MasterDocDSIO masterDocDSIO, MasterDocument masterDocTO, int startRow, int rowCount) {
        masterDocDSIO.setQuantityLabel(GenericValidator.isBlankOrNull(masterDocTO.getQtyDescription()) ? "QUANTITY" : ("QUANTITY " + "(" + masterDocTO.getQtyDescription() + ")"));
        masterDocDSIO.setUnitPriceLabel(GenericValidator.isBlankOrNull(masterDocTO.getPriceDescription()) ? "UNIT PRICE" : ("UNIT PRICE " + "(" + masterDocTO.getPriceDescription() + ")"));

        ItemDetail[] itemDetails = masterDocTO.getItemDetails();
        if (itemDetails != null) {
            int j = 1;
            for (int i = startRow; i <= (startRow + rowCount) - 1; i++, j++) {
                Class partypes1[] = new Class[1];
                partypes1[0] = String.class;
                Object arglist1[] = new Object[1];
                try {
                    arglist1[0] = itemDetails[i].getProductCode();
                    masterDocDSIO.getClass().getMethod("setProductCode" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = itemDetails[i].getDescription();
                    masterDocDSIO.getClass().getMethod("setDescription" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = itemDetails[i].getQuantity();
                    masterDocDSIO.getClass().getMethod("setQuantity" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = itemDetails[i].getUnitPrice();
                    masterDocDSIO.getClass().getMethod("setUnitPrice" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = itemDetails[i].getTotalPrice();
                    masterDocDSIO.getClass().getMethod("setTotalPrice" + j, partypes1).invoke(masterDocDSIO, arglist1);
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return masterDocDSIO;
    }

    private MasterDocDSIO setPackageDetails(MasterDocDSIO masterDocDSIO, MasterDocument masterDocTO) {
        PackageDetail[] packageDetails = masterDocTO.getPackageDetails();
        if (packageDetails != null) {
            for (int i = 0; i < packageDetails.length; i++) {
                int j = i + 1;
                Class partypes1[] = new Class[1];
                partypes1[0] = String.class;
                Object arglist1[] = new Object[1];
                try {
                    arglist1[0] = packageDetails[i].getMarks();
                    masterDocDSIO.getClass().getMethod("setMarks" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = packageDetails[i].getDescriptionofgoods();
                    masterDocDSIO.getClass().getMethod("setDescriptionofgoods" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = packageDetails[i].getPckg();
                    masterDocDSIO.getClass().getMethod("setPckg" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = packageDetails[i].getGrossMass();
                    masterDocDSIO.getClass().getMethod("setGrossMass" + j, partypes1).invoke(masterDocDSIO, arglist1);
                    arglist1[0] = packageDetails[i].getCubic();
                    masterDocDSIO.getClass().getMethod("setCubic" + j, partypes1).invoke(masterDocDSIO, arglist1);
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return masterDocDSIO;
    }

    private String getJasperClasspathForFirstPage(int printTemplateId) {
        String jasperName = "";
        if (printTemplateId == 1) {
            jasperName = "MasterDoc.jasper";
        } else if (printTemplateId == 2) {
            jasperName = "AcknowledgementOfOrder.jasper";
        } else if (printTemplateId == 3) {
            jasperName = "CertificateOfInsurance.jasper";
        } else if (printTemplateId == 4) {
            jasperName = "CommercialInvoice_Standard.jasper";
        } else if (printTemplateId == 5) {
            jasperName = "CommercialInvoice_Meat.jasper";
        } else if (printTemplateId == 6) {
            jasperName = "CommercialInvoice_Unrestricted.jasper";
        } else if (printTemplateId == 7) {
            jasperName = "PackingList.jasper";
        } else if (printTemplateId == 8) {
            jasperName = "ProformaInvoice.jasper";
        } else if (printTemplateId == 9) {
            jasperName = "QualityAssurance.jasper";
        } 
        jasperName = "/docprep" + File.separator + "src" + File.separator + "reports" + File.separator + "jasper" + File.separator + jasperName;
        return jasperName;
    }

    private String getJasperClasspathForContinuationPage(int printTemplateId) {
        String jasperName = "";
        if (printTemplateId == 4) {
            jasperName = "CommercialInvoice_Standard_Continuation.jasper";
        } else if (printTemplateId == 6) {
            jasperName = "CommercialInvoice_Unrestricted_Continuation.jasper";
        } else if (printTemplateId == 7) {
            jasperName = "PackingList_Continuation.jasper";
        } else if (printTemplateId == 9) {
            jasperName = "QualityAssurance_Continuation.jasper";
        } else {
            jasperName = "MasterDoc_Continuation.jasper";
        }
        jasperName = "/docprep" + File.separator + "src" + File.separator + "reports" + File.separator + "jasper" + File.separator + jasperName;
        return jasperName;
    }

    private String getContinuationReportTitle(int printTemplateId) {
        String reportTitle = "";
        if (printTemplateId == 1) {
            reportTitle = "MASTER DOCUMENT";
        } else if (printTemplateId == 2) {
            reportTitle = "ACKNOWLEDGEMENT OF ORDER";
        } else if (printTemplateId == 3) {
            reportTitle = "CERTIFICATE OF INSURANCE";
        } else if (printTemplateId == 4) {
            reportTitle = "COMMERCIAL INVOICE";
        } else if (printTemplateId == 5) {
            reportTitle = "COMMERCIAL INVOICE";
        } else if (printTemplateId == 6) {
            reportTitle = "COMMERCIAL INVOICE";
        } else if (printTemplateId == 7) {
            reportTitle = "PACKING LIST";
        } else if (printTemplateId == 8) {
            reportTitle = "PROFORMA INVOICE";
        } else if (printTemplateId == 9) {
            reportTitle = "QUALITY ASSURANCE CERTIFICATE";
        }
        return reportTitle;
    }
}