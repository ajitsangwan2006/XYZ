package docprep.src.bto.valueListHandler;

import dev.zing.framework.businesstier.listhelper.ListHelper;
import dev.zing.framework.businesstier.listpages.PageDAOProvider;
import dev.zing.framework.daotier.listpages.PageDAO;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.handler.DAOExceptionHandler;
import docprep.src.bto.base.BTOBase;
import docprep.src.listhelper.ExportDocumentListHelper;

public class ExportDocumentPageDAOProvider extends BTOBase implements PageDAOProvider {
    public PageDAO getPageDAO(ListHelper criteria, int startRowNo, int pageScrollValue) {
        PageDAO pageDAO = null;
        try {
            pageDAO = getExportDocumentDAO().getList((ExportDocumentListHelper) criteria, startRowNo, pageScrollValue);
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        }
        return pageDAO;
    }

}