package docprep.src.bto.userAccessImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.bto.controller.PersonManager;
import usermgmt.src.bto.controllerImpl.PersonManagerImpl;
import usermgmt.src.dto.Person;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.userAccess.AdminEnvironment;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;

public class AdminEnvironmentImpl extends BTOBase implements AdminEnvironment {

    private Long uniqueUserRef;
    
    private String userId;

    private String siteId;

    private boolean isCertifyAuthorityUser;

    protected PageHandlerHolder pageHandlerHolder;

    protected int pageScrollValue;

    private String ipAddress;

    public void initialize(Long uniqueUserRef, String userId, String siteId, boolean isCertifyAuthorityUser, int pageScrollValue, PageHandlerHolder pageHandlerHolder, String ipAddress) {
        this.uniqueUserRef = uniqueUserRef;
        this.userId = userId;
        this.siteId = siteId;
        this.isCertifyAuthorityUser = isCertifyAuthorityUser;
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public void changePassword(String newPassword) throws InvalidPasswordException, InvalidPasswordException {
        Person user = getPersonDAO().getPerson(this.siteId, this.userId);
        user.setPassword(newPassword);
        getPersonDAO().updatePerson(user);
    }

    public void changeListPageScrollValue(int newscrollValue) throws InvalidArgumentException {
        if (newscrollValue < 1 || newscrollValue > 100) {
            throw new InvalidArgumentException("List Scroll Value should be between 1 and 100.");
        }
        Person user = getPersonDAO().getPerson(this.siteId, this.userId);
        user.setScrollAmount(newscrollValue);
        getPersonDAO().updatePerson(user);
    }

    public Person getMyProfile() {
        Person user = null;
        user = getPersonDAO().getPerson(this.siteId, this.userId);
        return user;
    }

    public void updateMyProfile(Person user) throws InvalidArgumentException, InvalidPasswordException {
        if (user == null) {
            throw new InvalidArgumentException("Enduser connot be null.");
        }
        if (user.getPassword() == null || user.getPassword().trim().length() == 0) {
            throw new InvalidArgumentException("Password or Confirm Password connot be null. Both must have same value");
        }
        if (user.getPassword().trim().length() < 4) {
            throw new InvalidArgumentException("Password cannot be less than 4 digit.");
        }
        if (user.getScrollAmount() == 0) {
            throw new InvalidArgumentException("ScrollAmount cannot be less than 1.");
        }

        changePassword(user.getPassword());

        user.setUserId(this.userId);
        getPersonDAO().updatePerson(user);
    }

    public PersonManager getPersonManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        PersonManagerImpl personupManagerImpl = (PersonManagerImpl) springFactory.getBean("personManager");
        personupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return personupManagerImpl;
    }
  
}
