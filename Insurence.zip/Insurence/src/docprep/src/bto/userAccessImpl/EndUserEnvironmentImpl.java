package docprep.src.bto.userAccessImpl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import userlookup.src.bto.controller.ClausesUserLookupManager;
import userlookup.src.bto.controller.CurrencyUserLookupManager;
import userlookup.src.bto.controller.ProductUserLookupManager;
import userlookup.src.bto.controller.TradingPartnerLookupManager;
import userlookup.src.bto.controllerImpl.ClausesUserLookupManagerImpl;
import userlookup.src.bto.controllerImpl.CurrencyUserLookupManagerImpl;
import userlookup.src.bto.controllerImpl.ProductUserLookupManagerImpl;
import userlookup.src.bto.controllerImpl.TradingPartnerLookupManagerImpl;
import usermgmt.src.bto.controller.CompanyManager;
import usermgmt.src.bto.controller.CompanyModuleManager;
import usermgmt.src.bto.controller.ModuleManager;
import usermgmt.src.bto.controller.PersonManager;
import usermgmt.src.bto.controllerImpl.CompanyManagerImpl;
import usermgmt.src.bto.controllerImpl.CompanyModuleManagerImpl;
import usermgmt.src.bto.controllerImpl.ModuleManagerImpl;
import usermgmt.src.bto.controllerImpl.PersonManagerImpl;
import codemaintenance.src.bto.controller.CountryLookupManager;
import codemaintenance.src.bto.controller.CurrencyLookupManager;
import codemaintenance.src.bto.controller.PortLookupManager;
import codemaintenance.src.bto.controller.VesselLookupManager;
import codemaintenance.src.bto.controllerImpl.CountryLookupManagerImpl;
import codemaintenance.src.bto.controllerImpl.CurrencyLookupManagerImpl;
import codemaintenance.src.bto.controllerImpl.PortLookupManagerImpl;
import codemaintenance.src.bto.controllerImpl.VesselLookupManagerImpl;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.bto.InvalidPasswordException;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.controller.DefaultSetupManager;
import docprep.src.bto.controller.DocReportManager;
import docprep.src.bto.controller.DocumentMgmtManager;
import docprep.src.bto.controllerImpl.ActivityLogManagerImpl;
import docprep.src.bto.controllerImpl.DefaultSetupManagerImpl;
import docprep.src.bto.controllerImpl.DocReportManagerImpl;
import docprep.src.bto.controllerImpl.DocumentMgmtManagerImpl;
import docprep.src.bto.userAccess.EndUserEnvironment;

public class EndUserEnvironmentImpl extends BTOBase implements EndUserEnvironment {

    private Long uniqueUserRef;
    
    private String userId;

    private String siteId;

    private boolean isUser;

    protected PageHandlerHolder pageHandlerHolder;

    protected int pageScrollValue;

    private String ipAddress;

    public void initialize(Long uniqueUserRef, String userId, String siteId, boolean isUser, int pageScrollValue, PageHandlerHolder pageHandlerHolder, String ipAddress) {
        this.uniqueUserRef = uniqueUserRef;
        this.userId = userId;
        this.siteId = siteId;
        this.isUser = isUser;
        this.pageScrollValue = pageScrollValue;
        this.pageHandlerHolder = pageHandlerHolder;
        this.ipAddress = ipAddress;
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    }

    public TradingPartnerLookupManager getTradingPartnerLookupManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        TradingPartnerLookupManagerImpl tradingPartnerLookupManagerImpl = (TradingPartnerLookupManagerImpl) springFactory.getBean("tradingPartnerLookupManager");
        tradingPartnerLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return tradingPartnerLookupManagerImpl;
    }  

    public ActivityLogManager getActivityLogManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ActivityLogManagerImpl activityManagerImpl = (ActivityLogManagerImpl) springFactory.getBean("activityLogManager");
        activityManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return activityManagerImpl;
    }
    
    public PersonManager getPersonManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        PersonManagerImpl personupManagerImpl = (PersonManagerImpl) springFactory.getBean("personManager");
        personupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return personupManagerImpl;
    }

    public CompanyModuleManager getCompanyModuleManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CompanyModuleManagerImpl companyModuleManagerImpl = (CompanyModuleManagerImpl) springFactory.getBean("companyModuleManager");
        companyModuleManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return companyModuleManagerImpl;
    }

    public ModuleManager getModuleManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        ModuleManagerImpl moduleManagerImpl = (ModuleManagerImpl) springFactory.getBean("moduleManager");
        moduleManagerImpl.initialize(this.siteId, this.userId, this.ipAddress, pageScrollValue, pageHandlerHolder);
        return moduleManagerImpl;
    }
    
    public CompanyManager getCompanyManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CompanyManagerImpl companyManagerImpl = (CompanyManagerImpl) springFactory.getBean("companyManager");
        companyManagerImpl.initialize(this.userId, this.siteId, this.ipAddress, pageScrollValue, pageHandlerHolder);
        return companyManagerImpl;
    }

    public DocumentMgmtManager getDocumentMgmtManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        DocumentMgmtManagerImpl documentMgmtManagerImpl = (DocumentMgmtManagerImpl) springFactory.getBean("documentMgmtManager");
        documentMgmtManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
        return documentMgmtManagerImpl;
    }
    
    public CountryLookupManager getCountryLookupManager() {
    	ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CountryLookupManagerImpl countryLookupManagerImpl = (CountryLookupManagerImpl) springFactory.getBean("countryLookupManager");
        countryLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return countryLookupManagerImpl;
	}
   
    
    public PortLookupManager getPortLookupManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        PortLookupManagerImpl portLookupManagerImpl = (PortLookupManagerImpl) springFactory.getBean("portLookupManager");
        portLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return portLookupManagerImpl;
    }
    
    public CurrencyUserLookupManager getCurrencyUserLookupManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CurrencyUserLookupManagerImpl currencyUserLookupManagerImpl = (CurrencyUserLookupManagerImpl) springFactory.getBean("currencyUserLookupManager");
        currencyUserLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return currencyUserLookupManagerImpl;
    }

    public CurrencyLookupManager getCurrencyLookupManager() {
        ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        CurrencyLookupManagerImpl currencyLookupManagerImpl = (CurrencyLookupManagerImpl) springFactory.getBean("currencyLookupManager");
        currencyLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, this.userId, this.siteId, this.ipAddress);
        return currencyLookupManagerImpl;
    }
	
    
    public VesselLookupManager getVesselLookupManager() {
		ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
		VesselLookupManagerImpl vesselLookupManagerImpl = (VesselLookupManagerImpl) springFactory.getBean("vesselLookupManager");
		vesselLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
		return vesselLookupManagerImpl;
	}
    
    public ProductUserLookupManager getProductUserLookupManager() {
		ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
		ProductUserLookupManagerImpl productUserLookupManagerImpl = (ProductUserLookupManagerImpl) springFactory.getBean("productUserLookupManager");
		productUserLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
		return productUserLookupManagerImpl;
	}
    
    public ClausesUserLookupManager getClausesUserLookupManager(){
		ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
		ClausesUserLookupManagerImpl clausesUserLookupManagerImpl = (ClausesUserLookupManagerImpl) springFactory.getBean("clausesUserLookupManager");
		clausesUserLookupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
		return clausesUserLookupManagerImpl;
	}
    
    public DefaultSetupManager getDefaultSetupManager(){
    	ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
    	DefaultSetupManagerImpl defaultSetupManagerImpl = (DefaultSetupManagerImpl) springFactory.getBean("defaultSetupManager");
    	defaultSetupManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
		return defaultSetupManagerImpl;
    }
    
    public DocReportManager getDocReportManager(){
		ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
		DocReportManagerImpl docReportManagerImpl = (DocReportManagerImpl) springFactory.getBean("docReportManager");
		docReportManagerImpl.initialize(pageScrollValue, pageHandlerHolder, siteId, userId, ipAddress);
		return docReportManagerImpl;
	}
    
	public void changePassword(String newPassword) throws InvalidPasswordException {
		// TODO Auto-generated method stub
		
	}

	public void changeListPageScrollValue(int newscrollValue) throws InvalidArgumentException {
		// TODO Auto-generated method stub
		
	}


}
