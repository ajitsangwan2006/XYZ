package docprep.src.bto.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.dto.Company;
import docprep.src.bto.base.SpringFactoryUtil;
import dev.zing.framework.services.exception.application.bto.AuthenticationFailureException;
import dev.zing.framework.services.exception.application.bto.InactiveUserException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;

public class Server {

    public static boolean checkUser(String userId, String password) throws InvalidArgumentException {
        BTOMain btoMain = getBTOMainBean();
        return btoMain.checkUser(userId, password);
    }

    public static SignedInUser login(String userId, String password, String ipAddress) throws InvalidArgumentException, AuthenticationFailureException, InactiveUserException {
        BTOMain btoMain = getBTOMainBean();
        return btoMain.login(userId, password, ipAddress);
    }

    public static boolean isProjectAssigned(String siteId) throws InvalidArgumentException {
        BTOMain btoMain = getBTOMainBean();
        return btoMain.isProjectAssigned(siteId);
    }

    public static Company getCompany(String siteId) throws InvalidArgumentException {
        BTOMain btoMain = getBTOMainBean();
        return btoMain.getCompany(siteId);
    }
    
    public static int getNumberOfUnpaidTaxInvoices(String siteId) throws InvalidArgumentException {
        BTOMain btoMain = getBTOMainBean();
        return btoMain.getNumberOfUnpaidTaxInvoices(siteId);
    }

    private static BTOMain getBTOMainBean() {
    	ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
        System.out.println("TYPE: "+springFactory.getType("btoMain"));
    	BTOMain btoMain = (BTOMain) springFactory.getBean("btoMain"); 
		return btoMain;
	} 
}
