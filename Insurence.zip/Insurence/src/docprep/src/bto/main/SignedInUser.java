package docprep.src.bto.main;

import docprep.src.bto.base.BTOBase;
import docprep.src.bto.userAccess.AdminEnvironment;
import docprep.src.bto.userAccess.EndUserEnvironment;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;


public abstract class SignedInUser extends BTOBase implements dev.zing.framework.webtier.adapter.SignedInUser {	
	 
	 abstract public EndUserEnvironment getEndUserEnvironment() throws AccessDeniedException;
	 
	 abstract public AdminEnvironment getAdminEnvironment() throws AccessDeniedException;
	 	 
	 abstract public boolean isUser(); 	 
	 
	 abstract public boolean isAdmin();
	 
	 abstract public int getPageScrollValue(); 	 	 
}
