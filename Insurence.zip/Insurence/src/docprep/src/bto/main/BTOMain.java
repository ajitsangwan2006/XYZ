package docprep.src.bto.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import usermgmt.src.dto.Company;
import usermgmt.src.dto.Person;
import docprep.src.bto.base.BTOBase;
import docprep.src.bto.base.SpringFactoryUtil;
import docprep.src.bto.controller.ActivityLogManager;
import docprep.src.bto.controllerImpl.ActivityLogManagerImpl;
import docprep.src.dto.Activitylog;
import dev.zing.framework.services.exception.application.bto.AuthenticationFailureException;
import dev.zing.framework.services.exception.application.bto.InactiveUserException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DAOException;
import dev.zing.framework.services.exception.application.dao.InvalidDAOArgumentException;
import dev.zing.framework.services.exception.handler.DAOExceptionHandler;
import dev.zing.framework.services.exception.handler.ProgrammingExceptionHandler;
import dev.zing.framework.services.exception.system.ConfigurationException;

public class BTOMain extends BTOBase {

    private ActivityLogManager activityLogManager;

    public boolean checkUser(String userId, String password) throws InvalidArgumentException {
        String userSiteId = null;
        if (userId == null || userId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.UserId");
            invalidArgumentException.setErrorOzCode("system.errors.UserId");
            throw invalidArgumentException;
        }
        if (password == null || password.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.loginPassword");
            invalidArgumentException.setErrorOzCode("system.errors.loginPassword");
            throw invalidArgumentException;
        }
        try {
            Person personDetails = getPersonDAO().getPerson(userId);
            if (personDetails != null) {
                return true;
            }
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return false;
    }

    public String getSiteId(String userId, String password) throws InvalidArgumentException {
        String userSiteId = null;
        if (userId == null || userId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.UserId");
            invalidArgumentException.setErrorOzCode("system.errors.UserId");
            throw invalidArgumentException;
        }
        if (password == null || password.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.loginPassword");
            invalidArgumentException.setErrorOzCode("system.errors.loginPassword");
            throw invalidArgumentException;
        }
        try {
            Person personDetails = getPersonDAO().getPerson(userId);
            if (personDetails != null) {
                userSiteId = personDetails.getSiteId();
            }
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return userSiteId;
    }

    public SignedInUser login(String userId, String password, String ipAddress) throws InvalidArgumentException, AuthenticationFailureException, InactiveUserException {
        SignedInUserImpl userImpl = null;
        boolean isUserActive = false;
        boolean isAdmin = false;
        boolean isUser = false;
        boolean isSupportUser = false;

        if (userId == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.UserId");
            invalidArgumentException.setErrorOzCode("system.errors.UserId");
            throw invalidArgumentException;
        }
        if (password == null) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.loginPassword");
            invalidArgumentException.setErrorOzCode("system.errors.loginPassword");
            throw invalidArgumentException;
        }
        try {
            log("Going to load userDetails from database for loginId: " + userId);
            Person person = getPersonDAO().getPerson(userId);
            log("userDetails loaded successfully from database for username: " + person.getFirstName());

            if (person == null) {
                throw new AuthenticationFailureException("ERUTM-001-2876");
            }
            if (!(person != null && person.getPassword().equalsIgnoreCase(password))) {
                throw new AuthenticationFailureException("ERUTM-001-2876");
            }

            if (person.getStatus() != 1) {
                throw new InactiveUserException("ERUTM-001-2877");
            }

            if (person.getStatus() == 1) {
                isUserActive = true;
            }

            if (person.getUserType().equalsIgnoreCase("A")) {
                isAdmin = true;
            }
            if (person.getUserType().equalsIgnoreCase("U")) {
                isUser = true;
            }
            if (person.getUserType().equalsIgnoreCase("S")) {
                isUser = true;
                isSupportUser = true;
            }
            Company company = getCompany(person.getSiteId());
            if(!(Server.isProjectAssigned(person.getSiteId()))){
            	throw new ConfigurationException("User has not subscribed this application. Please contact Document Preparation System administrator.");
            }
            ClassPathXmlApplicationContext springFactory = SpringFactoryUtil.getSpringFactory();
            userImpl = (SignedInUserImpl) springFactory.getBean("signedInUser");
            userImpl.initialize(person.getUniqueUserRef(), person.getUserId(), person.getSiteId(), isUser, isAdmin, person.getScrollAmount(), isUserActive, ipAddress);
            ActivityLogManagerImpl activityManagerImpl = (ActivityLogManagerImpl) springFactory.getBean("activityLogManager");
            activityManagerImpl.initialize(person.getScrollAmount(), null, userId, person.getSiteId(), ipAddress);
            this.activityLogManager = activityManagerImpl;
            Activitylog activity = new Activitylog();
            activity.setActivityDesc("User (UserID: " + person.getUserId() + ", SiteID: " + person.getSiteId() + ") has been logged in successfully.");
            activity.setActivityType("6");
            activityLogManager.addActivityLogEntry(activity);
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return userImpl;
    }

    public boolean isProjectAssigned(String siteId) throws InvalidArgumentException {
        boolean projectAsso = false;
        if (siteId == null || siteId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SiteId");
            invalidArgumentException.setErrorOzCode("system.errors.SiteId");
            throw invalidArgumentException;
        }
        try {
            projectAsso = getPersonDAO().isProjectAssigned(siteId);
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return projectAsso;
    }

    public Company getCompany(String siteId) throws InvalidArgumentException {
        Company companyTo = null;
        if (siteId == null || siteId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SiteId");
            invalidArgumentException.setErrorOzCode("system.errors.SiteId");
            throw invalidArgumentException;
        }
        try {
            companyTo = getCompanyDAO().getCompany(siteId);
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return companyTo;
    }

    public int getNumberOfUnpaidTaxInvoices(String siteId) throws InvalidArgumentException {
        int noOfTaxInvoices = 0;
        if (siteId == null || siteId.trim().length() <= 0) {
            InvalidArgumentException invalidArgumentException = new InvalidArgumentException("system.errors.SiteId");
            invalidArgumentException.setErrorOzCode("system.errors.SiteId");
            throw invalidArgumentException;
        }
        try {
            noOfTaxInvoices = getTaxInvoiceDAO().getNumberOfUnpaidTaxInvoices(siteId);
        } catch (DAOException e) {
            new DAOExceptionHandler().handleAndReThrowException(e);
        } catch (InvalidDAOArgumentException e) {
            new ProgrammingExceptionHandler().handleException(e, null);
        }
        return noOfTaxInvoices;
    }
}
