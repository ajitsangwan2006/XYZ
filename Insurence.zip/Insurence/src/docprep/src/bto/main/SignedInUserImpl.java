package docprep.src.bto.main;

import docprep.src.bto.userAccess.AdminEnvironment;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.bto.userAccessImpl.AdminEnvironmentImpl;
import docprep.src.bto.userAccessImpl.EndUserEnvironmentImpl;
import dev.zing.framework.businesstier.listpages.PageHandlerHolder;
import dev.zing.framework.services.exception.application.bto.AccessDeniedException;

public class SignedInUserImpl extends SignedInUser {

    private Long uniqueUserRef;

    private String userId;

    private String siteId;

    private String welcomeMessage;

    private boolean isUser;

    private boolean isAdmin;

    private boolean isCertifyAuthorityUser;

    private boolean isActive;

    private String ipAddress;

    private int pageScrollValue;

    private EndUserEnvironment endUserEnvironment = null;

    private AdminEnvironment adminEnvironment = null;

    private PageHandlerHolder pageHandlerHolder = null;

    public void initialize(Long uniqueUserRef, String userid, String siteId, boolean isUser, boolean isAdmin, int pageScrollValue, boolean isActive, String ipAddress) {
        this.uniqueUserRef = uniqueUserRef;
        this.userId = userid;
        this.siteId = siteId;
        this.isUser = isUser;
        this.isAdmin = isAdmin;
        this.isActive = isActive;
        this.ipAddress = ipAddress;
        this.pageScrollValue = pageScrollValue;
        pageHandlerHolder = new PageHandlerHolder();
    }

    public EndUserEnvironment getEndUserEnvironment() throws AccessDeniedException {
        if (!(isUser())) {
            throw new AccessDeniedException("ERUTM-001-2876");
        }
        ((EndUserEnvironmentImpl) endUserEnvironment).initialize(uniqueUserRef, userId, siteId, isUser, pageScrollValue, pageHandlerHolder, ipAddress);
        return endUserEnvironment;
    }

    public AdminEnvironment getAdminEnvironment() throws AccessDeniedException {
        if (!(isAdmin())) {
            throw new AccessDeniedException("ERUTM-001-2876");
        }
        ((AdminEnvironmentImpl) adminEnvironment).initialize(this.uniqueUserRef, userId, siteId, isCertifyAuthorityUser, pageScrollValue, pageHandlerHolder, ipAddress);
        return adminEnvironment;
    }

    public String getUserId() {
        return this.userId;
    }

    public String getSiteId() {
        return this.siteId;
    }

    public String getWelcomeMessage() {
        return this.welcomeMessage;
    }

    public boolean isUser() {
        return this.isUser;
    }

    public boolean isCertifyAuthorityUser() {
        return this.isCertifyAuthorityUser;
    }

    public boolean isAdmin() {
        return this.isAdmin;
    }

    public void logout() {

    }

    public boolean isActive() {
        return this.isActive;
    }

    public void setEndUserEnvironment(EndUserEnvironment endUserEnvironment) {
        this.endUserEnvironment = endUserEnvironment;
    }

    public void setAdminEnvironment(AdminEnvironment adminEnvironment) {
        this.adminEnvironment = adminEnvironment;
    }
    
    public int getPageScrollValue() {
        return pageScrollValue;
    }
}
