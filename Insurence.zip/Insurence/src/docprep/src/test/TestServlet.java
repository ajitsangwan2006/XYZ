package docprep.src.test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import userlookup.src.bto.controller.ClausesUserLookupManager;
import userlookup.src.dto.ClausesUserLookup;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.services.exception.application.dao.DuplicateRecordException;
import docprep.src.bto.userAccess.EndUserEnvironment;
import docprep.src.bto.userAccessImpl.EndUserEnvironmentImpl;

public class TestServlet extends HttpServlet implements Servlet {
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public TestServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if((request.getParameter("module")!=null) && (request.getParameter("module").length()>0)){
			String module=request.getParameter("module");
			String action=request.getParameter("action");
			Class partypes[] = new Class[]{String.class};
			try {
				Method method = this.getClass().getMethod(module, partypes);
				Object arg[]= new Object[]{action};
				method.invoke(this,arg);
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	public void userLookupClause(String action) {
		EndUserEnvironment env = new EndUserEnvironmentImpl();

       ClausesUserLookupManager useManager = env.getClausesUserLookupManager();
		System.err.println("I m called::::");
		
		ClausesUserLookup clausesUserLookup= new ClausesUserLookup();
		if ("createClauses".equals(action)){
			//uses.setUseId(new Long(1));
			clausesUserLookup.getId().setClauseId("1233");
			clausesUserLookup.getId().setUserId("aqisw01");
									
			try {
				useManager.createClauses(clausesUserLookup);
				} catch (InvalidArgumentException e) {
				e.printStackTrace();
			} catch (DuplicateRecordException e) {
				e.printStackTrace();
			}
		}
//		else if ("updateClauses".equals(action)){
//			clausesUserLookup.;
//			tax.setStateName("Delhi");	
//			tax.setState("noidadelhi");
//			try {
//				useManager1.update(tax);
//				
//			} catch (InvalidArgumentException e) {
//				e.printStackTrace();
//			}
//		}
//		else if("list".equals(action)) {
//			try {
//				TaxTable taxTable1=useManager1.getTaxTable(new Long(34));
//				System.out.println("Tax Id:::" + taxTable1.getTaxId());
//				System.out.println("State:::" + taxTable1.getState());
//			} catch (InvalidArgumentException e) {				
//				e.printStackTrace();
//			}
//		}
		
	}
	
	
		
	

}