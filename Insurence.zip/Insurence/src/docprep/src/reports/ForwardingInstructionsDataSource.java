package docprep.src.reports;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRAbstractBeanDataSourceProvider;
import net.sf.jasperreports.engine.data.JRBeanArrayDataSource;
import docprep.src.reports.dsio.ForwardingInstructionsDSIO;

public class ForwardingInstructionsDataSource extends JRAbstractBeanDataSourceProvider {

    private ForwardingInstructionsDSIO forwardingInstructionsDSIO ;

    public ForwardingInstructionsDataSource() {
        super(ForwardingInstructionsDSIO.class);
    }

    public ForwardingInstructionsDataSource(ForwardingInstructionsDSIO forwardingInstructionsDSIO) {
        super(ForwardingInstructionsDSIO.class);
        this.forwardingInstructionsDSIO = forwardingInstructionsDSIO;
    }

    public JRDataSource create(JasperReport arg0) throws JRException {
    	ForwardingInstructionsDSIO[] printPartTo = new ForwardingInstructionsDSIO[1];
        if (forwardingInstructionsDSIO != null) {
            printPartTo[0] = forwardingInstructionsDSIO;
        } else {
            printPartTo[0] = getSampleData();
        }
        return new JRBeanArrayDataSource(printPartTo);
    }

    private ForwardingInstructionsDSIO getSampleData() {
    	ForwardingInstructionsDSIO sampleTo = new ForwardingInstructionsDSIO();              
        return sampleTo;
    }

    public void dispose(JRDataSource arg0) throws JRException {
    }

}
