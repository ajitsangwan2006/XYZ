package docprep.src.reports.impls;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

import net.sf.jasperreports.engine.JRException;
import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import dev.zing.framework.util.PDFAppend;
import docprep.src.reports.ForwardingInstructionsDataSource;
import docprep.src.reports.GeneratePDF;
import docprep.src.reports.PackingListDetailsDataSource;
import docprep.src.reports.ResourceFileAccess;
import docprep.src.reports.dsio.ForwardingInstructionsDSIO;
import docprep.src.reports.dsio.PackingListDSIO;
import docprep.src.reports.interfaces.DocumentPrint;

public class DerivedDocumentPrintImpl implements DocumentPrint {

    public byte[] getPackingListBytes(PackingListDSIO packingListDSIO) throws InvalidArgumentException {
        byte[] finalBytes = null;
        PDFAppend pdfAppend = new PDFAppend();
        Map headerParameters = new HashMap();       
        
        try {
            ResourceFileAccess resourceFile = ResourceFileAccess.getInstance();
            PackingListDetailsDataSource packingListDetailsDataSource = new PackingListDetailsDataSource(packingListDSIO.getPackingListDetailsDSIOs());
            GeneratePDF generator = new GeneratePDF();
                       
            headerParameters.put("HeaderDataSource", packingListDetailsDataSource.create(null));
            
            InputStream jasperInputStream = resourceFile.getJasperInputStream("PackingListDetails.jasper");            
            finalBytes = generator.getPreparedPDF(jasperInputStream, packingListDetailsDataSource, headerParameters);
            jasperInputStream.close();            
            
        } catch (IOException e) {
            throw new InvalidArgumentException(e.getMessage());
        } catch (JRException e) {
            throw new InvalidArgumentException(e.getMessage());
        } 
        return getStampedBytes(finalBytes);
    }
    
    public byte[] getForwardingInstructionBytes(ForwardingInstructionsDSIO forwardingInstructionsDSIO) throws InvalidArgumentException {
        byte[] finalBytes = null;
        PDFAppend pdfAppend = new PDFAppend();
        Map headerParameters = new HashMap();       
        
        try {
            ResourceFileAccess resourceFile = ResourceFileAccess.getInstance();
            ForwardingInstructionsDataSource forwardingInstructionsDataSource = new ForwardingInstructionsDataSource(forwardingInstructionsDSIO);
            GeneratePDF generator = new GeneratePDF();
                       
            headerParameters.put("HeaderDataSource", forwardingInstructionsDataSource.create(null));
            
            InputStream jasperInputStream = resourceFile.getJasperInputStream("ForwardingInstruction.jasper");            
            finalBytes = generator.getPreparedPDF(jasperInputStream, forwardingInstructionsDataSource, headerParameters);
            jasperInputStream.close();            
            
        } catch (IOException e) {
            throw new InvalidArgumentException(e.getMessage());
        } catch (JRException e) {
            throw new InvalidArgumentException(e.getMessage());
        } 
        return getStampedBytes(finalBytes);
    }
    
    private byte[] getStampedBytes(byte[] nonStampedBytes) throws InvalidArgumentException {
        try {
            PdfReader reader = new PdfReader(nonStampedBytes);
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            PdfStamper pdfStamper = new PdfStamper(reader, bout);
            int n = reader.getNumberOfPages();
            for (int i = 1; i <= n; i++) {
                PdfContentByte under = pdfStamper.getUnderContent(i);                
                
                under.beginText();
                under.setTextMatrix(450, 815);
                under.setFontAndSize(BaseFont.createFont("arial.ttf", "CP1252", false), 11);
                under.showText("EXPORT PACKING LIST");
                under.endText();
                
                under.beginText();
                under.setTextMatrix(295, 13);
                under.setFontAndSize(BaseFont.createFont("arial.ttf", "CP1252", false), 7);
                under.showText("Page " + i + " of " + n );
                under.endText();
                
                under.beginText();
                under.setTextMatrix(20, 13);
                under.setFontAndSize(BaseFont.createFont("arial.ttf", "CP1252", false), 6);
                under.showText("(C) Ozdocs International Pty. Ltd.");
                under.endText();
                
                if(n > 1 && i < n) {
                	under.beginText();
                    under.setTextMatrix(520, 13);
                    under.setFontAndSize(BaseFont.createFont("arial.ttf", "CP1252", false), 8);
                    under.showText("Continued...");
                    under.endText();                    
                }
                PdfContentByte over = pdfStamper.getOverContent(i);
                over.beginText();
                over.endText();
            }
            reader.close();
            pdfStamper.close();
            byte[] stampedBytes = bout.toByteArray();
            return stampedBytes;
        } catch (IOException e) {
            throw new InvalidArgumentException(e.getMessage());
        } catch (DocumentException e) {
            throw new InvalidArgumentException(e.getMessage());
        }
    }

}
