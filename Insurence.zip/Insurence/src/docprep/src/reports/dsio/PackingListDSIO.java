package docprep.src.reports.dsio;

public class PackingListDSIO {

    private PackingListDetailsDSIO[] packingListDetailsDSIOs;

    public PackingListDSIO() {

    }

    public PackingListDetailsDSIO[] getPackingListDetailsDSIOs() {
        return packingListDetailsDSIOs;
    }

    public void setPackingListDetailsDSIOs(PackingListDetailsDSIO[] packingListDetailsDSIOs) {
        this.packingListDetailsDSIOs = packingListDetailsDSIOs;
    }

}