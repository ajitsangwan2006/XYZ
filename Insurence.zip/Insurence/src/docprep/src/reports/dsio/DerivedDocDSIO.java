package docprep.src.reports.dsio;

import java.io.InputStream;

public class DerivedDocDSIO {
	

	    private InputStream imageName = null;
	    
	    private String methodOfDispatch = null;
	    
	    private String packListNo = null;
	    
	    private String pageNo = null;
	    
	    private String internalLine1 = null;
	    
	    private String internalLine2 = null;
	    
	    private String internalLine3 = null;
	    
	    private String internalLine4 = null;
	    
	    private String internalLine5 = null;
	    
	    private String internalLine6 = null;
	    
	    private String internalLine7 = null;
	    
	    private String packingDate = null;
	    
	    
	    private String exporterReference = null;

	    private String agentReference = null;

	    private String invoiceNumber = null;

	    private String invoiceDate = null;

	    private String nameofShipping = null;

	    private String shippingCo = null;
	  
	    private String buyerReference = null;
	    
	    private String edn = null;
	    
	    private String exporterName = null;

	    private String exporterAbnNo = null;

	    private String exporterStreetNo = null;

	    private String exporterStreetName = null;

	    private String exporterCity = null;

	    private String exporterState = null;

	    private String exporterCountry = null;

	    private String consigneeName = null;

	    private String consigneeStreetNo = null;

	    private String consigneeStreetName = null;

	    private String consigneeCity = null;

	    private String consigneeState = null;

	    private String consigneeCountry = null;

	    private String agentName = null;

	    private String agentStreetNo = null;

	    private String agentStreetName = null;

	    private String agentCity = null;

	    private String agentState = null;

	    private String agentCountry = null;

	    private String buyerName = null;

	    private String buyerStreetNo = null;

	    private String buyerStreetName = null;

	    private String buyerCity = null;

	    private String buyerState = null;

	    private String buyerCountry = null;
	   
	    private String termsLine1 = null;

	    private String termsLine2 = null;

	    private String termsLine3 = null;

	    private String termsLine4 = null;

	    private String termsLine5 = null;

	    private String termsLine6 = null;

	    private String countryofOrigin = null;

	    private String countryofdestination = null;

	    private String portofLoading1 = null;

	    private String portofDischarge1 = null;
	    
	    private String portofLoading2 = null;

	    private String portofDischarge2 = null;

	    private double invoiceValueUSD = (double) 0.00;
	       
	    private String insuredValue = null;
	    
	    private String issuePlace = null;

	    private Integer numberofOriginal = null;

	    private Integer numberofcopy = null;

	    private String voyageNumber = null;

	    private String vessel = null;

	    private String finalDestination1 = null;
	    
	    private String finalDestination2 = null;

	    private String receivingDate = null;
	   
	    private String dateofDeparture1 = null;
	    
	    private String dateofDeparture2 = null;

	    private String issueDate = null;
	        
	    private String comments = null;

	    private double invoiceSubtotal = (double) 0.00;

	    private double invoiceTotal = (double) 0.00;

	    private String clause1 = null;

	    private String clause2 = null;

	    private String clause3 = null;

	    private String clause4 = null;

	    private String clause5 = null;

	    private String clause6 = null;

	    private String clause7 = null;

	    private String clause8 = null;

	    private String clause9 = null;
	   
	    private String modeOfTransport = null;

	    private String categories = null;

	    private String status = null;

	    private String frightcharge = null;
	          
	    private String freightPayableAt = null;

	    private String signatoryCompanyName = null;

	    private String nameofAuthorizedSignatory = null;

	    private String currencyCode = null;
	      
	    private String countryOriginCode = null;

	    private String countryDestCode = null;

	    private String form1 = null;
	          
	    private String issuerBankID = null;
	     
	    private String reimBankBIC = null;
	   
	    private String availablewithBuyerID = null;
	     
	    private String toleranceMinus = null;
	                   
	    private String quantity1 = null;

	    private String quantity2 = null;

	    private String quantity3 = null;

	    private String quantity4 = null;

	    private String quantity5 = null;

	    private String quantity6 = null;

	    private String quantity7 = null;

	    private String quantity8 = null;

	    private String quantity9 = null;

	    private String quantity10 = null;

	    private String quantity11 = null;

	    private String quantity12 = null;

	    private String quantity13 = null;

	    private String quantity14 = null;

	    private String quantity15 = null;

	    private String quantity16 = null;
	    
	    private String quantity17 = null;
	    
	    private String quantity18 = null;
	    
	    private String quantity19 = null;
	    
	    private String quantity20 = null;
	    
	    private String quantity21 = null;
	    
	    private String quantity22 = null;
	    
	    private String quantity23 = null;
	    
	    private String quantity24 = null;
	    
	    private String quantity25 = null;
	    
	    private String quantity26 = null;
	    
	    private String quantity27 = null;
	    
	    private String quantity28 = null;
	    
	    private String quantity29 = null;
	    
	    private String quantity30 = null;
	    
	    private String quantity31 = null;
	    
	    private String quantity32 = null;

	    private String description1 = null;

	    private String description2 = null;

	    private String description3 = null;

	    private String description4 = null;

	    private String description5 = null;

	    private String description6 = null;

	    private String description7 = null;

	    private String description8 = null;

	    private String description9 = null;

	    private String description10 = null;

	    private String description11 = null;

	    private String description12 = null;

	    private String description13 = null;

	    private String description14 = null;

	    private String description15 = null;

	    private String description16 = null;
	    
	    private String description17 = null;
	    
	    private String description18 = null;
	    
	    private String description19 = null;
	    
	    private String description20 = null;
	    
	    private String description21 = null;
	    
	    private String description22 = null;
	    
	    private String description23 = null;
	    
	    private String description24 = null;
	    
	    private String description25 = null;
	    
	    private String description26 = null;
	    
	    private String description27 = null;
	    
	    private String description28 = null;
	    
	    private String description29 = null;
	    
	    private String description30 = null;
	    
	    private String description31 = null;
	    
	    private String description32 = null;

	    private String productCode1 = null;

	    private String productCode2 = null;

	    private String productCode3 = null;

	    private String productCode4 = null;

	    private String productCode5 = null;

	    private String productCode6 = null;

	    private String productCode7 = null;

	    private String productCode8 = null;

	    private String productCode9 = null;

	    private String productCode10 = null;

	    private String productCode11 = null;

	    private String productCode12 = null;

	    private String productCode13 = null;

	    private String productCode14 = null;

	    private String productCode15 = null;

	    private String productCode16 = null;

	    private String productCode17 = null;

	    private String productCode18 = null;

	    private String productCode19 = null;

	    private String productCode20 = null;

	    private String productCode21 = null;

	    private String productCode22 = null;

	    private String productCode23 = null;

	    private String productCode24 = null;

	    private String productCode25 = null;

	    private String productCode26 = null;

	    private String productCode27 = null;

	    private String productCode28 = null;

	    private String productCode29 = null;

	    private String productCode30 = null;

	    private String productCode31 = null;

	    private String productCode32 = null;

	    private String unitPrice1 = null;

	    private String unitPrice2 = null;

	    private String unitPrice3 = null;

	    private String unitPrice4 = null;

	    private String unitPrice5 = null;

	    private String unitPrice6 = null;

	    private String unitPrice7 = null;

	    private String unitPrice8 = null;

	    private String unitPrice9 = null;

	    private String unitPrice10 = null;

	    private String unitPrice11 = null;

	    private String unitPrice12 = null;

	    private String unitPrice13 = null;

	    private String unitPrice14 = null;

	    private String unitPrice15 = null;

	    private String unitPrice16 = null;

	    private String unitPrice17 = null;

	    private String unitPrice18 = null;

	    private String unitPrice19 = null;

	    private String unitPrice20 = null;

	    private String unitPrice21 = null;

	    private String unitPrice22 = null;

	    private String unitPrice23 = null;

	    private String unitPrice24 = null;

	    private String unitPrice25 = null;

	    private String unitPrice26 = null;

	    private String unitPrice27 = null;

	    private String unitPrice28 = null;

	    private String unitPrice29 = null;

	    private String unitPrice30 = null;

	    private String unitPrice31 = null;

	    private String unitPrice32 = null;

	    private String totalPrice1 = null;

	    private String totalPrice2 = null;

	    private String totalPrice3 = null;

	    private String totalPrice4 = null;

	    private String totalPrice5 = null;

	    private String totalPrice6 = null;

	    private String totalPrice7 = null;

	    private String totalPrice8 = null;

	    private String totalPrice9 = null;

	    private String totalPrice10 = null;

	    private String totalPrice11 = null;

	    private String totalPrice12 = null;

	    private String totalPrice13 = null;

	    private String totalPrice14 = null;

	    private String totalPrice15 = null;

	    private String totalPrice16 = null;

	    private String totalPrice17 = null;

	    private String totalPrice18 = null;

	    private String totalPrice19 = null;

	    private String totalPrice20 = null;

	    private String totalPrice21 = null;

	    private String totalPrice22 = null;

	    private String totalPrice23 = null;

	    private String totalPrice24 = null;

	    private String totalPrice25 = null;

	    private String totalPrice26 = null;

	    private String totalPrice27 = null;

	    private String totalPrice28 = null;

	    private String totalPrice29 = null;

	    private String totalPrice30 = null;

	    private String totalPrice31 = null;

	    private String totalPrice32 = null;

	    private String marks1 = null;

	    private String marks2 = null;

	    private String marks3 = null;

	    private String marks4 = null;

	    private String marks5 = null;

	    private String marks6 = null;

	    private String pckg1 = null;

	    private String pckg2 = null;

	    private String pckg3 = null;

	    private String pckg4 = null;

	    private String pckg5 = null;

	    private String pckg6 = null;

	    private String descriptionofgoods1 = null;

	    private String descriptionofgoods2 = null;

	    private String descriptionofgoods3 = null;

	    private String descriptionofgoods4 = null;

	    private String descriptionofgoods5 = null;

	    private String descriptionofgoods6 = null;

	    private String grossMass1 = null;

	    private String grossMass2 = null;

	    private String grossMass3 = null;

	    private String grossMass4 = null;

	    private String grossMass5 = null;

	    private String grossMass6 = null;

	    private String cubic1 = null;
	    
	    private String cubic2 = null;

	    private String cubic3 = null;

	    private String cubic4 = null;

	    private String cubic5 = null;

	    private String cubic6 = null;

	    private String originalOrCopy;
	    
	    private String finePrintLine1 = null;
	    
	    private String finePrintLine2 = null;
	    
	    private String finePrintLine3 = null;
	    
	    private String finePrintLine4 = null;
	    
	    private String finePrintLine5 = null;
	    
	    private String finePrintLine6 = null;
	    
	    private String finePrintLine7 = null;
	    
	    private String additionalCharges1 = null;
	    
	    private String additionalCharges2 = null;
	    
	    private String additionalCharges3 = null;
	    
	    private String additionalCharges4 = null;
	    
	    private String additionalChargesDesc1 = null;
	    
	    private String additionalChargesDesc2 = null;
	    
	    private String additionalChargesDesc3 = null;
	    
	    private String additionalChargesDesc4 = null;
	           
	    private String totalNumberOfPages = null;
	    
	    private Integer docTypeVersion;
	    
		private String lastUpdateDate;	
		
		private String dockContBase = null;
		
		private String qtyDescription = null;
		    
		private String priceDescription = null;
		    
		private String continuationPageNo = null;
		
		private String continuationTotalPageNo = null;
		
		private String totalThisPage = null;
		
		private String carriedForward = null;
		
		private String bfwd = null;
		
		private String bfwdLabel = null;
	        
		private String reportTitle = null;
		
		private String exportLicenceNo= null;
		
		private String dpiPermitNo= null;
		
		private String establishmentNo= null;
		
		private String fecNo= null;;
		
		private String special1= null;
		
		private String special2= null;
		
		private String special3= null;
		
		private String special4= null;
		
		private String special5= null;
		
	   

		public String getAdditionalCharges1() {
			return additionalCharges1;
		}
		public void setAdditionalCharges1(String additionalCharges1) {
			this.additionalCharges1 = additionalCharges1;
		}
		public String getAdditionalCharges2() {
			return additionalCharges2;
		}
		public void setAdditionalCharges2(String additionalCharges2) {
			this.additionalCharges2 = additionalCharges2;
		}
		public String getAdditionalCharges3() {
			return additionalCharges3;
		}
		public void setAdditionalCharges3(String additionalCharges3) {
			this.additionalCharges3 = additionalCharges3;
		}
		public String getAdditionalCharges4() {
			return additionalCharges4;
		}
		public void setAdditionalCharges4(String additionalCharges4) {
			this.additionalCharges4 = additionalCharges4;
		}
		public String getAdditionalChargesDesc1() {
			return additionalChargesDesc1;
		}
		public void setAdditionalChargesDesc1(String additionalChargesDesc1) {
			this.additionalChargesDesc1 = additionalChargesDesc1;
		}
		public String getAdditionalChargesDesc2() {
			return additionalChargesDesc2;
		}
		public void setAdditionalChargesDesc2(String additionalChargesDesc2) {
			this.additionalChargesDesc2 = additionalChargesDesc2;
		}
		public String getAdditionalChargesDesc3() {
			return additionalChargesDesc3;
		}
		public void setAdditionalChargesDesc3(String additionalChargesDesc3) {
			this.additionalChargesDesc3 = additionalChargesDesc3;
		}
		public String getAdditionalChargesDesc4() {
			return additionalChargesDesc4;
		}
		public void setAdditionalChargesDesc4(String additionalChargesDesc4) {
			this.additionalChargesDesc4 = additionalChargesDesc4;
		}
		public String getAgentCity() {
			return agentCity;
		}
		public void setAgentCity(String agentCity) {
			this.agentCity = agentCity;
		}
		public String getAgentCountry() {
			return agentCountry;
		}
		public void setAgentCountry(String agentCountry) {
			this.agentCountry = agentCountry;
		}
		public String getAgentName() {
			return agentName;
		}
		public void setAgentName(String agentName) {
			this.agentName = agentName;
		}
		public String getAgentReference() {
			return agentReference;
		}
		public void setAgentReference(String agentReference) {
			this.agentReference = agentReference;
		}
		public String getAgentState() {
			return agentState;
		}
		public void setAgentState(String agentState) {
			this.agentState = agentState;
		}
		public String getAgentStreetName() {
			return agentStreetName;
		}
		public void setAgentStreetName(String agentStreetName) {
			this.agentStreetName = agentStreetName;
		}
		public String getAgentStreetNo() {
			return agentStreetNo;
		}
		public void setAgentStreetNo(String agentStreetNo) {
			this.agentStreetNo = agentStreetNo;
		}
		public String getAvailablewithBuyerID() {
			return availablewithBuyerID;
		}
		public void setAvailablewithBuyerID(String availablewithBuyerID) {
			this.availablewithBuyerID = availablewithBuyerID;
		}
		public String getBfwd() {
			return bfwd;
		}
		public void setBfwd(String bfwd) {
			this.bfwd = bfwd;
		}
		public String getBfwdLabel() {
			return bfwdLabel;
		}
		public void setBfwdLabel(String bfwdLabel) {
			this.bfwdLabel = bfwdLabel;
		}
		public String getBuyerCity() {
			return buyerCity;
		}
		public void setBuyerCity(String buyerCity) {
			this.buyerCity = buyerCity;
		}
		public String getBuyerCountry() {
			return buyerCountry;
		}
		public void setBuyerCountry(String buyerCountry) {
			this.buyerCountry = buyerCountry;
		}
		public String getBuyerName() {
			return buyerName;
		}
		public void setBuyerName(String buyerName) {
			this.buyerName = buyerName;
		}
		public String getBuyerReference() {
			return buyerReference;
		}
		public void setBuyerReference(String buyerReference) {
			this.buyerReference = buyerReference;
		}
		public String getBuyerState() {
			return buyerState;
		}
		public void setBuyerState(String buyerState) {
			this.buyerState = buyerState;
		}
		public String getBuyerStreetName() {
			return buyerStreetName;
		}
		public void setBuyerStreetName(String buyerStreetName) {
			this.buyerStreetName = buyerStreetName;
		}
		public String getBuyerStreetNo() {
			return buyerStreetNo;
		}
		public void setBuyerStreetNo(String buyerStreetNo) {
			this.buyerStreetNo = buyerStreetNo;
		}
		public String getCarriedForward() {
			return carriedForward;
		}
		public void setCarriedForward(String carriedForward) {
			this.carriedForward = carriedForward;
		}
		public String getCategories() {
			return categories;
		}
		public void setCategories(String categories) {
			this.categories = categories;
		}
		public String getClause1() {
			return clause1;
		}
		public void setClause1(String clause1) {
			this.clause1 = clause1;
		}
		public String getClause2() {
			return clause2;
		}
		public void setClause2(String clause2) {
			this.clause2 = clause2;
		}
		public String getClause3() {
			return clause3;
		}
		public void setClause3(String clause3) {
			this.clause3 = clause3;
		}
		public String getClause4() {
			return clause4;
		}
		public void setClause4(String clause4) {
			this.clause4 = clause4;
		}
		public String getClause5() {
			return clause5;
		}
		public void setClause5(String clause5) {
			this.clause5 = clause5;
		}
		public String getClause6() {
			return clause6;
		}
		public void setClause6(String clause6) {
			this.clause6 = clause6;
		}
		public String getClause7() {
			return clause7;
		}
		public void setClause7(String clause7) {
			this.clause7 = clause7;
		}
		public String getClause8() {
			return clause8;
		}
		public void setClause8(String clause8) {
			this.clause8 = clause8;
		}
		public String getClause9() {
			return clause9;
		}
		public void setClause9(String clause9) {
			this.clause9 = clause9;
		}
		public String getComments() {
			return comments;
		}
		public void setComments(String comments) {
			this.comments = comments;
		}
		public String getConsigneeCity() {
			return consigneeCity;
		}
		public void setConsigneeCity(String consigneeCity) {
			this.consigneeCity = consigneeCity;
		}
		public String getConsigneeCountry() {
			return consigneeCountry;
		}
		public void setConsigneeCountry(String consigneeCountry) {
			this.consigneeCountry = consigneeCountry;
		}
		public String getConsigneeName() {
			return consigneeName;
		}
		public void setConsigneeName(String consigneeName) {
			this.consigneeName = consigneeName;
		}
		public String getConsigneeState() {
			return consigneeState;
		}
		public void setConsigneeState(String consigneeState) {
			this.consigneeState = consigneeState;
		}
		public String getConsigneeStreetName() {
			return consigneeStreetName;
		}
		public void setConsigneeStreetName(String consigneeStreetName) {
			this.consigneeStreetName = consigneeStreetName;
		}
		public String getConsigneeStreetNo() {
			return consigneeStreetNo;
		}
		public void setConsigneeStreetNo(String consigneeStreetNo) {
			this.consigneeStreetNo = consigneeStreetNo;
		}
		public String getContinuationPageNo() {
			return continuationPageNo;
		}
		public void setContinuationPageNo(String continuationPageNo) {
			this.continuationPageNo = continuationPageNo;
		}
		public String getContinuationTotalPageNo() {
			return continuationTotalPageNo;
		}
		public void setContinuationTotalPageNo(String continuationTotalPageNo) {
			this.continuationTotalPageNo = continuationTotalPageNo;
		}
		public String getCountryDestCode() {
			return countryDestCode;
		}
		public void setCountryDestCode(String countryDestCode) {
			this.countryDestCode = countryDestCode;
		}
		public String getCountryofdestination() {
			return countryofdestination;
		}
		public void setCountryofdestination(String countryofdestination) {
			this.countryofdestination = countryofdestination;
		}
		public String getCountryofOrigin() {
			return countryofOrigin;
		}
		public void setCountryofOrigin(String countryofOrigin) {
			this.countryofOrigin = countryofOrigin;
		}
		public String getCountryOriginCode() {
			return countryOriginCode;
		}
		public void setCountryOriginCode(String countryOriginCode) {
			this.countryOriginCode = countryOriginCode;
		}
		public String getCubic1() {
			return cubic1;
		}
		public void setCubic1(String cubic1) {
			this.cubic1 = cubic1;
		}
		public String getCubic2() {
			return cubic2;
		}
		public void setCubic2(String cubic2) {
			this.cubic2 = cubic2;
		}
		public String getCubic3() {
			return cubic3;
		}
		public void setCubic3(String cubic3) {
			this.cubic3 = cubic3;
		}
		public String getCubic4() {
			return cubic4;
		}
		public void setCubic4(String cubic4) {
			this.cubic4 = cubic4;
		}
		public String getCubic5() {
			return cubic5;
		}
		public void setCubic5(String cubic5) {
			this.cubic5 = cubic5;
		}
		public String getCubic6() {
			return cubic6;
		}
		public void setCubic6(String cubic6) {
			this.cubic6 = cubic6;
		}
		public String getCurrencyCode() {
			return currencyCode;
		}
		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}
		public String getDateofDeparture1() {
			return dateofDeparture1;
		}
		public void setDateofDeparture1(String dateofDeparture1) {
			this.dateofDeparture1 = dateofDeparture1;
		}
		public String getDateofDeparture2() {
			return dateofDeparture2;
		}
		public void setDateofDeparture2(String dateofDeparture2) {
			this.dateofDeparture2 = dateofDeparture2;
		}
		public String getDescription1() {
			return description1;
		}
		public void setDescription1(String description1) {
			this.description1 = description1;
		}
		public String getDescription10() {
			return description10;
		}
		public void setDescription10(String description10) {
			this.description10 = description10;
		}
		public String getDescription11() {
			return description11;
		}
		public void setDescription11(String description11) {
			this.description11 = description11;
		}
		public String getDescription12() {
			return description12;
		}
		public void setDescription12(String description12) {
			this.description12 = description12;
		}
		public String getDescription13() {
			return description13;
		}
		public void setDescription13(String description13) {
			this.description13 = description13;
		}
		public String getDescription14() {
			return description14;
		}
		public void setDescription14(String description14) {
			this.description14 = description14;
		}
		public String getDescription15() {
			return description15;
		}
		public void setDescription15(String description15) {
			this.description15 = description15;
		}
		public String getDescription16() {
			return description16;
		}
		public void setDescription16(String description16) {
			this.description16 = description16;
		}
		public String getDescription17() {
			return description17;
		}
		public void setDescription17(String description17) {
			this.description17 = description17;
		}
		public String getDescription18() {
			return description18;
		}
		public void setDescription18(String description18) {
			this.description18 = description18;
		}
		public String getDescription19() {
			return description19;
		}
		public void setDescription19(String description19) {
			this.description19 = description19;
		}
		public String getDescription2() {
			return description2;
		}
		public void setDescription2(String description2) {
			this.description2 = description2;
		}
		public String getDescription20() {
			return description20;
		}
		public void setDescription20(String description20) {
			this.description20 = description20;
		}
		public String getDescription21() {
			return description21;
		}
		public void setDescription21(String description21) {
			this.description21 = description21;
		}
		public String getDescription22() {
			return description22;
		}
		public void setDescription22(String description22) {
			this.description22 = description22;
		}
		public String getDescription23() {
			return description23;
		}
		public void setDescription23(String description23) {
			this.description23 = description23;
		}
		public String getDescription24() {
			return description24;
		}
		public void setDescription24(String description24) {
			this.description24 = description24;
		}
		public String getDescription25() {
			return description25;
		}
		public void setDescription25(String description25) {
			this.description25 = description25;
		}
		public String getDescription26() {
			return description26;
		}
		public void setDescription26(String description26) {
			this.description26 = description26;
		}
		public String getDescription27() {
			return description27;
		}
		public void setDescription27(String description27) {
			this.description27 = description27;
		}
		public String getDescription28() {
			return description28;
		}
		public void setDescription28(String description28) {
			this.description28 = description28;
		}
		public String getDescription29() {
			return description29;
		}
		public void setDescription29(String description29) {
			this.description29 = description29;
		}
		public String getDescription3() {
			return description3;
		}
		public void setDescription3(String description3) {
			this.description3 = description3;
		}
		public String getDescription30() {
			return description30;
		}
		public void setDescription30(String description30) {
			this.description30 = description30;
		}
		public String getDescription31() {
			return description31;
		}
		public void setDescription31(String description31) {
			this.description31 = description31;
		}
		public String getDescription32() {
			return description32;
		}
		public void setDescription32(String description32) {
			this.description32 = description32;
		}
		public String getDescription4() {
			return description4;
		}
		public void setDescription4(String description4) {
			this.description4 = description4;
		}
		public String getDescription5() {
			return description5;
		}
		public void setDescription5(String description5) {
			this.description5 = description5;
		}
		public String getDescription6() {
			return description6;
		}
		public void setDescription6(String description6) {
			this.description6 = description6;
		}
		public String getDescription7() {
			return description7;
		}
		public void setDescription7(String description7) {
			this.description7 = description7;
		}
		public String getDescription8() {
			return description8;
		}
		public void setDescription8(String description8) {
			this.description8 = description8;
		}
		public String getDescription9() {
			return description9;
		}
		public void setDescription9(String description9) {
			this.description9 = description9;
		}
		public String getDescriptionofgoods1() {
			return descriptionofgoods1;
		}
		public void setDescriptionofgoods1(String descriptionofgoods1) {
			this.descriptionofgoods1 = descriptionofgoods1;
		}
		public String getDescriptionofgoods2() {
			return descriptionofgoods2;
		}
		public void setDescriptionofgoods2(String descriptionofgoods2) {
			this.descriptionofgoods2 = descriptionofgoods2;
		}
		public String getDescriptionofgoods3() {
			return descriptionofgoods3;
		}
		public void setDescriptionofgoods3(String descriptionofgoods3) {
			this.descriptionofgoods3 = descriptionofgoods3;
		}
		public String getDescriptionofgoods4() {
			return descriptionofgoods4;
		}
		public void setDescriptionofgoods4(String descriptionofgoods4) {
			this.descriptionofgoods4 = descriptionofgoods4;
		}
		public String getDescriptionofgoods5() {
			return descriptionofgoods5;
		}
		public void setDescriptionofgoods5(String descriptionofgoods5) {
			this.descriptionofgoods5 = descriptionofgoods5;
		}
		public String getDescriptionofgoods6() {
			return descriptionofgoods6;
		}
		public void setDescriptionofgoods6(String descriptionofgoods6) {
			this.descriptionofgoods6 = descriptionofgoods6;
		}
		public String getDockContBase() {
			return dockContBase;
		}
		public void setDockContBase(String dockContBase) {
			this.dockContBase = dockContBase;
		}
		public Integer getDocTypeVersion() {
			return docTypeVersion;
		}
		public void setDocTypeVersion(Integer docTypeVersion) {
			this.docTypeVersion = docTypeVersion;
		}
		public String getDpiPermitNo() {
			return dpiPermitNo;
		}
		public void setDpiPermitNo(String dpiPermitNo) {
			this.dpiPermitNo = dpiPermitNo;
		}
		public String getEdn() {
			return edn;
		}
		public void setEdn(String edn) {
			this.edn = edn;
		}
		public String getEstablishmentNo() {
			return establishmentNo;
		}
		public void setEstablishmentNo(String establishmentNo) {
			this.establishmentNo = establishmentNo;
		}
		public String getExporterAbnNo() {
			return exporterAbnNo;
		}
		public void setExporterAbnNo(String exporterAbnNo) {
			this.exporterAbnNo = exporterAbnNo;
		}
		public String getExporterCity() {
			return exporterCity;
		}
		public void setExporterCity(String exporterCity) {
			this.exporterCity = exporterCity;
		}
		public String getExporterCountry() {
			return exporterCountry;
		}
		public void setExporterCountry(String exporterCountry) {
			this.exporterCountry = exporterCountry;
		}
		public String getExporterName() {
			return exporterName;
		}
		public void setExporterName(String exporterName) {
			this.exporterName = exporterName;
		}
		public String getExporterReference() {
			return exporterReference;
		}
		public void setExporterReference(String exporterReference) {
			this.exporterReference = exporterReference;
		}
		public String getExporterState() {
			return exporterState;
		}
		public void setExporterState(String exporterState) {
			this.exporterState = exporterState;
		}
		public String getExporterStreetName() {
			return exporterStreetName;
		}
		public void setExporterStreetName(String exporterStreetName) {
			this.exporterStreetName = exporterStreetName;
		}
		public String getExporterStreetNo() {
			return exporterStreetNo;
		}
		public void setExporterStreetNo(String exporterStreetNo) {
			this.exporterStreetNo = exporterStreetNo;
		}
		public String getExportLicenceNo() {
			return exportLicenceNo;
		}
		public void setExportLicenceNo(String exportLicenceNo) {
			this.exportLicenceNo = exportLicenceNo;
		}
		public String getFecNo() {
			return fecNo;
		}
		public void setFecNo(String fecNo) {
			this.fecNo = fecNo;
		}
		public String getFinalDestination1() {
			return finalDestination1;
		}
		public void setFinalDestination1(String finalDestination1) {
			this.finalDestination1 = finalDestination1;
		}
		public String getFinalDestination2() {
			return finalDestination2;
		}
		public void setFinalDestination2(String finalDestination2) {
			this.finalDestination2 = finalDestination2;
		}
		public String getFinePrintLine1() {
			return finePrintLine1;
		}
		public void setFinePrintLine1(String finePrintLine1) {
			this.finePrintLine1 = finePrintLine1;
		}
		public String getFinePrintLine2() {
			return finePrintLine2;
		}
		public void setFinePrintLine2(String finePrintLine2) {
			this.finePrintLine2 = finePrintLine2;
		}
		public String getFinePrintLine3() {
			return finePrintLine3;
		}
		public void setFinePrintLine3(String finePrintLine3) {
			this.finePrintLine3 = finePrintLine3;
		}
		public String getFinePrintLine4() {
			return finePrintLine4;
		}
		public void setFinePrintLine4(String finePrintLine4) {
			this.finePrintLine4 = finePrintLine4;
		}
		public String getFinePrintLine5() {
			return finePrintLine5;
		}
		public void setFinePrintLine5(String finePrintLine5) {
			this.finePrintLine5 = finePrintLine5;
		}
		public String getFinePrintLine6() {
			return finePrintLine6;
		}
		public void setFinePrintLine6(String finePrintLine6) {
			this.finePrintLine6 = finePrintLine6;
		}
		public String getFinePrintLine7() {
			return finePrintLine7;
		}
		public void setFinePrintLine7(String finePrintLine7) {
			this.finePrintLine7 = finePrintLine7;
		}
		public String getForm1() {
			return form1;
		}
		public void setForm1(String form1) {
			this.form1 = form1;
		}
		public String getFreightPayableAt() {
			return freightPayableAt;
		}
		public void setFreightPayableAt(String freightPayableAt) {
			this.freightPayableAt = freightPayableAt;
		}
		public String getFrightcharge() {
			return frightcharge;
		}
		public void setFrightcharge(String frightcharge) {
			this.frightcharge = frightcharge;
		}
		public String getGrossMass1() {
			return grossMass1;
		}
		public void setGrossMass1(String grossMass1) {
			this.grossMass1 = grossMass1;
		}
		public String getGrossMass2() {
			return grossMass2;
		}
		public void setGrossMass2(String grossMass2) {
			this.grossMass2 = grossMass2;
		}
		public String getGrossMass3() {
			return grossMass3;
		}
		public void setGrossMass3(String grossMass3) {
			this.grossMass3 = grossMass3;
		}
		public String getGrossMass4() {
			return grossMass4;
		}
		public void setGrossMass4(String grossMass4) {
			this.grossMass4 = grossMass4;
		}
		public String getGrossMass5() {
			return grossMass5;
		}
		public void setGrossMass5(String grossMass5) {
			this.grossMass5 = grossMass5;
		}
		public String getGrossMass6() {
			return grossMass6;
		}
		public void setGrossMass6(String grossMass6) {
			this.grossMass6 = grossMass6;
		}
		public InputStream getImageName() {
			return imageName;
		}
		public void setImageName(InputStream imageName) {
			this.imageName = imageName;
		}
		public String getInsuredValue() {
			return insuredValue;
		}
		public void setInsuredValue(String insuredValue) {
			this.insuredValue = insuredValue;
		}
		public String getInternalLine1() {
			return internalLine1;
		}
		public void setInternalLine1(String internalLine1) {
			this.internalLine1 = internalLine1;
		}
		public String getInternalLine2() {
			return internalLine2;
		}
		public void setInternalLine2(String internalLine2) {
			this.internalLine2 = internalLine2;
		}
		public String getInternalLine3() {
			return internalLine3;
		}
		public void setInternalLine3(String internalLine3) {
			this.internalLine3 = internalLine3;
		}
		public String getInternalLine4() {
			return internalLine4;
		}
		public void setInternalLine4(String internalLine4) {
			this.internalLine4 = internalLine4;
		}
		public String getInternalLine5() {
			return internalLine5;
		}
		public void setInternalLine5(String internalLine5) {
			this.internalLine5 = internalLine5;
		}
		public String getInternalLine6() {
			return internalLine6;
		}
		public void setInternalLine6(String internalLine6) {
			this.internalLine6 = internalLine6;
		}
		public String getInternalLine7() {
			return internalLine7;
		}
		public void setInternalLine7(String internalLine7) {
			this.internalLine7 = internalLine7;
		}
		public String getInvoiceDate() {
			return invoiceDate;
		}
		public void setInvoiceDate(String invoiceDate) {
			this.invoiceDate = invoiceDate;
		}
		public String getInvoiceNumber() {
			return invoiceNumber;
		}
		public void setInvoiceNumber(String invoiceNumber) {
			this.invoiceNumber = invoiceNumber;
		}
		public double getInvoiceSubtotal() {
			return invoiceSubtotal;
		}
		public void setInvoiceSubtotal(double invoiceSubtotal) {
			this.invoiceSubtotal = invoiceSubtotal;
		}
		public double getInvoiceTotal() {
			return invoiceTotal;
		}
		public void setInvoiceTotal(double invoiceTotal) {
			this.invoiceTotal = invoiceTotal;
		}
		public double getInvoiceValueUSD() {
			return invoiceValueUSD;
		}
		public void setInvoiceValueUSD(double invoiceValueUSD) {
			this.invoiceValueUSD = invoiceValueUSD;
		}
		public String getIssueDate() {
			return issueDate;
		}
		public void setIssueDate(String issueDate) {
			this.issueDate = issueDate;
		}
		public String getIssuePlace() {
			return issuePlace;
		}
		public void setIssuePlace(String issuePlace) {
			this.issuePlace = issuePlace;
		}
		public String getIssuerBankID() {
			return issuerBankID;
		}
		public void setIssuerBankID(String issuerBankID) {
			this.issuerBankID = issuerBankID;
		}
		public String getLastUpdateDate() {
			return lastUpdateDate;
		}
		public void setLastUpdateDate(String lastUpdateDate) {
			this.lastUpdateDate = lastUpdateDate;
		}
		public String getMarks1() {
			return marks1;
		}
		public void setMarks1(String marks1) {
			this.marks1 = marks1;
		}
		public String getMarks2() {
			return marks2;
		}
		public void setMarks2(String marks2) {
			this.marks2 = marks2;
		}
		public String getMarks3() {
			return marks3;
		}
		public void setMarks3(String marks3) {
			this.marks3 = marks3;
		}
		public String getMarks4() {
			return marks4;
		}
		public void setMarks4(String marks4) {
			this.marks4 = marks4;
		}
		public String getMarks5() {
			return marks5;
		}
		public void setMarks5(String marks5) {
			this.marks5 = marks5;
		}
		public String getMarks6() {
			return marks6;
		}
		public void setMarks6(String marks6) {
			this.marks6 = marks6;
		}
		public String getMethodOfDispatch() {
			return methodOfDispatch;
		}
		public void setMethodOfDispatch(String methodOfDispatch) {
			this.methodOfDispatch = methodOfDispatch;
		}
		public String getModeOfTransport() {
			return modeOfTransport;
		}
		public void setModeOfTransport(String modeOfTransport) {
			this.modeOfTransport = modeOfTransport;
		}
		public String getNameofAuthorizedSignatory() {
			return nameofAuthorizedSignatory;
		}
		public void setNameofAuthorizedSignatory(
				String nameofAuthorizedSignatory) {
			this.nameofAuthorizedSignatory = nameofAuthorizedSignatory;
		}
		public String getNameofShipping() {
			return nameofShipping;
		}
		public void setNameofShipping(String nameofShipping) {
			this.nameofShipping = nameofShipping;
		}
		public Integer getNumberofcopy() {
			return numberofcopy;
		}
		public void setNumberofcopy(Integer numberofcopy) {
			this.numberofcopy = numberofcopy;
		}
		public Integer getNumberofOriginal() {
			return numberofOriginal;
		}
		public void setNumberofOriginal(Integer numberofOriginal) {
			this.numberofOriginal = numberofOriginal;
		}
		public String getOriginalOrCopy() {
			return originalOrCopy;
		}
		public void setOriginalOrCopy(String originalOrCopy) {
			this.originalOrCopy = originalOrCopy;
		}
		public String getPackingDate() {
			return packingDate;
		}
		public void setPackingDate(String packingDate) {
			this.packingDate = packingDate;
		}
		public String getPackListNo() {
			return packListNo;
		}
		public void setPackListNo(String packListNo) {
			this.packListNo = packListNo;
		}
		public String getPageNo() {
			return pageNo;
		}
		public void setPageNo(String pageNo) {
			this.pageNo = pageNo;
		}
		public String getPckg1() {
			return pckg1;
		}
		public void setPckg1(String pckg1) {
			this.pckg1 = pckg1;
		}
		public String getPckg2() {
			return pckg2;
		}
		public void setPckg2(String pckg2) {
			this.pckg2 = pckg2;
		}
		public String getPckg3() {
			return pckg3;
		}
		public void setPckg3(String pckg3) {
			this.pckg3 = pckg3;
		}
		public String getPckg4() {
			return pckg4;
		}
		public void setPckg4(String pckg4) {
			this.pckg4 = pckg4;
		}
		public String getPckg5() {
			return pckg5;
		}
		public void setPckg5(String pckg5) {
			this.pckg5 = pckg5;
		}
		public String getPckg6() {
			return pckg6;
		}
		public void setPckg6(String pckg6) {
			this.pckg6 = pckg6;
		}
		public String getPortofDischarge1() {
			return portofDischarge1;
		}
		public void setPortofDischarge1(String portofDischarge1) {
			this.portofDischarge1 = portofDischarge1;
		}
		public String getPortofDischarge2() {
			return portofDischarge2;
		}
		public void setPortofDischarge2(String portofDischarge2) {
			this.portofDischarge2 = portofDischarge2;
		}
		public String getPortofLoading1() {
			return portofLoading1;
		}
		public void setPortofLoading1(String portofLoading1) {
			this.portofLoading1 = portofLoading1;
		}
		public String getPortofLoading2() {
			return portofLoading2;
		}
		public void setPortofLoading2(String portofLoading2) {
			this.portofLoading2 = portofLoading2;
		}
		public String getPriceDescription() {
			return priceDescription;
		}
		public void setPriceDescription(String priceDescription) {
			this.priceDescription = priceDescription;
		}
		public String getProductCode1() {
			return productCode1;
		}
		public void setProductCode1(String productCode1) {
			this.productCode1 = productCode1;
		}
		public String getProductCode10() {
			return productCode10;
		}
		public void setProductCode10(String productCode10) {
			this.productCode10 = productCode10;
		}
		public String getProductCode11() {
			return productCode11;
		}
		public void setProductCode11(String productCode11) {
			this.productCode11 = productCode11;
		}
		public String getProductCode12() {
			return productCode12;
		}
		public void setProductCode12(String productCode12) {
			this.productCode12 = productCode12;
		}
		public String getProductCode13() {
			return productCode13;
		}
		public void setProductCode13(String productCode13) {
			this.productCode13 = productCode13;
		}
		public String getProductCode14() {
			return productCode14;
		}
		public void setProductCode14(String productCode14) {
			this.productCode14 = productCode14;
		}
		public String getProductCode15() {
			return productCode15;
		}
		public void setProductCode15(String productCode15) {
			this.productCode15 = productCode15;
		}
		public String getProductCode16() {
			return productCode16;
		}
		public void setProductCode16(String productCode16) {
			this.productCode16 = productCode16;
		}
		public String getProductCode17() {
			return productCode17;
		}
		public void setProductCode17(String productCode17) {
			this.productCode17 = productCode17;
		}
		public String getProductCode18() {
			return productCode18;
		}
		public void setProductCode18(String productCode18) {
			this.productCode18 = productCode18;
		}
		public String getProductCode19() {
			return productCode19;
		}
		public void setProductCode19(String productCode19) {
			this.productCode19 = productCode19;
		}
		public String getProductCode2() {
			return productCode2;
		}
		public void setProductCode2(String productCode2) {
			this.productCode2 = productCode2;
		}
		public String getProductCode20() {
			return productCode20;
		}
		public void setProductCode20(String productCode20) {
			this.productCode20 = productCode20;
		}
		public String getProductCode21() {
			return productCode21;
		}
		public void setProductCode21(String productCode21) {
			this.productCode21 = productCode21;
		}
		public String getProductCode22() {
			return productCode22;
		}
		public void setProductCode22(String productCode22) {
			this.productCode22 = productCode22;
		}
		public String getProductCode23() {
			return productCode23;
		}
		public void setProductCode23(String productCode23) {
			this.productCode23 = productCode23;
		}
		public String getProductCode24() {
			return productCode24;
		}
		public void setProductCode24(String productCode24) {
			this.productCode24 = productCode24;
		}
		public String getProductCode25() {
			return productCode25;
		}
		public void setProductCode25(String productCode25) {
			this.productCode25 = productCode25;
		}
		public String getProductCode26() {
			return productCode26;
		}
		public void setProductCode26(String productCode26) {
			this.productCode26 = productCode26;
		}
		public String getProductCode27() {
			return productCode27;
		}
		public void setProductCode27(String productCode27) {
			this.productCode27 = productCode27;
		}
		public String getProductCode28() {
			return productCode28;
		}
		public void setProductCode28(String productCode28) {
			this.productCode28 = productCode28;
		}
		public String getProductCode29() {
			return productCode29;
		}
		public void setProductCode29(String productCode29) {
			this.productCode29 = productCode29;
		}
		public String getProductCode3() {
			return productCode3;
		}
		public void setProductCode3(String productCode3) {
			this.productCode3 = productCode3;
		}
		public String getProductCode30() {
			return productCode30;
		}
		public void setProductCode30(String productCode30) {
			this.productCode30 = productCode30;
		}
		public String getProductCode31() {
			return productCode31;
		}
		public void setProductCode31(String productCode31) {
			this.productCode31 = productCode31;
		}
		public String getProductCode32() {
			return productCode32;
		}
		public void setProductCode32(String productCode32) {
			this.productCode32 = productCode32;
		}
		public String getProductCode4() {
			return productCode4;
		}
		public void setProductCode4(String productCode4) {
			this.productCode4 = productCode4;
		}
		public String getProductCode5() {
			return productCode5;
		}
		public void setProductCode5(String productCode5) {
			this.productCode5 = productCode5;
		}
		public String getProductCode6() {
			return productCode6;
		}
		public void setProductCode6(String productCode6) {
			this.productCode6 = productCode6;
		}
		public String getProductCode7() {
			return productCode7;
		}
		public void setProductCode7(String productCode7) {
			this.productCode7 = productCode7;
		}
		public String getProductCode8() {
			return productCode8;
		}
		public void setProductCode8(String productCode8) {
			this.productCode8 = productCode8;
		}
		public String getProductCode9() {
			return productCode9;
		}
		public void setProductCode9(String productCode9) {
			this.productCode9 = productCode9;
		}
		public String getQtyDescription() {
			return qtyDescription;
		}
		public void setQtyDescription(String qtyDescription) {
			this.qtyDescription = qtyDescription;
		}
		public String getQuantity1() {
			return quantity1;
		}
		public void setQuantity1(String quantity1) {
			this.quantity1 = quantity1;
		}
		public String getQuantity10() {
			return quantity10;
		}
		public void setQuantity10(String quantity10) {
			this.quantity10 = quantity10;
		}
		public String getQuantity11() {
			return quantity11;
		}
		public void setQuantity11(String quantity11) {
			this.quantity11 = quantity11;
		}
		public String getQuantity12() {
			return quantity12;
		}
		public void setQuantity12(String quantity12) {
			this.quantity12 = quantity12;
		}
		public String getQuantity13() {
			return quantity13;
		}
		public void setQuantity13(String quantity13) {
			this.quantity13 = quantity13;
		}
		public String getQuantity14() {
			return quantity14;
		}
		public void setQuantity14(String quantity14) {
			this.quantity14 = quantity14;
		}
		public String getQuantity15() {
			return quantity15;
		}
		public void setQuantity15(String quantity15) {
			this.quantity15 = quantity15;
		}
		public String getQuantity16() {
			return quantity16;
		}
		public void setQuantity16(String quantity16) {
			this.quantity16 = quantity16;
		}
		public String getQuantity17() {
			return quantity17;
		}
		public void setQuantity17(String quantity17) {
			this.quantity17 = quantity17;
		}
		public String getQuantity18() {
			return quantity18;
		}
		public void setQuantity18(String quantity18) {
			this.quantity18 = quantity18;
		}
		public String getQuantity19() {
			return quantity19;
		}
		public void setQuantity19(String quantity19) {
			this.quantity19 = quantity19;
		}
		public String getQuantity2() {
			return quantity2;
		}
		public void setQuantity2(String quantity2) {
			this.quantity2 = quantity2;
		}
		public String getQuantity20() {
			return quantity20;
		}
		public void setQuantity20(String quantity20) {
			this.quantity20 = quantity20;
		}
		public String getQuantity21() {
			return quantity21;
		}
		public void setQuantity21(String quantity21) {
			this.quantity21 = quantity21;
		}
		public String getQuantity22() {
			return quantity22;
		}
		public void setQuantity22(String quantity22) {
			this.quantity22 = quantity22;
		}
		public String getQuantity23() {
			return quantity23;
		}
		public void setQuantity23(String quantity23) {
			this.quantity23 = quantity23;
		}
		public String getQuantity24() {
			return quantity24;
		}
		public void setQuantity24(String quantity24) {
			this.quantity24 = quantity24;
		}
		public String getQuantity25() {
			return quantity25;
		}
		public void setQuantity25(String quantity25) {
			this.quantity25 = quantity25;
		}
		public String getQuantity26() {
			return quantity26;
		}
		public void setQuantity26(String quantity26) {
			this.quantity26 = quantity26;
		}
		public String getQuantity27() {
			return quantity27;
		}
		public void setQuantity27(String quantity27) {
			this.quantity27 = quantity27;
		}
		public String getQuantity28() {
			return quantity28;
		}
		public void setQuantity28(String quantity28) {
			this.quantity28 = quantity28;
		}
		public String getQuantity29() {
			return quantity29;
		}
		public void setQuantity29(String quantity29) {
			this.quantity29 = quantity29;
		}
		public String getQuantity3() {
			return quantity3;
		}
		public void setQuantity3(String quantity3) {
			this.quantity3 = quantity3;
		}
		public String getQuantity30() {
			return quantity30;
		}
		public void setQuantity30(String quantity30) {
			this.quantity30 = quantity30;
		}
		public String getQuantity31() {
			return quantity31;
		}
		public void setQuantity31(String quantity31) {
			this.quantity31 = quantity31;
		}
		public String getQuantity32() {
			return quantity32;
		}
		public void setQuantity32(String quantity32) {
			this.quantity32 = quantity32;
		}
		public String getQuantity4() {
			return quantity4;
		}
		public void setQuantity4(String quantity4) {
			this.quantity4 = quantity4;
		}
		public String getQuantity5() {
			return quantity5;
		}
		public void setQuantity5(String quantity5) {
			this.quantity5 = quantity5;
		}
		public String getQuantity6() {
			return quantity6;
		}
		public void setQuantity6(String quantity6) {
			this.quantity6 = quantity6;
		}
		public String getQuantity7() {
			return quantity7;
		}
		public void setQuantity7(String quantity7) {
			this.quantity7 = quantity7;
		}
		public String getQuantity8() {
			return quantity8;
		}
		public void setQuantity8(String quantity8) {
			this.quantity8 = quantity8;
		}
		public String getQuantity9() {
			return quantity9;
		}
		public void setQuantity9(String quantity9) {
			this.quantity9 = quantity9;
		}
		public String getReceivingDate() {
			return receivingDate;
		}
		public void setReceivingDate(String receivingDate) {
			this.receivingDate = receivingDate;
		}
		public String getReimBankBIC() {
			return reimBankBIC;
		}
		public void setReimBankBIC(String reimBankBIC) {
			this.reimBankBIC = reimBankBIC;
		}
		public String getReportTitle() {
			return reportTitle;
		}
		public void setReportTitle(String reportTitle) {
			this.reportTitle = reportTitle;
		}
		public String getShippingCo() {
			return shippingCo;
		}
		public void setShippingCo(String shippingCo) {
			this.shippingCo = shippingCo;
		}
		public String getSignatoryCompanyName() {
			return signatoryCompanyName;
		}
		public void setSignatoryCompanyName(String signatoryCompanyName) {
			this.signatoryCompanyName = signatoryCompanyName;
		}
		public String getSpecial1() {
			return special1;
		}
		public void setSpecial1(String special1) {
			this.special1 = special1;
		}
		public String getSpecial2() {
			return special2;
		}
		public void setSpecial2(String special2) {
			this.special2 = special2;
		}
		public String getSpecial3() {
			return special3;
		}
		public void setSpecial3(String special3) {
			this.special3 = special3;
		}
		public String getSpecial4() {
			return special4;
		}
		public void setSpecial4(String special4) {
			this.special4 = special4;
		}
		public String getSpecial5() {
			return special5;
		}
		public void setSpecial5(String special5) {
			this.special5 = special5;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getTermsLine1() {
			return termsLine1;
		}
		public void setTermsLine1(String termsLine1) {
			this.termsLine1 = termsLine1;
		}
		public String getTermsLine2() {
			return termsLine2;
		}
		public void setTermsLine2(String termsLine2) {
			this.termsLine2 = termsLine2;
		}
		public String getTermsLine3() {
			return termsLine3;
		}
		public void setTermsLine3(String termsLine3) {
			this.termsLine3 = termsLine3;
		}
		public String getTermsLine4() {
			return termsLine4;
		}
		public void setTermsLine4(String termsLine4) {
			this.termsLine4 = termsLine4;
		}
		public String getTermsLine5() {
			return termsLine5;
		}
		public void setTermsLine5(String termsLine5) {
			this.termsLine5 = termsLine5;
		}
		public String getTermsLine6() {
			return termsLine6;
		}
		public void setTermsLine6(String termsLine6) {
			this.termsLine6 = termsLine6;
		}
		public String getToleranceMinus() {
			return toleranceMinus;
		}
		public void setToleranceMinus(String toleranceMinus) {
			this.toleranceMinus = toleranceMinus;
		}
		public String getTotalNumberOfPages() {
			return totalNumberOfPages;
		}
		public void setTotalNumberOfPages(String totalNumberOfPages) {
			this.totalNumberOfPages = totalNumberOfPages;
		}
		public String getTotalPrice1() {
			return totalPrice1;
		}
		public void setTotalPrice1(String totalPrice1) {
			this.totalPrice1 = totalPrice1;
		}
		public String getTotalPrice10() {
			return totalPrice10;
		}
		public void setTotalPrice10(String totalPrice10) {
			this.totalPrice10 = totalPrice10;
		}
		public String getTotalPrice11() {
			return totalPrice11;
		}
		public void setTotalPrice11(String totalPrice11) {
			this.totalPrice11 = totalPrice11;
		}
		public String getTotalPrice12() {
			return totalPrice12;
		}
		public void setTotalPrice12(String totalPrice12) {
			this.totalPrice12 = totalPrice12;
		}
		public String getTotalPrice13() {
			return totalPrice13;
		}
		public void setTotalPrice13(String totalPrice13) {
			this.totalPrice13 = totalPrice13;
		}
		public String getTotalPrice14() {
			return totalPrice14;
		}
		public void setTotalPrice14(String totalPrice14) {
			this.totalPrice14 = totalPrice14;
		}
		public String getTotalPrice15() {
			return totalPrice15;
		}
		public void setTotalPrice15(String totalPrice15) {
			this.totalPrice15 = totalPrice15;
		}
		public String getTotalPrice16() {
			return totalPrice16;
		}
		public void setTotalPrice16(String totalPrice16) {
			this.totalPrice16 = totalPrice16;
		}
		public String getTotalPrice17() {
			return totalPrice17;
		}
		public void setTotalPrice17(String totalPrice17) {
			this.totalPrice17 = totalPrice17;
		}
		public String getTotalPrice18() {
			return totalPrice18;
		}
		public void setTotalPrice18(String totalPrice18) {
			this.totalPrice18 = totalPrice18;
		}
		public String getTotalPrice19() {
			return totalPrice19;
		}
		public void setTotalPrice19(String totalPrice19) {
			this.totalPrice19 = totalPrice19;
		}
		public String getTotalPrice2() {
			return totalPrice2;
		}
		public void setTotalPrice2(String totalPrice2) {
			this.totalPrice2 = totalPrice2;
		}
		public String getTotalPrice20() {
			return totalPrice20;
		}
		public void setTotalPrice20(String totalPrice20) {
			this.totalPrice20 = totalPrice20;
		}
		public String getTotalPrice21() {
			return totalPrice21;
		}
		public void setTotalPrice21(String totalPrice21) {
			this.totalPrice21 = totalPrice21;
		}
		public String getTotalPrice22() {
			return totalPrice22;
		}
		public void setTotalPrice22(String totalPrice22) {
			this.totalPrice22 = totalPrice22;
		}
		public String getTotalPrice23() {
			return totalPrice23;
		}
		public void setTotalPrice23(String totalPrice23) {
			this.totalPrice23 = totalPrice23;
		}
		public String getTotalPrice24() {
			return totalPrice24;
		}
		public void setTotalPrice24(String totalPrice24) {
			this.totalPrice24 = totalPrice24;
		}
		public String getTotalPrice25() {
			return totalPrice25;
		}
		public void setTotalPrice25(String totalPrice25) {
			this.totalPrice25 = totalPrice25;
		}
		public String getTotalPrice26() {
			return totalPrice26;
		}
		public void setTotalPrice26(String totalPrice26) {
			this.totalPrice26 = totalPrice26;
		}
		public String getTotalPrice27() {
			return totalPrice27;
		}
		public void setTotalPrice27(String totalPrice27) {
			this.totalPrice27 = totalPrice27;
		}
		public String getTotalPrice28() {
			return totalPrice28;
		}
		public void setTotalPrice28(String totalPrice28) {
			this.totalPrice28 = totalPrice28;
		}
		public String getTotalPrice29() {
			return totalPrice29;
		}
		public void setTotalPrice29(String totalPrice29) {
			this.totalPrice29 = totalPrice29;
		}
		public String getTotalPrice3() {
			return totalPrice3;
		}
		public void setTotalPrice3(String totalPrice3) {
			this.totalPrice3 = totalPrice3;
		}
		public String getTotalPrice30() {
			return totalPrice30;
		}
		public void setTotalPrice30(String totalPrice30) {
			this.totalPrice30 = totalPrice30;
		}
		public String getTotalPrice31() {
			return totalPrice31;
		}
		public void setTotalPrice31(String totalPrice31) {
			this.totalPrice31 = totalPrice31;
		}
		public String getTotalPrice32() {
			return totalPrice32;
		}
		public void setTotalPrice32(String totalPrice32) {
			this.totalPrice32 = totalPrice32;
		}
		public String getTotalPrice4() {
			return totalPrice4;
		}
		public void setTotalPrice4(String totalPrice4) {
			this.totalPrice4 = totalPrice4;
		}
		public String getTotalPrice5() {
			return totalPrice5;
		}
		public void setTotalPrice5(String totalPrice5) {
			this.totalPrice5 = totalPrice5;
		}
		public String getTotalPrice6() {
			return totalPrice6;
		}
		public void setTotalPrice6(String totalPrice6) {
			this.totalPrice6 = totalPrice6;
		}
		public String getTotalPrice7() {
			return totalPrice7;
		}
		public void setTotalPrice7(String totalPrice7) {
			this.totalPrice7 = totalPrice7;
		}
		public String getTotalPrice8() {
			return totalPrice8;
		}
		public void setTotalPrice8(String totalPrice8) {
			this.totalPrice8 = totalPrice8;
		}
		public String getTotalPrice9() {
			return totalPrice9;
		}
		public void setTotalPrice9(String totalPrice9) {
			this.totalPrice9 = totalPrice9;
		}
		public String getTotalThisPage() {
			return totalThisPage;
		}
		public void setTotalThisPage(String totalThisPage) {
			this.totalThisPage = totalThisPage;
		}
		public String getUnitPrice1() {
			return unitPrice1;
		}
		public void setUnitPrice1(String unitPrice1) {
			this.unitPrice1 = unitPrice1;
		}
		public String getUnitPrice10() {
			return unitPrice10;
		}
		public void setUnitPrice10(String unitPrice10) {
			this.unitPrice10 = unitPrice10;
		}
		public String getUnitPrice11() {
			return unitPrice11;
		}
		public void setUnitPrice11(String unitPrice11) {
			this.unitPrice11 = unitPrice11;
		}
		public String getUnitPrice12() {
			return unitPrice12;
		}
		public void setUnitPrice12(String unitPrice12) {
			this.unitPrice12 = unitPrice12;
		}
		public String getUnitPrice13() {
			return unitPrice13;
		}
		public void setUnitPrice13(String unitPrice13) {
			this.unitPrice13 = unitPrice13;
		}
		public String getUnitPrice14() {
			return unitPrice14;
		}
		public void setUnitPrice14(String unitPrice14) {
			this.unitPrice14 = unitPrice14;
		}
		public String getUnitPrice15() {
			return unitPrice15;
		}
		public void setUnitPrice15(String unitPrice15) {
			this.unitPrice15 = unitPrice15;
		}
		public String getUnitPrice16() {
			return unitPrice16;
		}
		public void setUnitPrice16(String unitPrice16) {
			this.unitPrice16 = unitPrice16;
		}
		public String getUnitPrice17() {
			return unitPrice17;
		}
		public void setUnitPrice17(String unitPrice17) {
			this.unitPrice17 = unitPrice17;
		}
		public String getUnitPrice18() {
			return unitPrice18;
		}
		public void setUnitPrice18(String unitPrice18) {
			this.unitPrice18 = unitPrice18;
		}
		public String getUnitPrice19() {
			return unitPrice19;
		}
		public void setUnitPrice19(String unitPrice19) {
			this.unitPrice19 = unitPrice19;
		}
		public String getUnitPrice2() {
			return unitPrice2;
		}
		public void setUnitPrice2(String unitPrice2) {
			this.unitPrice2 = unitPrice2;
		}
		public String getUnitPrice20() {
			return unitPrice20;
		}
		public void setUnitPrice20(String unitPrice20) {
			this.unitPrice20 = unitPrice20;
		}
		public String getUnitPrice21() {
			return unitPrice21;
		}
		public void setUnitPrice21(String unitPrice21) {
			this.unitPrice21 = unitPrice21;
		}
		public String getUnitPrice22() {
			return unitPrice22;
		}
		public void setUnitPrice22(String unitPrice22) {
			this.unitPrice22 = unitPrice22;
		}
		public String getUnitPrice23() {
			return unitPrice23;
		}
		public void setUnitPrice23(String unitPrice23) {
			this.unitPrice23 = unitPrice23;
		}
		public String getUnitPrice24() {
			return unitPrice24;
		}
		public void setUnitPrice24(String unitPrice24) {
			this.unitPrice24 = unitPrice24;
		}
		public String getUnitPrice25() {
			return unitPrice25;
		}
		public void setUnitPrice25(String unitPrice25) {
			this.unitPrice25 = unitPrice25;
		}
		public String getUnitPrice26() {
			return unitPrice26;
		}
		public void setUnitPrice26(String unitPrice26) {
			this.unitPrice26 = unitPrice26;
		}
		public String getUnitPrice27() {
			return unitPrice27;
		}
		public void setUnitPrice27(String unitPrice27) {
			this.unitPrice27 = unitPrice27;
		}
		public String getUnitPrice28() {
			return unitPrice28;
		}
		public void setUnitPrice28(String unitPrice28) {
			this.unitPrice28 = unitPrice28;
		}
		public String getUnitPrice29() {
			return unitPrice29;
		}
		public void setUnitPrice29(String unitPrice29) {
			this.unitPrice29 = unitPrice29;
		}
		public String getUnitPrice3() {
			return unitPrice3;
		}
		public void setUnitPrice3(String unitPrice3) {
			this.unitPrice3 = unitPrice3;
		}
		public String getUnitPrice30() {
			return unitPrice30;
		}
		public void setUnitPrice30(String unitPrice30) {
			this.unitPrice30 = unitPrice30;
		}
		public String getUnitPrice31() {
			return unitPrice31;
		}
		public void setUnitPrice31(String unitPrice31) {
			this.unitPrice31 = unitPrice31;
		}
		public String getUnitPrice32() {
			return unitPrice32;
		}
		public void setUnitPrice32(String unitPrice32) {
			this.unitPrice32 = unitPrice32;
		}
		public String getUnitPrice4() {
			return unitPrice4;
		}
		public void setUnitPrice4(String unitPrice4) {
			this.unitPrice4 = unitPrice4;
		}
		public String getUnitPrice5() {
			return unitPrice5;
		}
		public void setUnitPrice5(String unitPrice5) {
			this.unitPrice5 = unitPrice5;
		}
		public String getUnitPrice6() {
			return unitPrice6;
		}
		public void setUnitPrice6(String unitPrice6) {
			this.unitPrice6 = unitPrice6;
		}
		public String getUnitPrice7() {
			return unitPrice7;
		}
		public void setUnitPrice7(String unitPrice7) {
			this.unitPrice7 = unitPrice7;
		}
		public String getUnitPrice8() {
			return unitPrice8;
		}
		public void setUnitPrice8(String unitPrice8) {
			this.unitPrice8 = unitPrice8;
		}
		public String getUnitPrice9() {
			return unitPrice9;
		}
		public void setUnitPrice9(String unitPrice9) {
			this.unitPrice9 = unitPrice9;
		}
		public String getVessel() {
			return vessel;
		}
		public void setVessel(String vessel) {
			this.vessel = vessel;
		}
		public String getVoyageNumber() {
			return voyageNumber;
		}
		public void setVoyageNumber(String voyageNumber) {
			this.voyageNumber = voyageNumber;
		}
}
