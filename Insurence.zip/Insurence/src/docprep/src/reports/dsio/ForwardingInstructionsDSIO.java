package docprep.src.reports.dsio;

public class ForwardingInstructionsDSIO {

	private String companyName;

	private String companyAdd1;

	private String companyAdd2;

	private String city;

	private String state;

	private String country;

	private String exporterRef;

	private String customValue;

	private String shipCompany;

	private String shipper;

	private String lcllcl;

	private String fclfcl;

	private String fcllcl;

	private String lclfcl;

	private String breakbulk;

	private String hh;

	private String hp;

	private String pp;

	private String ph;

	private String suplierName;

	private String suplierAddress1;

	private String suplierAddress2;
	
	private String suplierCity;
	
	private String suplierState;
	
	private String suplierCountry;

	private String line1;

	private String line2;

	private String line3;

	private String marks1;

	private String marks2;

	private String marks3;

	private String marks4;

	private String marks5;

	private String marks6;

	private  String pkgs1;

	private  String pkgs2;

	private  String pkgs3;

	private  String pkgs4;

	private  String pkgs5;

	private  String pkgs6;

	private String description1;

	private String description2;

	private String description3;

	private String description4;

	private String description5;

	private String description6;

	private String gross1 ;

	private String gross2 ;

	private String gross3 ;

	private String gross4 ;

	private String gross5 ;

	private String gross6 ;
	
	private String cubic1 ;

    private String cubic2 ;

    private String cubic3;

    private String cubic4;

    private String cubic5 ;

    private String cubic6 ;

	private String quantity1;

	private String quantity2;

	private String quantity3;

	private String quantity4;

	private String quantity5;

	private String quantity6;

	private String quantity7;

	private String quantity8;

	private String quantity9;

	private String quantity10;

	private String quantity11;

	private String quantity12;

	private String quantity13;

	private String quantity14;

	private String quantity15;

	private String quantity16;

	private String productCode1;

	private String productCode2;

	private String productCode3;

	private String productCode4;

	private String productCode5;

	private String productCode6;

	private String productCode7;

	private String productCode8;

	private String productCode9;

	private String productCode10;

	private String productCode11;

	private String productCode12;

	private String productCode13;

	private String productCode14;

	private String productCode15;

	private String productCode16;

	private String unitPrice1 ;

    private String unitPrice2 ;

    private String unitPrice3  ;

    private String unitPrice4 ;

    private String unitPrice5;

    private String unitPrice6 ;

    private String unitPrice7 ;

    private String unitPrice8 ;

    private String unitPrice9 ;

    private String unitPrice10 ;

    private String unitPrice11 ;

    private String unitPrice12 ;

    private String unitPrice13 ;

    private String unitPrice14 ;

    private String unitPrice15 ;

    private String unitPrice16 ;

    private String totalPrice1;

    private String totalPrice2;

    private String totalPrice3;

    private String totalPrice4 ;

    private String totalPrice5;

    private String totalPrice6 ;

    private String totalPrice7 ;

    private String totalPrice8;

    private String totalPrice9 ;

    private String totalPrice10;

    private String totalPrice11;

    private String totalPrice12;

    private String totalPrice13;

    private String totalPrice14 ;

    private String totalPrice15 ;

    private String totalPrice16;
	
	private String printOriginals;

	private String printCopies;

	private String itemDescription1;

	private String itemDescription2;

	private String itemDescription3;

	private String itemDescription4;

	private String itemDescription5;

	private String itemDescription6;

	private String itemDescription7;

	private String itemDescription8;

	private String itemDescription9;

	private String itemDescription10;

	private String itemDescription11;

	private String itemDescription12;

	private String itemDescription13;

	private String itemDescription14;

	private String itemDescription15;

	private String itemDescription16;

	private String docDesc;
	
	public ForwardingInstructionsDSIO() {
		
	}
	
	public String getBreakbulk() {
		return breakbulk;
	}
	public void setBreakbulk(String breakbulk) {
		this.breakbulk = breakbulk;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCompanyAdd1() {
		return companyAdd1;
	}
	public void setCompanyAdd1(String companyAdd1) {
		this.companyAdd1 = companyAdd1;
	}
	public String getCompanyAdd2() {
		return companyAdd2;
	}
	public void setCompanyAdd2(String companyAdd2) {
		this.companyAdd2 = companyAdd2;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCubic1() {
		return cubic1;
	}
	public void setCubic1(String cubic1) {
		this.cubic1 = cubic1;
	}
	public String getCubic2() {
		return cubic2;
	}
	public void setCubic2(String cubic2) {
		this.cubic2 = cubic2;
	}
	public String getCubic3() {
		return cubic3;
	}
	public void setCubic3(String cubic3) {
		this.cubic3 = cubic3;
	}
	public String getCubic4() {
		return cubic4;
	}
	public void setCubic4(String cubic4) {
		this.cubic4 = cubic4;
	}
	public String getCubic5() {
		return cubic5;
	}
	public void setCubic5(String cubic5) {
		this.cubic5 = cubic5;
	}
	public String getCubic6() {
		return cubic6;
	}
	public void setCubic6(String cubic6) {
		this.cubic6 = cubic6;
	}
	public String getCustomValue() {
		return customValue;
	}
	public void setCustomValue(String customValue) {
		this.customValue = customValue;
	}
	public String getDescription1() {
		return description1;
	}
	public void setDescription1(String description1) {
		this.description1 = description1;
	}
	public String getDescription2() {
		return description2;
	}
	public void setDescription2(String description2) {
		this.description2 = description2;
	}
	public String getDescription3() {
		return description3;
	}
	public void setDescription3(String description3) {
		this.description3 = description3;
	}
	public String getDescription4() {
		return description4;
	}
	public void setDescription4(String description4) {
		this.description4 = description4;
	}
	public String getDescription5() {
		return description5;
	}
	public void setDescription5(String description5) {
		this.description5 = description5;
	}
	public String getDescription6() {
		return description6;
	}
	public void setDescription6(String description6) {
		this.description6 = description6;
	}
	public String getDocDesc() {
		return docDesc;
	}
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	public String getExporterRef() {
		return exporterRef;
	}
	public void setExporterRef(String exporterRef) {
		this.exporterRef = exporterRef;
	}
	public String getFclfcl() {
		return fclfcl;
	}
	public void setFclfcl(String fclfcl) {
		this.fclfcl = fclfcl;
	}
	public String getFcllcl() {
		return fcllcl;
	}
	public void setFcllcl(String fcllcl) {
		this.fcllcl = fcllcl;
	}
	public String getGross1() {
		return gross1;
	}
	public void setGross1(String gross1) {
		this.gross1 = gross1;
	}
	public String getGross2() {
		return gross2;
	}
	public void setGross2(String gross2) {
		this.gross2 = gross2;
	}
	public String getGross3() {
		return gross3;
	}
	public void setGross3(String gross3) {
		this.gross3 = gross3;
	}
	public String getGross4() {
		return gross4;
	}
	public void setGross4(String gross4) {
		this.gross4 = gross4;
	}
	public String getGross5() {
		return gross5;
	}
	public void setGross5(String gross5) {
		this.gross5 = gross5;
	}
	public String getGross6() {
		return gross6;
	}
	public void setGross6(String gross6) {
		this.gross6 = gross6;
	}
	public String getHh() {
		return hh;
	}
	public void setHh(String hh) {
		this.hh = hh;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getItemDescription1() {
		return itemDescription1;
	}
	public void setItemDescription1(String itemDescription1) {
		this.itemDescription1 = itemDescription1;
	}
	public String getItemDescription10() {
		return itemDescription10;
	}
	public void setItemDescription10(String itemDescription10) {
		this.itemDescription10 = itemDescription10;
	}
	public String getItemDescription11() {
		return itemDescription11;
	}
	public void setItemDescription11(String itemDescription11) {
		this.itemDescription11 = itemDescription11;
	}
	public String getItemDescription12() {
		return itemDescription12;
	}
	public void setItemDescription12(String itemDescription12) {
		this.itemDescription12 = itemDescription12;
	}
	public String getItemDescription13() {
		return itemDescription13;
	}
	public void setItemDescription13(String itemDescription13) {
		this.itemDescription13 = itemDescription13;
	}
	public String getItemDescription14() {
		return itemDescription14;
	}
	public void setItemDescription14(String itemDescription14) {
		this.itemDescription14 = itemDescription14;
	}
	public String getItemDescription15() {
		return itemDescription15;
	}
	public void setItemDescription15(String itemDescription15) {
		this.itemDescription15 = itemDescription15;
	}
	public String getItemDescription16() {
		return itemDescription16;
	}
	public void setItemDescription16(String itemDescription16) {
		this.itemDescription16 = itemDescription16;
	}
	public String getItemDescription2() {
		return itemDescription2;
	}
	public void setItemDescription2(String itemDescription2) {
		this.itemDescription2 = itemDescription2;
	}
	public String getItemDescription3() {
		return itemDescription3;
	}
	public void setItemDescription3(String itemDescription3) {
		this.itemDescription3 = itemDescription3;
	}
	public String getItemDescription4() {
		return itemDescription4;
	}
	public void setItemDescription4(String itemDescription4) {
		this.itemDescription4 = itemDescription4;
	}
	public String getItemDescription5() {
		return itemDescription5;
	}
	public void setItemDescription5(String itemDescription5) {
		this.itemDescription5 = itemDescription5;
	}
	public String getItemDescription6() {
		return itemDescription6;
	}
	public void setItemDescription6(String itemDescription6) {
		this.itemDescription6 = itemDescription6;
	}
	public String getItemDescription7() {
		return itemDescription7;
	}
	public void setItemDescription7(String itemDescription7) {
		this.itemDescription7 = itemDescription7;
	}
	public String getItemDescription8() {
		return itemDescription8;
	}
	public void setItemDescription8(String itemDescription8) {
		this.itemDescription8 = itemDescription8;
	}
	public String getItemDescription9() {
		return itemDescription9;
	}
	public void setItemDescription9(String itemDescription9) {
		this.itemDescription9 = itemDescription9;
	}
	public String getLclfcl() {
		return lclfcl;
	}
	public void setLclfcl(String lclfcl) {
		this.lclfcl = lclfcl;
	}
	public String getLcllcl() {
		return lcllcl;
	}
	public void setLcllcl(String lcllcl) {
		this.lcllcl = lcllcl;
	}
	public String getLine1() {
		return line1;
	}
	public void setLine1(String line1) {
		this.line1 = line1;
	}
	public String getLine2() {
		return line2;
	}
	public void setLine2(String line2) {
		this.line2 = line2;
	}
	public String getLine3() {
		return line3;
	}
	public void setLine3(String line3) {
		this.line3 = line3;
	}
	public String getMarks1() {
		return marks1;
	}
	public void setMarks1(String marks1) {
		this.marks1 = marks1;
	}
	public String getMarks2() {
		return marks2;
	}
	public void setMarks2(String marks2) {
		this.marks2 = marks2;
	}
	public String getMarks3() {
		return marks3;
	}
	public void setMarks3(String marks3) {
		this.marks3 = marks3;
	}
	public String getMarks4() {
		return marks4;
	}
	public void setMarks4(String marks4) {
		this.marks4 = marks4;
	}
	public String getMarks5() {
		return marks5;
	}
	public void setMarks5(String marks5) {
		this.marks5 = marks5;
	}
	public String getMarks6() {
		return marks6;
	}
	public void setMarks6(String marks6) {
		this.marks6 = marks6;
	}
	public String getPh() {
		return ph;
	}
	public void setPh(String ph) {
		this.ph = ph;
	}
	public String getPkgs1() {
		return pkgs1;
	}
	public void setPkgs1(String pkgs1) {
		this.pkgs1 = pkgs1;
	}
	public String getPkgs2() {
		return pkgs2;
	}
	public void setPkgs2(String pkgs2) {
		this.pkgs2 = pkgs2;
	}
	public String getPkgs3() {
		return pkgs3;
	}
	public void setPkgs3(String pkgs3) {
		this.pkgs3 = pkgs3;
	}
	public String getPkgs4() {
		return pkgs4;
	}
	public void setPkgs4(String pkgs4) {
		this.pkgs4 = pkgs4;
	}
	public String getPkgs5() {
		return pkgs5;
	}
	public void setPkgs5(String pkgs5) {
		this.pkgs5 = pkgs5;
	}
	public String getPkgs6() {
		return pkgs6;
	}
	public void setPkgs6(String pkgs6) {
		this.pkgs6 = pkgs6;
	}
	public String getPp() {
		return pp;
	}
	public void setPp(String pp) {
		this.pp = pp;
	}
	public String getPrintCopies() {
		return printCopies;
	}
	public void setPrintCopies(String printCopies) {
		this.printCopies = printCopies;
	}
	public String getPrintOriginals() {
		return printOriginals;
	}
	public void setPrintOriginals(String printOriginals) {
		this.printOriginals = printOriginals;
	}
	public String getProductCode1() {
		return productCode1;
	}
	public void setProductCode1(String productCode1) {
		this.productCode1 = productCode1;
	}
	public String getProductCode10() {
		return productCode10;
	}
	public void setProductCode10(String productCode10) {
		this.productCode10 = productCode10;
	}
	public String getProductCode11() {
		return productCode11;
	}
	public void setProductCode11(String productCode11) {
		this.productCode11 = productCode11;
	}
	public String getProductCode12() {
		return productCode12;
	}
	public void setProductCode12(String productCode12) {
		this.productCode12 = productCode12;
	}
	public String getProductCode13() {
		return productCode13;
	}
	public void setProductCode13(String productCode13) {
		this.productCode13 = productCode13;
	}
	public String getProductCode14() {
		return productCode14;
	}
	public void setProductCode14(String productCode14) {
		this.productCode14 = productCode14;
	}
	public String getProductCode15() {
		return productCode15;
	}
	public void setProductCode15(String productCode15) {
		this.productCode15 = productCode15;
	}
	public String getProductCode16() {
		return productCode16;
	}
	public void setProductCode16(String productCode16) {
		this.productCode16 = productCode16;
	}
	public String getProductCode2() {
		return productCode2;
	}
	public void setProductCode2(String productCode2) {
		this.productCode2 = productCode2;
	}
	public String getProductCode3() {
		return productCode3;
	}
	public void setProductCode3(String productCode3) {
		this.productCode3 = productCode3;
	}
	public String getProductCode4() {
		return productCode4;
	}
	public void setProductCode4(String productCode4) {
		this.productCode4 = productCode4;
	}
	public String getProductCode5() {
		return productCode5;
	}
	public void setProductCode5(String productCode5) {
		this.productCode5 = productCode5;
	}
	public String getProductCode6() {
		return productCode6;
	}
	public void setProductCode6(String productCode6) {
		this.productCode6 = productCode6;
	}
	public String getProductCode7() {
		return productCode7;
	}
	public void setProductCode7(String productCode7) {
		this.productCode7 = productCode7;
	}
	public String getProductCode8() {
		return productCode8;
	}
	public void setProductCode8(String productCode8) {
		this.productCode8 = productCode8;
	}
	public String getProductCode9() {
		return productCode9;
	}
	public void setProductCode9(String productCode9) {
		this.productCode9 = productCode9;
	}
	public String getQuantity1() {
		return quantity1;
	}
	public void setQuantity1(String quantity1) {
		this.quantity1 = quantity1;
	}
	public String getQuantity10() {
		return quantity10;
	}
	public void setQuantity10(String quantity10) {
		this.quantity10 = quantity10;
	}
	public String getQuantity11() {
		return quantity11;
	}
	public void setQuantity11(String quantity11) {
		this.quantity11 = quantity11;
	}
	public String getQuantity12() {
		return quantity12;
	}
	public void setQuantity12(String quantity12) {
		this.quantity12 = quantity12;
	}
	public String getQuantity13() {
		return quantity13;
	}
	public void setQuantity13(String quantity13) {
		this.quantity13 = quantity13;
	}
	public String getQuantity14() {
		return quantity14;
	}
	public void setQuantity14(String quantity14) {
		this.quantity14 = quantity14;
	}
	public String getQuantity15() {
		return quantity15;
	}
	public void setQuantity15(String quantity15) {
		this.quantity15 = quantity15;
	}
	public String getQuantity16() {
		return quantity16;
	}
	public void setQuantity16(String quantity16) {
		this.quantity16 = quantity16;
	}
	public String getQuantity2() {
		return quantity2;
	}
	public void setQuantity2(String quantity2) {
		this.quantity2 = quantity2;
	}
	public String getQuantity3() {
		return quantity3;
	}
	public void setQuantity3(String quantity3) {
		this.quantity3 = quantity3;
	}
	public String getQuantity4() {
		return quantity4;
	}
	public void setQuantity4(String quantity4) {
		this.quantity4 = quantity4;
	}
	public String getQuantity5() {
		return quantity5;
	}
	public void setQuantity5(String quantity5) {
		this.quantity5 = quantity5;
	}
	public String getQuantity6() {
		return quantity6;
	}
	public void setQuantity6(String quantity6) {
		this.quantity6 = quantity6;
	}
	public String getQuantity7() {
		return quantity7;
	}
	public void setQuantity7(String quantity7) {
		this.quantity7 = quantity7;
	}
	public String getQuantity8() {
		return quantity8;
	}
	public void setQuantity8(String quantity8) {
		this.quantity8 = quantity8;
	}
	public String getQuantity9() {
		return quantity9;
	}
	public void setQuantity9(String quantity9) {
		this.quantity9 = quantity9;
	}
	public String getShipCompany() {
		return shipCompany;
	}
	public void setShipCompany(String shipCompany) {
		this.shipCompany = shipCompany;
	}
	public String getShipper() {
		return shipper;
	}
	public void setShipper(String shipper) {
		this.shipper = shipper;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getSuplierAddress1() {
		return suplierAddress1;
	}
	public void setSuplierAddress1(String suplierAddress1) {
		this.suplierAddress1 = suplierAddress1;
	}
	public String getSuplierAddress2() {
		return suplierAddress2;
	}
	public void setSuplierAddress2(String suplierAddress2) {
		this.suplierAddress2 = suplierAddress2;
	}
	public String getSuplierCity() {
		return suplierCity;
	}
	public void setSuplierCity(String suplierCity) {
		this.suplierCity = suplierCity;
	}
	public String getSuplierCountry() {
		return suplierCountry;
	}
	public void setSuplierCountry(String suplierCountry) {
		this.suplierCountry = suplierCountry;
	}
	public String getSuplierName() {
		return suplierName;
	}
	public void setSuplierName(String suplierName) {
		this.suplierName = suplierName;
	}
	public String getSuplierState() {
		return suplierState;
	}
	public void setSuplierState(String suplierState) {
		this.suplierState = suplierState;
	}
	public String getTotalPrice1() {
		return totalPrice1;
	}
	public void setTotalPrice1(String totalPrice1) {
		this.totalPrice1 = totalPrice1;
	}
	public String getTotalPrice10() {
		return totalPrice10;
	}
	public void setTotalPrice10(String totalPrice10) {
		this.totalPrice10 = totalPrice10;
	}
	public String getTotalPrice11() {
		return totalPrice11;
	}
	public void setTotalPrice11(String totalPrice11) {
		this.totalPrice11 = totalPrice11;
	}
	public String getTotalPrice12() {
		return totalPrice12;
	}
	public void setTotalPrice12(String totalPrice12) {
		this.totalPrice12 = totalPrice12;
	}
	public String getTotalPrice13() {
		return totalPrice13;
	}
	public void setTotalPrice13(String totalPrice13) {
		this.totalPrice13 = totalPrice13;
	}
	public String getTotalPrice14() {
		return totalPrice14;
	}
	public void setTotalPrice14(String totalPrice14) {
		this.totalPrice14 = totalPrice14;
	}
	public String getTotalPrice15() {
		return totalPrice15;
	}
	public void setTotalPrice15(String totalPrice15) {
		this.totalPrice15 = totalPrice15;
	}
	public String getTotalPrice16() {
		return totalPrice16;
	}
	public void setTotalPrice16(String totalPrice16) {
		this.totalPrice16 = totalPrice16;
	}
	public String getTotalPrice2() {
		return totalPrice2;
	}
	public void setTotalPrice2(String totalPrice2) {
		this.totalPrice2 = totalPrice2;
	}
	public String getTotalPrice3() {
		return totalPrice3;
	}
	public void setTotalPrice3(String totalPrice3) {
		this.totalPrice3 = totalPrice3;
	}
	public String getTotalPrice4() {
		return totalPrice4;
	}
	public void setTotalPrice4(String totalPrice4) {
		this.totalPrice4 = totalPrice4;
	}
	public String getTotalPrice5() {
		return totalPrice5;
	}
	public void setTotalPrice5(String totalPrice5) {
		this.totalPrice5 = totalPrice5;
	}
	public String getTotalPrice6() {
		return totalPrice6;
	}
	public void setTotalPrice6(String totalPrice6) {
		this.totalPrice6 = totalPrice6;
	}
	public String getTotalPrice7() {
		return totalPrice7;
	}
	public void setTotalPrice7(String totalPrice7) {
		this.totalPrice7 = totalPrice7;
	}
	public String getTotalPrice8() {
		return totalPrice8;
	}
	public void setTotalPrice8(String totalPrice8) {
		this.totalPrice8 = totalPrice8;
	}
	public String getTotalPrice9() {
		return totalPrice9;
	}
	public void setTotalPrice9(String totalPrice9) {
		this.totalPrice9 = totalPrice9;
	}
	public String getUnitPrice1() {
		return unitPrice1;
	}
	public void setUnitPrice1(String unitPrice1) {
		this.unitPrice1 = unitPrice1;
	}
	public String getUnitPrice10() {
		return unitPrice10;
	}
	public void setUnitPrice10(String unitPrice10) {
		this.unitPrice10 = unitPrice10;
	}
	public String getUnitPrice11() {
		return unitPrice11;
	}
	public void setUnitPrice11(String unitPrice11) {
		this.unitPrice11 = unitPrice11;
	}
	public String getUnitPrice12() {
		return unitPrice12;
	}
	public void setUnitPrice12(String unitPrice12) {
		this.unitPrice12 = unitPrice12;
	}
	public String getUnitPrice13() {
		return unitPrice13;
	}
	public void setUnitPrice13(String unitPrice13) {
		this.unitPrice13 = unitPrice13;
	}
	public String getUnitPrice14() {
		return unitPrice14;
	}
	public void setUnitPrice14(String unitPrice14) {
		this.unitPrice14 = unitPrice14;
	}
	public String getUnitPrice15() {
		return unitPrice15;
	}
	public void setUnitPrice15(String unitPrice15) {
		this.unitPrice15 = unitPrice15;
	}
	public String getUnitPrice16() {
		return unitPrice16;
	}
	public void setUnitPrice16(String unitPrice16) {
		this.unitPrice16 = unitPrice16;
	}
	public String getUnitPrice2() {
		return unitPrice2;
	}
	public void setUnitPrice2(String unitPrice2) {
		this.unitPrice2 = unitPrice2;
	}
	public String getUnitPrice3() {
		return unitPrice3;
	}
	public void setUnitPrice3(String unitPrice3) {
		this.unitPrice3 = unitPrice3;
	}
	public String getUnitPrice4() {
		return unitPrice4;
	}
	public void setUnitPrice4(String unitPrice4) {
		this.unitPrice4 = unitPrice4;
	}
	public String getUnitPrice5() {
		return unitPrice5;
	}
	public void setUnitPrice5(String unitPrice5) {
		this.unitPrice5 = unitPrice5;
	}
	public String getUnitPrice6() {
		return unitPrice6;
	}
	public void setUnitPrice6(String unitPrice6) {
		this.unitPrice6 = unitPrice6;
	}
	public String getUnitPrice7() {
		return unitPrice7;
	}
	public void setUnitPrice7(String unitPrice7) {
		this.unitPrice7 = unitPrice7;
	}
	public String getUnitPrice8() {
		return unitPrice8;
	}
	public void setUnitPrice8(String unitPrice8) {
		this.unitPrice8 = unitPrice8;
	}
	public String getUnitPrice9() {
		return unitPrice9;
	}
	public void setUnitPrice9(String unitPrice9) {
		this.unitPrice9 = unitPrice9;
	}
}