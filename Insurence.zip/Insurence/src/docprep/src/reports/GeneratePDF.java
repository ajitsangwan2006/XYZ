package docprep.src.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.services.SystemUtil;

public class GeneratePDF {

    public GeneratePDF() {
        super();
    }

    public byte[] getPreparedPDF(InputStream jasperStream, PackingListDetailsDataSource dataSource, Map parameters) throws InvalidArgumentException {
        byte[] bytes = null;
        try {
            File tempFile = new File(SystemUtil.getPrintFolder());
            if (!tempFile.exists()) {
                tempFile.mkdirs();
            }
            tempFile = File.createTempFile("temp", ".pdf", tempFile);
            JasperPrint print = JasperFillManager.fillReport(jasperStream, parameters, dataSource.create(null));
            OutputStream output = new FileOutputStream(tempFile);
            JasperExportManager.exportReportToPdfStream(print, output);
            output.close();
            java.io.FileInputStream pdfFile = new java.io.FileInputStream(tempFile);
            bytes = new byte[pdfFile.available()];
            pdfFile.read(bytes);
            pdfFile.close();
            tempFile.delete();
        } catch (FileNotFoundException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        } catch (IOException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        } catch (JRException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        }
        return bytes;
    }
    
    public byte[] getPreparedPDF(InputStream jasperStream, ForwardingInstructionsDataSource dataSource, Map parameters) throws InvalidArgumentException {
        byte[] bytes = null;
        try {
            File tempFile = new File(SystemUtil.getPrintFolder());
            if (!tempFile.exists()) {
                tempFile.mkdirs();
            }
            tempFile = File.createTempFile("temp", ".pdf", tempFile);
            JasperPrint print = JasperFillManager.fillReport(jasperStream, parameters, dataSource.create(null));
            OutputStream output = new FileOutputStream(tempFile);
            JasperExportManager.exportReportToPdfStream(print, output);
            output.close();
            java.io.FileInputStream pdfFile = new java.io.FileInputStream(tempFile);
            bytes = new byte[pdfFile.available()];
            pdfFile.read(bytes);
            pdfFile.close();
            tempFile.delete();
        } catch (FileNotFoundException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        } catch (IOException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        } catch (JRException e) {
        	e.printStackTrace();
            throw new InvalidArgumentException(e.getMessage());
        }
        return bytes;
    }
    
}
