package docprep.src.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class ResourceFileAccess {

    static private ResourceFileAccess instance = new ResourceFileAccess();

    private InputStream jasperStream = null;    

    private ResourceFileAccess() {
        super();
    }

    public static ResourceFileAccess getInstance() {
        return instance;
    }
   
    public InputStream getJasperInputStream(String jasperName) {
        jasperStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "reports" + File.separator + "jasper" + File.separator + jasperName);
    	return jasperStream;
    }
    
    public void createResources() {
        try {
            java.io.FileOutputStream fout = null;            
            InputStream fontStream = null;
            byte[] fontBytes = null;
                    
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "verdana.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "verdana.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;
            
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "verdanab.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "verdanab.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;           
            
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "arial.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "arial.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;
            
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "arialbd.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "arialbd.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;
            
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "arialbi.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "arialbi.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;
            
            fontStream = this.getClass().getResourceAsStream("/docprep" + File.separator + "src" + File.separator + "resources" + File.separator + "ariali.ttf");
            fontBytes = new byte[fontStream.available()];
            fontStream.read(fontBytes);
            fontStream.close();
            fontStream = null;
            fout = new java.io.FileOutputStream(System.getProperty("user.dir") + File.separator + "ariali.ttf");
            fout.write(fontBytes);
            fout.close();
            fout = null;
            fontBytes = null;
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
