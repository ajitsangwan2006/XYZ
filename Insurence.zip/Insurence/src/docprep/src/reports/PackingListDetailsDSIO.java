package docprep.src.reports.dsio;

public class PackingListDetailsDSIO {

    private Integer lineNumber;
    
    private Integer pageNo;

    private String packListNo;

    private String productCode;

    private String marksOrDetail;

    private String quantity;

    private String netWeight;

    private String grossWeight;

    private String cubicWeight;

    private String detail;

    private String exporterReference;

    private String buyerReference;

    private String exporterName;

    private String exporterAbnNo;

    private String exporterStreetNo;

    private String exporterStreetName;

    private String exporterCity;

    private String exporterState;

    private String exporterCountry;

    private String buyerName;

    private String buyerStreetNo;

    private String buyerStreetName;

    private String buyerCity;

    private String buyerState;

    private String buyerCountry;

    private String consigneeName;

    private String consigneeStreetNo;

    private String consigneeStreetName;

    private String consigneeCity;

    private String consigneeState;

    private String consigneeCountry;

    private String packingDate;

    private String methodOfDispatch;

    private String internalLine1;

    private String internalLine2;

    private String internalLine3;

    private String internalLine4;

    private String internalLine5;

    private String internalLine6;

    private String internalLine7;

    private String issueDate;

    private String issuePlace;

    private String signatoryCompanyName;

    private String nameofAuthorizedSignatory;

    private String marks1;

    private String pckg1;

    private String grossMass1;

    private String cubic1;

    private String marks2;

    private String pckg2;

    private String grossMass2;

    private String cubic2;

    private String marks3;

    private String pckg3;

    private String grossMass3;

    private String cubic3;

    private String marks4;

    private String pckg4;

    private String grossMass4;

    private String cubic4;

    private String marks5;

    private String pckg5;

    private String grossMass5;

    private String cubic5;

    private String marks6;

    private String pckg6;

    private String grossMass6;

    private String cubic6;

    private String marks7;

    private String pckg7;

    private String grossMass7;

    private String cubic7;

    public PackingListDetailsDSIO() {

    }

    public String getCubicWeight() {
        return cubicWeight;
    }

    public void setCubicWeight(String cubicWeight) {
        this.cubicWeight = cubicWeight;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(String grossWeight) {
        this.grossWeight = grossWeight;
    }

    public Integer getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getMarksOrDetail() {
        return marksOrDetail;
    }

    public void setMarksOrDetail(String marksOrDetail) {
        this.marksOrDetail = marksOrDetail;
    }

    public String getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(String netWeight) {
        this.netWeight = netWeight;
    }

    public String getPackListNo() {
        return packListNo;
    }

    public void setPackListNo(String packListNo) {
        this.packListNo = packListNo;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getBuyerCity() {
        return buyerCity;
    }

    public void setBuyerCity(String buyerCity) {
        this.buyerCity = buyerCity;
    }

    public String getBuyerCountry() {
        return buyerCountry;
    }

    public void setBuyerCountry(String buyerCountry) {
        this.buyerCountry = buyerCountry;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getBuyerReference() {
        return buyerReference;
    }

    public void setBuyerReference(String buyerReference) {
        this.buyerReference = buyerReference;
    }

    public String getBuyerState() {
        return buyerState;
    }

    public void setBuyerState(String buyerState) {
        this.buyerState = buyerState;
    }

    public String getBuyerStreetName() {
        return buyerStreetName;
    }

    public void setBuyerStreetName(String buyerStreetName) {
        this.buyerStreetName = buyerStreetName;
    }

    public String getBuyerStreetNo() {
        return buyerStreetNo;
    }

    public void setBuyerStreetNo(String buyerStreetNo) {
        this.buyerStreetNo = buyerStreetNo;
    }

    public String getConsigneeCity() {
        return consigneeCity;
    }

    public void setConsigneeCity(String consigneeCity) {
        this.consigneeCity = consigneeCity;
    }

    public String getConsigneeCountry() {
        return consigneeCountry;
    }

    public void setConsigneeCountry(String consigneeCountry) {
        this.consigneeCountry = consigneeCountry;
    }

    public String getConsigneeName() {
        return consigneeName;
    }

    public void setConsigneeName(String consigneeName) {
        this.consigneeName = consigneeName;
    }

    public String getConsigneeState() {
        return consigneeState;
    }

    public void setConsigneeState(String consigneeState) {
        this.consigneeState = consigneeState;
    }

    public String getConsigneeStreetName() {
        return consigneeStreetName;
    }

    public void setConsigneeStreetName(String consigneeStreetName) {
        this.consigneeStreetName = consigneeStreetName;
    }

    public String getConsigneeStreetNo() {
        return consigneeStreetNo;
    }

    public void setConsigneeStreetNo(String consigneeStreetNo) {
        this.consigneeStreetNo = consigneeStreetNo;
    }

    public String getExporterAbnNo() {
        return exporterAbnNo;
    }

    public void setExporterAbnNo(String exporterAbnNo) {
        this.exporterAbnNo = exporterAbnNo;
    }

    public String getExporterCity() {
        return exporterCity;
    }

    public void setExporterCity(String exporterCity) {
        this.exporterCity = exporterCity;
    }

    public String getExporterCountry() {
        return exporterCountry;
    }

    public void setExporterCountry(String exporterCountry) {
        this.exporterCountry = exporterCountry;
    }

    public String getExporterName() {
        return exporterName;
    }

    public void setExporterName(String exporterName) {
        this.exporterName = exporterName;
    }

    public String getExporterReference() {
        return exporterReference;
    }

    public void setExporterReference(String exporterReference) {
        this.exporterReference = exporterReference;
    }

    public String getExporterState() {
        return exporterState;
    }

    public void setExporterState(String exporterState) {
        this.exporterState = exporterState;
    }

    public String getExporterStreetName() {
        return exporterStreetName;
    }

    public void setExporterStreetName(String exporterStreetName) {
        this.exporterStreetName = exporterStreetName;
    }

    public String getExporterStreetNo() {
        return exporterStreetNo;
    }

    public void setExporterStreetNo(String exporterStreetNo) {
        this.exporterStreetNo = exporterStreetNo;
    }

    public String getInternalLine1() {
        return internalLine1;
    }

    public void setInternalLine1(String internalLine1) {
        this.internalLine1 = internalLine1;
    }

    public String getInternalLine2() {
        return internalLine2;
    }

    public void setInternalLine2(String internalLine2) {
        this.internalLine2 = internalLine2;
    }

    public String getInternalLine3() {
        return internalLine3;
    }

    public void setInternalLine3(String internalLine3) {
        this.internalLine3 = internalLine3;
    }

    public String getInternalLine4() {
        return internalLine4;
    }

    public void setInternalLine4(String internalLine4) {
        this.internalLine4 = internalLine4;
    }

    public String getInternalLine5() {
        return internalLine5;
    }

    public void setInternalLine5(String internalLine5) {
        this.internalLine5 = internalLine5;
    }

    public String getInternalLine6() {
        return internalLine6;
    }

    public void setInternalLine6(String internalLine6) {
        this.internalLine6 = internalLine6;
    }

    public String getInternalLine7() {
        return internalLine7;
    }

    public void setInternalLine7(String internalLine7) {
        this.internalLine7 = internalLine7;
    }

    public String getMethodOfDispatch() {
        return methodOfDispatch;
    }

    public void setMethodOfDispatch(String methodOfDispatch) {
        this.methodOfDispatch = methodOfDispatch;
    }

    public String getPackingDate() {
        return packingDate;
    }

    public void setPackingDate(String packingDate) {
        this.packingDate = packingDate;
    }

    public String getCubic1() {
        return cubic1;
    }

    public void setCubic1(String cubic1) {
        this.cubic1 = cubic1;
    }

    public String getCubic2() {
        return cubic2;
    }

    public void setCubic2(String cubic2) {
        this.cubic2 = cubic2;
    }

    public String getCubic3() {
        return cubic3;
    }

    public void setCubic3(String cubic3) {
        this.cubic3 = cubic3;
    }

    public String getCubic4() {
        return cubic4;
    }

    public void setCubic4(String cubic4) {
        this.cubic4 = cubic4;
    }

    public String getCubic5() {
        return cubic5;
    }

    public void setCubic5(String cubic5) {
        this.cubic5 = cubic5;
    }

    public String getCubic6() {
        return cubic6;
    }

    public void setCubic6(String cubic6) {
        this.cubic6 = cubic6;
    }

    public String getCubic7() {
        return cubic7;
    }

    public void setCubic7(String cubic7) {
        this.cubic7 = cubic7;
    }

    public String getGrossMass1() {
        return grossMass1;
    }

    public void setGrossMass1(String grossMass1) {
        this.grossMass1 = grossMass1;
    }

    public String getGrossMass2() {
        return grossMass2;
    }

    public void setGrossMass2(String grossMass2) {
        this.grossMass2 = grossMass2;
    }

    public String getGrossMass3() {
        return grossMass3;
    }

    public void setGrossMass3(String grossMass3) {
        this.grossMass3 = grossMass3;
    }

    public String getGrossMass4() {
        return grossMass4;
    }

    public void setGrossMass4(String grossMass4) {
        this.grossMass4 = grossMass4;
    }

    public String getGrossMass5() {
        return grossMass5;
    }

    public void setGrossMass5(String grossMass5) {
        this.grossMass5 = grossMass5;
    }

    public String getGrossMass6() {
        return grossMass6;
    }

    public void setGrossMass6(String grossMass6) {
        this.grossMass6 = grossMass6;
    }

    public String getGrossMass7() {
        return grossMass7;
    }

    public void setGrossMass7(String grossMass7) {
        this.grossMass7 = grossMass7;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getIssuePlace() {
        return issuePlace;
    }

    public void setIssuePlace(String issuePlace) {
        this.issuePlace = issuePlace;
    }

    public String getMarks1() {
        return marks1;
    }

    public void setMarks1(String marks1) {
        this.marks1 = marks1;
    }

    public String getMarks2() {
        return marks2;
    }

    public void setMarks2(String marks2) {
        this.marks2 = marks2;
    }

    public String getMarks3() {
        return marks3;
    }

    public void setMarks3(String marks3) {
        this.marks3 = marks3;
    }

    public String getMarks4() {
        return marks4;
    }

    public void setMarks4(String marks4) {
        this.marks4 = marks4;
    }

    public String getMarks5() {
        return marks5;
    }

    public void setMarks5(String marks5) {
        this.marks5 = marks5;
    }

    public String getMarks6() {
        return marks6;
    }

    public void setMarks6(String marks6) {
        this.marks6 = marks6;
    }

    public String getMarks7() {
        return marks7;
    }

    public void setMarks7(String marks7) {
        this.marks7 = marks7;
    }

    public String getNameofAuthorizedSignatory() {
        return nameofAuthorizedSignatory;
    }

    public void setNameofAuthorizedSignatory(String nameofAuthorizedSignatory) {
        this.nameofAuthorizedSignatory = nameofAuthorizedSignatory;
    }

    public String getPckg1() {
        return pckg1;
    }

    public void setPckg1(String pckg1) {
        this.pckg1 = pckg1;
    }

    public String getPckg2() {
        return pckg2;
    }

    public void setPckg2(String pckg2) {
        this.pckg2 = pckg2;
    }

    public String getPckg3() {
        return pckg3;
    }

    public void setPckg3(String pckg3) {
        this.pckg3 = pckg3;
    }

    public String getPckg4() {
        return pckg4;
    }

    public void setPckg4(String pckg4) {
        this.pckg4 = pckg4;
    }

    public String getPckg5() {
        return pckg5;
    }

    public void setPckg5(String pckg5) {
        this.pckg5 = pckg5;
    }

    public String getPckg6() {
        return pckg6;
    }

    public void setPckg6(String pckg6) {
        this.pckg6 = pckg6;
    }

    public String getPckg7() {
        return pckg7;
    }

    public void setPckg7(String pckg7) {
        this.pckg7 = pckg7;
    }

    public String getSignatoryCompanyName() {
        return signatoryCompanyName;
    }

    public void setSignatoryCompanyName(String signatoryCompanyName) {
        this.signatoryCompanyName = signatoryCompanyName;
    }    
    
    public Integer getPageNo() {
        return pageNo;
    }
    
    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }
    
}