package docprep.src.reports;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.commons.beanutils.PropertyUtilsBean;

public class ReportUtil {

    private static PropertyUtilsBean propertyUtilsBean = new PropertyUtilsBean();

    public static String getMutatorCompatible(String name) {
        String str1 = name.substring(0, 1);
        String str2 = name.substring(1, name.length());
        return str1.toUpperCase().concat(str2);
    }

    private static PropertyUtilsBean getPropertyUtils() {
        return propertyUtilsBean;
    }

    public static Object getObject(Object returnObject, Object theObject) {
        Class theClass = theObject.getClass();
        Field[] theFields = theClass.getDeclaredFields();
        for (int i = 0; i < theFields.length; i++) {
            try {
                Class partypes[] = new Class[0];
                Method getMeth = theClass.getMethod("get" + getMutatorCompatible(theFields[i].getName()), partypes);
                Object arglist[] = new Object[0];
                Object getRetobj = getMeth.getName();
                if (getRetobj == null)
                    continue;

                setProperty(returnObject, theFields[i].getName(), getMeth.invoke(theObject, arglist));
            } catch (IllegalArgumentException e) {

            } catch (NoSuchMethodException e) {

            } catch (IllegalAccessException e) {

            } catch (InvocationTargetException e) {

            }
        }
        return returnObject;
    }
        
    public static Object getPreviousObject(Object returnObject, Object theObject) {
        Class theClass = theObject.getClass();
        Field[] theFields = theClass.getDeclaredFields();
        for (int i = 0; i < theFields.length; i++) {
            try {
                Class partypes[] = new Class[0];
                Method getMeth = theClass.getMethod("get" + getMutatorCompatible(theFields[i].getName()), partypes);
                Object arglist[] = new Object[0];
                Object getRetobj = getMeth.getName();
                if (getRetobj == null)
                    continue;

                setProperty(returnObject, theFields[i].getName() + "Previous", getMeth.invoke(theObject, arglist));
            } catch (IllegalArgumentException e) {

            } catch (NoSuchMethodException e) {

            } catch (IllegalAccessException e) {

            } catch (InvocationTargetException e) {

            }
        }
        return returnObject;
    }

    public static void setProperty(Object bean, String propName, Object value) throws IllegalAccessException, InvocationTargetException {
        try {
            getPropertyUtils().setProperty(bean, propName, value);
        } catch (NoSuchMethodException e) {
            return;
        }
    }

}
