package docprep.src.reports;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRAbstractBeanDataSourceProvider;
import net.sf.jasperreports.engine.data.JRBeanArrayDataSource;
import docprep.src.reports.dsio.PackingListDetailsDSIO;

public class PackingListDetailsDataSource extends JRAbstractBeanDataSourceProvider {

    private PackingListDetailsDSIO[] packingListDetailsDSIOs;

    public PackingListDetailsDataSource() {
        super(PackingListDetailsDSIO.class);
    }

    public PackingListDetailsDataSource(PackingListDetailsDSIO[] packingListDetailsDSIOs) {
        super(PackingListDetailsDSIO.class);
        this.packingListDetailsDSIOs = packingListDetailsDSIOs;
    }

    public JRDataSource create(JasperReport arg0) throws JRException {
    	PackingListDetailsDSIO[] printPartTo = new PackingListDetailsDSIO[1];
        if (packingListDetailsDSIOs != null) {
            printPartTo = new PackingListDetailsDSIO[packingListDetailsDSIOs.length];
            printPartTo = packingListDetailsDSIOs;
        } else {
            printPartTo = new PackingListDetailsDSIO[1];
            printPartTo = getSampleData();
        }
        return new JRBeanArrayDataSource(printPartTo);
    }

    private PackingListDetailsDSIO[] getSampleData() {
    	PackingListDetailsDSIO[] sampleToArray = new PackingListDetailsDSIO[1];
    	PackingListDetailsDSIO sampleTo = new PackingListDetailsDSIO();
        sampleTo.setCubicWeight("2422.25");
       
        return sampleToArray;
    }

    public void dispose(JRDataSource arg0) throws JRException {
    }

}
