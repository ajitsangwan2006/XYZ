package docprep.src.reports;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRAbstractBeanDataSourceProvider;
import net.sf.jasperreports.engine.data.JRBeanArrayDataSource;
import docprep.src.reports.dsio.PackingListDSIO;

public class PackingListDataSource extends JRAbstractBeanDataSourceProvider {
    private PackingListDSIO packingListDSIO ;

    public PackingListDataSource() {
        super(PackingListDSIO.class);

    }

    public PackingListDataSource(PackingListDSIO packingListDSIO) {
        super(PackingListDSIO.class);
        this.packingListDSIO = packingListDSIO;

    }

    public JRDataSource create(JasperReport report) throws JRException {
    	PackingListDSIO[] packingListDSIOs = new PackingListDSIO[1];
        if (packingListDSIO != null) {
        	packingListDSIOs[0] = packingListDSIO;
        } else {
        	packingListDSIOs[0] = getSampleData();
        }
        return new JRBeanArrayDataSource(packingListDSIOs);
    }

    private PackingListDSIO getSampleData() {
    	PackingListDSIO listDSIO = new PackingListDSIO();
        
    	
    	
        return listDSIO;
    }

    public void dispose(JRDataSource dataSource) throws JRException {

    }
}
