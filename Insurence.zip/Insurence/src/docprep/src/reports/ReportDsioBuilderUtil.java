package docprep.src.reports;

import java.lang.reflect.InvocationTargetException;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.dto.DerivedDocument;
import docprep.src.dto.ForwardingList;
import docprep.src.dto.MasterDocument;
import docprep.src.dto.PackageDetail;
import docprep.src.dto.PackingList;
import docprep.src.reports.dsio.ForwardingInstructionsDSIO;
import docprep.src.reports.dsio.PackingListDSIO;
import docprep.src.reports.dsio.PackingListDetailsDSIO;
import docprep.src.services.SystemUtil;

public class ReportDsioBuilderUtil {
    
    private MasterDocument masterDocument;
    
    private DerivedDocument derivedDocument;

    public ReportDsioBuilderUtil(MasterDocument masterDocument, DerivedDocument derivedDocument) {
        super();
        this.masterDocument = masterDocument;
        this.derivedDocument = derivedDocument;
    }
    
    public PackingListDSIO buildPackingListDSIO() throws InvalidArgumentException {
        PackingListDSIO dsioObject = new PackingListDSIO();
        
        PackingList packingList = (PackingList) derivedDocument.getBody();
        
        dsioObject.setPackingListDetailsDSIOs(buildPackingListDetails(packingList));
        return dsioObject;
    }  
    
    private PackingListDetailsDSIO[] buildPackingListDetails(PackingList packingList) throws InvalidArgumentException {  
        PackingListDetailsDSIO[] packingListDetailsDSIOs = null;
        if(packingList.getPackingListItemDetails() != null && packingList.getPackingListItemDetails().length > 0) {
            packingListDetailsDSIOs = new PackingListDetailsDSIO[packingList.getPackingListItemDetails().length];
            for(int x = 0; x < packingList.getPackingListItemDetails().length; x++) {
                PackingListDetailsDSIO packingListDetailsDSIO = new PackingListDetailsDSIO();
                packingListDetailsDSIO = (PackingListDetailsDSIO)ReportUtil.getObject(packingListDetailsDSIO, packingList.getPackingListItemDetails()[x]); 
                packingListDetailsDSIO.setLineNumber(packingList.getPackingListItemDetails()[x].getId().getLineNumber());
                packingListDetailsDSIO.setQuantity(SystemUtil.getCommifiedValue(packingListDetailsDSIO.getQuantity()));
                packingListDetailsDSIO = getPackingListDetailsDSIO(packingListDetailsDSIO, packingList);
                packingListDetailsDSIOs[x] = packingListDetailsDSIO;                
            }  
        } else {
            packingListDetailsDSIOs = new PackingListDetailsDSIO[1];
            PackingListDetailsDSIO packingListDetailsDSIO = new PackingListDetailsDSIO();
            packingListDetailsDSIO = getPackingListDetailsDSIO(packingListDetailsDSIO, packingList);
            packingListDetailsDSIOs[0] = packingListDetailsDSIO;  
        }
        return packingListDetailsDSIOs;
    }
    
    private PackingListDetailsDSIO getPackingListDetailsDSIO(PackingListDetailsDSIO packingListDetailsDSIO, PackingList packingList) {
        packingListDetailsDSIO = (PackingListDetailsDSIO) ReportUtil.getObject(packingListDetailsDSIO, packingList);
        packingListDetailsDSIO = (PackingListDetailsDSIO) ReportUtil.getObject(packingListDetailsDSIO, masterDocument);
        packingListDetailsDSIO = buildPackingListDetailsDSIO(packingListDetailsDSIO);
        return packingListDetailsDSIO;
    }
    
    private PackingListDetailsDSIO buildPackingListDetailsDSIO(PackingListDetailsDSIO dsioObject) {        
        dsioObject = buildDefaultPackingListDetailsDSIO(dsioObject);
        PackageDetail[] packageDetails = masterDocument.getPackageDetails();
        if(packageDetails != null && packageDetails.length > 0) {
            for(int x = 0; x < packageDetails.length; x++) {
                try {
                    ReportUtil.setProperty(dsioObject, "marks"+(x+1), packageDetails[x].getMarks() != null ? packageDetails[x].getMarks() : " ");
                    ReportUtil.setProperty(dsioObject, "pckg"+(x+1), packageDetails[x].getPckg() != null ? packageDetails[x].getPckg() : " ");
                    ReportUtil.setProperty(dsioObject, "grossMass"+(x+1), packageDetails[x].getGrossMass() != null ? packageDetails[x].getGrossMass() : " ");
                    ReportUtil.setProperty(dsioObject, "cubic"+(x+1), packageDetails[x].getCubic() != null ? packageDetails[x].getCubic() : " ");
                } catch (IllegalAccessException e) {                    
                } catch (InvocationTargetException e) {                    
                }
            }
        }
        return dsioObject;
    }
    
    private PackingListDetailsDSIO buildDefaultPackingListDetailsDSIO(PackingListDetailsDSIO dsioObject) {
        for(int x = 0; x < 7; x++) {
            try {
                ReportUtil.setProperty(dsioObject, "marks"+(x+1), " ");
                ReportUtil.setProperty(dsioObject, "pckg"+(x+1), " ");
                ReportUtil.setProperty(dsioObject, "grossMass"+(x+1), " ");
                ReportUtil.setProperty(dsioObject, "cubic"+(x+1), " ");
            } catch (IllegalAccessException e) {                
            } catch (InvocationTargetException e) {                
            }
        }        
        return dsioObject;
    }
    
    public ForwardingInstructionsDSIO buildForwardingInstructionsDSIO() throws InvalidArgumentException {
        ForwardingInstructionsDSIO dsioObject = new ForwardingInstructionsDSIO();        
        ForwardingList forwardingList = (ForwardingList) derivedDocument.getBody();  
        dsioObject = (ForwardingInstructionsDSIO) ReportUtil.getObject(dsioObject, forwardingList);        
        return dsioObject;
    }
}
