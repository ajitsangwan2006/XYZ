package docprep.src.reports.interfaces;

import dev.zing.framework.services.exception.application.bto.InvalidArgumentException;
import docprep.src.reports.dsio.ForwardingInstructionsDSIO;
import docprep.src.reports.dsio.PackingListDSIO;

public interface DocumentPrint {

    public byte[] getPackingListBytes(PackingListDSIO packingListDSIO) throws InvalidArgumentException;
    
    public byte[] getForwardingInstructionBytes(ForwardingInstructionsDSIO forwardingInstructionsDSIO) throws InvalidArgumentException;
    
}
