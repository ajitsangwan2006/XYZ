package docprep.src.listhelper;
import java.util.Date;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;


public class ReportCriteriaListHelper extends ListHelperImpl {

	// Fields    

	private String siteId;

	private String userId;

	private String reportId;
	
	private String transactionIdfrom;

	private String transactionIdto;

	private Date invoiceDateFrom;

	private Date invoiceDateTo;

	private String exporterReferenceFrom;

	private String exporterReferenceTo;

	
	public String getExporterReferenceFrom() {
		return exporterReferenceFrom;
	}
	public void setExporterReferenceFrom(String exporterReferenceFrom) {
		this.exporterReferenceFrom = exporterReferenceFrom;
	}
	public String getExporterReferenceTo() {
		return exporterReferenceTo;
	}
	public void setExporterReferenceTo(String exporterReferenceTo) {
		this.exporterReferenceTo = exporterReferenceTo;
	}
	public Date getInvoiceDateFrom() {
		return invoiceDateFrom;
	}
	public void setInvoiceDateFrom(Date invoiceDateFrom) {
		this.invoiceDateFrom = invoiceDateFrom;
	}
	public Date getInvoiceDateTo() {
		return invoiceDateTo;
	}
	public void setInvoiceDateTo(Date invoiceDateTo) {
		this.invoiceDateTo = invoiceDateTo;
	}
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getTransactionIdfrom() {
		return transactionIdfrom;
	}
	public void setTransactionIdfrom(String transactionIdfrom) {
		this.transactionIdfrom = transactionIdfrom;
	}
	public String getTransactionIdto() {
		return transactionIdto;
	}
	public void setTransactionIdto(String transactionIdto) {
		this.transactionIdto = transactionIdto;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
