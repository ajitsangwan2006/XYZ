package docprep.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class DefaultSetupListHelper extends ListHelperImpl {

	private String siteId;

	private String userId;
	
	private String exporterCountryCode;

	private String country;

	private String transferExportname;

	private String exporterName;
	
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getExporterCountryCode() {
		return exporterCountryCode;
	}
	public void setExporterCountryCode(String exporterCountryCode) {
		this.exporterCountryCode = exporterCountryCode;
	}
	public String getExporterName() {
		return exporterName;
	}
	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getTransferExportname() {
		return transferExportname;
	}
	public void setTransferExportname(String transferExportname) {
		this.transferExportname = transferExportname;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
