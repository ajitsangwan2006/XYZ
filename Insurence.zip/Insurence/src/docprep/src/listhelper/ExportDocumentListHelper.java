package docprep.src.listhelper;

import java.util.Date;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ExportDocumentListHelper extends ListHelperImpl {

    private Long sysDocId;

    private String docId;

    private String siteId;

    private String userId;

    private Long parentId;

    private String docTypeCode;

    private Integer docTypeVersion;

    private String exporterReference;

    private Integer status;

    private String lastUpdateDate;

    private String invoiceDate;

    private Integer formTemplateCode;

    private Integer sendToFreightForwarder;

    private String buyerName;

    private String invoiceNumber;

    private Date invoiceDateTo;

    private String dateBoundry;

    private String edn;

    private String buyerReference;

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocTypeCode() {
        return docTypeCode;
    }

    public void setDocTypeCode(String docTypeCode) {
        this.docTypeCode = docTypeCode;
    }

    public Integer getDocTypeVersion() {
        return docTypeVersion;
    }

    public void setDocTypeVersion(Integer docTypeVersion) {
        this.docTypeVersion = docTypeVersion;
    }

    public String getExporterReference() {
        return exporterReference;
    }

    public void setExporterReference(String exporterReference) {
        this.exporterReference = exporterReference;
    }

    public Integer getFormTemplateCode() {
        return formTemplateCode;
    }

    public void setFormTemplateCode(Integer formTemplateCode) {
        this.formTemplateCode = formTemplateCode;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Integer getSendToFreightForwarder() {
        return sendToFreightForwarder;
    }

    public void setSendToFreightForwarder(Integer sendToFreightForwarder) {
        this.sendToFreightForwarder = sendToFreightForwarder;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getSysDocId() {
        return sysDocId;
    }

    public void setSysDocId(Long sysDocId) {
        this.sysDocId = sysDocId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Date getInvoiceDateTo() {
        return invoiceDateTo;
    }

    public void setInvoiceDateTo(Date invoiceDateTo) {
        this.invoiceDateTo = invoiceDateTo;
    }

    public String getDateBoundry() {
        return dateBoundry;
    }

    public void setDateBoundry(String dateBoundry) {
        this.dateBoundry = dateBoundry;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getBuyerReference() {
        return buyerReference;
    }

    public void setBuyerReference(String buyerReference) {
        this.buyerReference = buyerReference;
    }

    public String getEdn() {
        return edn;
    }

    public void setEdn(String edn) {
        this.edn = edn;
    }
}