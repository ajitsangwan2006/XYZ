package docprep.src.listhelper;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ItemDetailListHelper extends ListHelperImpl {
	
	private Long sysDocId;
	
	private Integer packingListId;

	public Integer getPackingListId() {
		return packingListId;
	}
	public void setPackingListId(Integer packingListId) {
		this.packingListId = packingListId;
	}
	public Long getSysDocId() {
		return sysDocId;
	}
	public void setSysDocId(Long sysDocId) {
		this.sysDocId = sysDocId;
	}
}
