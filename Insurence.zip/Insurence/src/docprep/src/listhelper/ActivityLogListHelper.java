package docprep.src.listhelper;

import java.util.Date;

import dev.zing.framework.businesstier.listhelper.ListHelperImpl;

public class ActivityLogListHelper extends ListHelperImpl {

    private String selUserId;

    private String selDateBoundry;

    private String selSiteId;

    private Date selActivityDate;

    private Date selActivityDateTo;

    private String selActivityType;    

	public Date getSelActivityDate() {
		return selActivityDate;
	}
	public void setSelActivityDate(Date selActivityDate) {
		this.selActivityDate = selActivityDate;
	}
	public Date getSelActivityDateTo() {
		return selActivityDateTo;
	}
	public void setSelActivityDateTo(Date selActivityDateTo) {
		this.selActivityDateTo = selActivityDateTo;
	}
	public String getSelActivityType() {
		return selActivityType;
	}
	public void setSelActivityType(String selActivityType) {
		this.selActivityType = selActivityType;
	}
	public String getSelDateBoundry() {
		return selDateBoundry;
	}
	public void setSelDateBoundry(String selDateBoundry) {
		this.selDateBoundry = selDateBoundry;
	}
	public String getSelSiteId() {
		return selSiteId;
	}
	public void setSelSiteId(String selSiteId) {
		this.selSiteId = selSiteId;
	}
	public String getSelUserId() {
		return selUserId;
	}
	public void setSelUserId(String selUserId) {
		this.selUserId = selUserId;
	}
}